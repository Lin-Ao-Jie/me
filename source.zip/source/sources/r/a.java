package r;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static float f2112a = 230.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static float f2113b = 27.0f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static float f2114c = 1.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    static int f2115d = 180000;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    static int f2116e = 2300;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    static int f2117f = 12000;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    static long f2118g = 700;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    static float f2119h = 1.5f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    static float f2120i = 2.0f;
}
