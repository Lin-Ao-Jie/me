package r;

import android.content.Context;
import android.os.SystemClock;
import android.view.ViewConfiguration;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import java.lang.ref.SoftReference;
import java.lang.reflect.Method;
import p.c;
import p.d;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static int f2121l = 24000;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private static int f2122m = 30000;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static boolean f2123n = true;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static boolean f2124o = true;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private static int f2125p = r.a.f2115d;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private static int f2126q = 25;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private static int f2127r = 5;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private static int f2128s = 1;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private static int f2129t = 16;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected static boolean f2130u = true;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private static Object f2131v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static Method f2132w;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final a f2133a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final a f2134b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final boolean f2135c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f2136d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private Interpolator f2137e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private long f2138f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f2139g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f2140h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Context f2141i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private SoftReference f2142j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final Object f2143k;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {
        protected static final float L;
        protected static final float M;
        protected static final float N;
        protected static final float O;
        protected static final float P;
        protected static final float Q;
        protected static final float R;
        protected static final float S;
        protected static final float T;
        protected static final float U;
        protected static final float V;
        protected static final float W;
        protected static final float X;
        protected static final float Y;
        private static c Z;

        /* JADX INFO: renamed from: a0, reason: collision with root package name */
        private static c f2144a0;

        /* JADX INFO: renamed from: b0, reason: collision with root package name */
        private static c f2145b0;

        /* JADX INFO: renamed from: c0, reason: collision with root package name */
        private static c f2146c0;

        /* JADX INFO: renamed from: d0, reason: collision with root package name */
        private static c f2147d0;

        /* JADX INFO: renamed from: e0, reason: collision with root package name */
        private static float f2148e0;

        /* JADX INFO: renamed from: f0, reason: collision with root package name */
        private static float f2149f0;

        /* JADX INFO: renamed from: g0, reason: collision with root package name */
        private static c f2150g0;

        /* JADX INFO: renamed from: h0, reason: collision with root package name */
        private static c f2151h0;

        /* JADX INFO: renamed from: i0, reason: collision with root package name */
        private static float f2152i0;

        /* JADX INFO: renamed from: j0, reason: collision with root package name */
        private static float f2153j0;

        /* JADX INFO: renamed from: k0, reason: collision with root package name */
        private static c f2154k0;

        /* JADX INFO: renamed from: l0, reason: collision with root package name */
        private static double f2155l0;

        /* JADX INFO: renamed from: m0, reason: collision with root package name */
        private static float f2156m0;
        private float A;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f2157a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f2158b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f2159c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private float f2163g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private int f2164h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private int f2165i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private int f2166j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private float f2167k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        private float f2168l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        private long f2169m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private int f2170n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        private boolean f2171o;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        private p.b f2175s;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        private q.b f2176t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        private q.a f2177u;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        private SoftReference f2180x;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        private int f2181y;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        private int f2182z;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private long f2160d = 0;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private boolean f2161e = true;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private boolean f2162f = false;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        private int f2172p = 1000;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        private float f2173q = ViewConfiguration.getScrollFriction();

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        private int f2174r = 0;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        private int f2178v = Integer.MAX_VALUE;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        private int f2179w = 0;
        private Interpolator B = new DecelerateInterpolator();
        private int C = -1;
        private int D = -1;
        private double E = 2000.0d;
        private c F = new c(0.0d, 2.0d);
        private long G = 0;
        private long H = 0;
        private long I = 0;
        private boolean J = true;
        private d K = new C0023a();

        /* JADX INFO: renamed from: r.b$a$a, reason: collision with other inner class name */
        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class C0023a extends p.a {
            C0023a() {
            }

            @Override // p.d
            public void d(p.b bVar) {
                a.this.f2168l = (float) bVar.g();
                if (Math.signum(a.this.f2168l) != Math.signum(a.this.f2163g)) {
                    a.this.f2175s.w(a.f2144a0);
                    t.a.a("ReboundOverScroller", "When velocity begin reverse.");
                    a aVar = a.this;
                    aVar.f2163g = aVar.f2168l;
                    a.this.f2175s.l();
                }
            }
        }

        /* JADX INFO: renamed from: r.b$a$b, reason: collision with other inner class name */
        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class C0024b extends p.a {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ int f2184a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ int f2185b;

            C0024b(int i2, int i3) {
                this.f2184a = i2;
                this.f2185b = i3;
            }

            @Override // p.d
            public void d(p.b bVar) {
                int iRound = (int) Math.round(bVar.c());
                if ((this.f2184a <= this.f2185b || iRound >= a.this.f2158b) && (this.f2184a >= this.f2185b || iRound <= a.this.f2158b)) {
                    return;
                }
                a.this.f2175s.w(a.f2151h0);
                a.this.f2175s.q(a.this.f2159c);
                a.this.f2175s.l();
                t.a.c("ReboundOverScroller", "startSpringback startRelay2, friction = " + a.f2151h0.f2020a + ", tension = " + a.f2151h0.f2021b);
                a.this.f2160d = SystemClock.elapsedRealtime();
            }
        }

        static {
            float fT = b.t("test_bounceconfig_tension", 120.0f);
            L = fT;
            float fT2 = b.t("test_bounceconfig_friction", 26.0f);
            M = fT2;
            float fT3 = b.t("test_bounceendconfig_tension", 260.0f);
            N = fT3;
            float fT4 = b.t("test_bounceendconfig_friction", 45.0f);
            O = fT4;
            float fT5 = b.t("test_cubicconfig_tension", 176.0f);
            P = fT5;
            float fT6 = b.t("test_cubicconfig_friction", 26.0f);
            Q = fT6;
            float fT7 = b.t("test_scroll_config_tension", 15.5f);
            R = fT7;
            float fT8 = b.t("test_scroll_config_friction", 8.0f);
            S = fT8;
            float fT9 = b.t("test_cubic_relay_config1_tension", 600.0f);
            T = fT9;
            float fT10 = b.t("test_cubic_relay_config1_friction", 56.0f);
            U = fT10;
            float fT11 = b.t("test_cubic_relay_config2_tension", 196.0f);
            V = fT11;
            float fT12 = b.t("test_cubic_relay_config2_friction", 28.0f);
            W = fT12;
            float fT13 = b.t("test_scroll_config_tension_rebound", r.a.f2112a);
            X = fT13;
            float fT14 = b.t("test_scroll_config_friction_rebound", r.a.f2113b);
            Y = fT14;
            Z = new c(fT, fT2);
            f2144a0 = new c(fT3, fT4);
            f2145b0 = new c(fT5, fT6);
            f2146c0 = new c(fT7, fT8);
            f2147d0 = new c(0.0d, 2.0d);
            f2148e0 = 0.9f;
            f2149f0 = 0.7f;
            f2150g0 = new c(fT9, fT10);
            f2151h0 = new c(fT11, fT12);
            f2152i0 = 0.5f;
            f2153j0 = 10.0f;
            f2154k0 = new c(fT13, fT14);
            f2155l0 = 1.0d;
            f2156m0 = (float) (Math.log(0.78d) / Math.log(0.9d));
        }

        a(Context context) {
            p.b bVar = new p.b();
            this.f2175s = bVar;
            bVar.n(context);
            this.f2176t = new q.b(context);
            this.f2177u = new q.a();
            this.f2171o = true;
            this.A = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        }

        private void E(int i2, int i3, int i4) {
            t.a.c("ReboundOverScroller", "start bound back , tension=" + Z.f2021b + " , friction=" + Z.f2020a + " , endtension=" + f2144a0.f2021b + " , endfriction=" + f2144a0.f2020a);
            this.f2171o = false;
            float f2 = (float) i4;
            this.f2167k = f2;
            this.f2168l = f2;
            this.f2174r = 1;
            this.f2164h = i2;
            this.f2165i = i2;
            this.f2166j = i3;
            this.f2169m = b.r();
            this.f2175s.w(Z);
            this.f2175s.o(i2);
            int i5 = (int) (((double) i4) * f2155l0);
            this.f2175s.x(i5);
            this.f2175s.t(true);
            p.b bVar = this.f2175s;
            int i6 = this.C;
            bVar.u(i6 > 0 ? i6 : f2152i0);
            p.b bVar2 = this.f2175s;
            int i7 = this.D;
            bVar2.v(i7 > 0 ? i7 : f2153j0);
            this.f2175s.q(i3);
            this.f2175s.l();
            this.f2175s.a(this.K);
            q.b bVar3 = this.f2176t;
            float f3 = i2;
            float f4 = i3;
            c cVar = Z;
            int i8 = this.C;
            float f5 = i8 > 0 ? i8 : f2152i0;
            int i9 = this.D;
            bVar3.j(f3, f4, i5, cVar, f5, i9 > 0 ? i9 : f2153j0);
            this.f2170n = (int) this.f2176t.f();
        }

        private void F(int i2, int i3, int i4) {
            t.a.a("ReboundOverScroller", "start flingSnap back");
            this.f2171o = false;
            float f2 = i4;
            this.f2167k = f2;
            this.f2168l = f2;
            this.f2174r = 1;
            this.f2164h = i2;
            this.f2165i = i2;
            this.f2166j = i3;
            this.f2169m = SystemClock.uptimeMillis();
            this.f2175s.w(f2154k0);
            t.a.a("ReboundOverScroller", "mCubicConfig:" + f2154k0.f2021b + " / " + f2154k0.f2020a);
            this.f2175s.o((double) i2);
            int i5 = (int) (((double) i4) * f2155l0);
            this.f2175s.x((double) i5);
            this.f2175s.t(true);
            p.b bVar = this.f2175s;
            int i6 = this.C;
            if (i6 <= 0) {
                i6 = b.f2127r;
            }
            bVar.u(i6);
            p.b bVar2 = this.f2175s;
            int i7 = this.D;
            if (i7 <= 0) {
                i7 = b.f2126q;
            }
            bVar2.v(i7);
            this.f2175s.q(i3);
            q.b bVar3 = this.f2176t;
            float f3 = i2;
            float f4 = i3;
            c cVar = f2154k0;
            int i8 = this.C;
            if (i8 <= 0) {
                i8 = b.f2127r;
            }
            float f5 = i8;
            int i9 = this.D;
            if (i9 <= 0) {
                i9 = b.f2126q;
            }
            bVar3.j(f3, f4, i5, cVar, f5, i9);
            this.f2170n = (int) this.f2176t.f();
        }

        private void G(int i2, int i3, int i4) {
            t.a.c("ReboundOverScroller", "startSpringback Cubic back");
            float f2 = i3 - i2;
            this.f2157a = ((int) (f2148e0 * f2)) + i2;
            this.f2158b = ((int) (f2149f0 * f2)) + i2;
            this.f2159c = i3;
            this.f2171o = false;
            float f3 = i4;
            this.f2167k = f3;
            this.f2168l = f3;
            this.f2174r = 1;
            this.f2164h = i2;
            this.f2165i = i2;
            this.f2166j = i3;
            this.f2169m = b.r();
            this.f2175s.w(f2150g0);
            t.a.c("ReboundOverScroller", "startSpringback startRelay1, friction = " + f2150g0.f2020a + ", tension = " + f2150g0.f2021b);
            this.f2175s.o((double) i2);
            int i5 = (int) (((double) i4) * f2155l0);
            this.f2175s.x((double) i5);
            this.f2175s.t(true);
            p.b bVar = this.f2175s;
            int i6 = this.C;
            bVar.u(i6 > 0 ? i6 : f2152i0);
            p.b bVar2 = this.f2175s;
            int i7 = this.D;
            bVar2.v(i7 > 0 ? i7 : f2153j0);
            this.f2175s.q(this.f2157a);
            this.f2175s.l();
            this.f2175s.a(new C0024b(i2, i3));
            q.b bVar3 = this.f2176t;
            float f4 = i2;
            float f5 = i3;
            c cVar = f2145b0;
            int i8 = this.C;
            float f6 = i8 > 0 ? i8 : f2152i0;
            int i9 = this.D;
            bVar3.j(f4, f5, i5, cVar, f6, i9 > 0 ? i9 : f2153j0);
            this.f2170n = (int) this.f2176t.f();
        }

        private void H(int i2, int i3, int i4) {
            t.a.a("ReboundOverScroller", "start water back");
            this.f2171o = false;
            float f2 = i4;
            this.f2167k = f2;
            this.f2168l = f2;
            this.f2174r = 1;
            this.f2164h = i2;
            this.f2165i = i2;
            this.f2166j = i3;
            this.f2169m = b.r();
            this.f2175s.w(f2145b0);
            t.a.a("ReboundOverScroller", "mCubicConfig:" + f2145b0.f2021b + " / " + f2145b0.f2020a);
            this.f2175s.o((double) i2);
            int i5 = (int) (((double) i4) * f2155l0);
            this.f2175s.x((double) i5);
            this.f2175s.t(true);
            p.b bVar = this.f2175s;
            int i6 = this.C;
            if (i6 <= 0) {
                i6 = b.f2127r;
            }
            bVar.u(i6);
            p.b bVar2 = this.f2175s;
            int i7 = this.D;
            if (i7 <= 0) {
                i7 = b.f2126q;
            }
            bVar2.v(i7);
            this.f2175s.q(i3);
            q.b bVar3 = this.f2176t;
            float f3 = i2;
            float f4 = i3;
            c cVar = f2145b0;
            int i8 = this.C;
            if (i8 <= 0) {
                i8 = b.f2127r;
            }
            float f5 = i8;
            int i9 = this.D;
            if (i9 <= 0) {
                i9 = b.f2126q;
            }
            bVar3.j(f3, f4, i5, cVar, f5, i9);
            this.f2170n = (int) this.f2176t.f();
        }

        private float w(double d2) {
            return (float) (((d2 - this.E) * (-6.0E-4d)) + f2147d0.f2020a);
        }

        void A(int i2) {
            this.C = i2;
        }

        void B(int i2) {
            this.D = i2;
        }

        boolean C(int i2, int i3, int i4) {
            this.f2171o = true;
            this.f2166j = i2;
            this.f2164h = i2;
            this.f2167k = 0.0f;
            this.f2170n = 0;
            if (i2 < i3) {
                G(i2, i3, 0);
            } else if (i2 > i4) {
                G(i2, i4, 0);
            }
            return !this.f2171o;
        }

        boolean D(int i2, int i3, int i4, int i5) {
            this.f2166j = i2;
            this.f2164h = i2;
            this.f2167k = i4;
            this.f2170n = 0;
            if (i5 == 0) {
                H(i2, i3, i4);
            } else if (i5 == 1) {
                G(i2, i3, i4);
            } else if (i5 == 2) {
                E(i2, i3, i4);
            } else if (i5 == 3) {
                F(i2, i3, i4);
            }
            return !this.f2171o;
        }

        /* JADX WARN: Code duplicated, block: B:32:0x0078  */
        /* JADX WARN: Instruction removed from duplicated block: B:32:0x0078, please report this as an issue */
        boolean I() {
            long jR = b.r();
            long j2 = this.f2169m;
            long j3 = jR - j2;
            if (this.f2174r == 4) {
                long j4 = jR - j2;
                int i2 = this.f2170n;
                if (j4 >= i2) {
                    u();
                    return false;
                }
                float interpolation = this.B.getInterpolation(j4 / i2);
                if (!this.f2171o) {
                    J(interpolation);
                }
                return true;
            }
            if (b.f2131v != null) {
                long jF = o.b.f(this.f2169m, jR);
                if (jF >= 0) {
                    j3 = jF;
                }
            }
            long j5 = j3 - this.I;
            if (j5 < 0) {
                j5 = this.G;
            }
            this.G = j5;
            this.I = j3;
            if (this.J) {
                int i3 = b.f2129t;
                long j6 = this.G;
                if (j6 <= 0 || i3 <= 0) {
                    t.a.c("ReboundOverScroller", "update, disable smooth deltatime = " + this.G + " mState = " + this.f2174r);
                } else {
                    double d2 = i3;
                    if (j6 > 1.5d * d2 || j6 <= d2 * 0.5d) {
                        t.a.c("ReboundOverScroller", "update, disable smooth deltatime = " + this.G + " mState = " + this.f2174r);
                    } else if (b.f2130u) {
                        this.G = i3;
                    }
                }
            }
            this.f2175s.b(this.G / 1000.0d);
            float fG = (float) this.f2175s.g();
            this.f2168l = fG;
            this.f2167k = fG;
            t.a.a("test_log >>", "UPDATE : mVelocity=" + this.f2167k);
            int i4 = this.f2174r;
            if (i4 == 0) {
                if (this.f2161e && !this.f2162f) {
                    double d3 = this.f2175s.d();
                    if (Math.abs(d3) <= this.E) {
                        this.F.f2020a = w(Math.abs(d3));
                        this.f2175s.w(this.F);
                    }
                }
                int i5 = this.f2165i;
                this.f2165i = (int) Math.round(this.f2175s.c());
                if (b.f2131v != null) {
                    double d4 = this.f2165i - i5;
                    long j7 = this.G;
                    o.b.b(this.f2168l, d4, j7 > 0 ? (float) (d4 / ((double) (j7 / 1000.0f))) : 0.0f);
                }
                if (!t() && this.f2175s.i()) {
                    this.f2166j = this.f2165i;
                }
                t.a.a("test_log >>", "SPLINE : mCurrentPosition=" + this.f2165i);
                return !this.f2175s.i();
            }
            if (i4 == 1) {
                this.f2165i = (int) Math.round(this.f2175s.c());
                t.a.a("test_log >>", "CUBIC : mCurrentPosition=" + this.f2165i);
                if (!this.f2175s.i()) {
                    return true;
                }
                t.a.a("ReboundOverScroller", "case CUBIC : spring is reset. deltaTime:" + (SystemClock.elapsedRealtime() - this.f2160d));
                this.f2165i = 0;
                if (!this.f2175s.i()) {
                    this.f2175s.m();
                }
                return false;
            }
            if (i4 != 3) {
                return true;
            }
            this.f2165i = (int) Math.round(this.f2175s.c());
            t.a.a("test_log >>", "BOUNCE : mCurrentPosition=" + this.f2165i);
            if (y()) {
                t.a.b("ReboundOverScroller", "case BOUNCE : current position is too over, rest current spring");
                if (!this.f2175s.i()) {
                    this.f2175s.m();
                }
                int i6 = this.f2165i;
                int i7 = this.f2179w;
                if (i6 < i7) {
                    int i8 = i7 - this.f2172p;
                    this.f2165i = i8;
                    C(i8, i7, this.f2178v);
                } else {
                    int i9 = this.f2178v;
                    if (i6 > i9) {
                        int i10 = this.f2172p + i9;
                        this.f2165i = i10;
                        C(i10, i7, i9);
                    }
                }
            }
            if (!this.f2175s.i() || this.f2175s.j()) {
                return true;
            }
            t.a.a("ReboundOverScroller", "case BOUNCE : spring is reset");
            this.f2165i = 0;
            if (!this.f2175s.i()) {
                this.f2175s.m();
            }
            return false;
        }

        void J(float f2) {
            int i2 = this.f2164h;
            this.f2165i = i2 + Math.round(f2 * (this.f2166j - i2));
        }

        boolean t() {
            if (this.f2174r != 0) {
                return false;
            }
            int i2 = this.f2165i;
            if (i2 >= this.f2179w && (i2 <= this.f2178v || this.f2167k == 0.0f)) {
                return false;
            }
            t.a.a("ReboundOverScroller", "over fling need to spring back");
            SoftReference softReference = this.f2180x;
            if (softReference != null && softReference.get() != null) {
                b.c.a(this.f2180x.get());
                throw null;
            }
            t.a.a("ReboundOverScroller", "mOverflingMinRange=" + this.f2179w + " , mOverflingMaxRange=" + this.f2178v + " , mCurrentPosition=" + this.f2165i + " , mOver=" + this.f2172p);
            int i3 = this.f2178v;
            int i4 = this.f2172p;
            int i5 = i3 + i4;
            int i6 = this.f2165i;
            int i7 = this.f2179w;
            if (i6 < i7) {
                if (i6 > i5) {
                    x(i5, i7, i4);
                } else {
                    x(i6, i7, i4);
                }
            }
            int i8 = this.f2165i;
            int i9 = this.f2178v;
            if (i8 <= i9) {
                return true;
            }
            if (i8 > i5) {
                x(i5, i9, this.f2172p);
                return true;
            }
            x(i8, i9, this.f2172p);
            return true;
        }

        void u() {
            this.f2165i = this.f2166j;
            this.f2171o = true;
            this.f2175s.m();
        }

        void v(int i2, int i3, int i4, int i5, int i6) {
            double dAbs;
            t.a.c("ReboundOverScroller", "start fling");
            int i7 = (int) (((double) i3) * f2155l0);
            this.f2172p = i6;
            this.f2171o = false;
            float f2 = i7;
            this.f2167k = f2;
            this.f2168l = f2;
            this.f2170n = 0;
            this.f2164h = i2;
            this.f2165i = i2;
            if (i2 > i5 || i2 < i4) {
                if (i2 > i5) {
                    i4 = i5;
                }
                G(i2, i4, i7);
                return;
            }
            this.f2178v = i5;
            this.f2179w = i4;
            this.f2174r = 0;
            this.f2169m = b.r();
            if (b.f2131v != null) {
                o.b.e(this.f2169m * 1000000);
            }
            q.a aVar = this.f2177u;
            float f3 = i2;
            int i8 = this.D;
            if (i8 <= 0) {
                i8 = b.f2126q;
            }
            aVar.g(f3, f2, i8, (float) f2147d0.f2020a);
            t.a.a("ReboundOverScroller", "fling mFlingConfig==================");
            if (i7 != 0) {
                int iB = (int) this.f2177u.b();
                this.f2182z = iB;
                this.f2170n = iB;
                dAbs = Math.abs(this.f2177u.a());
                t.a.a("ReboundOverScroller", "EstimatedDuration=" + this.f2170n + " , EstimatedDistance=" + dAbs);
            } else {
                dAbs = 0.0d;
            }
            int iSignum = (int) (dAbs * ((double) Math.signum(f2)));
            this.f2181y = iSignum;
            int i9 = iSignum + i2;
            this.f2166j = i9;
            if (i9 < i4) {
                this.f2166j = i4;
            }
            if (this.f2166j > i5) {
                this.f2166j = i5;
            }
            this.f2169m = b.r();
            this.f2175s.o(i2);
            this.f2175s.x(i7);
            this.f2175s.w(f2147d0);
            this.f2175s.l();
            this.f2175s.t(true);
            p.b bVar = this.f2175s;
            int i10 = this.D;
            if (i10 <= 0) {
                i10 = b.f2126q;
            }
            bVar.v(i10);
            p.b bVar2 = this.f2175s;
            int i11 = this.C;
            if (i11 <= 0) {
                i11 = b.f2127r;
            }
            bVar2.u(i11);
            t.a.a("ReboundOverScroller", "sRestThresholdVelocity=" + b.f2126q + " , mRestDisplacementThreshold=" + this.C);
            this.f2175s.q(i2 >= i5 ? i4 : i5);
            this.f2162f = false;
        }

        void x(int i2, int i3, int i4) {
            t.a.a("ReboundOverScroller", "start notify edge reached. mState=" + this.f2174r);
            int i5 = this.f2174r;
            if (i5 != 0) {
                if (i5 == 4) {
                    this.f2165i = 0;
                    this.f2166j = 0;
                    this.f2171o = true;
                    return;
                }
                return;
            }
            this.f2172p = i4;
            float fG = (float) this.f2175s.g();
            t.a.c("ReboundOverScroller", "notifyEdgeReached, start bounce, tension = " + Z.f2021b + ", friction = " + Z.f2020a);
            this.f2163g = fG;
            this.f2175s.w(Z);
            this.f2174r = 3;
            this.f2164h = i2;
            this.f2169m = b.r();
            this.f2175s.o(i2);
            this.f2175s.x(fG);
            this.f2175s.t(true);
            this.f2175s.l();
            this.f2175s.a(this.K);
            this.f2175s.u(f2152i0);
            this.f2175s.v(f2153j0);
            this.f2175s.q(i3);
            this.f2166j = i3;
        }

        protected boolean y() {
            t.a.a("ReboundOverScroller", "overScrollBy, mCurrentPosition = " + this.f2165i + ", mOver = " + this.f2172p + ", mFlingMaxRange = " + this.f2178v);
            int i2 = this.f2165i;
            int i3 = this.f2172p;
            return i2 > this.f2178v + i3 || i2 < this.f2179w - i3;
        }

        public void z(boolean z2) {
            this.f2161e = z2;
        }
    }

    /* JADX INFO: renamed from: r.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class InterpolatorC0025b implements Interpolator {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static final float f2187a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private static final float f2188b;

        static {
            float fA = 1.0f / a(1.0f);
            f2187a = fA;
            f2188b = 1.0f - (fA * a(1.0f));
        }

        InterpolatorC0025b() {
        }

        private static float a(float f2) {
            float f3 = f2 * 8.0f;
            return f3 < 1.0f ? f3 - (1.0f - ((float) Math.exp(-f3))) : ((1.0f - ((float) Math.exp(1.0f - f3))) * 0.63212055f) + 0.36787945f;
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            float fA = f2187a * a(f2);
            return fA > 0.0f ? fA + f2188b : fA;
        }
    }

    public b(Context context) {
        this(context, null);
    }

    private int M(int i2) {
        return (!f2123n || Math.abs(i2) <= f2125p) ? i2 : ((int) Math.signum(i2)) * f2125p;
    }

    private int l(int i2, float f2, int i3, String str) {
        float f3;
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("-> ");
        sb.append(Math.abs(f2));
        sb.append(" >");
        sb.append(r.a.f2116e);
        sb.append(":");
        int i4 = 1;
        sb.append(Math.abs(f2) > ((float) r.a.f2116e));
        sb.append("-> ");
        sb.append(Math.abs(i3));
        sb.append(" >");
        sb.append(r.a.f2117f);
        sb.append(":");
        sb.append(Math.abs(i3) > r.a.f2117f);
        t.a.a("ReboundOverScroller", sb.toString());
        float f4 = i3;
        if (Math.signum(f4) != Math.signum(f2)) {
            t.a.a("ReboundOverScroller", "Signum mFlywheelCount" + str + " = 1!");
        } else if (Math.abs(f2) <= r.a.f2116e || Math.abs(i3) <= r.a.f2117f) {
            t.a.a("ReboundOverScroller", "Unsatisfied mFlywheelCount" + str + " = 1!");
        } else {
            i4 = 1 + i2;
            int i5 = (int) (f4 + f2);
            switch (i4) {
                case 8:
                    f3 = r.a.f2119h;
                    break;
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                    f3 = r.a.f2120i;
                    break;
                default:
                    i3 = i5;
                    t.a.a("ReboundOverScroller", "Satisfied mFlywheelCount" + str + " = " + i4 + "!");
                    break;
            }
            i5 = (int) (f3 * i5);
            i3 = i5;
            t.a.a("ReboundOverScroller", "Satisfied mFlywheelCount" + str + " = " + i4 + "!");
        }
        if (str.equals("X")) {
            this.f2139g = i4;
            return i3;
        }
        if (str.equals("Y")) {
            this.f2140h = i4;
        }
        return i3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static long r() {
        try {
            if (f2132w == null) {
                Class[] clsArr = new Class[0];
                f2132w = Class.forName("android.view.animation.AnimationUtils").getMethod("currentAnimationTimeMillis", null);
            }
            return ((Long) f2132w.invoke(null, null)).longValue();
        } catch (Exception e2) {
            t.a.b("ReboundOverScroller", "getCurrentAnimationTimeMillis error: " + e2.getMessage());
            return SystemClock.uptimeMillis();
        }
    }

    private int s() {
        Context context = this.f2141i;
        if (context != null) {
            int iC = t.b.c(context);
            t.a.a("ReboundOverScroller", "getDeltaCurrTime rate = " + iC);
            if (iC == 30) {
                return 33;
            }
            if (iC == 60) {
                return 16;
            }
            if (iC == 72) {
                return 14;
            }
            if (iC == 90) {
                return 11;
            }
            if (iC == 120) {
                return 8;
            }
            if (iC == 144) {
                return 7;
            }
        }
        return 16;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static float t(String str, float f2) {
        return Float.parseFloat(t.b.b("persis.debug." + str, String.valueOf(f2)));
    }

    public void A(int i2) {
        this.f2134b.f2165i = i2;
        this.f2134b.f2166j = i2;
    }

    public void B(boolean z2) {
        this.f2133a.z(z2);
        this.f2134b.z(z2);
    }

    public void C(int i2) {
        this.f2133a.A(i2);
        this.f2134b.A(i2);
        t.a.a("ReboundOverScroller", "mRestDisplacementThreshold = " + i2);
    }

    public void D(int i2) {
        if (i2 < 0) {
            i2 = Math.abs(i2);
        }
        this.f2133a.B(i2);
        this.f2134b.B(i2);
        t.a.a("ReboundOverScroller", "mRestVelocityThreshold = " + i2);
    }

    public boolean E(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2133a.D(i2, i3, i4, 2);
    }

    public boolean F(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2134b.D(i2, i3, i4, 2);
    }

    public boolean G(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2133a.D(i2, i3, i4, 3);
    }

    public boolean H(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2134b.D(i2, i3, i4, 3);
    }

    public boolean I(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2133a.D(i2, i3, i4, 1);
    }

    public boolean J(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2134b.D(i2, i3, i4, 1);
    }

    public boolean K(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2133a.D(i2, i3, i4, 0);
    }

    public boolean L(int i2, int i3, int i4) {
        this.f2136d = 1;
        f2129t = s();
        return this.f2134b.D(i2, i3, i4, 0);
    }

    public void a() {
        this.f2133a.u();
        this.f2134b.u();
        h();
        if (f2131v == null || this.f2136d != 1) {
            return;
        }
        o.b.c();
    }

    public void h() {
        synchronized (this.f2143k) {
            try {
                SoftReference softReference = this.f2142j;
                if (softReference != null) {
                    softReference.clear();
                    this.f2142j = null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean i() {
        t.a.a("test_log >>", "computeScrollOffset");
        if (w()) {
            if (f2131v == null || this.f2136d != 1) {
                return false;
            }
            o.b.c();
            return false;
        }
        int i2 = this.f2136d;
        if (i2 == 0) {
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis() - this.f2133a.f2169m;
            int i3 = this.f2133a.f2170n;
            if (jCurrentAnimationTimeMillis < i3) {
                float interpolation = this.f2137e.getInterpolation(jCurrentAnimationTimeMillis / i3);
                if (!this.f2133a.f2171o) {
                    this.f2133a.J(interpolation);
                }
                if (!this.f2134b.f2171o) {
                    this.f2134b.J(interpolation);
                }
            } else {
                a();
            }
        } else if (i2 == 1) {
            if (!this.f2133a.f2171o && !this.f2133a.I()) {
                this.f2133a.u();
            }
            if (!this.f2134b.f2171o && !this.f2134b.I()) {
                this.f2134b.u();
            }
        }
        return true;
    }

    public void j(int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
        k(i2, i3, i4, i5, i6, i7, i8, i9, 0, 0);
    }

    public void k(int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11) {
        int iL;
        StringBuilder sb = new StringBuilder();
        sb.append("fling: Vx=");
        sb.append(i4);
        sb.append(" , Vy=");
        int iL2 = i5;
        sb.append(iL2);
        sb.append(" , minVel=");
        sb.append(750);
        sb.append(" , sX=");
        sb.append(i2);
        sb.append(" , sY=");
        sb.append(i3);
        t.a.a("ReboundOverScroller", sb.toString());
        if (Math.abs(i4) >= 750 || Math.abs(iL2) >= 750) {
            iL = i4;
        } else {
            z(i2);
            A(i3);
            iL = 0;
            iL2 = 0;
        }
        long jCurrentTimeMillis = System.currentTimeMillis();
        t.a.a("ReboundOverScroller", "mFlywheel=" + this.f2135c);
        if (this.f2135c) {
            float f2 = this.f2133a.f2168l;
            float f3 = this.f2134b.f2168l;
            if (Math.abs(jCurrentTimeMillis - this.f2138f) > r.a.f2118g) {
                this.f2139g = 1;
                this.f2140h = 1;
                t.a.a("ReboundOverScroller", "> sMaxWheelFlingInterval mFlywheelCountX/Y = 1!");
            } else {
                iL = l(this.f2139g, f2, iL, "X");
                iL2 = l(this.f2140h, f3, iL2, "Y");
            }
        }
        this.f2138f = jCurrentTimeMillis;
        int iM = M(iL);
        int iM2 = M(iL2);
        t.a.a("ReboundOverScroller", "mFlywheelCountX=" + this.f2139g + " ,velocityX=" + iM);
        t.a.a("ReboundOverScroller", "mFlywheelCountY=" + this.f2140h + " ,velocityY=" + iM2);
        if (f2131v != null) {
            o.b.d();
        }
        f2129t = s();
        this.f2136d = 1;
        this.f2133a.v(i2, iM, i6, i7, i10);
        this.f2134b.v(i3, iM2, i8, i9, i11);
    }

    public final void m(boolean z2) {
        this.f2133a.f2171o = this.f2134b.f2171o = z2;
        h();
        if (f2131v != null && z2 && this.f2136d == 1) {
            o.b.c();
        }
    }

    public float n() {
        return this.f2133a.f2167k;
    }

    public float o() {
        return this.f2134b.f2167k;
    }

    public final int p() {
        return this.f2133a.f2165i;
    }

    public final int q() {
        return this.f2134b.f2165i;
    }

    void u() {
        f2121l = Integer.valueOf(!f2124o ? t.b.b("persist.debug.threshold_fling_velocity", String.valueOf(30000)) : t.b.b("persist.debug.threshold_fling_velocity", String.valueOf(24000))).intValue();
        t.a.a("ReboundOverScroller", "THRESHOLD_FLING_VELOCITY=" + f2121l);
        f2122m = Integer.valueOf(t.b.b("persist.debug.threshold_fling_velocity_flywheel", String.valueOf(30000))).intValue();
        t.a.a("ReboundOverScroller", "THRESHOLD_FLING_VELOCITY_FLYWHEEL=" + f2122m);
        f2123n = true;
    }

    public void v(double d2, double d3) {
        c unused = a.f2145b0 = new c(d2, d3);
    }

    public final boolean w() {
        return this.f2133a.f2171o && this.f2134b.f2171o;
    }

    public void x() {
        this.f2133a.A(-1);
        this.f2134b.A(-1);
        t.a.a("ReboundOverScroller", "mRestDisplacementThreshold = -1");
    }

    public void y() {
        this.f2133a.B(-1);
        this.f2134b.B(-1);
        t.a.a("ReboundOverScroller", "mRestVelocityThreshold = -1");
    }

    public void z(int i2) {
        this.f2133a.f2165i = i2;
        this.f2133a.f2166j = i2;
    }

    public b(Context context, Interpolator interpolator) {
        this(context, interpolator, f2124o);
    }

    public b(Context context, Interpolator interpolator, boolean z2) {
        this.f2138f = 0L;
        this.f2139g = 1;
        this.f2140h = 1;
        this.f2143k = new Object();
        t.a.a("ReboundOverScroller", "flywheel=" + z2);
        if (interpolator == null) {
            this.f2137e = new InterpolatorC0025b();
        } else {
            this.f2137e = interpolator;
        }
        this.f2135c = z2;
        this.f2133a = new a(context);
        a aVar = new a(context);
        this.f2134b = aVar;
        aVar.f2175s.r(true);
        this.f2141i = context;
        u();
        if (f2131v == null) {
            f2131v = o.b.a(context);
            StringBuilder sb = new StringBuilder();
            sb.append("IVivoScrollView initialized: ");
            sb.append(f2131v != null);
            t.a.a("ReboundOverScroller", sb.toString());
        }
    }
}
