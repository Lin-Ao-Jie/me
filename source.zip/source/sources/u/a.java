package u;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static double a(double d2, double d3) {
        return d2 * Math.sqrt(d3) * 2.0d;
    }

    public static double b(double d2) {
        return d2;
    }
}
