package k;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private k.a f1778a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private g.b f1779b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private f f1780c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private d f1781d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1782e;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        k.a f1783a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        f f1784b = new f();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        d f1785c = new d();

        public a(int i2) {
            this.f1783a = new k.a(i2);
        }

        public a a(String str) {
            this.f1783a.h(str);
            return this;
        }

        public e b() {
            return new e(this.f1783a, this.f1784b, this.f1785c);
        }

        public a c(int i2) {
            this.f1783a.j(i2);
            return this;
        }

        public a d(int i2) {
            this.f1783a.k(i2);
            return this;
        }

        public a e(int i2) {
            this.f1783a.l(i2);
            return this;
        }

        public a f(int i2) {
            this.f1784b.e(i2);
            return this;
        }

        public a g(int i2) {
            this.f1784b.f(i2);
            return this;
        }

        public a h(String str) {
            this.f1783a.m(str);
            return this;
        }

        public a i(float f2) {
            this.f1784b.g(f2);
            return this;
        }
    }

    public e(k.a aVar, f fVar, d dVar) {
        this.f1778a = aVar;
        this.f1780c = fVar;
        this.f1781d = dVar;
    }

    public k.a a() {
        return this.f1778a;
    }

    public d b() {
        return this.f1781d;
    }

    public g.b c() {
        return this.f1779b;
    }

    public f d() {
        return this.f1780c;
    }

    public int e() {
        return this.f1782e;
    }

    public void f(k.a aVar) {
        this.f1778a = aVar;
    }

    public e g(int i2, g.b bVar) {
        this.f1782e = i2;
        this.f1779b = bVar;
        return this;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("GridOp{");
        if (this.f1778a != null) {
            stringBuffer.append("BreakPoint=");
            stringBuffer.append(this.f1778a.toString());
            stringBuffer.append("\n");
        }
        if (this.f1779b != null) {
            stringBuffer.append(", GridLayout=");
            stringBuffer.append(this.f1779b.toString());
            stringBuffer.append("\n");
        }
        if (this.f1780c != null) {
            stringBuffer.append(", GridPair=");
            stringBuffer.append(this.f1780c.toString());
            stringBuffer.append("\n");
        }
        stringBuffer.append('}');
        return super.toString();
    }

    public e(k.a aVar, g.b bVar, f fVar, d dVar) {
        this.f1778a = aVar;
        this.f1779b = bVar;
        this.f1780c = fVar;
        this.f1781d = dVar;
    }
}
