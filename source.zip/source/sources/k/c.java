package k;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    public static void a(a aVar) {
        int iE = aVar.e();
        if (iE == 1) {
            aVar.n(200).j(2).i(8).l(8).k(8);
            return;
        }
        if (iE == 2) {
            aVar.n(480).j(4).i(g.c.C0010c.f1647b).l(g.c.C0010c.f1646a).k(8);
            return;
        }
        if (iE == 4) {
            aVar.n(920).j(8).i(g.c.b.f1645b).l(g.c.b.f1644a).k(8);
        } else if (iE == 8) {
            aVar.n(2000).j(12).i(g.c.a.f1643b).l(g.c.a.f1642a).k(8);
        } else {
            if (iE != 16) {
                return;
            }
            aVar.n(2000).j(12).i(g.c.a.f1643b).l(g.c.a.f1642a).k(8);
        }
    }
}
