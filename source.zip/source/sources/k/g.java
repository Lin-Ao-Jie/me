package k;

import android.view.View;
import android.view.ViewGroup;
import com.originui.core.utils.m;
import com.originui.core.utils.p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class g implements b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private View f1790a;

    public g(View view) {
        this.f1790a = view;
    }

    @Override // k.b
    public void a(e eVar) {
        float fC = eVar.d().c();
        int iF = eVar.c().f();
        int iA = p.a(eVar.c().h());
        boolean zD = eVar.d().d();
        int iA2 = eVar.d().a();
        if (iA2 < eVar.a().c()) {
            iA2 *= iF;
        }
        if (eVar.d().b() < 0) {
            this.f1790a.setVisibility(8);
        } else if (eVar.d().b() > 0) {
            this.f1790a.setVisibility(0);
        }
        if (!zD) {
            fC = (iF * fC) + (iA * (fC - 1.0f));
        }
        m.b("ViewBreakPointChangeListener", this.f1790a + " gridOp=" + eVar.toString() + ",mIsFixedWidth=" + zD + ",width=" + fC);
        try {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1790a.getLayoutParams();
            marginLayoutParams.width = (int) fC;
            marginLayoutParams.leftMargin = iA2;
            this.f1790a.setLayoutParams(marginLayoutParams);
        } catch (Exception unused) {
            m.f("ViewBreakPointChangeListener", "onBreakPointChange  error：", new Exception());
        }
    }
}
