package k;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a implements Cloneable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1765a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f1766b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f1767c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1768d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1769e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f1770f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1771g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1772h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1773i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1774j;

    public a(int i2) {
        this.f1765a = i2;
        c.a(this);
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public a clone() {
        try {
            a aVar = (a) super.clone();
            aVar.f1765a = this.f1765a;
            aVar.f1766b = this.f1766b;
            aVar.f1767c = this.f1767c;
            aVar.f1768d = this.f1768d;
            aVar.f1769e = this.f1769e;
            aVar.f1770f = this.f1770f;
            aVar.f1771g = this.f1771g;
            aVar.f1772h = this.f1772h;
            aVar.f1773i = this.f1773i;
            aVar.f1774j = this.f1774j;
            return aVar;
        } catch (CloneNotSupportedException unused) {
            return this;
        }
    }

    public int b() {
        return this.f1773i;
    }

    public int c() {
        return this.f1770f;
    }

    public int d() {
        return this.f1771g;
    }

    public int e() {
        return this.f1765a;
    }

    public int f() {
        return this.f1772h;
    }

    public int g() {
        return this.f1769e;
    }

    public a h(String str) {
        this.f1766b = str;
        return this;
    }

    public a i(int i2) {
        this.f1773i = i2;
        return this;
    }

    public a j(int i2) {
        this.f1770f = i2;
        return this;
    }

    public a k(int i2) {
        this.f1771g = i2;
        return this;
    }

    public a l(int i2) {
        this.f1772h = i2;
        return this;
    }

    public a m(String str) {
        this.f1767c = str;
        return this;
    }

    public a n(int i2) {
        this.f1769e = i2;
        return this;
    }

    public String toString() {
        return "BreakPoint{level=" + this.f1765a + ", adapter=" + this.f1766b + ", reference=" + this.f1767c + ", referenceComponentId=" + this.f1768d + ", value=" + this.f1769e + ", column=" + this.f1770f + ", gutter=" + this.f1771g + ", margin=" + this.f1772h + ", columnValue=" + this.f1774j + '}';
    }
}
