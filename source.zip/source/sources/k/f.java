package k;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f1786a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1787b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1788c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f1789d;

    public int a() {
        return this.f1787b;
    }

    public int b() {
        return this.f1788c;
    }

    public float c() {
        return this.f1786a;
    }

    public boolean d() {
        return this.f1789d;
    }

    public f e(int i2) {
        this.f1787b = i2;
        return this;
    }

    public f f(int i2) {
        this.f1788c = i2;
        return this;
    }

    public f g(float f2) {
        this.f1786a = f2;
        return this;
    }

    public String toString() {
        return "GridPair{, span=" + this.f1786a + ", offset=" + this.f1787b + ", order=" + this.f1788c + ", isFixedWidth=" + this.f1789d + '}';
    }
}
