package k;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f1775a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f1776b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1777c;

    public String toString() {
        return "GridChild{, childSpan=" + this.f1775a + ", childColumn=" + this.f1776b + ", childGutter=" + this.f1777c + '}';
    }
}
