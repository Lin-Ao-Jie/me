package b;

import android.graphics.RectF;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class e {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f154d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private float f155e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f156f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f157g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f158h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f159i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f160j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f161k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f162l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f163m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f164n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private a f165o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private RectF f166p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f167q;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f174x;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f151a = -1.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f152b = -1.0f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f153c = -1;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f168r = -1;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f169s = -1.0f;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f170t = -1;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f171u = -1;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private int f172v = -1;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f173w = -1.0f;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private boolean f175y = false;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private int f176z = -1;
    private int A = -1;
    private int B = -1;
    private boolean C = false;
    private boolean D = false;
    private int E = -1;
    private boolean F = false;

    public float A() {
        return this.f152b;
    }

    public boolean B() {
        return this.f174x;
    }

    public boolean C() {
        return this.C;
    }

    public boolean D() {
        return this.D;
    }

    public int E() {
        return this.E;
    }

    public boolean F() {
        return this.f175y;
    }

    public boolean G() {
        return this.F;
    }

    public e H(int i2) {
        this.f153c = i2;
        return this;
    }

    public e I(a aVar) {
        this.f165o = aVar;
        return this;
    }

    public e J(int i2) {
        this.E = i2;
        return this;
    }

    public e K(boolean z2) {
        this.F = z2;
        return this;
    }

    public float a() {
        return this.f173w;
    }

    public int b() {
        return this.f153c;
    }

    public float c() {
        return this.f151a;
    }

    public RectF d() {
        return this.f166p;
    }

    public float e() {
        return this.f167q;
    }

    public int f() {
        return this.f171u;
    }

    public int g() {
        return this.B;
    }

    public int h() {
        return this.f172v;
    }

    public a i() {
        return this.f165o;
    }

    public float j() {
        return this.f169s;
    }

    public int k() {
        return this.f164n;
    }

    public float l() {
        return this.f163m;
    }

    public int m() {
        return this.f176z;
    }

    public int n() {
        return this.f168r;
    }

    public int o() {
        return this.f154d;
    }

    public int p() {
        return this.f157g;
    }

    public int q() {
        return this.f160j;
    }

    public int r() {
        return this.f156f;
    }

    public int s() {
        return this.f159i;
    }

    public int t() {
        return this.f162l;
    }

    public float u() {
        return this.f155e;
    }

    public float v() {
        return this.f158h;
    }

    public float w() {
        return this.f161k;
    }

    public int x() {
        return this.A;
    }

    public d y() {
        return null;
    }

    public int z() {
        return this.f170t;
    }
}
