package b;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f147a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f148b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f149c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f150d;

    public a(float f2) {
        this.f149c = f2;
        this.f150d = f2;
        this.f148b = f2;
        this.f147a = f2;
    }
}
