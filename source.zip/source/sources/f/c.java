package f;

import android.content.Context;
import android.graphics.Color;
import android.graphics.RuntimeShader;
import android.view.View;
import com.originui.core.utils.m;
import com.originui.core.utils.q;
import com.originui.widget.button.R$raw;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final RuntimeShader f1621a;

    public c(Context context) {
        this.f1621a = new RuntimeShader(d(context));
        e();
    }

    private static float[] b(int[] iArr) {
        return new float[]{iArr[0] / 255.0f, iArr[1] / 255.0f, iArr[2] / 255.0f};
    }

    private static String d(Context context) {
        return f(context, R$raw.blur_filter_shader_radius);
    }

    private void e() {
        this.f1621a.setIntUniform("uType", 2);
        this.f1621a.setFloatUniform("uSaturation", 0.0f);
    }

    private static String f(Context context, int i2) {
        try {
            InputStream inputStreamOpenRawResource = context.getResources().openRawResource(i2);
            byte[] bArr = new byte[inputStreamOpenRawResource.available()];
            inputStreamOpenRawResource.read(bArr);
            inputStreamOpenRawResource.close();
            return new String(bArr, StandardCharsets.UTF_8);
        } catch (Exception e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public void a(View view) throws Exception {
        a aVarA = a.a();
        if (aVarA == null) {
            throw new Exception("Must initialize global config first!");
        }
        b[] bVarArr = aVarA.f1613b;
        b bVar = bVarArr[0];
        b bVar2 = bVarArr[1];
        b bVar3 = bVarArr[2];
        q.m(view, "setMaterialCustomized", Float.valueOf(aVarA.f1614c), Float.valueOf(aVarA.f1615d), Integer.valueOf(Color.rgb(bVar.b()[0], bVar.b()[1], bVar.b()[2])), Float.valueOf(bVar.c()), Integer.valueOf(bVar.a()), Integer.valueOf(Color.rgb(bVar2.b()[0], bVar2.b()[1], bVar2.b()[2])), Float.valueOf(bVar2.c()), Integer.valueOf(bVar2.a()), Integer.valueOf(Color.rgb(bVar3.b()[0], bVar3.b()[1], bVar3.b()[2])), Float.valueOf(bVar3.c()), Integer.valueOf(bVar3.a()), Float.valueOf(aVarA.f1616e), Integer.valueOf(aVarA.f1617f));
    }

    public RuntimeShader c() {
        return this.f1621a;
    }

    public void g(List list) {
        int[] iArr = new int[5];
        float[] fArr = new float[5];
        if (list.size() != 5) {
            m.f("FifthFilterShader", "Set params size not match agsl!", new Exception());
            return;
        }
        int i2 = 0;
        while (i2 < list.size()) {
            b bVar = (b) list.get(i2);
            iArr[i2] = bVar.a();
            fArr[i2] = bVar.c();
            RuntimeShader runtimeShader = this.f1621a;
            StringBuilder sb = new StringBuilder();
            sb.append("uCustomMask");
            i2++;
            sb.append(i2);
            runtimeShader.setFloatUniform(sb.toString(), b(bVar.b()));
        }
        this.f1621a.setIntUniform("uCustomFusion", iArr);
        this.f1621a.setFloatUniform("uCustomOpacity", fArr);
    }

    public void h(float f2, float f3, float f4) {
        this.f1621a.setFloatUniform("uRadius", f2, f2, f2, f2);
        this.f1621a.setFloatUniform("uWidth", f3);
        this.f1621a.setFloatUniform("uHeight", f4);
    }
}
