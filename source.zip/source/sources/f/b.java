package f;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1618a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int[] f1619b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private float f1620c;

    public b(int i2, int[] iArr, float f2) {
        this.f1618a = i2;
        this.f1619b = iArr;
        this.f1620c = f2;
    }

    public int a() {
        return this.f1618a;
    }

    public int[] b() {
        return this.f1619b;
    }

    public float c() {
        return this.f1620c;
    }

    public void d(int[] iArr) {
        this.f1619b = iArr;
    }
}
