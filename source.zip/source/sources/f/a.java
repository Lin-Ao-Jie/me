package f;

import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static a f1611g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public List f1612a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public b[] f1613b = {new b(0, new int[]{255, 255, 255}, 0.0f), new b(0, new int[]{255, 255, 255}, 0.0f), new b(0, new int[]{255, 255, 255}, 0.0f)};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f1614c = 0.04f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f1615d = 0.0f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f1616e = 1.0f;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1617f = 0;

    public static a a() {
        return f1611g;
    }

    public static void b(a aVar) {
        f1611g = aVar;
    }
}
