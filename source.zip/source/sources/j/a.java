package j;

import java.util.ArrayList;
import k.e;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1741c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f1739a = "spring";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f1740b = "window";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final ArrayList f1742d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final ArrayList f1743e = new ArrayList();

    /* JADX INFO: renamed from: j.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class C0013a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        a f1744a = new a();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        e.a f1745b = new e.a(1);

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        e.a f1746c = new e.a(2);

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        e.a f1747d = new e.a(4);

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        e.a f1748e = new e.a(8);

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        e.a f1749f = new e.a(16);

        public C0013a a(String str) {
            this.f1744a.k(str);
            this.f1745b.a(str);
            this.f1746c.a(str);
            this.f1747d.a(str);
            this.f1748e.a(str);
            this.f1749f.a(str);
            return this;
        }

        public a b() {
            this.f1744a.d(this.f1745b.b());
            this.f1744a.d(this.f1746c.b());
            this.f1744a.d(this.f1747d.b());
            this.f1744a.d(this.f1748e.b());
            this.f1744a.d(this.f1749f.b());
            return this.f1744a;
        }

        public C0013a c(int i2, int i3, int i4) {
            this.f1746c.c(i2);
            this.f1747d.c(i3);
            this.f1748e.c(i4);
            return this;
        }

        public C0013a d(int i2, int i3, int i4, int i5, int i6) {
            this.f1745b.c(i2);
            this.f1746c.c(i3);
            this.f1747d.c(i4);
            this.f1748e.c(i5);
            this.f1749f.c(i6);
            return this;
        }

        public C0013a e(int i2, int i3, int i4) {
            this.f1746c.d(i2);
            this.f1747d.d(i3);
            this.f1748e.d(i4);
            return this;
        }

        public C0013a f(int i2, int i3, int i4, int i5, int i6) {
            this.f1745b.d(i2);
            this.f1746c.d(i3);
            this.f1747d.d(i4);
            this.f1748e.d(i5);
            this.f1749f.d(i6);
            return this;
        }

        public C0013a g(float f2) {
            this.f1748e.i(f2);
            return this;
        }

        public C0013a h(float f2, int i2) {
            this.f1748e.i(f2).f(i2);
            return this;
        }

        public C0013a i(float f2, int i2, int i3) {
            this.f1748e.i(f2).f(i2).g(i3);
            return this;
        }

        public C0013a j(int i2, int i3, int i4) {
            this.f1746c.e(i2);
            this.f1747d.e(i3);
            this.f1748e.e(i4);
            return this;
        }

        public C0013a k(int i2, int i3, int i4, int i5, int i6) {
            this.f1745b.e(i2);
            this.f1746c.e(i3);
            this.f1747d.e(i4);
            this.f1748e.e(i5);
            this.f1749f.e(i6);
            return this;
        }

        public C0013a l(float f2) {
            this.f1749f.i(f2);
            return this;
        }

        public C0013a m(float f2, int i2) {
            this.f1749f.i(f2).f(i2);
            return this;
        }

        public C0013a n(float f2) {
            this.f1747d.i(f2);
            return this;
        }

        public C0013a o(float f2, int i2) {
            this.f1747d.i(f2).f(i2);
            return this;
        }

        public C0013a p(float f2, int i2, int i3) {
            this.f1747d.i(f2).f(i2).g(i3);
            return this;
        }

        public C0013a q(float f2) {
            this.f1745b.i(f2);
            return this;
        }

        public C0013a r(float f2, int i2) {
            this.f1745b.i(f2).f(i2);
            return this;
        }

        public C0013a s(float f2, int i2, int i3) {
            this.f1745b.i(f2).f(i2).g(i3);
            return this;
        }

        public C0013a t(String str) {
            this.f1744a.l(str);
            this.f1745b.h(str);
            this.f1746c.h(str);
            this.f1747d.h(str);
            this.f1748e.h(str);
            this.f1749f.h(str);
            return this;
        }

        public C0013a u(float f2) {
            this.f1746c.i(f2);
            return this;
        }

        public C0013a v(float f2, int i2) {
            this.f1746c.i(f2).f(i2);
            return this;
        }

        public C0013a w(float f2, int i2, int i3) {
            this.f1746c.i(f2).f(i2).g(i3);
            return this;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d(e eVar) {
        this.f1742d.add(eVar);
    }

    public void b(ArrayList arrayList) {
        this.f1743e.clear();
        this.f1743e.addAll(arrayList);
    }

    public void c(k.b bVar) {
        if (this.f1743e.contains(bVar)) {
            return;
        }
        this.f1743e.add(bVar);
    }

    public String e() {
        return this.f1739a;
    }

    public ArrayList f() {
        return this.f1743e;
    }

    public ArrayList g() {
        return this.f1742d;
    }

    public String h() {
        return this.f1740b;
    }

    public int i() {
        return this.f1741c;
    }

    public void j(e eVar) {
        ArrayList arrayList = this.f1743e;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            k.b bVar = (k.b) obj;
            if (bVar != null) {
                bVar.a(eVar);
            }
        }
    }

    public void k(String str) {
        this.f1739a = str;
    }

    public void l(String str) {
        this.f1740b = str;
    }

    public void m(int i2) {
        this.f1741c = i2;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("GridRule{");
        ArrayList arrayList = this.f1742d;
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayList.get(i3);
            i3++;
            e eVar = (e) obj;
            if (eVar != null) {
                stringBuffer.append("gridOp");
                stringBuffer.append(i2);
                stringBuffer.append("=");
                stringBuffer.append(eVar.toString());
                stringBuffer.append("\n");
                i2++;
            }
        }
        if (this.f1740b != null) {
            stringBuffer.append(", reference=");
            stringBuffer.append(this.f1740b.toString());
            stringBuffer.append("\n");
        }
        if (this.f1739a != null) {
            stringBuffer.append(", adapter=");
            stringBuffer.append(this.f1739a.toString());
            stringBuffer.append("\n");
        }
        stringBuffer.append('}');
        return super.toString();
    }
}
