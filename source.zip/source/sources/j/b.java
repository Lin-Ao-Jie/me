package j;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.a0;
import com.originui.core.utils.m;
import g.i;
import h.d;
import java.util.ArrayList;
import k.e;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private a f1750a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f1751b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Context f1752c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private h.a f1753d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1754e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f1755f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float f1756g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1757h = -1;

    public b(View view, Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f1751b = view;
        this.f1752c = context;
    }

    private e d(int i2) {
        ArrayList arrayListG = this.f1750a.g();
        int size = arrayListG.size();
        int i3 = 0;
        while (i3 < size) {
            Object obj = arrayListG.get(i3);
            i3++;
            e eVar = (e) obj;
            if (i2 <= eVar.a().g()) {
                return eVar;
            }
        }
        return null;
    }

    public void a(a aVar) {
        this.f1750a = aVar;
        String strE = aVar.e();
        strE.getClass();
        switch (strE) {
            case "indent":
                this.f1753d = new h.b();
                break;
            case "permut":
                this.f1753d = new h.c();
                break;
            case "spring":
                this.f1753d = new d();
                break;
            default:
                this.f1753d = new d();
                break;
        }
    }

    public boolean b(int i2, Configuration configuration, i iVar, Object obj) {
        return c(i2, configuration, iVar, obj, false);
    }

    public boolean c(int i2, Configuration configuration, i iVar, Object obj, boolean z2) {
        int width;
        int paddingEnd;
        if (this.f1750a == null || this.f1754e == i2) {
            return false;
        }
        this.f1756g = g.c.e() / 160.0f;
        m.b("GridRuleController", "filterBreakPoint value: " + i2 + " mGridRule" + this.f1750a.toString() + ",mGridRule.getReference()=" + this.f1750a.h());
        if (i2 == -1 && TextUtils.equals(this.f1750a.h(), "window")) {
            if (iVar == null) {
                m.b("GridRuleController", "state is null");
                return false;
            }
            this.f1754e = Math.round(iVar.g() / this.f1752c.getResources().getDisplayMetrics().density);
            this.f1755f = Math.round(iVar.g() / this.f1756g);
        } else if (i2 == -2 && TextUtils.equals(this.f1750a.h(), "component")) {
            try {
                width = this.f1751b.getRootView().findViewById(this.f1750a.i()).getWidth() - this.f1751b.getRootView().findViewById(this.f1750a.i()).getPaddingStart();
                paddingEnd = this.f1751b.getRootView().findViewById(this.f1750a.i()).getPaddingEnd();
            } catch (Exception e2) {
                Activity activityB = a0.b(this.f1751b.getContext());
                m.b("GridRuleController", "filterBreakPoint: " + e2.getMessage() + " activity" + activityB);
                if (activityB == null) {
                    return false;
                }
                width = activityB.getWindow().getDecorView().findViewById(this.f1750a.i()).getWidth() - activityB.getWindow().getDecorView().findViewById(this.f1750a.i()).getPaddingStart();
                paddingEnd = activityB.getWindow().getDecorView().findViewById(this.f1750a.i()).getPaddingEnd();
            }
            float f2 = width - paddingEnd;
            this.f1754e = Math.round(f2 / this.f1752c.getResources().getDisplayMetrics().density);
            this.f1755f = Math.round(f2 / this.f1756g);
        }
        e eVarD = d(this.f1755f);
        m.b("GridRuleController", "filterBreakPoint result: " + eVarD.toString() + ",mWidth=" + this.f1754e);
        if (this.f1754e <= 0) {
            return false;
        }
        eVarD.f(eVarD.a().h(this.f1750a.e()).m(this.f1750a.h()));
        int i3 = this.f1754e;
        eVarD.g(i3, this.f1753d.a(i3, eVarD.a()));
        m.b("GridRuleController", "mLastValue=" + this.f1757h + " result.getValue()=" + eVarD.e() + " mWidth=" + this.f1754e + " mWidthFilterOp=" + this.f1755f);
        if (this.f1757h == eVarD.e() && !z2) {
            return false;
        }
        this.f1757h = eVarD.e();
        this.f1750a.j(eVarD);
        return true;
    }

    @Override // j.c
    public a getGridRule() {
        return this.f1750a;
    }
}
