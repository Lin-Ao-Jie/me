package c;

import com.originui.vbaseres.R$dimen;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int f177a = R$dimen.originui_vbaseres_fillet_s_value_rom15_0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int f178b = R$dimen.originui_vbaseres_fillet_m_value_rom15_0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int f179c = R$dimen.originui_vbaseres_fillet_l_value_rom15_0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int f180d = R$dimen.originui_vbaseres_fillet_xl_value_rom15_0;
}
