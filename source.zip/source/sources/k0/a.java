package k0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;
import w.p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1794d;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1798h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f1799i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1800j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f1801k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f1802l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1803m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1804n;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f1791a = "";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f1792b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f1793c = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f1795e = "";

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public String f1796f = "";

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public String f1797g = "Disabled";

    private static void a(String str) {
        VmdriLog.e("DeviceStateMessage", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(this.f1791a)) {
                jSONObject.put("devId", this.f1791a);
            }
            if (!TextUtils.isEmpty(this.f1792b)) {
                jSONObject.put("name", this.f1792b);
            }
            if (!TextUtils.isEmpty(this.f1793c)) {
                jSONObject.put("cmd", this.f1793c);
            }
            int i2 = this.f1794d;
            if (i2 >= 0) {
                jSONObject.put("sw", i2);
            }
            if (!TextUtils.isEmpty(this.f1795e)) {
                jSONObject.put("p2pIf", this.f1795e);
            }
            if (!TextUtils.isEmpty(this.f1796f)) {
                jSONObject.put("p2pIp", this.f1796f);
            }
            if (!TextUtils.isEmpty(this.f1797g)) {
                jSONObject.put("p2pState", this.f1797g);
            }
            jSONObject.put("simNum", this.f1798h);
            jSONObject.put("dtEn", this.f1799i ? 1 : 0);
            jSONObject.put("scrOn", this.f1800j ? 1 : 0);
            jSONObject.put("airp", this.f1801k ? 1 : 0);
            jSONObject.put("wfOn", this.f1802l ? 1 : 0);
            jSONObject.put("wfAp", this.f1803m ? 1 : 0);
            jSONObject.put("btOn", this.f1804n ? 1 : 0);
            return jSONObject;
        } catch (JSONException e2) {
            a("Error converting DeviceStateMessage to JSONObject:" + e2.toString());
            return jSONObject;
        }
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            a("Error parsing jsonStr to DeviceStateMessage object:" + e2.toString());
            return aVar;
        }
    }

    private static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1791a = jSONObject.optString("devId", "");
            aVar.f1792b = jSONObject.optString("name", "");
            aVar.f1793c = jSONObject.optString("cmd", "");
            aVar.f1794d = jSONObject.optInt("sw", 0);
            aVar.f1795e = jSONObject.optString("p2pIf", "");
            aVar.f1796f = jSONObject.optString("p2pIp", "");
            aVar.f1797g = jSONObject.optString("p2pState", "Disabled");
            aVar.f1798h = jSONObject.optInt("simNum", 0);
            aVar.f1799i = jSONObject.optInt("dtEn", 0) == 1;
            aVar.f1800j = jSONObject.optInt("scrOn", 0) == 1;
            aVar.f1801k = jSONObject.optInt("airp", 0) == 1;
            aVar.f1802l = jSONObject.optInt("wfOn", 0) == 1;
            aVar.f1803m = jSONObject.optInt("wfAp", 0) == 1;
            aVar.f1804n = jSONObject.optInt("btOn", 0) == 1;
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to DeviceStateMessage object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "DeviceStateMessage{devId:'" + this.f1791a + "', devName:'" + this.f1792b + "', cmd:" + this.f1793c + ", switch:" + p.f(this.f1794d) + ", p2pIf:'" + this.f1795e + "', p2pIp:'" + this.f1796f + "', p2pState:'" + this.f1797g + "', simNum:" + this.f1798h + ", dataEnable:" + this.f1799i + ", screenOn:" + this.f1800j + ", airplaneOn:" + this.f1801k + ", wifiOn:" + this.f1802l + ", wifiApOn:" + this.f1803m + ", bluetoothOn:" + this.f1804n + '}';
    }
}
