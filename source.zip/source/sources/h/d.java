package h;

import android.content.res.Resources;
import com.originui.core.utils.p;
import g.l;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class d implements a {
    @Override // h.a
    public g.b a(int i2, k.a aVar) {
        StringBuilder sb = new StringBuilder();
        sb.append(Resources.getSystem().getDisplayMetrics().density);
        sb.append(",value=");
        sb.append(i2);
        sb.append(",");
        float f2 = i2;
        sb.append(p.a(f2));
        sb.append(",getMargin=");
        sb.append(aVar.f());
        sb.append(",getGutter=");
        sb.append(aVar.d());
        sb.append(",getColumn=");
        sb.append(aVar.c());
        sb.append(",");
        sb.append(aVar.f());
        l.a("SpringLayoutAdapter", sb.toString());
        return new g.b(p.a(f2), aVar.e(), p.a(f2), aVar.c(), aVar.d(), aVar.f(), aVar.b());
    }
}
