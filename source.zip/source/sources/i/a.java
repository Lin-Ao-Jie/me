package i;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.d;
import com.originui.core.utils.m;
import com.originui.widget.responsive.R$styleable;
import g.e;
import g.f;
import g.j;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import k.g;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class a implements f {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static volatile a f1723f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private j f1724a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final ArrayList f1725b = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Map f1726c = new ConcurrentHashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Map f1727d = new ConcurrentHashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final Map f1728e = new ConcurrentHashMap();

    /* JADX INFO: renamed from: i.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0011a implements b {
        C0011a() {
        }

        @Override // i.a.b
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public boolean accept(Context context) {
            return context instanceof Activity;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    interface b {
        boolean accept(Object obj);
    }

    private a() {
    }

    public static Activity e(Context context) {
        if (context instanceof Activity) {
            return (Activity) context;
        }
        if (context instanceof ContextWrapper) {
            return (Activity) g((ContextWrapper) context, new HashSet(), new C0011a());
        }
        return null;
    }

    private synchronized c f(Context context) {
        if (context == null) {
            return null;
        }
        Activity activityE = e(context);
        if (activityE == null) {
            return null;
        }
        m(activityE);
        return (c) this.f1726c.get(Integer.valueOf(System.identityHashCode(activityE)));
    }

    private static Context g(ContextWrapper contextWrapper, Set set, b bVar) {
        Context baseContext = contextWrapper.getBaseContext();
        if (bVar.accept(baseContext)) {
            return baseContext;
        }
        String strJ = j(contextWrapper);
        if (set.contains(strJ)) {
            return null;
        }
        set.add(strJ);
        if (baseContext instanceof ContextWrapper) {
            return g((ContextWrapper) baseContext, set, bVar);
        }
        return null;
    }

    public static a i() {
        if (f1723f == null) {
            synchronized (a.class) {
                try {
                    if (f1723f == null) {
                        f1723f = new a();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return f1723f;
    }

    private static String j(Object obj) {
        if (obj == null) {
            return "";
        }
        return obj.getClass().getName() + "@" + Integer.toHexString(obj.hashCode());
    }

    private int k(Context context, int i2) {
        if (i2 == 0) {
            return 0;
        }
        TypedArray typedArrayObtainTypedArray = context.getResources().obtainTypedArray(i2);
        int dimensionPixelOffset = 0;
        for (int i3 = 0; i3 < typedArrayObtainTypedArray.length(); i3++) {
            if (typedArrayObtainTypedArray.getType(i3) == 5) {
                dimensionPixelOffset = typedArrayObtainTypedArray.getDimensionPixelOffset(i3, 0);
            }
        }
        typedArrayObtainTypedArray.recycle();
        return dimensionPixelOffset;
    }

    private synchronized void m(Activity activity) {
        if (activity == null) {
            return;
        }
        int iIdentityHashCode = System.identityHashCode(activity);
        if (this.f1726c.containsKey(Integer.valueOf(iIdentityHashCode))) {
            return;
        }
        c cVar = new c();
        try {
            activity.registerActivityLifecycleCallbacks(cVar);
            this.f1726c.put(Integer.valueOf(iIdentityHashCode), cVar);
        } catch (Exception e2) {
            m.f("GridManager", "registerActivityLifecycleCallbacks error=", e2);
        }
    }

    public void b(View view) {
        j jVar;
        if (view == null || (jVar = (j) this.f1728e.get(view)) == null) {
            return;
        }
        jVar.r(view.getContext().getResources().getConfiguration());
    }

    public void c(View view, j.a aVar, boolean z2) {
        this.f1724a = new j(view);
        if (z2) {
            aVar.c(new g(view));
        }
        this.f1724a.t(aVar);
        this.f1725b.add(this.f1724a);
        if (view != null) {
            this.f1728e.put(view, this.f1724a);
        }
        if (view != null && aVar != null) {
            this.f1727d.put(view, aVar);
        }
        c cVarF = f(view.getContext());
        if (cVarF != null) {
            cVarF.b(view);
        }
        d.j(view, false, "GridView");
        d.j(view, true, "GridView");
    }

    public void d() {
        for (Map.Entry entry : new ConcurrentHashMap(this.f1726c).entrySet()) {
            Integer num = (Integer) entry.getKey();
            num.intValue();
            c cVar = (c) entry.getValue();
            if (cVar != null) {
                cVar.c();
            }
            this.f1726c.remove(num);
        }
        this.f1726c.clear();
    }

    @Override // g.f
    public e getGridContainer() {
        return this.f1724a;
    }

    public j.a h(View view) {
        return (j.a) this.f1727d.get(view);
    }

    public void l(View view, AttributeSet attributeSet, int i2, int i3) {
        j.a.C0013a c0013a;
        if (view == null) {
            return;
        }
        Context context = view.getContext();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.GridLayout, i2, i3);
        int i4 = R$styleable.GridLayout_vGridAdapter;
        if (typedArrayObtainStyledAttributes.hasValue(i4)) {
            c0013a = new j.a.C0013a();
            int i5 = typedArrayObtainStyledAttributes.getInt(i4, 0);
            if (i5 == 1) {
                c0013a.a("permut");
            } else if (i5 != 2) {
                c0013a.a("spring");
            } else {
                c0013a.a("indent");
            }
        } else {
            c0013a = null;
        }
        int i6 = R$styleable.GridLayout_vGridReference;
        if (typedArrayObtainStyledAttributes.hasValue(i6)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            if (typedArrayObtainStyledAttributes.getInt(i6, 0) != 1) {
                c0013a.t("window");
            } else {
                c0013a.t("component");
            }
        }
        int i7 = R$styleable.GridLayout_vMinOp;
        if (typedArrayObtainStyledAttributes.hasValue(i7)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(i7, 0);
            if (resourceId != 0) {
                int iK = k(context, resourceId);
                int[] intArray = context.getResources().getIntArray(resourceId);
                int length = intArray.length;
                if (length == 1) {
                    c0013a.q(intArray[0]);
                } else if (length == 2) {
                    float f2 = intArray[0];
                    if (iK == 0) {
                        iK = intArray[1];
                    }
                    c0013a.r(f2, iK);
                } else if (length == 3) {
                    float f3 = intArray[0];
                    if (iK == 0) {
                        iK = intArray[1];
                    }
                    c0013a.s(f3, iK, intArray[2]);
                }
            }
        }
        int i8 = R$styleable.GridLayout_vSmallOp;
        if (typedArrayObtainStyledAttributes.hasValue(i8)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(i8, 0);
            if (resourceId2 != 0) {
                int iK2 = k(context, resourceId2);
                int[] intArray2 = context.getResources().getIntArray(resourceId2);
                int length2 = intArray2.length;
                if (length2 == 1) {
                    c0013a.u(intArray2[0]);
                } else if (length2 == 2) {
                    float f4 = intArray2[0];
                    if (iK2 == 0) {
                        iK2 = intArray2[1];
                    }
                    c0013a.v(f4, iK2);
                } else if (length2 == 3) {
                    float f5 = intArray2[0];
                    if (iK2 == 0) {
                        iK2 = intArray2[1];
                    }
                    c0013a.w(f5, iK2, intArray2[2]);
                }
            }
        }
        int i9 = R$styleable.GridLayout_vMediumOp;
        if (typedArrayObtainStyledAttributes.hasValue(i9)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(i9, 0);
            if (resourceId3 != 0) {
                int iK3 = k(context, resourceId3);
                int[] intArray3 = context.getResources().getIntArray(resourceId3);
                int length3 = intArray3.length;
                if (length3 == 1) {
                    c0013a.n(intArray3[0]);
                } else if (length3 == 2) {
                    float f6 = intArray3[0];
                    if (iK3 == 0) {
                        iK3 = intArray3[1];
                    }
                    c0013a.o(f6, iK3);
                } else if (length3 == 3) {
                    float f7 = intArray3[0];
                    if (iK3 == 0) {
                        iK3 = intArray3[1];
                    }
                    c0013a.p(f7, iK3, intArray3[2]);
                }
            }
        }
        int i10 = R$styleable.GridLayout_vLargeOp;
        if (typedArrayObtainStyledAttributes.hasValue(i10)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(i10, 0);
            if (resourceId4 != 0) {
                int iK4 = k(context, resourceId4);
                int[] intArray4 = context.getResources().getIntArray(resourceId4);
                int length4 = intArray4.length;
                if (length4 == 1) {
                    c0013a.g(intArray4[0]);
                } else if (length4 == 2) {
                    float f8 = intArray4[0];
                    if (iK4 == 0) {
                        iK4 = intArray4[1];
                    }
                    c0013a.h(f8, iK4);
                } else if (length4 == 3) {
                    float f9 = intArray4[0];
                    if (iK4 == 0) {
                        iK4 = intArray4[1];
                    }
                    c0013a.i(f9, iK4, intArray4[2]);
                }
            }
        }
        int i11 = R$styleable.GridLayout_vMaxOp;
        if (typedArrayObtainStyledAttributes.hasValue(i11)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(i11, 0);
            if (resourceId5 != 0) {
                int iK5 = k(context, resourceId5);
                int[] intArray5 = context.getResources().getIntArray(resourceId5);
                int length5 = intArray5.length;
                if (length5 == 1) {
                    c0013a.l(intArray5[0]);
                } else if (length5 == 2) {
                    float f10 = intArray5[0];
                    if (iK5 == 0) {
                        iK5 = intArray5[1];
                    }
                    c0013a.m(f10, iK5);
                } else if (length5 == 3) {
                    float f11 = intArray5[0];
                    if (iK5 == 0) {
                        iK5 = intArray5[1];
                    }
                    c0013a.m(f11, iK5);
                }
            }
        }
        int i12 = R$styleable.GridLayout_vGridColumn;
        if (typedArrayObtainStyledAttributes.hasValue(i12)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            j.a.C0013a c0013a2 = c0013a;
            int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(i12, 0);
            if (resourceId6 != 0) {
                int[] intArray6 = context.getResources().getIntArray(resourceId6);
                int length6 = intArray6.length;
                if (length6 == 3) {
                    c0013a2.c(intArray6[0], intArray6[1], intArray6[2]);
                } else if (length6 == 5) {
                    c0013a2.d(intArray6[0], intArray6[1], intArray6[2], intArray6[3], intArray6[4]);
                }
            }
            c0013a = c0013a2;
        }
        int i13 = R$styleable.GridLayout_vGridGutter;
        if (typedArrayObtainStyledAttributes.hasValue(i13)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            j.a.C0013a c0013a3 = c0013a;
            int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(i13, 0);
            if (resourceId7 != 0) {
                int[] intArray7 = context.getResources().getIntArray(resourceId7);
                int length7 = intArray7.length;
                if (length7 == 3) {
                    c0013a3.e(intArray7[0], intArray7[1], intArray7[2]);
                } else if (length7 == 5) {
                    c0013a3.f(intArray7[0], intArray7[1], intArray7[2], intArray7[3], intArray7[4]);
                }
            }
            c0013a = c0013a3;
        }
        int i14 = R$styleable.GridLayout_vGridMargin;
        if (typedArrayObtainStyledAttributes.hasValue(i14)) {
            if (c0013a == null) {
                c0013a = new j.a.C0013a();
            }
            j.a.C0013a c0013a4 = c0013a;
            int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(i14, 0);
            if (resourceId8 != 0) {
                int[] intArray8 = context.getResources().getIntArray(resourceId8);
                int length8 = intArray8.length;
                if (length8 == 3) {
                    c0013a4.j(intArray8[0], intArray8[1], intArray8[2]);
                } else if (length8 == 5) {
                    c0013a4.k(intArray8[0], intArray8[1], intArray8[2], intArray8[3], intArray8[4]);
                }
            }
            c0013a = c0013a4;
        }
        typedArrayObtainStyledAttributes.recycle();
        if (c0013a != null) {
            c(view, c0013a.b(), true);
        }
    }

    public void n(View view) {
        if (view != null) {
            this.f1727d.remove(view);
            this.f1725b.remove(this.f1728e.get(view));
            this.f1728e.remove(view);
            c cVarF = f(view.getContext());
            if (cVarF != null) {
                cVarF.d(view);
            }
        }
    }

    public void o(Activity activity) {
        int iIdentityHashCode = System.identityHashCode(activity);
        m.b("GridManager", "unbindActivity activity=" + activity + ",activityId=" + iIdentityHashCode);
        c cVar = (c) this.f1726c.get(Integer.valueOf(iIdentityHashCode));
        if (activity != null) {
            activity.unregisterActivityLifecycleCallbacks(cVar);
        }
        this.f1726c.remove(Integer.valueOf(iIdentityHashCode));
    }

    public void p() {
        synchronized (this.f1727d) {
            this.f1727d.clear();
        }
        synchronized (this.f1728e) {
            this.f1728e.clear();
        }
        synchronized (this.f1725b) {
            this.f1725b.clear();
        }
        d();
        this.f1724a = null;
        f1723f = null;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public class c implements Application.ActivityLifecycleCallbacks {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Set f1729a = Collections.newSetFromMap(new WeakHashMap());

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Handler f1730b = new Handler(Looper.getMainLooper());

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final Runnable f1731c = new RunnableC0012a();

        /* JADX INFO: renamed from: i.a$c$a, reason: collision with other inner class name */
        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class RunnableC0012a implements Runnable {
            RunnableC0012a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                for (View view : c.this.f1729a) {
                    if (view != null) {
                        a.i().b(view);
                    }
                }
            }
        }

        public c() {
        }

        void b(View view) {
            this.f1729a.add(view);
        }

        void c() {
            this.f1729a.clear();
        }

        void d(View view) {
            this.f1729a.remove(view);
        }

        public void onActivityConfigurationChanged(Activity activity) {
            this.f1730b.removeCallbacks(this.f1731c);
            this.f1730b.postDelayed(this.f1731c, 100L);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            m.b("WeakActivityLifecycleCallbacks", "onActivityCreated activity=" + activity);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            m.b("WeakActivityLifecycleCallbacks", "onActivityDestroyed activity=" + activity);
            a.this.o(activity);
            Iterator it = this.f1729a.iterator();
            while (it.hasNext()) {
                a.this.n((View) it.next());
            }
            if (a.this.f1728e.isEmpty()) {
                a.this.p();
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }
    }
}
