package p0;

import a0.a0;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.UserHandle;
import android.os.UserManager;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;
import c0.z0;
import com.vivo.vmdri.R;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import com.vivo.vmdri.ctrl.u;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import q0.f;
import w.c;
import w.d;
import w.e;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static final String[] f2025j = {"B", "KB", "MB", "GB", "TB"};

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static b f2026k;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f2027a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private UserManager f2028b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private NotificationManager f2029c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private Calendar f2030d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private Calendar f2031e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private Calendar f2032f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f2033g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private ArrayList f2034h = new ArrayList();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final BroadcastReceiver f2035i;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends BroadcastReceiver {
        a() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("com.vivo.vmdri.intent.action.close_comm_sharing".equals(intent.getAction())) {
                b.this.p(intent);
                return;
            }
            if ("com.vivo.vmdri.intent.action.click_comm_sharing".equals(intent.getAction())) {
                b.this.m();
                return;
            }
            if ("com.vivo.vmdri.intent.action.click_recommend_auto_comm_share".equals(intent.getAction())) {
                b.this.o();
                return;
            }
            if ("com.vivo.vmdri.intent.action.open_auto_comm_share".equals(intent.getAction())) {
                b.this.L();
                return;
            }
            if ("com.vivo.vmdri.intent.action.never_remind".equals(intent.getAction())) {
                b.this.n();
                return;
            }
            if ("com.vivo.vmdri.intent.action.delete_comm_sharing_notification".equals(intent.getAction())) {
                b.F("onReceive, action: ACTION_DELETE_COMM_SHARING_NOTIFICATION");
                b.this.q();
            } else if ("com.vivo.vmdri.intetn.action.recover_netshare_unavaliable".equals(intent.getAction())) {
                b.this.N();
            } else if ("com.vivo.vmdri.intent.action.action_recover_netshare_failed".equals(intent.getAction())) {
                b.this.M();
            }
        }
    }

    /* JADX INFO: renamed from: p0.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class AbstractC0021b {
        public abstract void a();
    }

    private b(Context context) {
        this.f2033g = false;
        a aVar = new a();
        this.f2035i = aVar;
        this.f2027a = context;
        this.f2028b = (UserManager) context.getSystemService("user");
        this.f2029c = (NotificationManager) this.f2027a.getSystemService("notification");
        this.f2030d = x("last_comm_share_noisy_notify_calendar");
        this.f2031e = x("last_comm_share_deletion_times_calendar");
        this.f2032f = x("last_p2p_noisy_notify_calendar");
        this.f2033g = Settings.Secure.getInt(this.f2027a.getContentResolver(), "support_custom_notification_always_expand", 1) == 1;
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.vivo.vmdri.intent.action.close_comm_sharing");
        intentFilter.addAction("com.vivo.vmdri.intent.action.click_comm_sharing");
        intentFilter.addAction("com.vivo.vmdri.intent.action.click_recommend_auto_comm_share");
        intentFilter.addAction("com.vivo.vmdri.intent.action.open_auto_comm_share");
        intentFilter.addAction("com.vivo.vmdri.intent.action.never_remind");
        if (VmdriContext.isPhone()) {
            intentFilter.addAction("com.vivo.vmdri.intent.action.delete_comm_sharing_notification");
        }
        if (VmdriContext.isPad()) {
            intentFilter.addAction("com.vivo.vmdri.intetn.action.recover_netshare_unavaliable");
            intentFilter.addAction("com.vivo.vmdri.intent.action.action_recover_netshare_failed");
        }
        this.f2027a.getApplicationContext().registerReceiver(aVar, intentFilter, 2);
        P();
    }

    public static b A(Context context) {
        b bVar;
        synchronized (b.class) {
            try {
                if (f2026k == null) {
                    f2026k = new b(context);
                } else {
                    G("init() called multiple times!  sInstance = " + f2026k);
                }
                bVar = f2026k;
            } catch (Throwable th) {
                throw th;
            }
        }
        return bVar;
    }

    private boolean B(int i2) {
        return i2 == 5 || i2 == 4 || i2 == 6;
    }

    private boolean C(int i2) {
        if (!E(i2)) {
            F("isNeedNoisyNotify is silence reason:" + J(i2));
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.f2027a);
        int i3 = defaultSharedPreferences.getInt("comm_share_noisy_notify_times", 0);
        F("isNeedNoisyNotify, reason:" + J(i2) + ", currentCalendar:" + s(calendar) + ", mLastNoisyNotifyCalendar: " + s(this.f2030d) + ", totalNoisyNotifyTimesOfDay: " + i3);
        if (!VmdriUtils.isSameDay(this.f2030d, calendar)) {
            this.f2030d = calendar;
            defaultSharedPreferences.edit().putInt("comm_share_noisy_notify_times", 1).apply();
            W("last_comm_share_noisy_notify_calendar", calendar);
            return true;
        }
        if (i3 >= 2) {
            return false;
        }
        defaultSharedPreferences.edit().putInt("comm_share_noisy_notify_times", i3 + 1).apply();
        this.f2030d = calendar;
        W("last_comm_share_noisy_notify_calendar", calendar);
        return true;
    }

    private boolean D() {
        Calendar calendar = Calendar.getInstance();
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.f2027a);
        int i2 = defaultSharedPreferences.getInt("p2p_conflict_noisy_notify_times", 0);
        F("isNeedNoisyNotifyP2pConflict, currentCalendar:" + s(calendar) + ", mLastNoisyNotifyP2pConflictCalendar: " + s(this.f2032f) + ", p2pConflictNoiseNotifyTimes: " + i2);
        if (!VmdriUtils.isSameDay(this.f2032f, calendar)) {
            this.f2032f = calendar;
            defaultSharedPreferences.edit().putInt("p2p_conflict_noisy_notify_times", 1).apply();
            W("last_p2p_noisy_notify_calendar", calendar);
            return true;
        }
        if (i2 >= 2) {
            return false;
        }
        defaultSharedPreferences.edit().putInt("p2p_conflict_noisy_notify_times", i2 + 1).apply();
        this.f2032f = calendar;
        W("last_p2p_noisy_notify_calendar", calendar);
        return true;
    }

    public static boolean E(int i2) {
        return i2 == 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void F(String str) {
        VmdriLog.d("NotificationMgr", str);
    }

    private static void G(String str) {
        VmdriLog.e("NotificationMgr", str);
    }

    private static void H(String str) {
        VmdriLog.w("NotificationMgr", str);
    }

    private void I(String str, int i2, Notification notification, UserHandle userHandle) {
        try {
            Context context = this.f2027a;
            ((NotificationManager) context.createPackageContextAsUser(context.getPackageName(), 0, userHandle).getSystemService("notification")).notify(str, i2, notification);
        } catch (PackageManager.NameNotFoundException e2) {
            G("unable to notify for user " + userHandle);
            e2.printStackTrace();
        }
    }

    public static String J(int i2) {
        switch (i2) {
            case 1:
                return "bothConn";
            case 2:
                return "bothDisConn";
            case 3:
                return "capabilityChanged";
            case 4:
                return "remoteDataUsageUpdate";
            case 5:
                return "localDataUsageUpdate";
            case 6:
                return "localDataUsageUpdateForConn";
            case 7:
                return "recoverNetShare";
            case 8:
                return "recoverNetShareFailed";
            default:
                return "unknown(" + i2 + ")";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L() {
        z0.f().m(true);
        z();
        f.w().r();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M() {
        try {
            Intent intent = new Intent();
            intent.setPackage("com.vivo.connbase");
            intent.setAction("vivo.intent.action.ACTION_HANDOFF_SETTING_HELP");
            intent.addFlags(268435456);
            intent.putExtra("handoff_show_type", "1");
            intent.putExtra("fromPkg", "com.vivo.vmdri");
            this.f2027a.startActivity(intent);
        } catch (Exception e2) {
            F("clickCommSharing, Failed to start activity " + e2.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void N() {
        F("recoverFromNetShareUnavaliable");
        a0 a0VarT = a0.T();
        if (a0VarT == null) {
            G("CommunicationStateReporter is null");
            return;
        }
        a0VarT.x0(0);
        a0VarT.l0(false);
        V(7, 0);
        K();
    }

    private void P() {
        UserHandle userHandle = UserHandle.ALL;
        k(null, 1, userHandle);
        k(null, 3, userHandle);
        k(null, 4, userHandle);
        l();
    }

    private void W(String str, Calendar calendar) {
        PreferenceManager.getDefaultSharedPreferences(this.f2027a).edit().putString(str, calendar.get(1) + "-" + calendar.get(2) + "-" + calendar.get(5)).apply();
    }

    private boolean j(int i2) {
        return i2 == 6 || w("comm_share_notify_deletion_times", 0) < 3;
    }

    private void k(String str, int i2, UserHandle userHandle) {
        try {
            Context context = this.f2027a;
            ((NotificationManager) context.createPackageContextAsUser(context.getPackageName(), 0, userHandle).getSystemService("notification")).cancel(str, i2);
        } catch (PackageManager.NameNotFoundException e2) {
            G("unable to cancel for user " + userHandle);
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void m() {
        try {
            Intent intent = new Intent();
            intent.setPackage("com.vivo.connbase");
            intent.setAction("vivo.intent.action.ACTION_HANDOFF_SETTING_DETAILS");
            intent.addFlags(268435456);
            intent.putExtra(":settings:fragment_args_key", "providerSettingDetailsSetRawData_hoffsetting_content_syn");
            intent.putExtra("handoff_show_type", "1");
            intent.putExtra("fromPkg", "com.vivo.vmdri");
            this.f2027a.startActivity(intent);
        } catch (Exception e2) {
            F("clickCommSharing, Failed to start activity " + e2.getMessage());
        }
        f.w().f();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void n() {
        z();
        Settings.Global.putInt(this.f2027a.getContentResolver(), "recommend_auto_comm_share_never_remind", 1);
        f.w().g();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void o() {
        try {
            Intent intent = new Intent();
            intent.setPackage("com.vivo.connbase");
            intent.setAction("vivo.intent.action.ACTION_HANDOFF_SETTING_DETAILS");
            intent.addFlags(268435456);
            intent.putExtra(":settings:fragment_args_key", "providerSettingDetailsSetRawData_hoffsetting_content_syn");
            intent.putExtra("handoff_show_type", "1");
            intent.putExtra("fromPkg", "com.vivo.vmdri");
            this.f2027a.startActivity(intent);
        } catch (Exception e2) {
            F("clickRecommendAutoCommShare, Failed to start activity " + e2.getMessage());
        }
        f.w().h();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void p(Intent intent) {
        String stringExtra = intent.getStringExtra("remoteDeviceId");
        F("closeCommSharing, remoteDeviceId = " + stringExtra);
        u.d().c().a(stringExtra, null);
        f.w().i();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void q() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.f2027a);
        int i2 = defaultSharedPreferences.getInt("comm_share_notify_deletion_times", 0);
        Calendar calendar = Calendar.getInstance();
        boolean zIsSameDay = VmdriUtils.isSameDay(this.f2031e, calendar);
        if (VmdriUtils.isSameDay(this.f2031e, calendar)) {
            if (i2 < 3) {
                defaultSharedPreferences.edit().putInt("comm_share_notify_deletion_times", i2 + 1).apply();
            }
        } else if (i2 == 3) {
            defaultSharedPreferences.edit().putInt("comm_share_notify_deletion_times", 1).apply();
        }
        F("deleteCommShareNotification, isSameDay:" + zIsSameDay + ", oldDeletionTimes:" + i2 + ", currentDeletionTimes:" + defaultSharedPreferences.getInt("comm_share_notify_deletion_times", 0));
        this.f2031e = calendar;
        W("last_comm_share_deletion_times_calendar", calendar);
    }

    private String r(long j2) {
        return v(j2) + u(j2);
    }

    public static String s(Calendar calendar) {
        if (calendar == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(calendar.get(1));
        sb.append("-");
        sb.append(calendar.get(2));
        sb.append("-");
        sb.append(calendar.get(5));
        sb.append(" ");
        sb.append(calendar.get(11));
        sb.append(":");
        sb.append(calendar.get(12));
        sb.append(":");
        sb.append(calendar.get(13));
        sb.append(".");
        sb.append(calendar.get(14));
        TimeZone timeZone = calendar.getTimeZone();
        if (timeZone != null) {
            sb.append("(tz:");
            sb.append(timeZone.getID());
            sb.append(")");
        }
        sb.append("(t:");
        sb.append(calendar.getTimeInMillis());
        sb.append(")");
        return sb.toString();
    }

    private String t(long j2) {
        return this.f2027a.getString(R.string.vivo_comm_sharing_data_traffic_used, r(j2));
    }

    private String u(long j2) {
        float f2 = j2;
        int i2 = 0;
        while (4 > i2 && 1024.0f <= f2) {
            f2 /= 1024.0f;
            i2++;
        }
        return f2025j[i2];
    }

    private String v(long j2) {
        float f2 = j2;
        for (int i2 = 0; 4 > i2 && 1024.0f <= f2; i2++) {
            f2 /= 1024.0f;
        }
        if (j2 >= 1073741824) {
            return String.format("%.2f", Float.valueOf(f2));
        }
        return (j2 < 1024 || j2 >= 1073741824) ? String.format("%.0f", Float.valueOf(f2)) : String.format("%.1f", Float.valueOf(f2));
    }

    private int w(String str, int i2) {
        return PreferenceManager.getDefaultSharedPreferences(this.f2027a).getInt(str, i2);
    }

    private Calendar x(String str) {
        String string = PreferenceManager.getDefaultSharedPreferences(this.f2027a).getString(str, null);
        F("getLastEventCalendarFromPreference:" + str + ", data:" + string);
        Calendar calendar = Calendar.getInstance();
        if (string != null) {
            String[] strArrSplit = string.split("-");
            if (strArrSplit.length == 3) {
                calendar.set(Integer.parseInt(strArrSplit[0]), Integer.parseInt(strArrSplit[1]), Integer.parseInt(strArrSplit[2]));
            }
        }
        return calendar;
    }

    public void K() {
        ArrayList arrayList = this.f2034h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            ((AbstractC0021b) obj).a();
        }
    }

    public void O(AbstractC0021b abstractC0021b) {
        this.f2034h.add(abstractC0021b);
    }

    public void Q() {
        PreferenceManager.getDefaultSharedPreferences(this.f2027a).edit().putInt("comm_share_noisy_notify_times", 0).apply();
    }

    public void R(int i2, boolean z2, long j2, d dVar, d dVar2, boolean z3, boolean z4, boolean z5, boolean z6) {
        if (!z4 && !z5 && !z6) {
            H("showCommSharingNotify all capability no available, return");
            y();
            return;
        }
        if (!z3) {
            H("showCommSharingNotify commShareState is false, return");
            y();
            return;
        }
        if (i2 == 2) {
            H("showCommSharingNotify comm share disconn, return");
            y();
            return;
        }
        boolean zIsPhone = VmdriContext.isPhone();
        boolean zIsPad = VmdriContext.isPad();
        String strH = dVar.h();
        String strH2 = dVar2.h();
        String strI = dVar2.i();
        F("showCommSharingNotify, reason:" + J(i2) + ", forceNoisy:" + z2 + ", isLocalDevicePhone:" + zIsPhone + ", isLocalDevicePad: " + zIsPad + ", localDeviceName: " + strH + ", remoteDeviceName: " + strH2 + ", commShareState: " + z3 + ", callAvailable: " + z4 + ", smsAvailable: " + z5 + ", dataAvailable: " + z6 + ", remoteDeviceId: " + strI);
        if (VmdriContext.isPhone() && B(i2) && !j(i2)) {
            F("showCommSharingNotify, user delete notification twice, not need notify data usage");
            return;
        }
        Intent intent = new Intent("com.vivo.vmdri.intent.action.close_comm_sharing");
        intent.putExtra("remoteDeviceId", strI);
        PendingIntent broadcast = PendingIntent.getBroadcast(this.f2027a, 0, intent, 201326592);
        PendingIntent broadcast2 = PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intent.action.click_comm_sharing"), 201326592);
        PendingIntent broadcast3 = PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intent.action.delete_comm_sharing_notification"), 201326592);
        String string = this.f2027a.getString(R.string.vivo_comm_sharing_tip);
        String string2 = zIsPhone ? this.f2027a.getString(R.string.vivo_comm_sharing_phone_tips_content, strH2) : this.f2027a.getString(R.string.vivo_comm_sharing_pad_tips_content, strH2);
        if (z6) {
            string2 = string2 + " " + t(j2);
        }
        String string3 = this.f2027a.getString(R.string.vivo_comm_sharing_close);
        String str = "commShareStatus";
        if (!z2 && !C(i2)) {
            str = "silenceNotify";
        }
        Bundle bundle = new Bundle();
        bundle.putInt("vivo.summaryIconRes", R.drawable.state_comm_sharing);
        if (this.f2033g) {
            bundle.putBoolean("custom_always_expand", true);
        }
        I(null, 1, new Notification.BigTextStyle(new Notification.Builder(this.f2027a, str).setSmallIcon(R.drawable.ic_comm_sharing).setWhen(System.currentTimeMillis()).setShowWhen(true).setContentTitle(string).setContentIntent(broadcast2).setDeleteIntent(broadcast3).addAction(0, string3, broadcast).setExtras(bundle).setOnlyAlertOnce(true).setContentText(string2)).bigText(string2).build(), UserHandle.ALL);
        if (i2 == 1) {
            f.w().t();
        }
    }

    public void S(int i2) {
        a0.T().x0(1);
        F("recoverNetShareFailed, errorCode:" + e.a(i2) + ", notifyReason:8");
        V(8, i2);
    }

    public void T(boolean z2, c cVar) {
        F("showOrHideP2pConflictNotify, isShow = " + z2 + ", connectFailureInfo:" + cVar);
        if (!z2) {
            k(null, 4, UserHandle.ALL);
            return;
        }
        String strA = cVar != null ? cVar.a() : "";
        String string = this.f2027a.getString(R.string.vivo_netshare_unavailable_toast_for_p2pconflict);
        String string2 = TextUtils.isEmpty(strA) ? this.f2027a.getString(R.string.vivo_newshare_recovery_failed_without_extra_info) : this.f2027a.getString(R.string.vivo_netshare_unavaliable_auxiliary_text, strA);
        String string3 = this.f2027a.getString(R.string.vivo_comm_share_recovery);
        PendingIntent broadcast = PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intetn.action.recover_netshare_unavaliable"), 201326592);
        String str = !D() ? "silenceNotify" : "othersHighImportance";
        Bundle bundle = new Bundle();
        bundle.putInt("vivo.summaryIconRes", R.drawable.state_comm_sharing);
        if (this.f2033g) {
            bundle.putBoolean("custom_always_expand", true);
        }
        I(null, 4, new Notification.BigTextStyle(new Notification.Builder(this.f2027a, str).setSmallIcon(R.drawable.ic_comm_sharing).setWhen(System.currentTimeMillis()).setShowWhen(true).setExtras(bundle).setOnlyAlertOnce(false).addAction(0, string3, broadcast).setContentTitle(string).setContentText(string2)).bigText(string2).build(), UserHandle.ALL);
    }

    public void U() {
        PendingIntent broadcast = PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intent.action.open_auto_comm_share"), 201326592);
        PendingIntent broadcast2 = PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intent.action.never_remind"), 201326592);
        PendingIntent broadcast3 = PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intent.action.click_recommend_auto_comm_share"), 201326592);
        String string = this.f2027a.getString(R.string.vivo_recommend_auto_comm_share_title);
        String string2 = this.f2027a.getString(R.string.vivo_recommend_auto_comm_share_msg);
        String string3 = this.f2027a.getString(R.string.vivo_recommend_auto_comm_share_open);
        String string4 = this.f2027a.getString(R.string.vivo_recommend_auto_comm_share_never_remind);
        Bundle bundle = new Bundle();
        bundle.putInt("vivo.summaryIconRes", R.drawable.state_comm_sharing);
        if (this.f2033g) {
            bundle.putBoolean("custom_always_expand", true);
        }
        I(null, 3, new Notification.BigTextStyle(new Notification.Builder(this.f2027a, "recommendAlert").setSmallIcon(R.drawable.ic_comm_sharing).setWhen(System.currentTimeMillis()).setShowWhen(true).setContentTitle(string).setContentIntent(broadcast3).addAction(0, string3, broadcast).addAction(0, string4, broadcast2).setExtras(bundle).setContentText(string2)).bigText(string2).build(), UserHandle.ALL);
        f.w().u();
    }

    public void V(int i2, int i3) {
        F("showRecoveryProcessNtofication, reason:" + J(i2));
        Bundle bundle = new Bundle();
        bundle.putInt("vivo.summaryIconRes", R.drawable.state_comm_sharing);
        if (this.f2033g) {
            bundle.putBoolean("custom_always_expand", true);
        }
        Notification.Builder onlyAlertOnce = new Notification.Builder(this.f2027a, "silenceNotify").setSmallIcon(R.drawable.ic_comm_sharing).setWhen(System.currentTimeMillis()).setShowWhen(true).setExtras(bundle).setOnlyAlertOnce(false);
        if (i2 == 7) {
            onlyAlertOnce.setContentTitle(this.f2027a.getString(R.string.vivo_netshare_unavaliable_recovering));
        } else {
            onlyAlertOnce.setContentIntent(PendingIntent.getBroadcast(this.f2027a, 0, new Intent("com.vivo.vmdri.intent.action.action_recover_netshare_failed"), 201326592));
            if (i2 == 8) {
                onlyAlertOnce.setContentTitle(this.f2027a.getString(R.string.vivo_netshare_unavaliable_recovery_failed_check_guid));
            }
        }
        I(null, 5, new Notification.BigTextStyle(onlyAlertOnce).bigText("").build(), UserHandle.ALL);
    }

    public void l() {
        k(null, 5, UserHandle.ALL);
    }

    public void y() {
        k(null, 1, UserHandle.ALL);
    }

    public void z() {
        k(null, 3, UserHandle.ALL);
    }
}
