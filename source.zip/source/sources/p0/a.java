package p0;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import com.vivo.vmdri.R;
import java.util.Arrays;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {
    public a(Context context) {
        a(context);
    }

    private static void a(Context context) {
        NotificationChannel notificationChannel = new NotificationChannel("recommendAlert", context.getText(R.string.vivo_comm_share_notify_type_recommend), 3);
        notificationChannel.setBlockable(true);
        NotificationChannel notificationChannel2 = new NotificationChannel("commShareStatus", context.getText(R.string.vivo_comm_share_notify_type_alert), 4);
        notificationChannel2.setBlockable(true);
        NotificationChannel notificationChannel3 = new NotificationChannel("silenceNotify", context.getText(R.string.vivo_vmdri_notify_type_silence_notification), 3);
        notificationChannel3.setBlockable(true);
        notificationChannel3.setSound(null, null);
        NotificationChannel notificationChannel4 = new NotificationChannel("others", context.getText(R.string.vivo_comm_share_notify_type_other), 3);
        notificationChannel4.setBlockable(true);
        NotificationChannel notificationChannel5 = new NotificationChannel("othersHighImportance", context.getText(R.string.vivo_comm_share_notify_type_other), 4);
        notificationChannel5.setBlockable(true);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
        if (notificationManager != null) {
            notificationManager.createNotificationChannels(Arrays.asList(notificationChannel, notificationChannel2, notificationChannel3, notificationChannel4, notificationChannel5));
        }
    }
}
