package c0;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.util.ArraySet;
import android.util.IndentingPrintWriter;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class e0 extends Handler {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static e0 f206i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static final Object f207j = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f208a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final u0 f209b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private w.i f210c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final HashMap f211d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final HashMap f212e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final Set f213f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final Set f214g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final Set f215h;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends u0.d {
        a() {
        }

        @Override // c0.u0.d
        public void onConnectFailure(w.c cVar) {
            e0.this.F(cVar);
        }

        @Override // c0.u0.d
        public void onLocalP2pInfoChanged(String str, String str2) {
            e0.this.G(str, str2);
        }

        @Override // c0.u0.d
        public void onRemoteDeviceConnStatusChanged(w.i iVar, int i2, int i3) {
            e0.D("onRemoteDeviceConnStatusChanged, devInfo:" + iVar + ", connType:" + w.p.j(i2) + ", connStatus:" + w.p.i(i3));
            String strD = iVar.d();
            boolean zC = e0.this.C(strD);
            if (iVar.k()) {
                e0.this.f211d.put(strD, iVar);
            } else {
                e0.this.f212e.put(strD, 0);
                e0.this.f211d.remove(strD);
            }
            if (zC) {
                e0.E("onRemoteDeviceConnStatusChanged, ignore notify!Because remote vmdri process is died!");
            } else {
                e0.this.I(iVar);
            }
        }

        @Override // c0.u0.d
        public void onRemoteProcessStateChanged(String str, int i2) {
            int iIntValue = ((Integer) e0.this.f212e.getOrDefault(str, 0)).intValue();
            e0.D("onRemoteProcessStateChanged remoteBleDevId:" + str + "  old: " + w.p.l(iIntValue) + ", cur: " + w.p.l(i2));
            if (iIntValue == i2) {
                return;
            }
            e0.this.f212e.put(str, Integer.valueOf(i2));
            w.i iVar = (w.i) e0.this.f211d.get(str);
            if (iVar == null) {
                return;
            }
            if (i2 == 2) {
                e0.this.J(iVar);
            } else {
                if (iIntValue != 2 || i2 == 2) {
                    return;
                }
                e0.this.I(iVar);
            }
        }

        @Override // c0.u0.d
        public void onSdkStateChanged(int i2) {
            if (i2 == 2) {
                e0 e0Var = e0.this;
                e0Var.f210c = e0Var.f209b.s();
                e0 e0Var2 = e0.this;
                e0Var2.H(e0Var2.f210c);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class b extends w.a {
        public b(Executor executor) {
            super(executor);
        }

        public abstract void a(String str, String str2);

        public abstract void b(w.i iVar);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class c extends w.a {
        public c(Executor executor) {
            super(executor);
        }

        public abstract void a(w.c cVar);

        public abstract void b(w.i iVar);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class d {
        public abstract void a(w.i iVar);
    }

    private e0(Context context, u0 u0Var) {
        super(u0Var.getLooper());
        this.f210c = new w.i();
        this.f211d = new HashMap();
        this.f212e = new HashMap();
        this.f213f = new ArraySet();
        this.f214g = new ArraySet();
        this.f215h = new ArraySet();
        this.f208a = context;
        this.f209b = u0Var;
        u0Var.O(new a());
    }

    public static e0 A() {
        e0 e0Var = f206i;
        if (e0Var != null) {
            return e0Var;
        }
        throw new RuntimeException("DistributedDeviceManager.getInstance can't be called before create()");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void D(String str) {
        VmdriLog.d("DistributedDeviceManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void E(String str) {
        VmdriLog.w("DistributedDeviceManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void F(final w.c cVar) {
        this.f213f.forEach(new Consumer() { // from class: c0.x
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                e0.c cVar2 = (e0.c) obj;
                cVar2.invokeFromExecutor(new Runnable() { // from class: c0.a0
                    @Override // java.lang.Runnable
                    public final void run() {
                        cVar2.a(cVar);
                    }
                });
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G(final String str, final String str2) {
        D("notifyLocalDevP2pInfoChanged, curLocalP2pIp:" + str + ", curLocalP2pIfName:" + str2);
        this.f215h.forEach(new Consumer() { // from class: c0.w
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                e0.b bVar = (e0.b) obj;
                bVar.invokeFromExecutor(new Runnable() { // from class: c0.c0
                    @Override // java.lang.Runnable
                    public final void run() {
                        bVar.a(str, str);
                    }
                });
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H(final w.i iVar) {
        D("notifyLocalDeviceInfoChanged, localDevInfo:" + iVar);
        this.f215h.forEach(new Consumer() { // from class: c0.d0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                e0.b bVar = (e0.b) obj;
                bVar.invokeFromExecutor(new Runnable() { // from class: c0.u
                    @Override // java.lang.Runnable
                    public final void run() {
                        bVar.b(iVar);
                    }
                });
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I(final w.i iVar) {
        D("notifyRemoteDeviceConnStatusChanged, remoteDevInfo:" + iVar);
        this.f214g.forEach(new Consumer() { // from class: c0.y
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((e0.d) obj).a(iVar);
            }
        });
        this.f213f.forEach(new Consumer() { // from class: c0.z
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                e0.c cVar = (e0.c) obj;
                cVar.invokeFromExecutor(new Runnable() { // from class: c0.b0
                    @Override // java.lang.Runnable
                    public final void run() {
                        cVar.b(iVar);
                    }
                });
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void J(w.i iVar) {
        final w.i iVarM = w.i.m(iVar);
        iVarM.p(0);
        D("notifyRemoteDeviceDisConnForRemoteProcDied, notifyDevInfo:" + iVarM);
        this.f214g.forEach(new Consumer() { // from class: c0.s
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((e0.d) obj).a(iVarM);
            }
        });
        this.f213f.forEach(new Consumer() { // from class: c0.v
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                e0.c cVar = (e0.c) obj;
                cVar.invokeFromExecutor(new Runnable() { // from class: c0.t
                    @Override // java.lang.Runnable
                    public final void run() {
                        cVar.b(iVar);
                    }
                });
            }
        });
    }

    public static e0 y(Context context, u0 u0Var) {
        e0 e0Var;
        synchronized (f207j) {
            try {
                if (f206i != null) {
                    throw new RuntimeException("DistributedDeviceManager already created!");
                }
                e0Var = new e0(context, u0Var);
                f206i = e0Var;
            } catch (Throwable th) {
                throw th;
            }
        }
        return e0Var;
    }

    public String B() {
        return this.f210c.d();
    }

    public boolean C(String str) {
        return ((Integer) this.f212e.getOrDefault(str, 0)).intValue() == 2;
    }

    public void K(b bVar) {
        this.f215h.add(bVar);
        if (TextUtils.isEmpty(this.f210c.d())) {
            return;
        }
        bVar.b(this.f210c);
    }

    public void L(c cVar) {
        this.f213f.add(cVar);
    }

    public void M(d dVar) {
        this.f214g.add(dVar);
    }

    public void z(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("DistributedDeviceManager:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mLocalDevInfo=" + this.f210c);
        indentingPrintWriter.println("mRemoteDevInfos=" + this.f211d);
        indentingPrintWriter.println("mRemoteVmdriProcState=" + this.f212e);
        indentingPrintWriter.decreaseIndent();
    }
}
