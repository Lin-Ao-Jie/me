package c0;

import android.content.ContentResolver;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.ArraySet;
import com.vivo.vmdri.VmdriLog;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class z0 extends Handler {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static z0 f343k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static final Object f344l = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f345a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final ContentResolver f346b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final w.j f347c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final z.o f348d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f349e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f350f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f351g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f352h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f353i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final Set f354j;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends z.o.e {
        a() {
        }

        @Override // z.o.e
        public void c() {
            z0.this.n(false);
        }
    }

    private z0(Context context, Looper looper) {
        super(looper);
        this.f349e = 0;
        this.f350f = false;
        this.f351g = false;
        this.f352h = false;
        this.f353i = false;
        this.f354j = new ArraySet();
        this.f345a = context;
        this.f346b = context.getContentResolver();
        this.f347c = new w.j(context, this);
        this.f348d = new z.o(looper);
        k();
    }

    public static z0 e(Context context, Looper looper) {
        z0 z0Var;
        synchronized (f344l) {
            try {
                if (f343k != null) {
                    throw new RuntimeException("SwitchSettingsManager already created!");
                }
                z0Var = new z0(context, looper);
                f343k = z0Var;
            } catch (Throwable th) {
                throw th;
            }
        }
        return z0Var;
    }

    public static z0 f() {
        z0 z0Var = f343k;
        if (z0Var != null) {
            return z0Var;
        }
        throw new RuntimeException("SwitchSettingsManager.getInstance can't be called before create()");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g(b bVar) {
        bVar.a(this.f349e);
    }

    private static void h(String str) {
        VmdriLog.d("SwitchSettingsManager", str);
    }

    private static void i(String str) {
        VmdriLog.e("SwitchSettingsManager", str);
    }

    private void j(final int i2) {
        h("notifyVmdriSwitchStatusChanged, switchStatus: (" + i2 + ")" + w.p.f(i2));
        this.f354j.forEach(new Consumer() { // from class: c0.w0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                z0.b bVar = (z0.b) obj;
                bVar.invokeFromExecutor(new Runnable() { // from class: c0.y0
                    @Override // java.lang.Runnable
                    public final void run() {
                        bVar.a(i);
                    }
                });
            }
        });
    }

    private void k() {
        this.f348d.F(new a());
        n(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void n(boolean z2) {
        boolean z3;
        StringBuilder sb = new StringBuilder();
        sb.append("updateSwitchStatusAndNotify (");
        sb.append("forceNotify:");
        sb.append(z2);
        sb.append(") ");
        boolean zP = this.f348d.p();
        boolean zT = this.f348d.t();
        boolean zR = this.f348d.r();
        boolean zN = this.f348d.n();
        int i2 = zT ? (zP ? 1 : 0) | 2 : zP ? 1 : 0;
        if (zR) {
            i2 = (i2 == true ? 1 : 0) | 4;
        }
        if (zN) {
            i2 = (i2 == true ? 1 : 0) | 8;
        }
        if (this.f350f != zP) {
            sb.append("[call enable changed:" + this.f350f + "->" + zP + "]");
            this.f350f = zP;
        }
        if (this.f351g != zT) {
            sb.append("[sms enable changed:" + this.f351g + "->" + zT + "]");
            this.f351g = zT;
        }
        if (this.f352h != zR) {
            sb.append("[data enable changed:" + this.f352h + "->" + zR + "]");
            this.f352h = zR;
        }
        if (this.f353i != zN) {
            sb.append("[auto conn enable changed:" + this.f353i + "->" + zN + "]");
            this.f353i = zN;
        }
        if (this.f349e != i2) {
            sb.append("[switch status changed:");
            sb.append(w.p.f(this.f349e));
            sb.append("->");
            sb.append(w.p.f(i2));
            sb.append("]");
            this.f349e = i2;
            z3 = true;
        } else {
            z3 = false;
        }
        h(sb.toString());
        if (z3 || z2) {
            j(this.f349e);
        }
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        int i2 = message.what;
        i("Unknown msg.what: " + message.what);
    }

    public void l(final b bVar) {
        h("registerVmdriSwitchStatusCallBack: " + bVar);
        this.f354j.add(bVar);
        bVar.invokeFromExecutor(new Runnable() { // from class: c0.x0
            @Override // java.lang.Runnable
            public final void run() {
                this.f337a.g(bVar);
            }
        });
    }

    public void m(boolean z2) {
        this.f348d.G(z2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class b extends w.a {
        public b(Executor executor) {
            super(executor);
        }

        public void a(int i2) {
        }
    }
}
