package c0;

import android.annotation.NonNull;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemProperties;
import android.util.ArraySet;
import android.util.IndentingPrintWriter;
import com.vivo.commshare.ICommShareAudioStateListener;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class u0 extends Handler {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    protected static u0 f318l;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f319a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f320b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected w.i f321c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected ConcurrentHashMap f322d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final HashMap f323e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private b f324f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private e f325g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private f f326h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final Set f327i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final Set f328j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f329k;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private byte[] f330a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f331b;

        public a(byte[] bArr, int i2) {
            this.f330a = bArr;
            this.f331b = i2;
        }

        public int a() {
            return this.f331b;
        }

        public byte[] b() {
            return this.f330a;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class b {
        public abstract void a(String str, byte[] bArr, int i2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class f {
    }

    protected u0(Context context, Looper looper) {
        super(looper);
        this.f320b = 1;
        this.f321c = new w.i();
        this.f322d = new ConcurrentHashMap();
        this.f323e = new HashMap();
        this.f327i = new ArraySet();
        this.f328j = new ArraySet();
        this.f329k = SystemProperties.getBoolean("ro.vivo.comm.share", false);
        B("created, supportCommShare:" + this.f329k);
        this.f319a = context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A(String str, w.b bVar) {
        this.f325g.b(str, bVar);
    }

    private static void B(String str) {
        VmdriLog.d("DistributedSdk", str);
    }

    private static void C(String str) {
        VmdriLog.e("DistributedSdk", str);
    }

    private static void D(String str) {
        VmdriLog.w("DistributedSdk", str);
    }

    public static String V(int i2) {
        if (i2 == 0) {
            return "SDK_UNKNOWN";
        }
        if (i2 == 1) {
            return "SDK_DISCONNECTED";
        }
        if (i2 == 2) {
            return "SDK_CONNECTED";
        }
        return "SDK UNSUPPORTED STATE(" + i2 + ")";
    }

    public static /* synthetic */ boolean b(int i2, int i3) {
        return (i2 & w.p.g(i3)) == w.p.g(i3);
    }

    private void p(String str, a aVar) {
        D("addPendingQueue:" + str);
        ArrayList arrayList = (ArrayList) this.f323e.get(str);
        if (arrayList != null) {
            arrayList.add(aVar);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(aVar);
        this.f323e.put(str, arrayList2);
    }

    public static u0 r() {
        u0 u0Var = f318l;
        if (u0Var != null) {
            return u0Var;
        }
        throw new RuntimeException("DistributedSdkInterface.getInstance can't be called before create()");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y(w.i iVar, int i2) {
        iVar.n(i2);
        I(iVar, i2, 2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z(String str, w.b bVar) {
        this.f325g.a(str, bVar);
    }

    protected void E(final w.c cVar) {
        this.f328j.forEach(new Consumer() { // from class: c0.f0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((u0.d) obj).onConnectFailure(cVar);
            }
        });
    }

    protected void F(final String str, final String str2) {
        this.f328j.forEach(new Consumer() { // from class: c0.n0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((u0.d) obj).onLocalP2pInfoChanged(str, str2);
            }
        });
    }

    protected void G(final String str, final int i2) {
        B("notifyProcessStateChanged, remoteBleDevId:" + str + ", curState:" + w.p.l(i2));
        this.f328j.forEach(new Consumer() { // from class: c0.l0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((u0.d) obj).onRemoteProcessStateChanged(str, i2);
            }
        });
        this.f327i.forEach(new Consumer() { // from class: c0.m0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                u0.c cVar = (u0.c) obj;
                cVar.invokeFromExecutor(new Runnable() { // from class: c0.j0
                    @Override // java.lang.Runnable
                    public final void run() {
                        cVar.b(str, i);
                    }
                });
            }
        });
    }

    protected void H(String str, byte[] bArr, int i2) {
        b bVar = this.f324f;
        if (bVar != null) {
            bVar.a(str, bArr, i2);
        } else {
            p(str, new a(bArr, i2));
        }
    }

    protected void I(w.i iVar, final int i2, final int i3) {
        w.i iVarM = (w.i) this.f322d.get(iVar.d());
        B("notifyRemoteDeviceConnStatusChanged start, devInfoFromSdk:" + iVar + ", connType:" + w.p.j(i2) + ", connStatus:" + w.p.i(i3) + ", cacheRemoteDevInfo:" + iVarM);
        StringBuilder sb = new StringBuilder("notifyRemoteDeviceConnStatusChanged end, ");
        if (iVarM == null && i3 == 1) {
            sb.append("add a dev ");
            iVarM = w.i.m(iVar);
            iVarM.p(w.p.g(i2));
            this.f322d.put(iVar.d(), iVarM);
        } else if (iVarM != null && i3 == 1) {
            sb.append("add a conn ");
            iVarM.a(i2);
        } else if (iVarM == null || i3 == 1) {
            sb.append("disconnect a non-existent device !!!!! ");
        } else {
            iVarM.n(i2);
            if (iVarM.c() == 0) {
                sb.append("remove a dev ");
                this.f322d.remove(iVarM.d());
            } else {
                sb.append("remove a conn ");
            }
        }
        if (iVarM == null) {
            C(sb.toString());
            return;
        }
        sb.append("now sdk dev info:");
        sb.append(iVarM.toString());
        B(sb.toString());
        final w.i iVarM2 = w.i.m(iVarM);
        this.f328j.forEach(new Consumer() { // from class: c0.h0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((u0.d) obj).onRemoteDeviceConnStatusChanged(iVarM2, i2, i3);
            }
        });
        this.f327i.forEach(new Consumer() { // from class: c0.i0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                u0.c cVar = (u0.c) obj;
                cVar.invokeFromExecutor(new Runnable() { // from class: c0.k0
                    @Override // java.lang.Runnable
                    public final void run() {
                        cVar.a(iVar, i, i);
                    }
                });
            }
        });
    }

    protected void J(final int i2) {
        if (this.f320b != i2) {
            B("sdk state: " + V(this.f320b) + " -> " + V(i2));
            this.f320b = i2;
            if (i2 == 2) {
                this.f321c = t();
            } else {
                for (final w.i iVar : this.f322d.values()) {
                    final int iC = iVar.c();
                    IntStream.rangeClosed(1, 3).filter(new IntPredicate() { // from class: c0.o0
                        @Override // java.util.function.IntPredicate
                        public final boolean test(int i3) {
                            return u0.b(iC, i3);
                        }
                    }).forEach(new IntConsumer() { // from class: c0.p0
                        @Override // java.util.function.IntConsumer
                        public final void accept(int i3) {
                            this.f287a.y(iVar, i3);
                        }
                    });
                    iVar.p(0);
                }
                this.f322d.clear();
                this.f323e.clear();
            }
            this.f328j.forEach(new Consumer() { // from class: c0.q0
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    ((u0.d) obj).onSdkStateChanged(i2);
                }
            });
            this.f327i.forEach(new Consumer() { // from class: c0.r0
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    u0.c cVar = (u0.c) obj;
                    cVar.invokeFromExecutor(new Runnable() { // from class: c0.g0
                        @Override // java.lang.Runnable
                        public final void run() {
                            cVar.c(i);
                        }
                    });
                }
            });
        }
    }

    public void K(final String str, final w.b bVar) {
        e eVar = this.f325g;
        if (eVar == null) {
            bVar.onResult(27, "not ready");
        } else {
            eVar.invokeFromExecutor(new Runnable() { // from class: c0.s0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f308a.z(str, bVar);
                }
            });
        }
    }

    public void L(final String str, final w.b bVar) {
        e eVar = this.f325g;
        if (eVar == null) {
            bVar.onResult(27, "not ready");
        } else {
            eVar.invokeFromExecutor(new Runnable() { // from class: c0.t0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f313a.A(str, bVar);
                }
            });
        }
    }

    void M(b bVar) {
        if (bVar == null) {
            throw new IllegalArgumentException("DataReceiver must be not null!");
        }
        if (this.f324f != null) {
            throw new IllegalArgumentException("Duplicate registration of DataReceiver is not allowed!");
        }
        B("registerDataReceiver:" + bVar);
        this.f324f = bVar;
        for (String str : this.f323e.keySet()) {
            ArrayList arrayList = (ArrayList) this.f323e.get(str);
            B("dispatch pending data remoteDevId:" + str + "datas.size:" + arrayList.size());
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                a aVar = (a) obj;
                B("dispatch pending data remoteDevId:" + str + "data.len:" + aVar.b().length);
                this.f324f.a(str, aVar.b(), aVar.a());
            }
        }
        this.f323e.clear();
    }

    public void N(c cVar) {
        this.f327i.add(cVar);
        if (cVar != null) {
            B("registerDistributedSdkCallback:" + cVar + " notify sdk state when register callback");
            cVar.c(this.f320b);
        }
    }

    public void O(d dVar) {
        this.f328j.add(dVar);
    }

    public void P(e eVar) {
        this.f325g = eVar;
    }

    public void Q(f fVar) {
        this.f326h = fVar;
    }

    public void R(String str, int i2) {
        S(str, i2);
    }

    protected abstract void S(String str, int i2);

    public void T(String str, int i2, int i3, int i4, int i5) {
        U(str, i2, i3, i4, i5);
    }

    protected abstract void U(String str, int i2, int i3, int i4, int i5);

    public int W(String str, byte[] bArr, int i2) {
        return X(str, bArr, i2);
    }

    protected abstract int X(String str, byte[] bArr, int i2);

    public void Y(int i2, Bundle bundle) {
        Z(i2, bundle);
    }

    protected abstract void Z(int i2, Bundle bundle);

    protected abstract int a0(String str, boolean z2, int i2, boolean z3);

    public int b0(String str, boolean z2, int i2, boolean z3) {
        return a0(str, z2, i2, z3);
    }

    public void c0() {
        sendEmptyMessage(1);
    }

    public int d0(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) {
        return e0(str, bundle, iCommShareAudioStateListener);
    }

    protected abstract int e0(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener);

    protected abstract void f0();

    public void g0(String str) {
        h0(str);
    }

    protected abstract void h0(String str);

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        if (message.what != 1) {
            return;
        }
        f0();
    }

    public void i0(String str, int i2) {
        j0(str, i2);
    }

    protected abstract void j0(String str, int i2);

    public void k0(String str) {
        l0(str);
    }

    protected abstract void l0(String str);

    public void m0(c cVar) {
        this.f327i.remove(cVar);
    }

    public void q(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("DistributedSdk:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mConnSdkState=" + V(this.f320b) + "(" + this.f320b + ")");
        StringBuilder sb = new StringBuilder();
        sb.append("mLocalSdkDevInfo=");
        sb.append(this.f321c);
        indentingPrintWriter.println(sb.toString());
        indentingPrintWriter.println("mRemoteDevs=" + this.f322d);
        indentingPrintWriter.println("mPendingRecvData Size=" + this.f323e.size());
        indentingPrintWriter.decreaseIndent();
    }

    public w.i s() {
        return this.f321c;
    }

    public w.i t() {
        return u();
    }

    protected abstract w.i u();

    public boolean v() {
        return this.f329k;
    }

    public void w(String str, int i2) {
        x(str, i2);
    }

    protected abstract void x(String str, int i2);

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class c extends w.a {
        public c(Executor executor) {
            super(executor);
        }

        public void c(int i2) {
        }

        public void b(String str, int i2) {
        }

        public void a(w.i iVar, int i2, int i3) {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class d {
        public abstract void onRemoteDeviceConnStatusChanged(w.i iVar, int i2, int i3);

        public abstract void onSdkStateChanged(int i2);

        public void onConnectFailure(w.c cVar) {
        }

        public void onLocalDeviceInfoChanged(@NonNull w.i iVar) {
        }

        public void onRemoteDeviceInfoChanged(@NonNull w.i iVar) {
        }

        public void onLocalP2pInfoChanged(String str, String str2) {
        }

        public void onRemoteProcessStateChanged(String str, int i2) {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class e extends w.a {
        public e(Executor executor) {
            super(executor);
        }

        public void a(String str, w.b bVar) {
        }

        public void b(String str, w.b bVar) {
        }
    }
}
