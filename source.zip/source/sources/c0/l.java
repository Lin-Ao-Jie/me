package c0;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.text.TextUtils;
import com.vivo.vmdri.ThreadManager;
import com.vivo.vmdri.VmdriLog;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.IntUnaryOperator;
import java.util.function.ToIntFunction;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class l extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f244a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f245b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f246c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Context f247d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final r f248e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final b f249f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final String f250g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f251h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private List f252i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final ArrayList f253j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final ConcurrentHashMap f254k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final List f255l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private final PriorityQueue f256m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private a1 f257n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f258o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private String f259p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private String f260q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private final AtomicInteger f261r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private final AtomicInteger f262s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f263t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private boolean f264u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f265v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private volatile int f266w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private int f267x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private int f268y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private r.c f269z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends r.c {
        a(String str, int i2, String str2) {
            super(str, i2, str2);
        }

        @Override // c0.r.c
        public void b(w.i iVar) {
            l.this.I("onConnTypeBitmaskChanged, remoteDevInfo:" + iVar);
            if (!Objects.equals(l.this.f250g, iVar.d())) {
                l.this.J("onConnTypeBitmaskChanged, error remote dev id, channel remoteDevId:" + l.this.f250g + ", notifyDevInfo:" + iVar);
            }
            if (l.this.hasMessages(1)) {
                l.this.removeMessages(1);
            }
            l lVar = l.this;
            lVar.sendMessageAtFrontOfQueue(lVar.obtainMessage(1, iVar));
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class c {

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private static final Object f271e = new Object();

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private static c f272f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static int f273g;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private e0.a f274a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final e f275b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final ArrayList f276c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private c f277d;

        private c(e0.a aVar, int i2) {
            e eVar = new e();
            this.f275b = eVar;
            this.f276c = new ArrayList();
            this.f274a = aVar;
            eVar.c(i2);
        }

        public static c f(e0.a aVar, int i2) {
            synchronized (f271e) {
                try {
                    c cVar = f272f;
                    if (cVar == null) {
                        return new c(aVar, i2);
                    }
                    f272f = cVar.f277d;
                    cVar.f277d = null;
                    f273g--;
                    cVar.f274a = aVar;
                    cVar.f276c.clear();
                    cVar.f275b.c(i2);
                    return cVar;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public void a(int i2) {
            e eVar = new e();
            eVar.c(i2);
            this.f276c.add(eVar);
        }

        public e0.a b() {
            return this.f274a;
        }

        public long c() {
            return this.f275b.b();
        }

        public long d() {
            e eVar;
            if (this.f276c.size() > 0) {
                ArrayList arrayList = this.f276c;
                eVar = (e) arrayList.get(arrayList.size() - 1);
            } else {
                eVar = this.f275b;
            }
            return eVar.b();
        }

        public boolean e() {
            return this.f274a.d();
        }

        public void g() {
            this.f274a = null;
            this.f275b.a();
            this.f276c.clear();
            synchronized (f271e) {
                try {
                    int i2 = f273g;
                    if (i2 < 25) {
                        this.f277d = f272f;
                        f272f = this;
                        f273g = i2 + 1;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public String toString() {
            return "DataPacketCache{DataPacket:" + this.f274a + ", FirstTransmissionRecord:" + this.f275b + ", RetransmissionRecords:" + this.f276c + '}';
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class d extends w.a {
        public d(Executor executor) {
            super(executor);
        }

        public abstract void a(l lVar, e0.a aVar);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private long f278a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f279b;

        public void a() {
            this.f278a = -1L;
            this.f279b = 0;
        }

        public long b() {
            return this.f278a;
        }

        public void c(int i2) {
            this.f279b = i2;
            this.f278a = SystemClock.elapsedRealtime();
        }

        public String toString() {
            return "RTR{TT:" + this.f278a + ", Phy:" + w.p.j(this.f279b) + '}';
        }

        private e() {
            this.f278a = -1L;
            this.f279b = 0;
        }
    }

    l(Context context, r rVar, b bVar, String str, int i2) {
        super(ThreadManager.getsVmdriDataChannelLooper());
        this.f252i = new ArrayList();
        this.f253j = new ArrayList();
        this.f254k = new ConcurrentHashMap();
        this.f255l = new ArrayList();
        this.f256m = new PriorityQueue(Comparator.comparingInt(new ToIntFunction() { // from class: c0.d
            @Override // java.util.function.ToIntFunction
            public final int applyAsInt(Object obj) {
                return ((e0.a) obj).f1605g;
            }
        }));
        this.f258o = -1;
        this.f259p = "";
        this.f260q = "";
        this.f261r = new AtomicInteger(0);
        this.f262s = new AtomicInteger(0);
        this.f264u = false;
        this.f265v = false;
        this.f266w = 0;
        this.f247d = context;
        this.f250g = str;
        this.f248e = rVar;
        this.f249f = bVar;
        this.f251h = i2;
        a1 a1VarD = c1.c().d(str, i2);
        this.f257n = a1VarD;
        if (this.f251h == 1) {
            this.f258o = a1VarD.a();
        }
        if (this.f251h == 1) {
            String strA = w.g.a(7);
            this.f259p = strA;
            rVar.G(strA);
        } else {
            String strW = rVar.w();
            this.f259p = strW;
            if (TextUtils.isEmpty(strW)) {
                L("Local HS sessionId is empty");
                this.f259p = w.g.a(7);
            }
        }
        this.f244a = "DataChannel-(" + e0.a.a(i2) + ")-(" + this.f258o + ")";
        this.f245b = "(" + rVar.v() + "->" + str + ")";
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(this.f259p);
        sb.append("): ");
        this.f246c = sb.toString();
        I("DataChannel create.");
        a aVar = new a(str, this.f251h, this.f259p);
        this.f269z = aVar;
        rVar.C(aVar);
        if (h0(1)) {
            e0();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A(boolean z2) {
        if (z2) {
            removeMessages(2);
            this.f254k.clear();
        }
        if (h0(0)) {
            if (this.f251h == 1) {
                this.f248e.G("");
            }
            this.f248e.F(this.f269z);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B(e0.a aVar) {
        this.f249f.a(aVar.f1599a, aVar.f1608j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C(d dVar, e0.a aVar) {
        dVar.a(this, aVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void D(final e0.a aVar, final d dVar) {
        dVar.invokeFromExecutor(new Runnable() { // from class: c0.k
            @Override // java.lang.Runnable
            public final void run() {
                this.f237a.C(dVar, aVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E(e0.a aVar) {
        this.f249f.a(aVar.f1599a, aVar.f1608j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I(String str) {
        VmdriLog.d(this.f244a, this.f245b + this.f246c + str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void J(String str) {
        VmdriLog.e(this.f244a, this.f245b + this.f246c + str);
    }

    private void K(String str) {
        VmdriLog.i(this.f244a, this.f245b + this.f246c + str);
    }

    private void L(String str) {
        VmdriLog.w(this.f244a, this.f245b + this.f246c + str);
    }

    private e0.a M(int i2) {
        e0.a aVarF = e0.a.f();
        aVarF.f1599a = this.f248e.v();
        aVarF.f1600b = this.f250g;
        aVarF.f1601c = this.f251h;
        aVarF.f1602d = this.f259p;
        aVarF.f1603e = this.f258o;
        aVarF.f1604f = 2;
        aVarF.f1606h = i2;
        return aVarF;
    }

    private e0.a N(String str) {
        e0.a aVarF = e0.a.f();
        aVarF.f1599a = this.f248e.v();
        aVarF.f1600b = this.f250g;
        aVarF.f1601c = this.f251h;
        aVarF.f1602d = this.f259p;
        aVarF.f1603e = this.f258o;
        aVarF.f1604f = 4;
        aVarF.f1605g = this.f261r.getAndUpdate(new IntUnaryOperator() { // from class: c0.g
            @Override // java.util.function.IntUnaryOperator
            public final int applyAsInt(int i2) {
                return l.e(i2);
            }
        });
        aVarF.f1608j = str;
        return aVarF;
    }

    private e0.a O() {
        e0.a aVarF = e0.a.f();
        aVarF.f1599a = this.f248e.v();
        aVarF.f1600b = this.f250g;
        aVarF.f1601c = this.f251h;
        aVarF.f1602d = this.f259p;
        aVarF.f1603e = this.f258o;
        aVarF.f1604f = 1;
        aVarF.f1605g = this.f261r.getAndUpdate(new IntUnaryOperator() { // from class: c0.b
            @Override // java.util.function.IntUnaryOperator
            public final int applyAsInt(int i2) {
                return l.k(i2);
            }
        });
        return aVarF;
    }

    private boolean P(e0.a aVar) {
        if (this.f251h != 4 || TextUtils.isEmpty(aVar.f1608j)) {
            return false;
        }
        try {
            JSONObject jSONObject = new JSONObject(aVar.f1608j);
            return jSONObject.getInt("mdlId") == 2 && jSONObject.getInt("mId") == 4;
        } catch (JSONException e2) {
            throw new RuntimeException(e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: Q, reason: merged with bridge method [inline-methods] */
    public void F(e0.a aVar) {
        if (VmdriLog.isNormalDebugLevel()) {
            I("onRecvDataPacket:" + aVar + ", NextRecvSeq:" + this.f262s.get());
        }
        if ((aVar.f1604f & 8) == 8) {
            L("onRecvDataPacket recv stop:" + aVar);
            h0(3);
            this.f253j.clear();
            return;
        }
        if (aVar.f1605g == 0 && !aVar.d()) {
            J("onRecvDataPacket, recv seq 0 is not a syn packet, dataPacket:" + aVar);
            return;
        }
        if (this.f266w == 4 && !Objects.equals(this.f260q, aVar.f1602d)) {
            J("onRecvDataPacket, Received different remote unique id on ESTABLISHED, old remoteSessionId:" + this.f260q + ", dataPacket:" + aVar);
            this.f263t = this.f263t + 1;
            return;
        }
        if (aVar.d()) {
            z(aVar);
            return;
        }
        if (aVar.b()) {
            x(aVar);
        }
        if (aVar.c()) {
            y(aVar);
        }
    }

    private void R(boolean z2) {
        boolean z3 = z2;
        if (v() <= 0) {
            L("pollInFlightPacketsForRetransmission, not in flight DataPacket!");
            return;
        }
        if (this.f266w == 0) {
            J("pollInFlightPacketsForRetransmission, data channel is closed!");
            return;
        }
        long jU = u();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        I("pollInFlightPacketsForRetransmission, curTimestamp:" + jElapsedRealtime + ", defaultTimeout:" + jU + ", immediately:" + z3 + ", inFlightSize:" + v() + ", inFlightDataPackets:" + this.f254k);
        int iIntValue = Integer.MIN_VALUE;
        long j2 = jU;
        for (c cVar : this.f254k.values()) {
            if (jElapsedRealtime - cVar.c() >= 60000 && !z3) {
                J("pollInFlightPacketsForRetransmission, retransmission too much, so channel maybe disconnect , cause dataPacketCache:" + cVar + ", inFlightDataPackets:" + this.f254k);
                u0.r().i0(this.f250g, this.f268y);
                return;
            }
            long jD = jU - (jElapsedRealtime - cVar.d());
            if (jD <= 0 || z3) {
                cVar.a(this.f268y);
                if (!z3) {
                    L("pollInFlightPacketsForRetransmission, retransmission DataPacketCache:" + cVar);
                }
                b0(cVar.b(), true);
                if (this.f268y == 2) {
                    int size = this.f255l.size();
                    if (size > 0) {
                        iIntValue = ((Integer) this.f255l.get(size - 1)).intValue();
                        I("pollInFlightPacketsForRetransmission, criticalSeqs:" + Arrays.toString(this.f255l.toArray()) + ", maxCriticalSeq:" + iIntValue);
                    }
                    if (cVar.b().f1605g <= iIntValue && (this.f267x & 1) == 1) {
                        c0(cVar.b(), true, 1);
                    }
                }
            }
            if (jD > 0 && jD < j2) {
                j2 = jD;
            }
            z3 = z2;
        }
        I("pollInFlightPacketsForRetransmission, next poll:" + j2);
        removeMessages(2);
        sendEmptyMessageDelayed(2, j2);
    }

    private int S() {
        int i2 = 0;
        if (this.f256m.size() <= 0) {
            return 0;
        }
        I("processOfoDataPackets, expect seq:" + this.f262s.get() + ", ofo list size:" + this.f256m.size() + ", ofoDataPacketList:" + this.f256m);
        Iterator it = this.f256m.iterator();
        while (it.hasNext()) {
            final e0.a aVar = (e0.a) it.next();
            I("processOfoDataPackets, ofoDataPacket:" + aVar);
            AtomicInteger atomicInteger = this.f262s;
            int i3 = aVar.f1605g;
            if (!atomicInteger.compareAndSet(i3, (i3 + 1) % Integer.MAX_VALUE)) {
                break;
            }
            i2++;
            K("processOfoDataPackets, pop up ofo DataPacket:" + aVar);
            this.f249f.invokeFromExecutor(new Runnable() { // from class: c0.j
                @Override // java.lang.Runnable
                public final void run() {
                    this.f232a.E(aVar);
                }
            });
            it.remove();
        }
        return i2;
    }

    private void T() {
        int size = this.f253j.size();
        if (this.f266w != 4) {
            J("processPendingSend, The data channel has not been activated yet, state:" + p(this.f266w));
        }
        I("processPendingSend, start send! pending size:" + size);
        ArrayList arrayList = this.f253j;
        int size2 = arrayList.size();
        int i2 = 0;
        while (i2 < size2) {
            Object obj = arrayList.get(i2);
            i2++;
            H((e0.a) obj);
        }
        this.f253j.clear();
    }

    private int W(e0.a aVar, int i2) {
        if (!aVar.b() || this.f268y != 2 || (this.f267x & 1) != 1) {
            return i2;
        }
        int iD = this.f248e.D(aVar, 1);
        L("retrySendAckIfNeed dataPacket:" + aVar + ", rawErrorCode:" + i2 + ", newErrorCode:" + iD);
        return iD;
    }

    private int X(int i2) {
        return Y(i2, this.f268y);
    }

    private int Y(int i2, int i3) {
        e0.a aVarM = M(i2);
        c0(aVarM, false, i3);
        aVarM.g();
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: a0, reason: merged with bridge method [inline-methods] */
    public int H(e0.a aVar) {
        if (this.f266w == 0) {
            J("sendDataInternal, send data on CLOSED!");
            return 3;
        }
        if (this.f266w == 1 && !aVar.d()) {
            this.f253j.add(aVar);
            return 0;
        }
        c cVarF = c.f(aVar, this.f268y);
        c cVar = (c) this.f254k.put(Integer.valueOf(aVar.f1605g), cVarF);
        if (P(aVar)) {
            this.f255l.add(Integer.valueOf(aVar.f1605g));
        }
        if (cVar != null) {
            J("sendDataInternal, repeatedly push a data packet, prevCache:" + cVar + ", curCache:" + cVarF);
        }
        if (v() == 1) {
            f0(u());
        }
        return b0(aVar, false);
    }

    private int b0(e0.a aVar, boolean z2) {
        return c0(aVar, z2, this.f268y);
    }

    private int c0(e0.a aVar, boolean z2, int i2) {
        q(aVar);
        if (VmdriLog.isNormalDebugLevel()) {
            StringBuilder sb = new StringBuilder();
            sb.append("sendDataToSdk, (a:");
            sb.append(w.p.e(this.f267x));
            sb.append(", u:");
            sb.append(w.p.j(i2));
            sb.append(")");
            sb.append(z2 ? " retransmission " : "");
            sb.append(aVar);
            I(sb.toString());
        }
        int iD = this.f248e.D(aVar, i2);
        if (iD != 0) {
            J("sendDataToSdk error code:" + iD);
            if (aVar.b()) {
                return W(aVar, iD);
            }
        }
        return iD;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: d0, reason: merged with bridge method [inline-methods] */
    public void G(String str) {
        H(N(str));
    }

    public static /* synthetic */ int e(int i2) {
        return (i2 + 1) % Integer.MAX_VALUE;
    }

    private int e0() {
        if (this.f266w != 0) {
            final e0.a aVarO = O();
            post(new Runnable() { // from class: c0.h
                @Override // java.lang.Runnable
                public final void run() {
                    this.f222a.H(aVarO);
                }
            });
            return 0;
        }
        J("sendSynData on not established, state:" + this.f266w);
        return 3;
    }

    private void f0(long j2) {
        int iV = v();
        if (VmdriLog.isDetailDebugLevel()) {
            I("startRetransmitPoll, inFlightSize:" + iV + ", interval:" + j2);
        }
        sendEmptyMessageDelayed(2, j2);
    }

    private void g0(boolean z2) {
        int iV = v();
        if (VmdriLog.isDetailDebugLevel()) {
            I("stopRetransmit, force:" + z2 + ", inFlightSize:" + iV);
        }
        if (z2 || iV == 0) {
            removeMessages(2);
        }
    }

    private boolean h0(int i2) {
        I("updateChannelState, " + p(this.f266w) + "->" + p(i2));
        if (this.f266w == i2) {
            return false;
        }
        this.f266w = i2;
        return true;
    }

    private void i0() {
        int i2;
        int i3 = this.f267x;
        if ((i3 & 2) == 2) {
            i2 = 2;
        } else if ((i3 & 1) == 1) {
            i2 = 1;
        } else {
            i2 = (i3 & 4) == 4 ? 3 : 0;
        }
        if (i2 != this.f268y) {
            I("updatePreferredPhysicalConnTypeIfNeed, " + w.p.j(this.f268y) + "->" + w.p.j(i2));
            this.f268y = i2;
            if (i2 == 0) {
                L("updatePreferredPhysicalConnTypeIfNeed, All physical connections are broken, stop check in flight packers(retransmission)!");
                removeMessages(2);
            } else if (v() > 0) {
                R(true);
            }
        }
    }

    public static /* synthetic */ int k(int i2) {
        return (i2 + 1) % Integer.MAX_VALUE;
    }

    private void o(String str) {
        I("activateDataChannelIfNeed, reason:" + str);
        if (this.f266w != 1) {
            J("activateDataChannelIfNeed, Data channel is not in WAIT_SYN, mChannelState: " + this.f266w);
            return;
        }
        if (this.f264u && this.f265v) {
            K("activateDataChannelIfNeed, Data channel activated!");
            if (h0(4)) {
                T();
                return;
            }
            return;
        }
        K("activateDataChannelIfNeed, The data channel cannot be activated yet, Syn received:" + this.f265v + ", Syn arrives:" + this.f264u);
    }

    public static String p(int i2) {
        if (i2 == 0) {
            return "CLOSED";
        }
        if (i2 == 1) {
            return "WAIT_SYN";
        }
        if (i2 == 4) {
            return "ESTABLISHED";
        }
        return "UNKNOWN_STATE(" + i2 + ")";
    }

    private void q(e0.a aVar) {
        if (aVar.f1607i || !aVar.c() || aVar.f1608j.length() < 300) {
            return;
        }
        int length = aVar.f1608j.length();
        String strA = v0.a(aVar.f1608j);
        int length2 = !TextUtils.isEmpty(strA) ? strA.length() : length;
        if (VmdriLog.isFullDebugLevel()) {
            StringBuilder sb = new StringBuilder();
            sb.append("compressDataPacket, compressStrLen:");
            sb.append(strA != null ? Integer.valueOf(strA.length()) : null);
            sb.append(", beforeLen:");
            sb.append(length);
            sb.append(", afterLen:");
            sb.append(length2);
            I(sb.toString());
        }
        if (TextUtils.isEmpty(strA) || length2 >= length) {
            return;
        }
        aVar.f1608j = strA;
        aVar.f1607i = true;
    }

    private void r(e0.a aVar) {
        if (aVar.f1607i) {
            aVar.f1608j = v0.b(aVar.f1608j);
            aVar.f1607i = false;
        }
    }

    private long u() {
        long j2;
        int i2 = this.f268y;
        if (i2 != 1) {
            j2 = i2 != 2 ? 10000L : 3000L;
        } else {
            j2 = 20000;
        }
        if (this.f266w == 1) {
            return 3000L;
        }
        return j2;
    }

    private int v() {
        return this.f254k.size();
    }

    private void x(e0.a aVar) {
        int i2;
        if ((aVar.f1604f & 2) != 2) {
            return;
        }
        int i3 = aVar.f1603e;
        if (i3 != -1 && (i2 = this.f258o) != -1 && i3 != i2 && this.f251h == 1) {
            if (i3 > i2) {
                J("handleRecvAckPacket, recv larger uniqueId, dataPacket:" + aVar + ", mUniqueId:" + this.f258o);
                return;
            }
            if (i3 < i2) {
                L("handleRecvAckPacket, recv smaller uniqueId, dataPacket:" + aVar + ", mUniqueId:" + this.f258o);
                return;
            }
            return;
        }
        if (this.f265v && !Objects.equals(aVar.f1602d, this.f260q)) {
            J("handleRecvAckPacket, recv other sessionId, dataPacket:" + aVar + ", oldRemoteSessionId:" + this.f260q);
            return;
        }
        c cVar = (c) this.f254k.remove(Integer.valueOf(aVar.f1606h));
        boolean zRemove = this.f255l.remove(Integer.valueOf(aVar.f1606h));
        if (this.f251h == 4) {
            I("handleRecvAckPacket, ack:" + aVar.f1606h + ", needDualChannelRetransmit:" + zRemove);
        }
        if (cVar == null) {
            L("handleRecvAckPacket: recv ack, but it none send record packet, ack packet:" + aVar);
            return;
        }
        if (v() <= 0) {
            g0(false);
        }
        if (cVar.e()) {
            this.f264u = true;
            K("handleRecvAckPacket, The sent syn packet has been arrives");
            o("syn arrives");
        }
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        long jC = jElapsedRealtime - cVar.c();
        long jD = jElapsedRealtime - cVar.d();
        if (jC >= 500) {
            L("handleRecvAckPacket, calculate rtt, t:" + jC + ", l:" + jD + "ms, curTimestamp: " + jElapsedRealtime + ", for packet: " + cVar + " too slowly! ");
        } else if (VmdriLog.isNormalDebugLevel()) {
            I("handleRecvAckPacket, calculate rtt, t:" + jC + ", l:" + jD + "ms, curTimestamp: " + jElapsedRealtime + ", for packet: " + cVar);
        }
        cVar.b().g();
        cVar.g();
    }

    private void y(final e0.a aVar) {
        if ((aVar.f1604f & 4) != 4) {
            return;
        }
        if (this.f266w != 4) {
            L("handleRecvDataPacket, recv payload DataPacket not on ESTABLISHED!, mChannelState:" + this.f266w + ", dataPacket:" + aVar);
            if (!this.f265v) {
                J("handleRecvDataPacket, recv payload data packet before SYN! drop and don't ack");
                return;
            }
        }
        AtomicInteger atomicInteger = this.f262s;
        int i2 = aVar.f1605g;
        if (atomicInteger.compareAndSet(i2, (i2 + 1) % Integer.MAX_VALUE)) {
            this.f249f.invokeFromExecutor(new Runnable() { // from class: c0.i
                @Override // java.lang.Runnable
                public final void run() {
                    this.f227a.B(aVar);
                }
            });
            S();
        } else if (this.f262s.get() < aVar.f1605g) {
            L("handleRecvDataPacket, recv out of order dataPacket:" + aVar + ", expect seq:" + this.f262s.get());
            this.f256m.add(aVar);
        } else {
            L("handleRecvDataPacket drop dataPacket:" + aVar + ", expect seq:" + this.f262s.get());
        }
        int i3 = aVar.f1609k;
        X(aVar.f1605g);
        if (this.f268y == i3 || i3 == 0) {
            return;
        }
        L("handleRecvDataPacket send by:" + w.p.j(i3) + ", preferConn:" + w.p.j(this.f268y));
        Y(aVar.f1605g, i3);
    }

    private boolean z(final e0.a aVar) {
        int i2;
        if ((aVar.f1604f & 1) != 1) {
            return false;
        }
        int i3 = aVar.f1603e;
        if (i3 != -1 && (i2 = this.f258o) != -1 && i3 != i2 && this.f251h == 1) {
            if (i3 > i2) {
                J("handleRecvSynDataPacket, recv larger uniqueId, dataPacket:" + aVar + ", mUniqueId:" + this.f258o);
                this.f257n.e(aVar.f1603e);
                this.f252i.forEach(new Consumer() { // from class: c0.f
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        this.f217a.D(aVar, (l.d) obj);
                    }
                });
            } else if (i3 < i2) {
                L("handleRecvSynDataPacket, recv smaller uniqueId, dataPacket:" + aVar + ", mUniqueId:" + this.f258o);
            }
            return false;
        }
        AtomicInteger atomicInteger = this.f262s;
        int i4 = aVar.f1605g;
        if (atomicInteger.compareAndSet(i4, (i4 + 1) % Integer.MAX_VALUE)) {
            this.f265v = true;
            this.f260q = aVar.f1602d;
            this.f246c = "(" + this.f259p + "->" + this.f260q + "): ";
            K("handleRecvSynDataPacket, recv a syn packet");
            X(aVar.f1605g);
            o("recv syn");
        } else if (Objects.equals(this.f260q, aVar.f1602d)) {
            L("handleRecvSynDataPacket, recv a retransmit the packet drop and reply ack to avoid peer retransmission.");
            X(aVar.f1605g);
        } else {
            J("handleRecvSynDataPacket receive syn from another channel, drop, this channel and not reply ack, oldRemoteSessionId:" + this.f260q + ", dataPacket:" + aVar);
        }
        return true;
    }

    void U(final e0.a aVar) {
        r(aVar);
        post(new Runnable() { // from class: c0.a
            @Override // java.lang.Runnable
            public final void run() {
                this.f181a.F(aVar);
            }
        });
    }

    public void V(d dVar) {
        this.f252i.add(dVar);
    }

    public int Z(final String str) {
        if (this.f266w == 0) {
            J("sendData on CLOSED!");
            return 3;
        }
        if (this.f266w == 3) {
            J("sendData on STOP!");
            return 12;
        }
        if (str.length() <= 1536000.0d) {
            post(new Runnable() { // from class: c0.e
                @Override // java.lang.Runnable
                public final void run() {
                    this.f204a.G(str);
                }
            });
            return 0;
        }
        J("sendData, send too large packet: dataLen" + str.length() + ", drop!");
        return 11;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        int i2 = message.what;
        if (i2 == 1) {
            int iC = ((w.i) message.obj).c();
            if (iC != this.f267x) {
                this.f267x = iC;
                i0();
                return;
            }
            return;
        }
        if (i2 == 2) {
            if (v() > 0) {
                R(false);
            }
        } else {
            J("Unknown msg: " + message);
        }
    }

    void s(final boolean z2) {
        I("destroy, " + this + ", hard:" + z2);
        postAtFrontOfQueue(new Runnable() { // from class: c0.c
            @Override // java.lang.Runnable
            public final void run() {
                this.f194a.A(z2);
            }
        });
    }

    public int t() {
        return this.f251h;
    }

    @Override // android.os.Handler
    public String toString() {
        return "DataChannel{mRemoteDevId='" + this.f250g + "', mChannelId=" + e0.a.a(this.f251h) + ", mNextSendSeq=" + this.f261r + ", mNextRecvSeq=" + this.f262s + ", mState=" + p(this.f266w) + ", mUniqueId=" + this.f258o + ", mLocalSessionId=" + this.f259p + ", mRemoteSessionId=" + this.f260q + '}';
    }

    public String w() {
        return this.f250g;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class b extends w.a {
        public b(Executor executor) {
            super(executor);
        }

        public void a(String str, String str2) {
        }
    }
}
