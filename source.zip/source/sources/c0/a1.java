package c0;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;
import com.vivo.vmdri.VmdriLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f185a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f186b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ContentResolver f187c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f188d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f189e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private String f190f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f191g = b();

    public a1(Context context, String str, int i2) {
        this.f185a = "UniqueIdGenerator-" + str + "-" + e0.a.a(i2);
        this.f186b = context;
        this.f187c = context.getContentResolver();
        this.f188d = str;
        this.f189e = i2;
        this.f190f = "vmdri_channel_unique_id_" + this.f188d + "_" + this.f189e;
    }

    private int b() {
        return Settings.Global.getInt(this.f187c, this.f190f, 0);
    }

    private void c(String str) {
        VmdriLog.d(this.f185a, str);
    }

    public int a() {
        int i2 = this.f191g;
        e(i2 + 1);
        return i2;
    }

    public void d() {
        c("reset");
        e(0);
    }

    public void e(int i2) {
        this.f191g = i2;
        Settings.Global.putInt(this.f187c, this.f190f, i2);
    }

    public String toString() {
        return "UniqueIdGenerator{, mDemoteDevId='" + this.f188d + "', mChannelId=" + this.f189e + ", mKey='" + this.f190f + "', mUniqueId='" + this.f191g + "'}";
    }
}
