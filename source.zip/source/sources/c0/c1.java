package c0;

import android.content.Context;
import com.vivo.vmdri.VmdriContext;
import java.util.HashMap;
import java.util.function.Function;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c1 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static c1 f199c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final Object f200d = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f201a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private HashMap f202b = new HashMap();

    private c1(Context context) {
        this.f201a = context;
    }

    public static /* synthetic */ HashMap a(String str) {
        return new HashMap();
    }

    private a1 b(String str, int i2) {
        a1 a1Var = new a1(this.f201a, str, i2);
        ((HashMap) this.f202b.computeIfAbsent(str, new Function() { // from class: c0.b1
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return c1.a((String) obj);
            }
        })).put(Integer.valueOf(i2), a1Var);
        return a1Var;
    }

    public static synchronized c1 c() {
        try {
            if (f199c == null) {
                f199c = new c1(VmdriContext.getInstance().getApplicationContext());
            }
        } catch (Throwable th) {
            throw th;
        }
        return f199c;
    }

    public a1 d(String str, int i2) {
        HashMap map = (HashMap) this.f202b.get(str);
        return (map == null || !map.containsKey(Integer.valueOf(i2))) ? b(str, i2) : (a1) map.get(Integer.valueOf(i2));
    }

    public void e(String str, int i2) {
        a1 a1Var;
        HashMap map = (HashMap) this.f202b.get(str);
        if (map == null || (a1Var = (a1) map.get(Integer.valueOf(i2))) == null) {
            return;
        }
        a1Var.d();
    }
}
