package c0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class v0 {
    public static String a(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bytes.length);
            try {
                GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
                try {
                    gZIPOutputStream.write(bytes);
                    gZIPOutputStream.finish();
                    String strEncodeToString = Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
                    gZIPOutputStream.close();
                    byteArrayOutputStream.close();
                    return strEncodeToString;
                } catch (Throwable th) {
                    try {
                        gZIPOutputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                try {
                    byteArrayOutputStream.close();
                } catch (Throwable th4) {
                    th3.addSuppressed(th4);
                }
                throw th3;
            }
        } catch (Exception e2) {
            c("Failed to compress the data. e:" + e2);
            return null;
        }
    }

    public static String b(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(Base64.getDecoder().decode(str));
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    GZIPInputStream gZIPInputStream = new GZIPInputStream(byteArrayInputStream);
                    try {
                        byte[] bArr = new byte[1024];
                        while (true) {
                            int i2 = gZIPInputStream.read(bArr);
                            if (i2 < 0) {
                                gZIPInputStream.close();
                                byteArrayInputStream.close();
                                byte[] byteArray = byteArrayOutputStream.toByteArray();
                                byteArrayOutputStream.close();
                                String str2 = new String(byteArray, StandardCharsets.UTF_8);
                                gZIPInputStream.close();
                                byteArrayOutputStream.close();
                                byteArrayInputStream.close();
                                return str2;
                            }
                            byteArrayOutputStream.write(bArr, 0, i2);
                            try {
                                byteArrayOutputStream.close();
                            } catch (Throwable th) {
                                th.addSuppressed(th);
                            }
                            throw th;
                        }
                    } catch (Throwable th2) {
                        try {
                            gZIPInputStream.close();
                        } catch (Throwable th3) {
                            th2.addSuppressed(th3);
                        }
                        throw th2;
                    }
                } catch (Throwable th4) {
                    byteArrayOutputStream.close();
                    throw th4;
                }
            } catch (Throwable th5) {
                try {
                    byteArrayInputStream.close();
                } catch (Throwable th6) {
                    th5.addSuppressed(th6);
                }
                throw th5;
            }
        } catch (Exception e2) {
            c("Failed to decompress the data. e:" + e2);
            return null;
        }
    }

    private static void c(String str) {
        VmdriLog.e("GzipUtil", str);
    }
}
