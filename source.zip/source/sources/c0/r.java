package c0;

import android.content.Context;
import android.text.TextUtils;
import android.util.IndentingPrintWriter;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class r {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static final Object f290j = new Object();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static r f291k;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f292a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final u0 f293b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final e0 f294c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f295d = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final HashMap f296e = new HashMap();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final HashMap f297f = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final HashMap f298g = new HashMap();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final HashMap f299h = new HashMap();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final b f300i;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends e0.d {
        a() {
        }

        @Override // c0.e0.d
        public void a(w.i iVar) {
            synchronized (r.f290j) {
                try {
                    String strD = iVar.d();
                    if (iVar.k()) {
                        r.this.f296e.put(strD, iVar);
                    } else {
                        r.this.f296e.remove(strD);
                        r.this.f298g.remove(strD);
                        r.this.q(strD, "All physical disconnections or peer vmdri crash!");
                    }
                    Set set = (Set) r.this.f299h.get(strD);
                    if (set != null) {
                        Iterator it = set.iterator();
                        while (it.hasNext()) {
                            ((c) it.next()).b(iVar);
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends u0.b {
        b() {
        }

        @Override // c0.u0.b
        public void a(String str, byte[] bArr, int i2) {
            e0.a aVarM = e0.a.m(bArr);
            aVarM.k(i2);
            if (VmdriLog.isFullDebugLevel()) {
                r.x("recvData dataPacket:" + aVarM + ", remoteDevId:" + str);
            }
            if (TextUtils.isEmpty(aVarM.f1599a)) {
                aVarM.f1599a = str;
            }
            int i3 = aVarM.f1601c;
            if (i3 <= 0 || i3 > 5) {
                r.y("This channel is not supported, channelId:" + aVarM.f1601c);
                r.this.E(aVarM);
                return;
            }
            synchronized (r.f290j) {
                try {
                    if (r.this.f296e.containsKey(aVarM.f1599a)) {
                        l lVarT = r.this.t(aVarM.f1599a, aVarM.f1601c);
                        if (lVarT != null) {
                            lVarT.U(aVarM);
                        } else {
                            r.this.B(aVarM);
                        }
                        return;
                    }
                    r.y("without this device(" + aVarM.f1599a + "), drop the packet:" + aVarM);
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private String f303a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f304b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private String f305c;

        c(String str, int i2, String str2) {
            this.f303a = str;
            this.f304b = i2;
            this.f305c = str2;
        }

        public final String a() {
            return this.f303a;
        }

        public abstract void b(w.i iVar);

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj != null && getClass() == obj.getClass()) {
                c cVar = (c) obj;
                if (this.f304b == cVar.f304b && Objects.equals(this.f303a, cVar.f303a) && Objects.equals(this.f305c, cVar.f305c)) {
                    return true;
                }
            }
            return false;
        }

        public int hashCode() {
            return Objects.hash(this.f303a, Integer.valueOf(this.f304b), this.f305c);
        }

        public String toString() {
            return "RemoteDevConnTypeCallback{remoteDevId='" + this.f303a + "', channel=" + e0.a.a(this.f304b) + ", mLocalSessionId=" + this.f305c + '}';
        }
    }

    private r(Context context, u0 u0Var, e0 e0Var) {
        b bVar = new b();
        this.f300i = bVar;
        this.f292a = context;
        this.f293b = u0Var;
        this.f294c = e0Var;
        u0Var.M(bVar);
        e0Var.M(new a());
    }

    private void A(l lVar) {
        ArrayList arrayList;
        HashMap map = (HashMap) this.f298g.get(lVar.w());
        if (map == null || (arrayList = (ArrayList) map.remove(Integer.valueOf(lVar.t()))) == null) {
            return;
        }
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            e0.a aVar = (e0.a) obj;
            x("processPendingPackets:" + aVar);
            lVar.U(aVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean B(e0.a aVar) {
        x("pushPendingQueue:" + aVar);
        ArrayList arrayList = (ArrayList) ((HashMap) this.f298g.computeIfAbsent(aVar.f1599a, new Function() { // from class: c0.n
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return r.b((String) obj);
            }
        })).computeIfAbsent(Integer.valueOf(aVar.f1601c), new Function() { // from class: c0.o
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return r.a((Integer) obj);
            }
        });
        if (arrayList.isEmpty()) {
            if (aVar.f1605g == 0) {
                arrayList.add(aVar);
                return true;
            }
            z("pushPendingQueue, can't push pending queue:" + aVar);
            return false;
        }
        e0.a aVar2 = (e0.a) arrayList.get(arrayList.size() - 1);
        if (aVar2.f1605g + 1 == aVar.f1605g) {
            arrayList.add(aVar);
            return true;
        }
        z("pushPendingQueue, can't push pending queue preDataPacket:" + aVar2 + ", dataPacket" + aVar);
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:17:0x003d  */
    public void E(e0.a aVar) {
        int i2;
        e0.a aVarF = e0.a.f();
        aVarF.f1601c = aVar.f1601c;
        aVarF.f1599a = aVar.f1600b;
        aVarF.f1600b = aVar.f1599a;
        aVarF.f1604f = 8;
        synchronized (this.f296e) {
            try {
                w.i iVar = (w.i) this.f296e.get(aVarF.f1600b);
                if (iVar == null) {
                    i2 = 0;
                } else if (iVar.j()) {
                    i2 = 2;
                } else if (iVar.i()) {
                    i2 = 1;
                } else if (iVar.h()) {
                    i2 = 3;
                } else {
                    i2 = 0;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        x("sendStopMessage, stopPacket:" + aVarF + ", connType:" + w.p.j(i2));
        this.f293b.W(aVarF.f1600b, aVarF.i(), i2);
    }

    public static /* synthetic */ ArrayList a(Integer num) {
        return new ArrayList();
    }

    public static /* synthetic */ HashMap b(String str) {
        return new HashMap();
    }

    public static /* synthetic */ HashMap c(String str) {
        return new HashMap();
    }

    public static /* synthetic */ Set d(String str) {
        return new HashSet();
    }

    public static r o(Context context, u0 u0Var, e0 e0Var) {
        r rVar;
        synchronized (f290j) {
            try {
                if (f291k != null) {
                    throw new RuntimeException("DataPlaneInterface already created!");
                }
                rVar = new r(context, u0Var, e0Var);
                f291k = rVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return rVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void q(String str, String str2) {
        x("destroyAllDataChannelByRemoteDevId, remoteDevId:" + str + ", reason:" + str2);
        synchronized (f290j) {
            try {
                HashMap map = (HashMap) this.f297f.remove(str);
                if (map == null) {
                    return;
                }
                Iterator it = map.values().iterator();
                while (it.hasNext()) {
                    ((l) it.next()).s(true);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public l t(String str, int i2) {
        synchronized (f290j) {
            try {
                HashMap map = (HashMap) this.f297f.get(str);
                if (map == null) {
                    y("findDataChannel, not find this remote dev, remoteDevId:" + str + ", channelId:" + e0.a.a(i2));
                    return null;
                }
                l lVar = (l) map.get(Integer.valueOf(i2));
                if (lVar != null) {
                    return lVar;
                }
                y("findDataChannel, has dev but not find channel, remoteDevId:" + str + ", channelId:" + e0.a.a(i2));
                return null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static r u() {
        r rVar = f291k;
        if (rVar != null) {
            return rVar;
        }
        throw new RuntimeException("DataPlaneInterface.getInstance can't be called before create()");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void x(String str) {
        VmdriLog.d("DataPlaneInterface", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void y(String str) {
        VmdriLog.e("DataPlaneInterface", str);
    }

    private static void z(String str) {
        VmdriLog.w("DataPlaneInterface", str);
    }

    void C(c cVar) {
        String strA = cVar.a();
        x("registerRemoteDevConnTypeCallback, callback:" + cVar);
        if (TextUtils.isEmpty(strA)) {
            y("registerRemoteDevConnTypeCallback, callback remoteDevId is empty!");
            return;
        }
        synchronized (f290j) {
            try {
                ((Set) this.f299h.computeIfAbsent(strA, new Function() { // from class: c0.q
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return r.d((String) obj);
                    }
                })).add(cVar);
                w.i iVar = (w.i) this.f296e.get(strA);
                if (iVar != null) {
                    cVar.b(iVar);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    int D(e0.a aVar, int i2) {
        return this.f293b.W(aVar.f1600b, aVar.i(), i2);
    }

    void F(c cVar) {
        String strA = cVar.a();
        x("unregisterRemoteDevConnTypeCallback, callback:" + cVar);
        if (TextUtils.isEmpty(strA)) {
            y("unregisterRemoteDevConnTypeCallback, callback remoteDevId is empty!");
            return;
        }
        synchronized (f290j) {
            try {
                Set set = (Set) this.f299h.get(strA);
                if (set != null) {
                    set.remove(cVar);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void G(String str) {
        this.f295d = str;
    }

    public l p(String str, int i2, l.b bVar) {
        l lVar;
        x("createDataChannel remoteDevId:" + str + ", channelId:" + e0.a.a(i2));
        synchronized (f290j) {
            try {
                lVar = new l(this.f292a, this, bVar, str, i2);
                l lVar2 = (l) ((HashMap) this.f297f.computeIfAbsent(str, new Function() { // from class: c0.p
                    @Override // java.util.function.Function
                    public final Object apply(Object obj) {
                        return r.c((String) obj);
                    }
                })).put(Integer.valueOf(i2), lVar);
                if (lVar2 != null) {
                    y("createDataChannel on prevDataChannel is not destroy! prevDataChannel:" + lVar2);
                    lVar2.s(true);
                }
                A(lVar);
            } catch (Throwable th) {
                throw th;
            }
        }
        return lVar;
    }

    public void r(l lVar, boolean z2) {
        x("destroyDataChannel, hard:" + z2 + ", dataChannel:" + lVar);
        if (lVar == null) {
            return;
        }
        synchronized (f290j) {
            try {
                HashMap map = (HashMap) this.f297f.get(lVar.w());
                if (map != null && z2) {
                    map.remove(Integer.valueOf(lVar.t()));
                }
                lVar.s(z2);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void s(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("DataPlaneInterface:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mRemoteDevInfos=" + this.f296e);
        indentingPrintWriter.println("mDataChannels=" + this.f297f);
        for (String str : this.f298g.keySet()) {
            indentingPrintWriter.println("pendingPacketQueue remoteDevId=" + str + ", size:" + ((HashMap) this.f298g.get(str)).size());
            indentingPrintWriter.increaseIndent();
            StringBuilder sb = new StringBuilder();
            sb.append("pendingPacketQueue=");
            sb.append(this.f298g);
            indentingPrintWriter.println(sb.toString());
            indentingPrintWriter.decreaseIndent();
            indentingPrintWriter.flush();
        }
        indentingPrintWriter.decreaseIndent();
    }

    public String v() {
        return this.f293b.s().d();
    }

    public String w() {
        return this.f295d;
    }
}
