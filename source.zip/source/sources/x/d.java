package x;

import a0.g0;
import a0.w;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import c0.l;
import c0.r;
import c0.u0;
import com.vivo.commshare.CommDevInfo;
import com.vivo.commshare.ICommShareAudioStateListener;
import com.vivo.commshare.IDataChannel;
import com.vivo.commshare.IDataListener;
import com.vivo.commshare.IDeviceListener;
import com.vivo.commshare.IVmdriComm;
import com.vivo.commshare.framework.base.Constants;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.ctrl.h;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class d extends IVmdriComm.Stub {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final f f2248a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f2249b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final h f2250c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final c f2251d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final g0 f2252e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final l.b f2253f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f2255h;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private w.d f2260m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f2261n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private l f2262o;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private w.d f2254g = new w.d(true);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final ConcurrentHashMap f2256i = new ConcurrentHashMap();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final ConcurrentHashMap f2257j = new ConcurrentHashMap();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final ConcurrentHashMap f2258k = new ConcurrentHashMap();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final ConcurrentHashMap f2259l = new ConcurrentHashMap();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends l.b {
        a(Executor executor) {
            super(executor);
        }

        @Override // c0.l.b
        public void a(String str, String str2) {
            super.a(str, str2);
            if (d.this.f2260m != null && d.this.f2260m.i().equals(str)) {
                d.this.B(str, f0.a.d(str2));
                return;
            }
            d.E("Received a packet from a wrong device id, remoteDevId:" + str + ", mServerDevice:" + d.this.f2260m);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class b implements IBinder.DeathRecipient {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f2264a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private IBinder f2265b;

        b(int i2, IBinder iBinder) {
            this.f2264a = i2;
            this.f2265b = iBinder;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            d.this.A(this.f2264a);
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            d.F("binderDied : " + Constants.getBusinessTypeName(this.f2264a));
            d();
            d.this.f2248a.post(new Runnable() { // from class: x.e
                @Override // java.lang.Runnable
                public final void run() {
                    this.f2271a.b();
                }
            });
        }

        public void c() throws RemoteException {
            this.f2265b.linkToDeath(this, 0);
        }

        public synchronized void d() {
            IBinder iBinder = this.f2265b;
            if (iBinder != null) {
                iBinder.unlinkToDeath(this, 0);
                this.f2265b = null;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class c extends w {
        public c(Executor executor) {
            super(executor);
        }

        @Override // a0.w
        public void c(w.d dVar) {
            super.c(dVar);
            d.D("onLocalDeviceStateChanged, oldLocalDevice:" + d.this.f2254g + ", newLocalDevice:" + dVar);
            w.d dVar2 = d.this.f2254g;
            d.this.f2254g = dVar;
            if (d.this.f2260m == null) {
                return;
            }
            if (Objects.equals(dVar2.h(), dVar.h()) && Objects.equals(dVar2.m(), dVar.m()) && Objects.equals(dVar2.o(), dVar.o())) {
                return;
            }
            d.this.G(dVar);
        }

        @Override // a0.w
        public void d(w.d dVar, boolean z2) {
            super.d(dVar, z2);
            d.D("onRemoteDeviceConnected: " + dVar + ", isUserTarget: " + z2);
            if (d.this.f2260m != null) {
                d.E("serious error! client can only connect to one device, old:" + d.this.f2260m + ", new:" + dVar);
                return;
            }
            d.this.f2260m = dVar;
            d.this.f2262o = r.u().p(dVar.i(), 5, d.this.f2253f);
            d.this.M();
            d dVar2 = d.this;
            dVar2.I(dVar2.f2260m);
        }

        @Override // a0.w
        public void e(w.d dVar, boolean z2) {
            super.e(dVar, z2);
            d.D("onRemoteDeviceDisConnected: " + dVar + ", isUserTarget: " + z2);
            if (d.this.f2260m == null || !d.this.f2260m.i().equalsIgnoreCase(dVar.i())) {
                d.E("serious error! disconnect the device repeatedly, or disconnect a device that has not been connected before!, old:" + d.this.f2260m + ", new:" + dVar);
                return;
            }
            d dVar2 = d.this;
            dVar2.J(dVar2.f2260m);
            d.this.O(dVar.i(), 0);
            r.u().r(d.this.f2262o, true);
            d.this.f2262o = null;
            d.this.f2260m = null;
        }

        @Override // a0.w
        public void f(w.d dVar) {
            super.f(dVar);
            d.D("onRemoteDeviceStateChanged, oldDevice:" + d.this.f2260m + ", newDevice:" + dVar);
            if (d.this.f2260m == null || !Objects.equals(d.this.f2260m.i(), dVar.i())) {
                return;
            }
            w.d dVar2 = d.this.f2260m;
            d.this.f2260m = dVar;
            if (Objects.equals(dVar2.h(), dVar.h()) && dVar2.f() == dVar.f() && Objects.equals(dVar2.m(), dVar.m()) && Objects.equals(dVar2.o(), dVar.o())) {
                return;
            }
            d.this.K(dVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: x.d$d, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class BinderC0026d extends IDataChannel.Stub {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f2268a;

        public BinderC0026d(int i2) {
            this.f2268a = i2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            d.this.y(this.f2268a);
        }

        @Override // com.vivo.commshare.IDataChannel
        public int ready() {
            d.D("ready, businessType:(" + this.f2268a + "):" + Constants.getBusinessTypeName(this.f2268a));
            d.this.f2248a.post(new Runnable() { // from class: x.f
                @Override // java.lang.Runnable
                public final void run() {
                    this.f2272a.b();
                }
            });
            return 0;
        }

        @Override // com.vivo.commshare.IDataChannel
        public int sendData(String str, byte[] bArr) {
            StringBuilder sb = new StringBuilder();
            sb.append("sendData, remoteDevId:");
            sb.append(str);
            sb.append(", businessType:");
            sb.append(Constants.getBusinessTypeName(this.f2268a));
            sb.append(", dataLen:");
            sb.append(bArr != null ? Integer.valueOf(bArr.length) : null);
            d.D(sb.toString());
            return d.this.L(this.f2268a, str, bArr);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class e extends g0 {
        public e(Executor executor) {
            super(executor);
        }

        @Override // a0.g0
        public void b(String str, int i2) {
            super.c(str, i2);
            d.D("onBusinessStateIndication, remoteDevId:" + str + ", newBusinessStateBitmask:" + Constants.convertBusinessTypeBitmaskToString(i2));
            d.this.N(str, i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class f extends Handler {
        public f(d dVar, Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            d.E("unsupported message type:" + message.what);
        }
    }

    public d(Context context, Looper looper, h hVar) {
        this.f2249b = context;
        this.f2250c = hVar;
        final f fVar = new f(this, looper);
        this.f2248a = fVar;
        c cVar = new c(new Executor() { // from class: x.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                fVar.post(runnable);
            }
        });
        this.f2251d = cVar;
        g0 eVar = new e(new Executor() { // from class: x.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                fVar.post(runnable);
            }
        });
        this.f2252e = eVar;
        hVar.g(cVar);
        hVar.b(eVar);
        this.f2253f = new a(new Executor() { // from class: x.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                fVar.post(runnable);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A(int i2) {
        D("clearLocalCache, businessType:" + Constants.getBusinessTypeName(i2));
        this.f2255h = this.f2255h & (~Constants.getBitMaskForBusinessType(i2));
        this.f2257j.remove(Integer.valueOf(i2));
        this.f2256i.remove(Integer.valueOf(i2));
        this.f2259l.remove(Integer.valueOf(i2));
        this.f2258k.remove(Integer.valueOf(i2));
        M();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void B(String str, f0.a aVar) {
        D("onRecvMessage:" + aVar);
        IDataListener iDataListener = (IDataListener) this.f2258k.get(Integer.valueOf(aVar.f1622a));
        if (iDataListener != null) {
            try {
                iDataListener.onDataRecv(str, aVar.f1623b);
                return;
            } catch (RemoteException e2) {
                e2.printStackTrace();
                return;
            }
        }
        E("handleCommMessage, not dataListener for remoteDevId:" + str + ", commMessage:" + aVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C(String str, int i2, int i3) {
        H(str, i3, (i2 & Constants.getBitMaskForBusinessType(i3)) != 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void D(String str) {
        VmdriLog.d("CommClient", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void E(String str) {
        VmdriLog.e("CommClient", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void F(String str) {
        VmdriLog.i("CommClient", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G(w.d dVar) {
        D("notifyLocalDeviceStateChanged, localDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        for (Integer num : this.f2256i.keySet()) {
            try {
                ((IDeviceListener) this.f2256i.get(num)).onLocalDeviceStateChanged(commDevInfoA);
            } catch (RemoteException | RuntimeException e2) {
                E("notifyLocalDeviceStateChanged error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    private void H(String str, int i2, boolean z2) {
        D("notifyRemoteBusinessState, remoteDevId:" + str + ", businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2) + ", ready:" + z2);
        IDeviceListener iDeviceListener = (IDeviceListener) this.f2256i.get(Integer.valueOf(i2));
        if (iDeviceListener == null) {
            return;
        }
        try {
            iDeviceListener.onRemoteReady(str, z2);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I(w.d dVar) {
        D("notifyRemoteDeviceConnected, remoteDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        CommDevInfo commDevInfoA2 = this.f2254g.a();
        for (Integer num : this.f2256i.keySet()) {
            IDeviceListener iDeviceListener = (IDeviceListener) this.f2256i.get(num);
            try {
                iDeviceListener.onRemoteDeviceConnected(commDevInfoA);
                iDeviceListener.onLocalDeviceStateChanged(commDevInfoA2);
            } catch (RemoteException | RuntimeException e2) {
                E("notifyRemoteDeviceConnected error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void J(w.d dVar) {
        D("notifyRemoteDeviceDisConnected, remoteDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        for (Integer num : this.f2256i.keySet()) {
            try {
                ((IDeviceListener) this.f2256i.get(num)).onRemoteDeviceDisconnected(commDevInfoA);
            } catch (RemoteException | RuntimeException e2) {
                E("notifyRemoteDeviceDisConnected error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K(w.d dVar) {
        D("notifyRemoteDeviceStateChanged, remoteDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        for (Integer num : this.f2256i.keySet()) {
            try {
                ((IDeviceListener) this.f2256i.get(num)).onRemoteDeviceStateChanged(commDevInfoA);
            } catch (RemoteException | RuntimeException e2) {
                E("notifyRemoteDeviceStateChanged error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int L(int i2, String str, byte[] bArr) {
        int bitMaskForBusinessType = Constants.getBitMaskForBusinessType(i2);
        if ((this.f2255h & bitMaskForBusinessType) == 0) {
            E("sendDataInternal error, local dev not ready, remoteDevId:" + str + ", businessType:" + i2 + ", businessTypeBitMask:" + bitMaskForBusinessType + ", LocalBusinessTypeBitMask:" + this.f2255h + ", mServerDevice:" + this.f2260m);
            return 4;
        }
        w.d dVar = this.f2260m;
        if (dVar == null || !Objects.equals(str, dVar.i())) {
            E("sendDataInternal error, remote dev not conn, remoteDevId:" + str + ", mServerDevice:" + this.f2260m);
            return 3;
        }
        if ((this.f2261n & bitMaskForBusinessType) != 0) {
            f0.a aVar = new f0.a();
            aVar.f1622a = i2;
            aVar.f1623b = bArr;
            l lVar = this.f2262o;
            if (lVar != null) {
                return lVar.Z(aVar.c());
            }
            E("sendDataInternal error, comm data channel not conn, remoteDevId:" + str);
            return 3;
        }
        E("sendDataInternal error, remote dev not ready, remoteDevId:" + str + ", businessType:" + i2 + ", businessTypeBitMask:" + bitMaskForBusinessType + ", RemoteBusinessTypeBitMask:" + this.f2261n + ", mServerDevice:" + this.f2260m);
        return 5;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M() {
        w.d dVar = this.f2260m;
        if (dVar == null) {
            return;
        }
        this.f2250c.a1(dVar.i(), this.f2255h);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean N(final String str, final int i2) {
        if (this.f2260m == null) {
            E("setRemoteBusinessTypeBitmaskAndNotify a does not exist device Id, remoteDevId:" + str + ", curRemoteBusinessTypeBitMask:" + Constants.convertBusinessTypeBitmaskToString(i2));
            return false;
        }
        final int i3 = this.f2261n;
        if (i3 == i2) {
            return false;
        }
        this.f2261n = i2;
        D("setRemoteBusinessTypeBitmaskAndNotify remoteDevId:" + str + ", old:" + Constants.convertBusinessTypeBitmaskToString(i3) + ", cur:" + Constants.convertBusinessTypeBitmaskToString(i2));
        IntStream.rangeClosed(1, 7).filter(new IntPredicate() { // from class: x.b
            @Override // java.util.function.IntPredicate
            public final boolean test(int i4) {
                return d.a(i2, i3, i4);
            }
        }).forEach(new IntConsumer() { // from class: x.c
            @Override // java.util.function.IntConsumer
            public final void accept(int i4) {
                this.f2245a.C(str, i2, i4);
            }
        });
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean O(String str, int i2) {
        int i3 = this.f2261n;
        if (i3 == i2) {
            return false;
        }
        this.f2261n = i2;
        D("setRemoteBusinessTypeBitmaskOnly remoteDevId:" + str + ", old:" + Constants.convertBusinessTypeBitmaskToString(i3) + ", cur:" + Constants.convertBusinessTypeBitmaskToString(i2));
        return true;
    }

    public static /* synthetic */ boolean a(int i2, int i3, int i4) {
        return (i2 & Constants.getBitMaskForBusinessType(i4)) != (i3 & Constants.getBitMaskForBusinessType(i4));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean y(int i2) {
        return z(Constants.getBitMaskForBusinessType(i2));
    }

    private boolean z(int i2) {
        boolean z2;
        int i3 = this.f2255h;
        if ((i3 & i2) != i2) {
            this.f2255h = i2 | i3;
            z2 = true;
        } else {
            z2 = false;
        }
        M();
        return z2;
    }

    @Override // com.vivo.commshare.IVmdriComm
    public void bringUpRemoteProcess(String str, String str2) {
        this.f2250c.g0(str, str2);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public CommDevInfo getLocalDeviceState() {
        return this.f2254g.a();
    }

    @Override // com.vivo.commshare.IVmdriComm
    public List getRemoteDeviceState() {
        w.d dVar = this.f2260m;
        return dVar != null ? Collections.singletonList(dVar.a()) : new ArrayList();
    }

    @Override // com.vivo.commshare.IVmdriComm
    public IDataChannel initDataChannel(int i2, IDeviceListener iDeviceListener, IDataListener iDataListener) throws RemoteException {
        D("initDataChannel, businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2) + ", deviceListener:" + iDeviceListener + ", dataListener:" + iDataListener);
        this.f2256i.put(Integer.valueOf(i2), iDeviceListener);
        if (this.f2260m != null) {
            D("initDataChannel, notify dev conn, mServerDevice:" + this.f2260m + ", businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2));
            iDeviceListener.onRemoteDeviceConnected(this.f2260m.a());
            if ((this.f2261n & Constants.getBitMaskForBusinessType(i2)) == Constants.getBitMaskForBusinessType(i2)) {
                D("initDataChannel, notify dev ready, mServerDevice:" + this.f2260m + ", businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2));
                iDeviceListener.onRemoteReady(this.f2260m.i(), true);
            }
        }
        b bVar = new b(i2, iDeviceListener.asBinder());
        bVar.c();
        this.f2259l.put(Integer.valueOf(i2), bVar);
        this.f2258k.put(Integer.valueOf(i2), iDataListener);
        BinderC0026d binderC0026d = new BinderC0026d(i2);
        this.f2257j.put(Integer.valueOf(i2), binderC0026d);
        return binderC0026d;
    }

    @Override // com.vivo.commshare.IVmdriComm
    public void setAudioEventParam(int i2, Bundle bundle) {
        u0.r().Y(i2, bundle);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public int startAudioServer(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) {
        return u0.r().d0(str, bundle, iCommShareAudioStateListener);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public void stopAudioServer(String str) {
        u0.r().g0(str);
    }
}
