package a0;

import java.util.HashMap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f94a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f95b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f96c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private HashMap f97d;

    public n0(String str, int i2, boolean z2, HashMap map) {
        this.f94a = str;
        this.f95b = i2;
        this.f96c = z2;
        this.f97d = map;
    }

    public int a() {
        return this.f95b;
    }

    public HashMap b() {
        return this.f97d;
    }

    public boolean c() {
        return this.f96c;
    }

    public String toString() {
        return "RemoteCommState{mRemoteDevId='" + this.f94a + "', mMaxSupportedDevs=" + this.f95b + ", mCommShareState=" + this.f96c + ", mPreferredDevs=" + this.f97d + '}';
    }
}
