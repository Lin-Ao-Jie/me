package a0;

import android.os.Message;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface d0 {
    void a(String str, Message message);

    void b(g0 g0Var);

    void c(String str, long j2, long j3);

    y0 d(String str);

    z0 e(String str);

    void f(String str, Message message);

    void g(w wVar);
}
