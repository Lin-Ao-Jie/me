package a0;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class h0 {
    public static String a(int i2) {
        if (i2 == 1) {
            return "CTRL_REQ";
        }
        if (i2 == 2) {
            return "CTRL_RESP";
        }
        if (i2 == 3) {
            return "CTRL_UNSOLICITED";
        }
        return "UNKNOWN_CTRL_MSG_TYPE(" + i2 + ")";
    }
}
