package a0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class w extends w.a {
    public w(Executor executor) {
        super(executor);
    }

    private static void a(String str) {
        VmdriLog.w("CommShareDeviceCallback", str);
    }

    public void f(w.d dVar) {
        if ((TextUtils.isEmpty(dVar.m()) && TextUtils.isEmpty(dVar.o())) || dVar.w()) {
            return;
        }
        a("onRemoteDeviceStateChanged notify fake p2p info(clear reported p2p information)!because vmdri p2p is not conn.");
        dVar.L("");
        dVar.M("");
    }

    public void b(w.c cVar) {
    }

    public void c(w.d dVar) {
    }

    public void d(w.d dVar, boolean z2) {
    }

    public void e(w.d dVar, boolean z2) {
    }
}
