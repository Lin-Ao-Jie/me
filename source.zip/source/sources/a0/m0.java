package a0;

import android.app.usage.NetworkStats;
import android.app.usage.NetworkStatsManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemProperties;
import android.util.ArraySet;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import java.util.Calendar;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class m0 extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f77a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private NetworkStatsManager f78b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Set f79c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private Calendar f80d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private long f81e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private long f82f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private long f83g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f84h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private long f85i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private long f86j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private long f87k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private String f88l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private NetworkStatsManager.UsageCallback f89m;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends NetworkStatsManager.UsageCallback {
        a() {
        }

        @Override // android.app.usage.NetworkStatsManager.UsageCallback
        public void onThresholdReached(int i2, String str) {
            m0.this.r(false);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class b extends w.a {
        public b(Executor executor) {
            super(executor);
        }

        public abstract void a(long j2, long j3, long j4);
    }

    public m0(Context context, Looper looper, int i2, b bVar, String str) {
        super(looper);
        ArraySet arraySet = new ArraySet();
        this.f79c = arraySet;
        this.f89m = new a();
        this.f80d = Calendar.getInstance();
        long jCurrentTimeMillis = System.currentTimeMillis();
        this.f82f = jCurrentTimeMillis;
        this.f81e = g(jCurrentTimeMillis);
        n("NetworkStatsTracker, mStartTrackerTime:" + this.f82f + ", mFirstDayOfMonth:" + this.f81e);
        this.f77a = context;
        this.f84h = i2;
        arraySet.add(bVar);
        this.f78b = (NetworkStatsManager) this.f77a.getSystemService("netstats");
        this.f88l = str;
        i();
        j();
        this.f78b.registerUsageCallback(0, null, 2097152L, this.f89m, this);
    }

    private long g(long j2) {
        this.f80d.clear();
        this.f80d.setTimeInMillis(this.f82f);
        this.f80d.set(5, 1);
        this.f80d.set(11, 0);
        this.f80d.set(12, 0);
        this.f80d.set(13, 0);
        this.f80d.set(14, 0);
        long timeInMillis = this.f80d.getTimeInMillis();
        this.f80d.clear();
        return timeInMillis;
    }

    private long h() {
        long rxBytes = 0;
        try {
            NetworkStats networkStatsQueryDetailsForUid = this.f84h == 1 ? this.f78b.queryDetailsForUid(0, null, this.f81e, Long.MAX_VALUE, 5720) : this.f78b.querySummary(0, null, this.f81e, Long.MAX_VALUE);
            NetworkStats.Bucket bucket = new NetworkStats.Bucket();
            while (networkStatsQueryDetailsForUid.hasNextBucket() && networkStatsQueryDetailsForUid.getNextBucket(bucket)) {
                rxBytes += bucket.getRxBytes() + bucket.getTxBytes();
            }
            networkStatsQueryDetailsForUid.close();
        } catch (Exception e2) {
            o("pollMobileStats error:" + e2);
        }
        long j2 = (rxBytes - this.f85i) + this.f87k;
        n("getRealTimeDataUsage, mObservationType:" + this.f84h + ", dataUsage:" + j2);
        return j2;
    }

    private void i() {
        r(true);
    }

    private void j() {
        if (!VmdriContext.isPhone()) {
            this.f87k = 0L;
            return;
        }
        String str = SystemProperties.get("persist.radio.vmdri.data_usage", "remoteDevId,0");
        String[] strArrSplit = str.split(",");
        n("initLastDataUsage, dataUsageString:" + str);
        if (strArrSplit.length <= 1 || !strArrSplit[0].equals(this.f88l)) {
            SystemProperties.set("persist.radio.vmdri.data_usage", this.f88l + ",0");
            this.f87k = 0L;
        } else {
            try {
                this.f87k = Long.parseLong(strArrSplit[1]);
            } catch (NumberFormatException unused) {
                o("Invalid data usage value: " + strArrSplit[1]);
                this.f87k = 0L;
            }
        }
        n("initLastDataUsage, mLastDataUsage:" + this.f87k);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l(b bVar) {
        bVar.a(e(), f(), this.f86j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void m(final b bVar) {
        bVar.invokeFromExecutor(new Runnable() { // from class: a0.l0
            @Override // java.lang.Runnable
            public final void run() {
                this.f75a.l(bVar);
            }
        });
    }

    private static void n(String str) {
        VmdriLog.d("NetworkStatsTracker", str);
    }

    private static void o(String str) {
        VmdriLog.e("NetworkStatsTracker", str);
    }

    private void p() {
        this.f79c.forEach(new Consumer() { // from class: a0.k0
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                this.f72a.m((m0.b) obj);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void r(boolean z2) {
        long j2 = this.f86j;
        long jCurrentTimeMillis = System.currentTimeMillis();
        try {
            NetworkStats networkStatsQueryDetailsForUid = this.f84h == 1 ? this.f78b.queryDetailsForUid(0, null, this.f81e, Long.MAX_VALUE, 5720) : this.f78b.querySummary(0, null, this.f81e, Long.MAX_VALUE);
            NetworkStats.Bucket bucket = new NetworkStats.Bucket();
            long rxBytes = 0;
            while (networkStatsQueryDetailsForUid.hasNextBucket() && networkStatsQueryDetailsForUid.getNextBucket(bucket)) {
                rxBytes += bucket.getRxBytes() + bucket.getTxBytes();
            }
            networkStatsQueryDetailsForUid.close();
            this.f86j = rxBytes;
        } catch (Exception e2) {
            o("pollMobileStats error:" + e2);
        }
        if (z2) {
            this.f85i = this.f86j;
        }
        this.f83g = jCurrentTimeMillis;
        n("updateNetworkStats, observationType:" + this.f84h + ", startMobileDataUsage:" + this.f85i + ", beforeTotal:" + j2 + ", curTotal:" + this.f86j + ", deltaTotal:" + (this.f86j - j2) + ", dataUsage for this conn:" + (this.f86j - this.f85i));
        if (this.f86j != j2 || z2) {
            p();
        }
    }

    public void d() {
        this.f78b.unregisterUsageCallback(this.f89m);
    }

    public long e() {
        return (this.f86j - this.f85i) + this.f87k;
    }

    public long f() {
        return this.f86j - this.f85i;
    }

    public boolean k(z0 z0Var) {
        if (z0Var == null) {
            return false;
        }
        String strB = z0Var.b();
        boolean zF = z0Var.f();
        n("isStopCommShareByUser, isUserTarget " + zF + ", stopReason:" + strB);
        return zF;
    }

    public void q(z0 z0Var) {
        if (!VmdriContext.isPhone()) {
            n("recordDataUsage,device is not phone, not need record");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.f88l);
        sb.append(",");
        if (k(z0Var)) {
            sb.append("0");
        } else {
            sb.append(String.valueOf(h()));
        }
        SystemProperties.set("persist.radio.vmdri.data_usage", sb.toString());
    }
}
