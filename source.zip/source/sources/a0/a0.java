package a0;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.IndentingPrintWriter;
import com.vivo.commshare.framework.commonService.CommonServiceAgent;
import com.vivo.commshare.framework.commonService.CommonServiceCallback;
import com.vivo.commshare.framework.commonService.CommonServiceConnectionCallback;
import com.vivo.commshare.framework.commonService.CommonServiceManager;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.ThreadManager;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriGlobals;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a0 extends Handler {
    private static a0 H;
    private static final Object I = new Object();
    private boolean A;
    private Boolean B;
    private boolean C;
    private AtomicInteger D;
    private final i E;
    private CommonServiceCallback F;
    private final BroadcastReceiver G;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f2a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private CommonServiceManager f3b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private CommonServiceAgent f4c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private c0.u0 f5d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private d0 f6e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private m0 f7f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final DependentServiceController f8g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private ConcurrentHashMap f9h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private ConcurrentHashMap f10i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private ConcurrentHashMap f11j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private ConcurrentHashMap f12k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private ConcurrentHashMap f13l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private ConcurrentHashMap f14m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private ConcurrentHashMap f15n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private ConcurrentHashMap f16o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private ConcurrentHashMap f17p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private w.d f18q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private w.d f19r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private long f20s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private long f21t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private long f22u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private AtomicLong f23v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private AtomicInteger f24w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private p0.b f25x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private long f26y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private boolean f27z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends CommonServiceCallback {
        a() {
        }

        @Override // com.vivo.commshare.framework.commonService.CommonServiceCallback
        public void onCapabilityChanged(String str, int i2) {
            boolean z2 = (i2 & 1) == 1;
            boolean z3 = (i2 & 2) == 2;
            boolean z4 = (i2 & 4) == 4;
            a0.this.f10i.put(str, Integer.valueOf(i2));
            a0.this.f11j.put(str, Boolean.valueOf(z2));
            a0.this.f12k.put(str, Boolean.valueOf(z3));
            a0.this.f13l.put(str, Boolean.valueOf(z4));
            Boolean bool = (Boolean) a0.this.f9h.getOrDefault(str, Boolean.FALSE);
            boolean z5 = z2 || z3 || z4;
            a0.this.f9h.put(str, Boolean.valueOf(z5));
            if (!bool.booleanValue() && z5) {
                a0.this.b0(str);
            } else if (!bool.booleanValue() || z5) {
                a0.this.w0(str, 3);
            } else {
                a0.this.c0(str);
            }
            a0.this.n0(str);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends w {
        b(Executor executor) {
            super(executor);
        }

        @Override // a0.w
        public void b(w.c cVar) {
            String strI = a0.this.f19r != null ? a0.this.f19r.i() : null;
            if (cVar != null) {
                String strC = cVar.c();
                a0.g0("onConnectFailure: " + cVar + ", curRemotedevId:" + strI);
                if (strI == null || !strI.equals(strC)) {
                    a0.g0("onConnectFailure, the reported device is not the one that is already connected.");
                } else if (w.e.b(cVar.b())) {
                    a0.this.r0(cVar);
                }
            }
        }

        @Override // a0.w
        public void c(w.d dVar) {
            w.d dVar2 = a0.this.f18q;
            a0.this.f18q = dVar;
            if (dVar2.y() || !dVar.y()) {
                return;
            }
            a0.this.d0();
        }

        @Override // a0.w
        public void d(w.d dVar, boolean z2) {
            a0.this.f14m.put(dVar.i(), Boolean.TRUE);
            a0.this.W(dVar);
            a0.this.f19r = dVar;
            a0.this.l0(false);
            a0.this.k0();
            a0.this.sendEmptyMessageDelayed(2, 3000L);
            a0.this.removeMessages(5);
        }

        @Override // a0.w
        public void e(w.d dVar, boolean z2) {
            a0.this.f14m.put(dVar.i(), Boolean.FALSE);
            a0.this.X(dVar);
            a0.this.f19r = null;
            a0.this.l0(true);
            a0.this.k0();
            a0.this.removeMessages(5);
        }

        @Override // a0.w
        public void f(w.d dVar) {
            if (a0.this.f15n.containsKey(dVar.i())) {
                a0.this.Y(dVar);
            }
            w.d dVar2 = a0.this.f19r;
            a0.this.f19r = dVar;
            if (dVar2 == null || a0.this.f19r == null || dVar2.w() || !a0.this.f19r.w()) {
                return;
            }
            a0.g0("p2p is connected");
            a0.this.l0(false);
            a0.this.k0();
            a0.this.removeMessages(5);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends g0 {
        c(Executor executor) {
            super(executor);
        }

        @Override // a0.g0
        public void a(String str, long j2, long j3) {
            a0.this.f16o.put(str, Long.valueOf(j2));
            a0.this.f17p.put(str, Long.valueOf(j3));
            a0.g0("commShareDataUsageIndication, remoteDevId:" + str + ", dataUsageOfThisConn:" + j2);
            if (!VmdriContext.isPad() || j2 == 0) {
                return;
            }
            a0.this.w0(str, 4);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends c0.u0.f {
        d() {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends DependentServiceController.DependentServiceCallback {
        e(Executor executor) {
            super(executor);
        }

        @Override // com.vivo.vmdri.DependentServiceController.DependentServiceCallback
        public void tryStartBindDependentService() {
            synchronized (a0.I) {
                if (!a0.this.f27z && !a0.this.A) {
                    a0.g0("tryStartBindDependentService connCapabilityService");
                    a0.this.Q();
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f extends BroadcastReceiver {
        f() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("com.vivo.vmdri.intent.action.delete_comm_sharing_notification".equals(intent.getAction())) {
                a0.g0("onReceive, ACTION_DELETE_COMM_SHARING_NOTIFICATION");
                if (VmdriContext.isPhone()) {
                    a0.this.f23v.set(a0.this.f21t);
                    a0.this.f24w.incrementAndGet();
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g extends CommonServiceConnectionCallback {
        g() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void c(CommonServiceAgent commonServiceAgent) {
            a0.this.Z(commonServiceAgent);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void d() {
            a0.this.a0();
        }

        @Override // com.vivo.commshare.framework.commonService.CommonServiceConnectionCallback
        public void onConnected(final CommonServiceAgent commonServiceAgent) {
            a0.g0("onConnected, serviceAgent:" + commonServiceAgent);
            a0.this.f8g.setCapabilityServiceBound(true);
            synchronized (a0.I) {
                a0.this.f27z = false;
                a0.this.A = true;
            }
            a0.this.post(new Runnable() { // from class: a0.b0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f40a.c(commonServiceAgent);
                }
            });
        }

        @Override // com.vivo.commshare.framework.commonService.CommonServiceConnectionCallback
        public void onConnectedFailed(String str) {
            a0.g0("onConnectedFailed, reason:" + str);
            synchronized (a0.I) {
                a0.this.f27z = false;
                a0.this.A = false;
            }
        }

        @Override // com.vivo.commshare.framework.commonService.CommonServiceConnectionCallback
        public void onDisconnect() {
            a0.g0("onDisconnect");
            a0.this.f8g.setCapabilityServiceBound(false);
            synchronized (a0.I) {
                a0.this.f27z = false;
                a0.this.A = false;
            }
            a0.this.post(new Runnable() { // from class: a0.c0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f45a.d();
                }
            });
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class h extends m0.b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ String f35a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ boolean f36b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        h(Executor executor, String str, boolean z2) {
            super(executor);
            this.f35a = str;
            this.f36b = z2;
        }

        @Override // a0.m0.b
        public void a(long j2, long j3, long j4) {
            a0.this.f21t = j3;
            a0.this.f22u = j4;
            if (a0.this.f20s < 3) {
                if (a0.this.f20s > 0) {
                    a0.this.removeMessages(1);
                }
                a0 a0Var = a0.this;
                a0Var.sendMessageDelayed(a0Var.obtainMessage(1), 10000L);
            }
            a0.this.f20s++;
            a0.g0("onMobileNetworkStatsUpdate, remoteDevId" + this.f35a + ", totalDataUsageOfStartTracker:" + j2 + ", mDataUsageOfThisConn:" + a0.this.f21t);
            if (!this.f36b || a0.this.f21t == 0) {
                return;
            }
            if (a0.this.e0()) {
                a0.this.w0(this.f35a, 6);
            } else {
                if (a0.this.f23v.get() < 0 || j2 - a0.this.f23v.get() <= 1073741824) {
                    return;
                }
                a0.this.w0(this.f35a, 5);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class i extends Handler {
        public i(a0 a0Var, Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            a0.h0("unsupported message:" + message.what);
        }
    }

    private a0(d0 d0Var) {
        super(ThreadManager.getVmdriMainLooper());
        this.f9h = new ConcurrentHashMap();
        this.f10i = new ConcurrentHashMap();
        this.f11j = new ConcurrentHashMap();
        this.f12k = new ConcurrentHashMap();
        this.f13l = new ConcurrentHashMap();
        this.f14m = new ConcurrentHashMap();
        this.f15n = new ConcurrentHashMap();
        this.f16o = new ConcurrentHashMap();
        this.f17p = new ConcurrentHashMap();
        this.f18q = new w.d(true);
        this.f19r = null;
        this.f20s = 0L;
        this.f21t = 0L;
        this.f22u = 0L;
        this.f23v = new AtomicLong(0L);
        this.f24w = new AtomicInteger(0);
        this.f27z = false;
        this.A = false;
        this.B = Boolean.FALSE;
        this.C = false;
        this.D = new AtomicInteger(-1);
        this.F = new a();
        f fVar = new f();
        this.G = fVar;
        Context applicationContext = VmdriContext.getInstance().getApplicationContext();
        this.f2a = applicationContext;
        this.f6e = d0Var;
        this.f3b = CommonServiceManager.create(applicationContext);
        this.f5d = c0.u0.r();
        this.f25x = VmdriGlobals.getInstance().getNotificationMgr();
        this.E = new i(this, ThreadManager.getsVmdriCommLooper());
        if (VmdriContext.isPhone()) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("com.vivo.vmdri.intent.action.delete_comm_sharing_notification");
            this.f2a.registerReceiver(fVar, intentFilter, 2);
        }
        this.f6e.g(new b(new x(this)));
        this.f6e.b(new c(new x(this)));
        this.f5d.Q(new d());
        DependentServiceController dependentServiceController = DependentServiceController.getInstance();
        this.f8g = dependentServiceController;
        dependentServiceController.registerDependentServiceCallback(new e(new Executor() { // from class: a0.y
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f131a.postAtFrontOfQueue(runnable);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Q() {
        synchronized (I) {
            this.f27z = true;
        }
        CommonServiceManager commonServiceManager = this.f3b;
        g gVar = new g();
        final i iVar = this.E;
        iVar.getClass();
        commonServiceManager.connectService(gVar, new Executor() { // from class: a0.z
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                iVar.post(runnable);
            }
        });
    }

    public static a0 R(d0 d0Var) {
        a0 a0Var;
        synchronized (I) {
            try {
                if (H != null) {
                    throw new RuntimeException("CommunicationStateReporter already created!");
                }
                a0Var = new a0(d0Var);
                H = a0Var;
            } catch (Throwable th) {
                throw th;
            }
        }
        return a0Var;
    }

    public static a0 T() {
        return H;
    }

    private void U(String str) {
        this.f23v.set(0L);
        this.f24w.set(0);
        w.d dVar = (w.d) this.f15n.get(str);
        g0("handleBothCommShareConnect, remoteDevId:" + str + ", remoteDevState:" + dVar);
        this.f26y = SystemClock.elapsedRealtime();
        u0(str);
        w0(str, 1);
        t0(str);
        this.C = true;
        q0.f.w().n(str, ((Integer) this.f10i.getOrDefault(str, 0)).intValue(), this.f18q, dVar, this.f6e.d(str));
    }

    private void V(String str) {
        w.d dVar = (w.d) this.f15n.get(str);
        long jElapsedRealtime = SystemClock.elapsedRealtime() - this.f26y;
        g0("handleBothCommShareDisConnect, remoteDevId:" + str + ", disConnDevState:" + dVar + ", connectedTime:" + jElapsedRealtime);
        this.C = false;
        w0(str, 2);
        d0();
        this.f15n.remove(str);
        this.f16o.remove(str);
        this.f17p.remove(str);
        z0 z0VarE = this.f6e.e(str);
        v0(str, z0VarE);
        q0(str);
        q0.f.w().p(str, ((Integer) this.f10i.getOrDefault(str, 0)).intValue(), this.f18q, dVar, z0VarE, jElapsedRealtime);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void W(w.d dVar) {
        g0("handleBottomCommShareConnect, remoteDevState:" + dVar);
        String strI = dVar.i();
        this.f15n.put(strI, dVar);
        if (((Boolean) this.f9h.getOrDefault(strI, Boolean.FALSE)).booleanValue()) {
            U(strI);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void X(w.d dVar) {
        g0("handleBottomCommShareDisConnect, remoteDevState:" + dVar);
        String strI = dVar.i();
        if (((Boolean) this.f9h.getOrDefault(strI, Boolean.FALSE)).booleanValue()) {
            return;
        }
        V(strI);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Y(w.d dVar) {
        g0("handleCommShareDevStateChanged, remoteDevState:" + dVar);
        this.f15n.put(dVar.i(), dVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Z(CommonServiceAgent commonServiceAgent) {
        this.f4c = commonServiceAgent;
        try {
            commonServiceAgent.registerCapabilityCallback(this.F, new x(this));
        } catch (RemoteException e2) {
            h0("handleCommonServiceConnected registerCapabilityCallback error:" + e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a0() {
        try {
            this.f4c.unregisterCapabilityCallback();
        } catch (RemoteException e2) {
            h0("handleCommonServiceDisconnected registerCapabilityCallback error:" + e2);
        }
        this.f4c = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b0(String str) {
        g0("handleTopCommShareConnect, remoteDevId:" + str);
        if (((Boolean) this.f14m.getOrDefault(str, Boolean.FALSE)).booleanValue()) {
            U(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c0(String str) {
        g0("handleTopCommShareDisConnect, remoteDevId:" + str);
        if (((Boolean) this.f14m.getOrDefault(str, Boolean.FALSE)).booleanValue()) {
            return;
        }
        V(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d0() {
        if (this.f18q.B()) {
            this.f25x.z();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean e0() {
        g0("isNeedShowDataUsageForThisConn dataUsage:" + this.f23v.get() + ", deletionTimes:" + this.f24w.get());
        return this.f23v.get() == 0 && this.f24w.get() == 0;
    }

    private boolean f0() {
        return this.D.get() == 0 || this.D.get() == 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void g0(String str) {
        VmdriLog.d("CommunicationStateReporter", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void h0(String str) {
        VmdriLog.e("CommunicationStateReporter", str);
    }

    private static void i0(String str) {
        VmdriLog.w("CommunicationStateReporter", str);
    }

    private void j0() {
        g0("notifyCommShareDataUsageToRemote, mDataUsageOfThisConn:" + this.f21t + ", mDataUsageOfThisMonth:" + this.f22u);
        Iterator it = this.f15n.values().iterator();
        while (it.hasNext()) {
            this.f6e.c(((w.d) it.next()).i(), this.f21t, this.f22u);
        }
        this.f20s = 0L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void k0() {
        x0(-1);
        this.f25x.l();
    }

    private void m0(boolean z2) {
        g0("removeP2pConflictNotifyIfNeed, isShowing:" + this.B + " forceCancel:" + z2);
        synchronized (this.B) {
            if (this.B.booleanValue() || z2) {
                this.f25x.T(false, null);
                this.B = Boolean.FALSE;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public void n0(String str) {
        ConcurrentHashMap concurrentHashMap = this.f9h;
        Boolean bool = Boolean.FALSE;
        boolean zBooleanValue = ((Boolean) concurrentHashMap.getOrDefault(str, bool)).booleanValue();
        boolean zBooleanValue2 = ((Boolean) this.f11j.getOrDefault(str, bool)).booleanValue();
        boolean zBooleanValue3 = ((Boolean) this.f12k.getOrDefault(str, bool)).booleanValue();
        boolean zBooleanValue4 = ((Boolean) this.f13l.getOrDefault(str, bool)).booleanValue();
        g0("reportCommunicationStateToSdk, remoteDevId:" + str + ", commShareState:" + (zBooleanValue ? 1 : 0) + ", callShareState:" + (zBooleanValue2 ? 1 : 0) + ", smsShareState:" + (zBooleanValue3 ? 1 : 0) + ", dataShareState:" + (zBooleanValue4 ? 1 : 0));
        this.f5d.T(str, zBooleanValue ? 1 : 0, zBooleanValue2 ? 1 : 0, zBooleanValue3 ? 1 : 0, zBooleanValue4 ? 1 : 0);
    }

    private void p0(int i2) {
        if (i2 == 0) {
            k0();
        } else {
            this.f25x.S(i2);
        }
        g0("reportPreemptP2pConnResult, errorCode:" + w.e.a(i2) + ", netShareRecoveryState:" + this.D.get());
    }

    private void q0(String str) {
        g0("resetCommunicationState, remoteDevId:" + str);
        this.f5d.T(str, 0, 0, 0, 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void r0(w.c cVar) {
        if (this.f18q.B()) {
            g0("showP2pConflictNotifyIfNeed");
            removeMessages(4);
            if (hasMessages(2)) {
                sendMessageDelayed(obtainMessage(3, cVar), 3000L);
            } else {
                sendMessage(obtainMessage(3, cVar));
            }
        }
    }

    private void s0(w.c cVar) {
        g0("showP2pConflictNotifyIfNeed, isShowing:" + this.B + ", isCommShareConnected:" + this.C + ", isNetShareRecovering:" + f0());
        synchronized (this.B) {
            try {
                if (!this.B.booleanValue() && this.C && !f0()) {
                    this.f25x.T(true, cVar);
                    this.B = Boolean.TRUE;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void t0(String str) {
        boolean zD;
        boolean zB;
        if (this.f18q.B()) {
            y0 y0VarD = this.f6e.d(str);
            if (y0VarD != null) {
                zB = y0VarD.b();
                zD = y0VarD.d();
            } else {
                zD = false;
                zB = false;
            }
            boolean zY = this.f18q.y();
            boolean z2 = Settings.Global.getInt(this.f2a.getContentResolver(), "recommend_auto_comm_share_never_remind", 0) == 1;
            if (zY || !zB || !zD || z2) {
                return;
            }
            this.f25x.U();
        }
    }

    private void u0(String str) {
        if (this.f7f != null) {
            i0("already started listenDataUsage, remoteDevId:" + str);
            return;
        }
        boolean zIsPhone = VmdriContext.isPhone();
        int i2 = zIsPhone ? 1 : 2;
        this.f21t = 0L;
        this.f22u = 0L;
        this.f7f = new m0(this.f2a, getLooper(), i2, new h(new x(this), str, zIsPhone), str);
    }

    private void v0(String str, z0 z0Var) {
        if (this.f7f == null) {
            return;
        }
        if (this.f15n.size() <= 0) {
            this.f21t = 0L;
            this.f22u = 0L;
            this.f7f.q(z0Var);
            this.f7f.d();
            this.f7f = null;
            return;
        }
        i0("There are still connected devices and cannot stop listening, remoteDevId :" + str + ", mCommShareDevStates:" + this.f15n);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void w0(String str, int i2) {
        y0 y0VarD;
        g0("updateCommSharingStateNotification, remoteDevId:" + str + ", reason:" + p0.b.J(i2) + ", mCommShareDevStates:" + this.f15n);
        w.d dVar = (w.d) this.f15n.get(str);
        if (dVar == null) {
            g0("updateCommSharingStateNotification commShareState is false -> cancel notify");
            this.f25x.y();
            return;
        }
        boolean zD = false;
        if (i2 == 2) {
            z0 z0VarE = this.f6e.e(str);
            zD = z0VarE != null ? z0VarE.f() : false;
            g0("updateCommSharingStateNotification comm share disconn -> cancel notify, needResetNoisyNotifyTimes:" + zD);
            this.f25x.y();
            if (zD) {
                this.f25x.Q();
                return;
            }
            return;
        }
        ConcurrentHashMap concurrentHashMap = this.f11j;
        Boolean bool = Boolean.FALSE;
        boolean zBooleanValue = ((Boolean) concurrentHashMap.getOrDefault(str, bool)).booleanValue();
        boolean zBooleanValue2 = ((Boolean) this.f12k.getOrDefault(str, bool)).booleanValue();
        boolean zBooleanValue3 = ((Boolean) this.f13l.getOrDefault(str, bool)).booleanValue();
        boolean z2 = zBooleanValue || zBooleanValue2 || zBooleanValue3;
        if (!z2) {
            g0("updateCommSharingStateNotification all capability no available -> cancel notify");
            this.f25x.y();
            return;
        }
        long jLongValue = VmdriContext.isPhone() ? this.f21t : ((Long) this.f16o.getOrDefault(str, 0L)).longValue();
        if (i2 == 1 && (y0VarD = this.f6e.d(str)) != null) {
            zD = y0VarD.d();
        }
        this.f25x.R(i2, zD, jLongValue, this.f18q, dVar, z2, zBooleanValue, zBooleanValue2, zBooleanValue3);
    }

    public void S(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("CommunicationStateReporter:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mTopCommShareState=" + this.f9h);
        indentingPrintWriter.println("mCapability=" + this.f10i);
        indentingPrintWriter.println("mCallCapability=" + this.f11j);
        indentingPrintWriter.println("mSmsCapability=" + this.f12k);
        indentingPrintWriter.println("mDataCapability=" + this.f13l);
        indentingPrintWriter.println("mBottomCommShareState=" + this.f14m);
        indentingPrintWriter.println("mCommShareDevStates=" + this.f15n);
        indentingPrintWriter.println("mLocalDevState=" + this.f18q);
        indentingPrintWriter.println("mCommShareDataUsage=" + this.f21t);
        indentingPrintWriter.println("mDataUsageOfThisMonth=" + this.f22u);
        indentingPrintWriter.println("mDataUsageOfThisConnFromRemote=" + this.f16o);
        indentingPrintWriter.println("mDataUsageOfThisMonthFromRemote=" + this.f17p);
        indentingPrintWriter.println("mLastConnectedTime=" + this.f26y);
        indentingPrintWriter.decreaseIndent();
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        int i2 = message.what;
        if (i2 == 1) {
            j0();
            return;
        }
        if (i2 == 2) {
            g0("EVENT_DELAY_OTHER_NOTIFY, delayed other notification 3s");
            return;
        }
        if (i2 == 3) {
            Object obj = message.obj;
            s0(obj instanceof w.c ? (w.c) obj : null);
        } else {
            if (i2 == 4) {
                m0(((Boolean) message.obj).booleanValue());
                return;
            }
            if (i2 == 5) {
                p0(message.arg1);
                return;
            }
            h0("Unknown msg: " + message);
        }
    }

    public void l0(boolean z2) {
        if (this.f18q.B()) {
            Boolean boolValueOf = Boolean.valueOf(z2);
            removeMessages(3);
            sendMessage(obtainMessage(4, boolValueOf));
        }
    }

    public void o0(int i2) {
        sendMessageDelayed(obtainMessage(5, i2, 0), 3000L);
    }

    public void x0(int i2) {
        g0("updateRecoverNetshareState, state:" + i2 + ", mRecoverState:" + this.D.get());
        if (i2 != this.D.get()) {
            this.D.set(i2);
        }
    }
}
