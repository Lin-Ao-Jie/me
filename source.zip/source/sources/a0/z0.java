package a0;

import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.ctrl.RemoteDevConnEvaluation;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class z0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f139a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f140b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f141c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f142d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private i0.b f143e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private RemoteDevConnEvaluation f144f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private h0.c f145g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private String f146h;

    public z0(String str, boolean z2, boolean z3, boolean z4, i0.b bVar, RemoteDevConnEvaluation remoteDevConnEvaluation, h0.c cVar, String str2) {
        this.f139a = str;
        this.f140b = z2;
        this.f141c = z3;
        this.f142d = z4;
        this.f143e = bVar;
        this.f144f = remoteDevConnEvaluation;
        this.f145g = cVar;
        this.f146h = str2;
    }

    private static void g(String str) {
        VmdriLog.e("StopCommShareDoneRecord", str);
    }

    public String a() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("ReasonStr", this.f146h);
            jSONObject.put("Evaluation", this.f144f);
            jSONObject.put("ResponseMsg", this.f143e);
            jSONObject.put("RequestMsg", this.f145g);
        } catch (JSONException e2) {
            g("Error to reasonExact Json:" + e2.toString());
        }
        return jSONObject.toString();
    }

    public String b() {
        return this.f146h;
    }

    public String c() {
        return this.f139a;
    }

    public boolean d() {
        return this.f142d;
    }

    public boolean e() {
        return this.f140b;
    }

    public boolean f() {
        return this.f141c;
    }

    public String toString() {
        return "StopCommShareDoneRecord{mRemoteDevId='" + this.f139a + "', mIsFromRemoteTarget=" + this.f140b + ", mIsUserTarget=" + this.f141c + ", mIsForce=" + this.f142d + ", mStopCommShareResponseMsg=" + this.f143e + ", mEvaluation=" + this.f144f + ", mStopCommShareRequestMsg=" + this.f145g + ", mReasonStr='" + this.f146h + "'}";
    }
}
