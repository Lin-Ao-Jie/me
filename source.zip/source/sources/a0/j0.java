package a0;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.IndentingPrintWriter;
import com.vivo.vmdri.ThreadManager;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.HashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class j0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private d0 f60a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private d0.l f62c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private HashMap f63d = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private long f64e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private HashMap f65f = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private HashMap f66g = new HashMap();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private HashMap f67h = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private d f61b = new d(ThreadManager.getVmdriMainLooper());

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends d0.l.h {
        a(Executor executor) {
            super(executor);
        }

        @Override // d0.l.h
        public void c(w.d dVar) {
            super.c(dVar);
        }

        @Override // d0.l.h
        public void d(w.d dVar) {
            super.d(dVar);
            String strI = dVar.i();
            j0.this.f67h.put(strI, dVar);
            if (j0.this.f61b.hasEqualMessages(103, strI)) {
                j0.this.f61b.removeEqualMessages(103, strI);
                j0.this.u(strI);
            }
        }

        @Override // d0.l.h
        public void e(w.d dVar) {
            super.e(dVar);
            j0.this.f67h.remove(dVar.i());
        }

        @Override // d0.l.h
        public void f(w.d dVar, boolean z2, boolean z3) {
            super.f(dVar, z2, z3);
            if (j0.this.f67h.containsKey(dVar.i())) {
                j0.this.f67h.put(dVar.i(), dVar);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends c0.u0.c {
        b(Executor executor) {
            super(executor);
        }

        @Override // c0.u0.c
        public void a(w.i iVar, int i2, int i3) {
            super.a(iVar, i2, i3);
            iVar.d();
            if (!iVar.k()) {
                j0.this.f66g.remove(iVar.d());
                j0.this.s(iVar);
            } else if (((w.i) j0.this.f66g.put(iVar.d(), iVar)) == null) {
                j0.this.r(iVar);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends c0.u0.e {
        c(Executor executor) {
            super(executor);
        }

        @Override // c0.u0.e
        public void a(String str, w.b bVar) {
            super.a(str, bVar);
            if (bVar == null) {
                j0.y("startCommunicationShare resultCallback is null!");
                return;
            }
            if (j0.this.f63d.containsKey(str)) {
                j0.z("startCommunicationShare repeated trigger! remoteDevId:" + str + ", resultCallback:" + bVar);
                return;
            }
            if (j0.this.f63d.size() >= 1) {
                j0.y("startCommunicationShare, The previous trigger start event has not been processed yet, curTargetRemoteDevId:" + str + ", mTriggeringStartCommEvent:" + j0.this.f63d);
                bVar.onResult(32, "The previous trigger start event has not been processed yet");
                return;
            }
            j0.this.f64e = System.currentTimeMillis();
            j0.this.f63d.put(str, bVar);
            if (!j0.this.f66g.containsKey(str) || j0.this.f67h.containsKey(str)) {
                j0.x("startCommunicationShare, remoteDevId:" + str);
                j0.this.f60a.f(str, j0.this.f61b.obtainMessage(100, str));
                return;
            }
            j0.z("startCommunicationShare, remoteDevId:" + str + ", wait handshakes");
            j0.this.f61b.sendMessageDelayed(j0.this.f61b.obtainMessage(103, str), 5000L);
        }

        @Override // c0.u0.e
        public void b(String str, w.b bVar) {
            super.b(str, bVar);
            if (bVar == null) {
                j0.y("stopCommunicationShare resultCallback is null!");
                return;
            }
            if (((w.b) j0.this.f65f.put(str, bVar)) != null) {
                j0.z("stopCommunicationShare repeated trigger! remoteDevId:" + str + ", resultCallback:" + bVar);
                return;
            }
            j0.x("stopCommunicationShare, remoteDevId:" + str + ", resultCallback" + bVar);
            j0.this.f61b.sendMessageDelayed(j0.this.f61b.obtainMessage(102, str), 10000L);
            j0.this.f60a.a(str, j0.this.f61b.obtainMessage(101, str));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends Handler {
        public d(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            super.handleMessage(message);
            switch (message.what) {
                case 100:
                    j0.this.t(message);
                    break;
                case 101:
                    j0.this.v(message);
                    break;
                case 102:
                    j0.this.w(message);
                    break;
                case 103:
                    j0.this.u((String) message.obj);
                    break;
                default:
                    j0.y("Unhandled message with number: " + message.what);
                    break;
            }
        }
    }

    public j0(d0 d0Var, d0.l lVar) {
        this.f60a = d0Var;
        this.f62c = lVar;
        d0.l lVarY = d0.l.Y();
        final d dVar = this.f61b;
        dVar.getClass();
        lVarY.y0(new a(new Executor() { // from class: a0.i0
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                dVar.post(runnable);
            }
        }));
        c0.u0 u0VarR = c0.u0.r();
        final d dVar2 = this.f61b;
        dVar2.getClass();
        u0VarR.N(new b(new Executor() { // from class: a0.i0
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                dVar2.post(runnable);
            }
        }));
        c0.u0 u0VarR2 = c0.u0.r();
        final d dVar3 = this.f61b;
        dVar3.getClass();
        u0VarR2.P(new c(new Executor() { // from class: a0.i0
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                dVar3.post(runnable);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void s(w.i iVar) {
        String strD = iVar.d();
        w.b bVar = (w.b) this.f63d.remove(strD);
        if (bVar != null) {
            z("handleDevPhyDisconnected, remoteDevId:" + strD + ", remove TriggeringStartCommEvent!");
            bVar.onResult(28, "dev disonn");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void t(Message message) {
        w.k kVar = (w.k) message.obj;
        x("handleStartCommDone, result:" + kVar);
        String str = (String) kVar.f2236a;
        w.b bVar = (w.b) this.f63d.remove(str);
        if (bVar != null) {
            bVar.onResult(kVar.f2238c, kVar.f2239d);
        }
        if (kVar.f2238c == 0 || TextUtils.isEmpty(kVar.f2239d) || !kVar.f2239d.contains("REMOTE_DEV_NOT_CONN")) {
            return;
        }
        x("handleStartCommDone, [REMOTE_DEV_NOT_CONN] try to get remoteDev(" + str + ") actively");
        c0.u0.r().k0(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void u(String str) {
        x("handleStartCommWaitHs, remoteDevId:" + str);
        this.f60a.f(str, this.f61b.obtainMessage(100, str));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void v(Message message) {
        w.k kVar = (w.k) message.obj;
        x("handleStopCommDone, result:" + kVar);
        String str = (String) kVar.f2236a;
        this.f61b.removeEqualMessages(102, str);
        w.b bVar = (w.b) this.f65f.remove(str);
        if (bVar != null) {
            bVar.onResult(kVar.f2238c, kVar.f2239d);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void w(Message message) {
        String str = (String) message.obj;
        x("handleStopCommTimeOut, remoteDevId:" + str);
        w.b bVar = (w.b) this.f65f.remove(str);
        if (bVar != null) {
            bVar.onResult(31, "StopCommTimeOut");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void x(String str) {
        VmdriLog.d("LinkTriggerManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void y(String str) {
        VmdriLog.e("LinkTriggerManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void z(String str) {
        VmdriLog.w("LinkTriggerManager", str);
    }

    public void q(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("LinkTriggerManager:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mTriggeringStartCommEvent=" + this.f63d);
        indentingPrintWriter.println("mLastTriggeringStartCommTime=" + this.f64e);
        indentingPrintWriter.println("mTriggeringStopCommEvent=" + this.f65f);
        indentingPrintWriter.decreaseIndent();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void r(w.i iVar) {
    }
}
