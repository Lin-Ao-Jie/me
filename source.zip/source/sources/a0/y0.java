package a0;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class y0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f132a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f133b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f134c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private com.vivo.vmdri.ctrl.t f135d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private i0.a f136e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private h0.b f137f;

    public y0(String str, boolean z2, boolean z3, com.vivo.vmdri.ctrl.t tVar, i0.a aVar, h0.b bVar) {
        this.f132a = str;
        this.f133b = z2;
        this.f134c = z3;
        this.f135d = tVar;
        this.f136e = aVar;
        this.f137f = bVar;
    }

    public String a() {
        return this.f132a;
    }

    public boolean b() {
        return !this.f133b;
    }

    public boolean c() {
        return this.f133b;
    }

    public boolean d() {
        return this.f134c;
    }

    public String toString() {
        return "StartCommShareDoneRecord{mRemoteDevId='" + this.f132a + "', mIsFromRemoteTarget=" + this.f133b + ", mIsUserTarget=" + this.f134c + ", mTargetInfo=" + this.f135d + ", mResponseMsg=" + this.f136e + ", mRequestMsg=" + this.f137f + '}';
    }
}
