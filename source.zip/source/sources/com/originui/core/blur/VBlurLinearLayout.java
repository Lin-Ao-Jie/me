package com.originui.core.blur;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.LinearLayout;
import com.originui.core.R$color;
import com.originui.core.R$dimen;
import com.originui.core.R$id;
import com.originui.core.R$styleable;
import com.originui.core.utils.a0;
import com.originui.core.utils.f;
import com.originui.core.utils.g;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VBlurLinearLayout extends LinearLayout {
    private boolean A;
    private int B;
    private int C;
    private boolean D;
    private boolean E;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f391a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f392b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f393c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f394d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f395e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private Map f396f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f397g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f398h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f399i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private List f400j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private Paint f401k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f402l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f403m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f404n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f405o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f406p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private int f407q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f408r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private int f409s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f410t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f411u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f412v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f413w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f414x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private b.e f415y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private boolean f416z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements b.b {
        b() {
        }

        @Override // b.b
        public void a(boolean z2) {
            if (m.f583b) {
                m.b("VBlurLinearLayout", "blurBackground-result:" + z2 + ",blurAlpha:" + VBlurLinearLayout.this.f394d);
            }
            VBlurLinearLayout.this.g(z2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements b.b {
        c() {
        }

        @Override // b.b
        public void a(boolean z2) {
            if (m.f583b) {
                m.b("VBlurLinearLayout", "blurBackgroundCustomized-result:" + z2 + ",blurAlpha:" + VBlurLinearLayout.this.f394d);
            }
            VBlurLinearLayout.this.g(z2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface d {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class e extends LinearLayout.LayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        boolean f420a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int f421b;

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VBlurLinearLayout_LayoutParams);
            this.f420a = typedArrayObtainStyledAttributes.getBoolean(R$styleable.VBlurLinearLayout_LayoutParams_vKeepBackground, false);
            this.f421b = typedArrayObtainStyledAttributes.getInt(R$styleable.VBlurLinearLayout_LayoutParams_vclearInnerChildBackgroundLevel, 0);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public VBlurLinearLayout(Context context) {
        this(context, null);
    }

    private void e(View view, boolean z2) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (!n(childAt)) {
                    if (z2) {
                        a0.n(childAt, R$id.tag_child_view_clear_material, Boolean.TRUE);
                        f.a(childAt);
                    } else {
                        a0.n(childAt, R$id.tag_child_view_clear_material, Boolean.FALSE);
                    }
                    a0.l(childAt, z2 ? ColorStateList.valueOf(0) : null);
                    a0.n(childAt, R$id.tag_child_view_material_blur_alpha, Float.valueOf(this.f394d));
                }
                if ((childAt instanceof ViewGroup) && m(childAt)) {
                    e(childAt, z2);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g(boolean z2) {
        this.f413w = z2;
        if (z2) {
            f.E(this, this.f394d);
            j(this.f394d);
            setBackground(new ColorDrawable(0));
        }
        e(this, z2);
        k(z2);
    }

    private void h() {
        this.f406p = R$color.originui_vblur_linearlayout_divider_color_rom13_0;
        this.f407q = R$dimen.originui_vblur_linearlayout_divider_height_rom13_0;
        if (s.e(this.f391a)) {
            this.f406p = R$color.originui_vblur_linearlayout_divider_color_rom15_0;
            this.f407q = R$dimen.originui_vblur_linearlayout_divider_height_rom15_0;
        }
        int iC = k.c(this.f391a, this.f406p, this.E, "vigour_tmbsel_text_color_light", "color", "vivo");
        this.f406p = iC;
        this.f404n = r.b(this.f391a, iC);
        this.f403m = r.c(this.f391a, this.f407q);
        Paint paint = new Paint(1);
        this.f401k = paint;
        paint.setStrokeWidth(this.f403m);
        this.f401k.setStyle(Paint.Style.FILL);
        this.f401k.setColor(this.f404n);
        this.f401k.setAlpha(0);
    }

    private void i(Drawable drawable) {
        for (int i2 = 0; i2 < g.c(this.f400j); i2++) {
            b.c.a(g.a(this.f400j, i2));
        }
    }

    private void j(float f2) {
        for (int i2 = 0; i2 < g.c(this.f400j); i2++) {
            b.c.a(g.a(this.f400j, i2));
        }
    }

    private void k(boolean z2) {
        for (int i2 = 0; i2 < g.c(this.f400j); i2++) {
            b.c.a(g.a(this.f400j, i2));
        }
    }

    private void l(float f2) {
        for (int i2 = 0; i2 < g.c(this.f400j); i2++) {
            b.c.a(g.a(this.f400j, i2));
        }
    }

    private boolean m(View view) {
        int i2;
        if (this.f399i) {
            return true;
        }
        ViewGroup.LayoutParams layoutParams = null;
        int i3 = 1;
        while (true) {
            if (i3 <= 5) {
                layoutParams = view.getLayoutParams();
                if (layoutParams instanceof e) {
                    break;
                }
                Object parent = view.getParent();
                if (parent instanceof View) {
                    view = (View) parent;
                    i3++;
                }
            }
            i3 = -1;
            break;
        }
        if (i3 >= 0 && (layoutParams instanceof e) && (i2 = ((e) layoutParams).f421b) != 0) {
            return i2 < 0 || i3 <= i2;
        }
        return false;
    }

    private boolean n(View view) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof e) {
            return ((e) layoutParams).f420a;
        }
        return false;
    }

    private void o(View view) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (!n(childAt)) {
                    a0.n(childAt, R$id.tag_child_view_clear_material, Boolean.TRUE);
                    if ((childAt instanceof ViewGroup) && m(childAt)) {
                        o(viewGroup.getChildAt(i2));
                    }
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        o(view);
        super.addView(view, i2, layoutParams);
    }

    public void c() {
        if (m.f583b) {
            m.b("VBlurLinearLayout", "BlurLinearLayout-blurBackground-blurEnabled:" + this.f392b + ",global blur enabled:" + f.d() + ",view blur enabled:" + f.f());
        }
        this.f415y.K(this.A);
        f.w(this, this.f393c, this.f415y, false, this.f392b, k.f(this.f391a), false, this.f395e, this.B, new b());
    }

    public void d() {
        f.y(this, getBlurParams(), this.f392b, k.f(this.f391a), false, this.B, new c());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        q.q(canvas, 0);
        if (this.f412v) {
            this.f408r = 0;
            this.f410t = getMeasuredWidth();
            if (this.f402l) {
                this.f409s = getMeasuredHeight() - this.f403m;
                this.f411u = getMeasuredHeight();
            } else {
                this.f409s = 0;
                this.f411u = this.f403m;
            }
            canvas.drawRect(this.f408r, this.f409s, this.f410t, this.f411u, this.f401k);
        }
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    public float getBlurAlpha() {
        return this.f394d;
    }

    public b.e getBlurParams() {
        if (m.f583b) {
            m.b("VBlurLinearLayout", "getBlurParams");
        }
        return this.f415y;
    }

    public float getDividerAlpha() {
        return this.f414x;
    }

    public int getDividerHeight() {
        return this.f403m;
    }

    public int getMaterialGroupId() {
        return this.C;
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f396f.clear();
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            this.f396f.put(childAt, childAt.getBackground());
        }
        r();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (m.f583b) {
            m.b("VBlurLinearLayout", "BlurLinearLayout-blurBackground-blurEnabled:" + this.f392b + ",global blur enabled:" + f.p(getContext()) + ",view blur enabled:" + f.f());
        }
        int i2 = configuration.uiMode;
        if (i2 != this.f397g || this.D) {
            this.f397g = i2;
            int iB = r.b(this.f391a, this.f406p);
            this.f404n = iB;
            int i3 = this.f405o;
            if (i3 != 0) {
                iB = i3;
            }
            this.f401k.setAlpha((int) (this.f414x * Color.alpha(iB)));
            f.a(this);
            r();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f396f.clear();
    }

    public void p(float f2, boolean z2) {
        q(f2, false, z2);
    }

    public void q(float f2, boolean z2, boolean z3) {
        if (z3) {
            setDividerAlpha(f2);
        }
        if (z2 || this.f394d != f2) {
            this.f394d = f2;
            f.E(this, f2);
            j(this.f394d);
            setMaterialGroupId(this.C);
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                a0.n(getChildAt(i2), R$id.tag_child_view_material_blur_alpha, Float.valueOf(this.f394d));
            }
        }
    }

    public void r() {
        if (m.f583b) {
            m.b("VBlurLinearLayout", "setBlurEffect-mNeedCustomMaterial:" + this.f416z);
        }
        if (this.f416z) {
            d();
        } else {
            c();
        }
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        super.setBackgroundColor(i2);
        i(getBackground());
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        i(drawable);
    }

    public void setBlurAlpha(float f2) {
        if (this.f394d == f2) {
            return;
        }
        if (m.f583b) {
            m.b("VBlurLinearLayout", "setBlurAlpha:" + f2);
        }
        this.f394d = f2;
        f.E(this, f2);
        j(this.f394d);
        setDividerAlpha(f2);
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            a0.n(getChildAt(i2), R$id.tag_child_view_material_blur_alpha, Float.valueOf(this.f394d));
        }
    }

    public void setBlurAlphaAndMaterialAlpha(float f2) {
        p(f2, true);
    }

    public void setBlurEnabled(boolean z2) {
        if (m.f583b) {
            m.b("VBlurLinearLayout", "setBlurEnabled:" + z2);
        }
        this.f392b = z2;
        r();
    }

    public void setBlurSource(int i2) {
        this.B = i2;
    }

    public void setCustomDividerColor(int i2) {
        this.f405o = i2;
        this.f401k.setColor(i2);
        this.f401k.setAlpha((int) (Color.alpha(this.f405o) * this.f414x));
        invalidate();
    }

    public void setDividerAlpha(float f2) {
        float fMin = Math.min(1.0f, Math.max(f2, 0.0f));
        if (fMin == this.f414x) {
            return;
        }
        if (m.f583b) {
            m.b("VBlurLinearLayout", "setDividerAlpha-alpha: " + fMin + ",mDividerAlpha:" + this.f414x);
        }
        this.f414x = fMin;
        int i2 = this.f405o;
        if (i2 == 0) {
            i2 = this.f404n;
        }
        this.f401k.setAlpha((int) (Color.alpha(i2) * fMin));
        invalidate();
        l(fMin);
    }

    public void setDividerBottom(boolean z2) {
        this.f402l = z2;
        invalidate();
    }

    public void setDividerHeight(int i2) {
        this.f403m = i2;
        requestLayout();
        invalidate();
    }

    public void setJudgeNightModeBySettings(boolean z2) {
        this.D = z2;
    }

    public void setMaterial(int i2) {
        this.f393c = i2;
    }

    public void setMaterialGroupId(int i2) {
        this.C = i2;
        if (i2 == -1) {
            return;
        }
        f.K(this, i2);
        f.I(this, false);
    }

    public void setMaterialNightMode(int i2) {
        this.f395e = i2;
    }

    public void setNeedClearAllChildBackground(boolean z2) {
        this.f399i = z2;
    }

    public void setNeedCustomMaterial(boolean z2) {
        this.f416z = z2;
    }

    public void setUseGradientBlur(boolean z2) {
        this.A = z2;
    }

    public VBlurLinearLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.generateLayoutParams(layoutParams);
    }

    public VBlurLinearLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f393c = 2;
        this.f395e = 0;
        this.f396f = new HashMap();
        this.f397g = -1;
        this.f398h = 0;
        this.f399i = false;
        this.f400j = new ArrayList();
        this.f402l = true;
        this.f414x = 0.0f;
        this.f416z = false;
        this.A = false;
        this.C = -1;
        this.D = false;
        this.f391a = context;
        this.f392b = f.p(getContext()) && f.f();
        this.f397g = context.getResources().getConfiguration().uiMode;
        this.f398h = f.j(this.f391a);
        this.E = k.f(context);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VBlurLinearLayout);
        this.C = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VBlurLinearLayout_vmaterialGroupId, -1);
        this.B = typedArrayObtainStyledAttributes.getInt(R$styleable.VBlurLinearLayout_vblurSource, 0);
        typedArrayObtainStyledAttributes.recycle();
        a0.m(this, new a());
        this.f415y = new b.e();
        h();
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
        }
    }

    public void setBlurResultCallback(d dVar) {
    }

    public void setGradientBlurParams(b.d dVar) {
    }
}
