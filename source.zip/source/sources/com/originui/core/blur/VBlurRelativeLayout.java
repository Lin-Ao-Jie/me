package com.originui.core.blur;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.RelativeLayout;
import b.e;
import com.originui.core.R$color;
import com.originui.core.R$dimen;
import com.originui.core.R$id;
import com.originui.core.R$styleable;
import com.originui.core.utils.a0;
import com.originui.core.utils.f;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VBlurRelativeLayout extends RelativeLayout {
    private boolean A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f422a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f423b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f424c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f425d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f426e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private Map f427f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f428g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f429h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f430i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f431j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f432k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Paint f433l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f434m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f435n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f436o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f437p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private int f438q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f439r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private int f440s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f441t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f442u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f443v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f444w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private final List f445x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private int f446y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private e f447z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements b.b {
        b() {
        }

        @Override // b.b
        public void a(boolean z2) {
            VBlurRelativeLayout.this.f430i = z2;
            m.b("VBlurRelativeLayoutBase", "blurBackground-result:" + z2);
            if (z2) {
                VBlurRelativeLayout vBlurRelativeLayout = VBlurRelativeLayout.this;
                f.E(vBlurRelativeLayout, vBlurRelativeLayout.f425d);
                if (VBlurRelativeLayout.this.f431j != -1) {
                    f.I(VBlurRelativeLayout.this, false);
                    VBlurRelativeLayout vBlurRelativeLayout2 = VBlurRelativeLayout.this;
                    f.K(vBlurRelativeLayout2, vBlurRelativeLayout2.f431j);
                }
            }
            if (z2) {
                VBlurRelativeLayout.this.setBackground(new ColorDrawable(0));
            }
            VBlurRelativeLayout vBlurRelativeLayout3 = VBlurRelativeLayout.this;
            vBlurRelativeLayout3.f(vBlurRelativeLayout3, z2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class c extends RelativeLayout.LayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f450a;

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VBlurRelativeLayout_Layout);
            this.f450a = typedArrayObtainStyledAttributes.getInt(R$styleable.VBlurRelativeLayout_Layout_layout_os50_blur_effect, 0);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface d {
    }

    public VBlurRelativeLayout(Context context) {
        this(context, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void f(View view, boolean z2) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (z2) {
                    a0.n(childAt, R$id.tag_child_view_clear_material, Boolean.TRUE);
                    f.a(childAt);
                }
                ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
                if ((layoutParams instanceof c) && ((c) layoutParams).f450a == 1) {
                    m.b("VBlurRelativeLayoutBase", "child: " + childAt + " ignore blur");
                } else {
                    a0.l(childAt, z2 ? ColorStateList.valueOf(0) : null);
                }
                a0.n(childAt, R$id.tag_child_view_material_blur_alpha, Float.valueOf(this.f425d));
                if (this.f429h && (childAt instanceof ViewGroup)) {
                    f(viewGroup.getChildAt(i2), z2);
                }
            }
        }
    }

    private void h() {
        this.f437p = R$color.originui_vblur_linearlayout_divider_color_rom13_0;
        this.f438q = R$dimen.originui_vblur_linearlayout_divider_height_rom13_0;
        if (s.c(this.f422a) >= 15.0f) {
            this.f437p = R$color.originui_vblur_linearlayout_divider_color_rom15_0;
            this.f438q = R$dimen.originui_vblur_linearlayout_divider_height_rom15_0;
        }
        int iC = k.c(this.f422a, this.f437p, this.A, "vigour_tmbsel_text_color_light", "color", "vivo");
        this.f437p = iC;
        this.f435n = r.b(this.f422a, iC);
        this.f434m = r.c(this.f422a, this.f438q);
        Paint paint = new Paint(1);
        this.f433l = paint;
        paint.setStrokeWidth(this.f434m);
        this.f433l.setStyle(Paint.Style.FILL);
        this.f433l.setColor(this.f435n);
        this.f433l.setAlpha(0);
    }

    private void i(float f2) {
        Iterator it = this.f445x.iterator();
        while (it.hasNext()) {
            b.c.a(it.next());
        }
    }

    public void addOnBlurAlphaChangedListener(d dVar) {
        if (dVar == null || this.f445x.contains(dVar)) {
            return;
        }
        this.f445x.add(dVar);
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        f(view, this.f430i);
        super.addView(view, i2, layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        q.q(canvas, 0);
        if (this.f443v) {
            canvas.drawRect(this.f439r, this.f440s, this.f441t, this.f442u, this.f433l);
        }
    }

    public void e() {
        m.b("VBlurRelativeLayoutBase", "BlurRelativeLayout-blurBackground-blurEnabled:" + this.f423b + ",global blur enabled:" + f.p(getContext()) + ",view blur enabled:" + f.f());
        f.w(this, this.f424c, this.f447z, false, this.f423b, k.f(this.f422a), false, this.f426e, this.f446y, new b());
    }

    @Override // android.widget.RelativeLayout, android.view.ViewGroup
    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public c generateLayoutParams(AttributeSet attributeSet) {
        return new c(getContext(), attributeSet);
    }

    public float getBlurAlpha() {
        return this.f425d;
    }

    public e getBlurParams() {
        return this.f447z;
    }

    public boolean getBlurResult() {
        return this.f430i;
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    public void j(float f2, boolean z2) {
        this.f425d = f2;
        if (z2) {
            setDividerAlpha(f2);
        }
        i(f2);
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            a0.n(getChildAt(i2), R$id.tag_child_view_material_blur_alpha, Float.valueOf(this.f425d));
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f427f.clear();
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            this.f427f.put(childAt, childAt.getBackground());
        }
        e();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m.b("VBlurRelativeLayoutBase", "onConfigurationChanged");
        int i2 = configuration.uiMode;
        if (i2 != this.f428g) {
            this.f428g = i2;
            int iB = r.b(this.f422a, this.f437p);
            this.f435n = iB;
            int i3 = this.f436o;
            if (i3 != 0) {
                iB = i3;
            }
            this.f433l.setAlpha((int) (this.f444w * Color.alpha(iB)));
            f.a(this);
            e();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f427f.clear();
        this.f445x.clear();
    }

    @Override // android.widget.RelativeLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        this.f439r = 0;
        this.f441t = getMeasuredWidth();
        if (this.f432k) {
            this.f440s = getMeasuredHeight() - this.f434m;
            this.f442u = getMeasuredHeight();
        } else {
            this.f440s = 0;
            this.f442u = this.f434m;
        }
    }

    public void removeOnBlurAlphaChangedListener(d dVar) {
        if (dVar != null && this.f445x.contains(dVar)) {
            this.f445x.remove(dVar);
        }
    }

    public void setBlurAlpha(float f2) {
        j(f2, true);
    }

    public void setBlurEnabled(boolean z2) {
        m.b("VBlurRelativeLayoutBase", "setBlurEnabled:" + z2);
        this.f423b = z2;
        e();
    }

    public void setBlurSource(int i2) {
        this.f446y = i2;
    }

    public void setCustomDividerColor(int i2) {
        this.f436o = i2;
        this.f433l.setColor(i2);
        this.f433l.setAlpha((int) (Color.alpha(this.f436o) * this.f444w));
        invalidate();
    }

    public void setDividerAlpha(float f2) {
        float fMin = Math.min(1.0f, Math.max(f2, 0.0f));
        if (m.f583b) {
            m.b("VBlurRelativeLayoutBase", "setDividerAlpha-alpha: " + fMin + ",mDividerAlpha:" + this.f444w);
        }
        if (fMin == this.f444w) {
            return;
        }
        this.f444w = fMin;
        int i2 = this.f436o;
        if (i2 == 0) {
            i2 = this.f435n;
        }
        this.f433l.setAlpha((int) (fMin * Color.alpha(i2)));
        invalidate();
    }

    public void setDividerBottom(boolean z2) {
        this.f432k = z2;
        invalidate();
    }

    public void setDividerHeight(int i2) {
        this.f434m = i2;
        requestLayout();
        invalidate();
    }

    public void setMaterial(int i2) {
        this.f424c = i2;
    }

    public void setMaterialGroupId(int i2) {
        this.f431j = i2;
    }

    public void setMaterialNightMode(int i2) {
        this.f426e = i2;
    }

    public void setNeedClearAllChildBackground(boolean z2) {
        this.f429h = z2;
    }

    public VBlurRelativeLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VBlurRelativeLayout(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VBlurRelativeLayout(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f424c = 2;
        this.f426e = 0;
        this.f427f = new HashMap();
        this.f428g = -1;
        this.f429h = false;
        this.f432k = true;
        this.f444w = 0.0f;
        this.f445x = new CopyOnWriteArrayList();
        this.f446y = 1;
        this.f422a = context;
        this.f423b = f.p(getContext()) && f.f();
        this.f428g = context.getResources().getConfiguration().uiMode;
        this.A = k.f(context);
        a0.m(this, new a());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VBlurRelativeLayout, i2, 0);
        this.f431j = typedArrayObtainStyledAttributes.getInteger(R$styleable.VBlurRelativeLayout_blurShareGroupId, -1);
        typedArrayObtainStyledAttributes.recycle();
        this.f447z = new e();
        h();
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
        }
    }
}
