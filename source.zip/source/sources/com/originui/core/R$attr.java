package com.originui.core;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static final int blurShareGroupId = 2130837512;
    public static final int layout_os50_blur_effect = 2130837636;
    public static final int vKeepBackground = 2130837720;
    public static final int vblurSource = 2130837745;
    public static final int vclearInnerChildBackgroundLevel = 2130837747;
    public static final int vmaterialGroupId = 2130837760;
}
