package com.originui.core;

import com.vivo.vmdri.R;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$styleable {
    public static final int VBlurLinearLayout_LayoutParams_vKeepBackground = 0;
    public static final int VBlurLinearLayout_LayoutParams_vclearInnerChildBackgroundLevel = 1;
    public static final int VBlurLinearLayout_vblurSource = 0;
    public static final int VBlurLinearLayout_vmaterialGroupId = 1;
    public static final int VBlurRelativeLayout_Layout_layout_os50_blur_effect = 0;
    public static final int VBlurRelativeLayout_blurShareGroupId = 0;
    public static final int[] VBlurLinearLayout = {R.attr.vblurSource, R.attr.vmaterialGroupId};
    public static final int[] VBlurLinearLayout_LayoutParams = {R.attr.vKeepBackground, R.attr.vclearInnerChildBackgroundLevel};
    public static final int[] VBlurRelativeLayout = {R.attr.blurShareGroupId};
    public static final int[] VBlurRelativeLayout_Layout = {R.attr.layout_os50_blur_effect};
}
