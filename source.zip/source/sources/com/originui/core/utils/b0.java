package com.originui.core.utils;

import android.content.Context;
import android.os.UserHandle;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int f507a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static int f508b = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f509c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static int f510d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f511e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f512f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static boolean f513g = false;

    private static Integer a() {
        Integer num = null;
        try {
            if (f509c == null) {
                Class[] clsArr = new Class[0];
                f509c = UserHandle.class.getDeclaredMethod("myUserId", null);
            }
            f509c.setAccessible(true);
            Object objInvoke = f509c.invoke(null, null);
            if (objInvoke instanceof Integer) {
                num = (Integer) objInvoke;
            }
        } catch (Exception e2) {
            m.f("VVXSpaceUtils", "getUserId error = ", e2);
        }
        m.b("VVXSpaceUtils", "getCurrentUserId:" + num);
        return num;
    }

    public static int b() {
        if (f513g) {
            m.b("VVXSpaceUtils", "getXSpaceUserId:" + f510d);
            return f510d;
        }
        int iIntValue = f508b;
        try {
            Field fieldA = q.a(UserHandle.class, "XSPACE_USER_ID");
            if (fieldA != null) {
                fieldA.setAccessible(true);
                iIntValue = ((Integer) fieldA.get(null)).intValue();
            }
        } catch (Exception e2) {
            m.e("VVXSpaceUtils", "getXSpaceUserId error:" + e2.getMessage());
        }
        if (f510d != f508b) {
            f513g = true;
            f510d = iIntValue;
        }
        m.b("VVXSpaceUtils", "getXSpaceUserId:" + f510d);
        return iIntValue;
    }

    public static boolean c(Context context) {
        if (f511e) {
            m.b("VVXSpaceUtils", "isPrivacyFileManager:" + f512f);
            return f512f;
        }
        int iIntValue = a().intValue();
        if (iIntValue == f508b) {
            iIntValue = Math.max(context.getApplicationInfo().uid / 100000, 0);
            m.i("VVXSpaceUtils", "==isPrivacyFileManager==currentUserId:" + iIntValue);
        } else {
            m.i("VVXSpaceUtils", "==isPrivacyFileManager==currentUserId:" + iIntValue);
        }
        f512f = iIntValue == b();
        f511e = true;
        m.b("VVXSpaceUtils", "isPrivacyFileManager:" + f512f);
        return f512f;
    }
}
