package com.originui.core.utils;

import android.content.Context;
import android.provider.Settings;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f577a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static boolean f578b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static boolean f579c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Method f580d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static Method f581e;

    public static boolean a(Context context) {
        return f577a && d(context);
    }

    public static int b(Context context) {
        return Settings.System.getInt(context.getContentResolver(), "realtime_blur_state", 0);
    }

    public static boolean c() {
        boolean zB;
        if (f579c) {
            return f578b;
        }
        f579c = true;
        try {
            Class<?> cls = Class.forName("android.util.FtFeature");
            if (f580d == null) {
                Method declaredMethod = cls.getDeclaredMethod("isFeatureSupport", String.class);
                f580d = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            Boolean bool = (Boolean) f580d.invoke(null, "vivo.software.originui.diffused.light");
            if (bool == null || !bool.booleanValue()) {
                zB = false;
            } else {
                if (f581e == null) {
                    Method declaredMethod2 = cls.getDeclaredMethod("getFeatureAttribute", String.class, String.class, String.class);
                    f581e = declaredMethod2;
                    declaredMethod2.setAccessible(true);
                }
                zB = v.b("6", (String) f581e.invoke(cls, "vivo.software.originui.diffused.light", "version", "1"));
            }
            f578b = zB;
        } catch (Exception unused) {
            m.e("VLightEffectUtils", "isFeatureSupport failed");
            f578b = false;
        }
        return f578b;
    }

    public static boolean d(Context context) {
        return b(context) == 1;
    }
}
