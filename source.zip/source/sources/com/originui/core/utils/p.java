package com.originui.core.utils;

import android.content.Context;
import android.content.res.Resources;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class p {
    public static int a(float f2) {
        float f3 = Resources.getSystem().getDisplayMetrics().density * f2;
        if (Math.abs(f3) <= 0.2f) {
            return 0;
        }
        return Math.round(f3);
    }

    public static int b(Context context, float f2) {
        float f3 = context.getResources().getDisplayMetrics().density * f2;
        if (Math.abs(f3) <= 0.2f) {
            return 0;
        }
        return Math.round(f3);
    }

    public static int c(float f2) {
        if (Math.abs(f2) <= 0.0f) {
            return 0;
        }
        return (int) ((f2 / Resources.getSystem().getDisplayMetrics().scaledDensity) + 0.5f);
    }

    public static float d(Context context, float f2) {
        float f3 = f2 / context.getResources().getDisplayMetrics().scaledDensity;
        if (Math.abs(f2) <= 0.0f) {
            return 0.0f;
        }
        return f3;
    }

    public static int e(Context context, float f2) {
        float f3 = context.getResources().getDisplayMetrics().scaledDensity * f2;
        if (Math.abs(f3) <= 0.2f) {
            return 0;
        }
        return Math.round(f3);
    }
}
