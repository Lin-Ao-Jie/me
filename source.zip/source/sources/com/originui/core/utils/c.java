package com.originui.core.utils;

import android.graphics.Path;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Path f514a = new Path();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f515b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private float f516c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f517d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private float f518e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private float f519f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f520g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f521h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f522i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f523j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f524k;

    private void b(float f2, float f3, float f4, float f5, float f6, boolean z2, boolean z3, boolean z4, boolean z5) {
        this.f515b = f2;
        this.f516c = f3;
        this.f517d = f4;
        this.f518e = f5;
        this.f519f = f6;
        this.f520g = z2;
        this.f521h = z3;
        this.f522i = z4;
        this.f523j = z5;
        b.g(this.f514a, f3, f4, f5, f6, f2, z2, z3, z4, z5);
        if (m.f583b) {
            m.b("G2PathCache", toString());
        }
    }

    public Path a(float f2, float f3, float f4, float f5, float f6, boolean z2, boolean z3, boolean z4, boolean z5) {
        if (this.f514a == null) {
            this.f514a = new Path();
            b(f2, f3, f4, f5, f6, z2, z3, z4, z5);
        }
        if (this.f515b != f2 || this.f516c != f3 || this.f517d != f4 || this.f518e != f5 || this.f519f != f6 || this.f520g != z2 || this.f521h != z3 || this.f522i != z4 || this.f523j != z5) {
            b(f2, f3, f4, f5, f6, z2, z3, z4, z5);
        }
        return this.f514a;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("G2PathCache{");
        stringBuffer.append("mRadius=");
        stringBuffer.append(this.f515b);
        stringBuffer.append("mG2RoundRect=");
        stringBuffer.append(this.f524k);
        stringBuffer.append(", mLeft=");
        stringBuffer.append(this.f516c);
        stringBuffer.append(", mTop=");
        stringBuffer.append(this.f517d);
        stringBuffer.append(", mRight=");
        stringBuffer.append(this.f518e);
        stringBuffer.append(", mBottom=");
        stringBuffer.append(this.f519f);
        stringBuffer.append(", mLeftTopCorner=");
        stringBuffer.append(this.f520g);
        stringBuffer.append(", mRightTopCorner=");
        stringBuffer.append(this.f521h);
        stringBuffer.append(", mRightBottomCorner=");
        stringBuffer.append(this.f522i);
        stringBuffer.append(", mLeftBottomCorner=");
        stringBuffer.append(this.f523j);
        stringBuffer.append(", mPath=");
        stringBuffer.append(this.f514a);
        stringBuffer.append('}');
        String string = stringBuffer.toString();
        stringBuffer.setLength(0);
        return string;
    }
}
