package com.originui.core.utils;

import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Class f622a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Method f623b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f624c;

    public static int a(String str, int i2) {
        try {
            if (f624c == null) {
                Class<?> cls = Class.forName("android.os.SystemProperties");
                f622a = cls;
                f624c = cls.getDeclaredMethod("getInt", String.class, Integer.TYPE);
            }
            return ((Integer) f624c.invoke(f622a, str, Integer.valueOf(i2))).intValue();
        } catch (Exception e2) {
            m.b("SystemProperties", "get(<int>), e = " + e2);
            return i2;
        }
    }

    public static String b(String str, String str2) {
        try {
            if (f623b == null) {
                Class<?> cls = Class.forName("android.os.SystemProperties");
                f622a = cls;
                f623b = cls.getDeclaredMethod("get", String.class, String.class);
            }
            return (String) f623b.invoke(f622a, str, str2);
        } catch (Exception e2) {
            m.b("SystemProperties", "get(<String>), e = " + e2);
            return str2;
        }
    }
}
