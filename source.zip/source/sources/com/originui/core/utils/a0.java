package com.originui.core.utils;

import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.util.Property;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import android.widget.TextView;
import com.originui.core.R$id;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final c f482c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final c f483d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final Interpolator f480a = o.a(0.25f, 0.45f, 0.3f, 1.0f);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final Interpolator f481b = o.a(0.33f, 0.1f, 0.67f, 1.0f);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f484e = true;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static int f485f = -1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static long f486g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static final ThreadLocal f487h = new ThreadLocal();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static final ThreadLocal f488i = new ThreadLocal();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static int f489j = -1;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f490a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f491b;

        a(int i2, View view) {
            this.f490a = i2;
            this.f491b = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            if ((this.f490a & 1) != 0) {
                View view = this.f491b;
                view.setPivotX(view.getWidth() >> 1);
                View view2 = this.f491b;
                view2.setPivotY(view2.getHeight() >> 1);
                this.f491b.setScaleX(((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue());
                this.f491b.setScaleY(((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue());
            }
            if ((this.f490a & 2) != 0) {
                a0.q(this.f491b, ((Float) valueAnimator.getAnimatedValue("alpha")).floatValue());
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f492a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f493b;

        b(int i2, View view) {
            this.f492a = i2;
            this.f493b = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            if ((this.f492a & 1) != 0) {
                View view = this.f493b;
                view.setPivotX(view.getWidth() >> 1);
                View view2 = this.f493b;
                view2.setPivotY(view2.getHeight() >> 1);
                this.f493b.setScaleX(((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue());
                this.f493b.setScaleY(((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue());
            }
            if ((this.f492a & 2) != 0) {
                a0.q(this.f493b, ((Float) valueAnimator.getAnimatedValue("alpha")).floatValue());
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static final class c implements View.OnTouchListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f494a;

        /* synthetic */ c(boolean z2, z zVar) {
            this(z2);
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 0) {
                a0.f(view);
            } else if (action == 1) {
                if (a0.h(view, motionEvent) && this.f494a) {
                    view.performClick();
                }
                a0.g(view);
            } else if (action == 3) {
                a0.g(view);
            }
            Object objD = a0.d(view, R$id.originui_vcore_viewtouchlistener_customtouchlistener_rom14);
            return objD instanceof View.OnTouchListener ? ((View.OnTouchListener) objD).onTouch(view, motionEvent) : this.f494a;
        }

        private c(boolean z2) {
            this.f494a = z2;
        }
    }

    static {
        z zVar = null;
        f482c = new c(true, zVar);
        f483d = new c(false, zVar);
    }

    public static int a(int i2, float f2) {
        return Color.argb((int) (f2 * Color.alpha(i2)), Color.red(i2), Color.green(i2), Color.blue(i2));
    }

    public static Activity b(Context context) {
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return null;
    }

    public static int c() {
        int i2 = f489j;
        if (i2 != -1) {
            return i2;
        }
        try {
            Class[] clsArr = new Class[0];
            f489j = ((Integer) Class.forName("android.graphics.text.fontsymbol.FontSymbolSpan").getDeclaredMethod("getFontVersion", null).invoke(null, null)).intValue();
        } catch (Exception unused) {
            f489j = 1;
        }
        return f489j;
    }

    public static Object d(View view, int i2) {
        if (view == null) {
            return null;
        }
        return e(view, i2, null);
    }

    public static Object e(View view, int i2, Object obj) {
        Object tag;
        return (view == null || (tag = view.getTag(i2)) == null) ? obj : tag;
    }

    public static void f(View view) {
        float fFloatValue;
        float fFloatValue2;
        if (!v.g(d(view, R$id.originui_vcore_viewtouchlistener_checkviewenable_animator_rom14), true) || k(view)) {
            int i2 = R$id.originui_vcore_viewtouchlistener_down_animator_rom14;
            Object objD = d(view, i2);
            Object objD2 = d(view, R$id.originui_vcore_viewtouchlistener_up_animator_rom14);
            Object objD3 = d(view, R$id.originui_vcore_viewtouchlistener_animType_rom14);
            Object objD4 = d(view, R$id.originui_vcore_viewtouchlistener_scale_rom14);
            Object objD5 = d(view, R$id.originui_vcore_viewtouchlistener_alpha_rom14);
            ValueAnimator valueAnimator = objD instanceof ValueAnimator ? (ValueAnimator) objD : null;
            ValueAnimator valueAnimator2 = objD2 instanceof ValueAnimator ? (ValueAnimator) objD2 : null;
            int iIntValue = objD3 instanceof Integer ? ((Integer) objD3).intValue() : 2;
            float fFloatValue3 = objD4 instanceof Float ? ((Float) objD4).floatValue() : 0.9f;
            float fFloatValue4 = objD5 instanceof Float ? ((Float) objD5).floatValue() : 0.3f;
            if (valueAnimator != null) {
                if (valueAnimator.isRunning()) {
                    valueAnimator.cancel();
                }
                valueAnimator.removeAllUpdateListeners();
                valueAnimator.removeAllListeners();
            }
            float fFloatValue5 = 1.0f;
            if (valueAnimator2 != null) {
                if (valueAnimator2.isRunning()) {
                    fFloatValue5 = ((Float) valueAnimator2.getAnimatedValue("scaleX")).floatValue();
                    fFloatValue = ((Float) valueAnimator2.getAnimatedValue("scaleY")).floatValue();
                    fFloatValue2 = ((Float) valueAnimator2.getAnimatedValue("alpha")).floatValue();
                    valueAnimator2.cancel();
                } else {
                    fFloatValue = 1.0f;
                    fFloatValue2 = 1.0f;
                }
                valueAnimator2.removeAllUpdateListeners();
                valueAnimator2.removeAllListeners();
            } else {
                fFloatValue = 1.0f;
                fFloatValue2 = 1.0f;
            }
            if (valueAnimator == null) {
                valueAnimator = new ValueAnimator();
                valueAnimator.setInterpolator(f480a);
                n(view, i2, valueAnimator);
            }
            valueAnimator.setDuration(200L);
            valueAnimator.addUpdateListener(new a(iIntValue, view));
            valueAnimator.setValues(PropertyValuesHolder.ofFloat((Property<?, Float>) View.SCALE_X, fFloatValue5, fFloatValue3), PropertyValuesHolder.ofFloat((Property<?, Float>) View.SCALE_Y, fFloatValue, fFloatValue3), PropertyValuesHolder.ofFloat((Property<?, Float>) View.ALPHA, fFloatValue2, fFloatValue4));
            valueAnimator.start();
        }
    }

    public static void g(View view) {
        long jI = (v.g(d(view, R$id.originui_vcore_viewtouchlistener_checkviewenable_animator_rom14), true) && k(view)) ? v.i(d(view, R$id.originui_vcore_viewtouchlistener_up_animator_duration_time_rom14), 250) : 0L;
        Object objD = d(view, R$id.originui_vcore_viewtouchlistener_down_animator_rom14);
        int i2 = R$id.originui_vcore_viewtouchlistener_up_animator_rom14;
        Object objD2 = d(view, i2);
        Object objD3 = d(view, R$id.originui_vcore_viewtouchlistener_animType_rom14);
        Object objD4 = d(view, R$id.originui_vcore_viewtouchlistener_scale_rom14);
        Object objD5 = d(view, R$id.originui_vcore_viewtouchlistener_alpha_rom14);
        ValueAnimator valueAnimator = objD instanceof ValueAnimator ? (ValueAnimator) objD : null;
        ValueAnimator valueAnimator2 = objD2 instanceof ValueAnimator ? (ValueAnimator) objD2 : null;
        int iIntValue = objD3 instanceof Integer ? ((Integer) objD3).intValue() : 2;
        float fFloatValue = objD4 instanceof Float ? ((Float) objD4).floatValue() : 0.9f;
        float fFloatValue2 = fFloatValue;
        float fFloatValue3 = objD5 instanceof Float ? ((Float) objD5).floatValue() : 0.3f;
        if (valueAnimator != null) {
            if (valueAnimator.isRunning()) {
                fFloatValue = ((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue();
                fFloatValue2 = ((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue();
                fFloatValue3 = ((Float) valueAnimator.getAnimatedValue("alpha")).floatValue();
                valueAnimator.cancel();
            }
            valueAnimator.removeAllUpdateListeners();
            valueAnimator.removeAllListeners();
        }
        if (valueAnimator2 != null) {
            if (valueAnimator2.isRunning()) {
                valueAnimator2.cancel();
            }
            valueAnimator2.removeAllUpdateListeners();
            valueAnimator2.removeAllListeners();
        }
        if (valueAnimator2 == null) {
            valueAnimator2 = new ValueAnimator();
            valueAnimator2.setInterpolator(f480a);
            n(view, i2, valueAnimator2);
        }
        valueAnimator2.setDuration(jI);
        valueAnimator2.removeAllUpdateListeners();
        valueAnimator2.addUpdateListener(new b(iIntValue, view));
        valueAnimator2.setValues(PropertyValuesHolder.ofFloat((Property<?, Float>) View.SCALE_X, fFloatValue, 1.0f), PropertyValuesHolder.ofFloat((Property<?, Float>) View.SCALE_Y, fFloatValue2, 1.0f), PropertyValuesHolder.ofFloat((Property<?, Float>) View.ALPHA, fFloatValue3, 1.0f));
        valueAnimator2.start();
    }

    public static boolean h(View view, MotionEvent motionEvent) {
        if (motionEvent == null) {
            return false;
        }
        return i(view, new float[]{motionEvent.getX(), motionEvent.getY()});
    }

    public static boolean i(View view, float[] fArr) {
        if (fArr == null || fArr.length < 2) {
            return false;
        }
        return new Rect(0, 0, view.getWidth(), view.getHeight()).contains(Math.round(fArr[0]), Math.round(fArr[1]));
    }

    public static boolean j(View view) {
        return view != null && view.isEnabled();
    }

    public static boolean k(View view) {
        return j(view) && view.isClickable();
    }

    public static void l(View view, ColorStateList colorStateList) {
        if (view == null || view.getBackgroundTintList() == colorStateList) {
            return;
        }
        view.setBackgroundTintList(colorStateList);
        view.setBackgroundTintMode(PorterDuff.Mode.SRC_IN);
    }

    public static void m(View view, View.OnClickListener onClickListener) {
        if (view == null) {
            return;
        }
        view.setOnClickListener(onClickListener);
        if (onClickListener == null) {
            view.setClickable(false);
        }
    }

    public static void n(View view, int i2, Object obj) {
        if (view == null) {
            return;
        }
        view.setTag(i2, obj);
    }

    public static void o(TextView textView, int i2, float f2) {
        p(textView, i2, f2);
    }

    public static boolean p(TextView textView, int i2, float f2) {
        if (textView == null || f2 < -1.0f) {
            return false;
        }
        if (textView.getTextSize() == TypedValue.applyDimension(i2, f2, textView.getResources().getDisplayMetrics())) {
            return false;
        }
        textView.setTextSize(i2, f2);
        return true;
    }

    public static void q(View view, float f2) {
        if (view == null) {
            return;
        }
        float fMax = Math.max(0.0f, Math.min(1.0f, f2));
        if (f484e) {
            try {
                if (view.getTransitionAlpha() == fMax) {
                    return;
                }
                view.setTransitionAlpha(fMax);
                return;
            } catch (NoSuchMethodError unused) {
                f484e = false;
            }
        }
        r(view, fMax);
    }

    public static void r(View view, float f2) {
        if (view == null || view.getAlpha() == f2) {
            return;
        }
        view.setAlpha(Math.max(0.0f, Math.min(1.0f, f2)));
    }
}
