package com.originui.core.utils;

import java.util.Collection;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class g {
    public static Object a(List list, int i2) {
        if (list == null || i2 < 0 || i2 >= list.size()) {
            return null;
        }
        return list.get(i2);
    }

    public static boolean b(Collection collection) {
        return collection == null || collection.size() <= 0;
    }

    public static int c(Collection collection) {
        if (collection == null) {
            return 0;
        }
        return collection.size();
    }

    public static int d(Object[] objArr) {
        if (objArr == null) {
            return 0;
        }
        return objArr.length;
    }
}
