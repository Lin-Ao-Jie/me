package com.originui.core.utils;

import android.content.Context;
import android.graphics.Color;
import com.vivo.framework.themeicon.ThemeIconManager;
import java.util.Arrays;
import java.util.HashMap;
import vivo.app.themeicon.SystemColorListener;
import vivo.app.themeicon.SystemColorWheelListener;
import vivo.app.themeicon.SystemFilletListener;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class VThemeIconUtils {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f451a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static int f452b = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Object f453c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Object f454d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static int f455e = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static int f456f = -1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static Object f457g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static Object f458h = null;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static int[] f459i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static Object f460j = null;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static Object f461k = null;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static int f462l = -1;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private static int f463m = -1;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static boolean f464n = true;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static boolean f465o = true;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private static HashMap f466p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private static int f467q = Color.parseColor("#579CF8");

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private static int f468r = Color.parseColor("#579CF8");

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private static int f469s = Color.parseColor("#579CF8");

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private static int f470t = Color.parseColor("#0F77FF");

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private static boolean f471u = true;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static boolean f472v = false;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static String f473w = "system_accent1_";

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static String f474x = "system_accent2_";

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static String f475y = "system_accent3_";

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static String f476z = "system_neutral1_";
    public static String A = "system_neutral2_";
    public static int B = 1000;
    public static int C = 900;
    public static int D = 800;
    public static int E = 700;
    public static int F = 600;
    public static int G = 500;
    public static int H = 400;
    public static int I = 300;
    public static int J = 200;
    public static int K = 100;
    public static int L = 50;
    public static int M = 10;
    public static int N = 0;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public @interface SystemFilletLevel {
    }

    public static boolean A(Context context) {
        return n.a(context);
    }

    public static boolean B() {
        return r() >= 1;
    }

    public static boolean C(int[] iArr) {
        return iArr != null && iArr.length >= 15;
    }

    public static int D(int i2) {
        return Color.argb(Color.alpha(i2), Math.round((Color.red(i2) * 0.9f) + (Color.red(-1) * 0.1f)), Math.round((Color.green(i2) * 0.9f) + (Color.green(-1) * 0.1f)), Math.round((Color.blue(i2) * 0.9f) + (Color.blue(-1) * 0.1f)));
    }

    public static void E(Context context, boolean z2, ISystemColorRom14 iSystemColorRom14) {
        F(context, z2, iSystemColorRom14, 0);
    }

    public static void F(Context context, boolean z2, ISystemColorRom14 iSystemColorRom14, int i2) {
        x();
        if (iSystemColorRom14 == null) {
            return;
        }
        try {
            if (context == null || !z2) {
                iSystemColorRom14.setViewDefaultColor();
                return;
            }
            if (!B()) {
                iSystemColorRom14.setViewDefaultColor();
                return;
            }
            float fC = s.c(context);
            if (fC < 14.0f) {
                iSystemColorRom14.setSystemColorRom13AndLess(fC);
                return;
            }
            int[] iArrQ = q();
            if (!C(iArrQ)) {
                iSystemColorRom14.setSystemColorRom13AndLess(fC);
                return;
            }
            if (i2 == -1) {
                if (A(context)) {
                    iSystemColorRom14.setSystemColorByDayModeRom14(iArrQ);
                    return;
                } else {
                    iSystemColorRom14.setSystemColorNightModeRom14(iArrQ);
                    return;
                }
            }
            if (i2 == 1) {
                iSystemColorRom14.setSystemColorNightModeRom14(iArrQ);
                return;
            }
            if (i2 == 2) {
                iSystemColorRom14.setSystemColorByDayModeRom14(iArrQ);
            } else if (A(context)) {
                iSystemColorRom14.setSystemColorNightModeRom14(iArrQ);
            } else {
                iSystemColorRom14.setSystemColorByDayModeRom14(iArrQ);
            }
        } catch (Throwable unused) {
        }
    }

    public static int j(int i2) {
        return Color.argb(Color.alpha(i2), (int) (Color.red(i2) * 0.9f), (int) (Color.green(i2) * 0.9f), (int) (Color.blue(i2) * 0.9f));
    }

    public static int k(Context context, int i2, boolean z2) {
        return l(context, i2, z2, 3);
    }

    public static int l(Context context, int i2, boolean z2, int i3) {
        int iC;
        int iT = z2 ? t() : 1;
        switch (i2) {
            case 100:
                iC = r.c(context, c.a.f177a);
                break;
            case 101:
            default:
                iC = r.c(context, c.a.f178b);
                break;
            case 102:
                iC = r.c(context, c.a.f179c);
                break;
            case 103:
                iC = r.c(context, c.a.f180d);
                break;
            case 104:
                return q.e(context);
        }
        return Math.round(iC * m(iT, i3));
    }

    public static float m(int i2, int i3) {
        if (i2 > i3) {
            i2 = i3;
        }
        if (i2 == 0) {
            return 0.3333f;
        }
        if (i2 != 2) {
            return i2 != 3 ? 1.0f : 1.96f;
        }
        return 1.4f;
    }

    public static boolean n() {
        return f464n;
    }

    public static boolean o() {
        return f465o;
    }

    public static int p(Context context, String str, int i2) {
        return 0;
    }

    public static int[] q() {
        x();
        return f459i;
    }

    public static int r() {
        x();
        return f452b;
    }

    public static int s() {
        x();
        return f463m;
    }

    public static int t() {
        x();
        return f462l;
    }

    public static int u() {
        x();
        return f455e;
    }

    public static int v(Context context, String str, int i2) {
        HashMap map = f466p;
        if (map != null && map.containsKey(str)) {
            try {
                int iIntValue = ((Integer) f466p.get(str)).intValue();
                return (f471u && A(context)) ? j(iIntValue) : iIntValue;
            } catch (Exception unused) {
            }
        }
        return i2;
    }

    public static int w(Context context) {
        int i2 = f467q;
        if (i2 == f468r) {
            i2 = s.c(context) >= 15.0f ? f470t : f469s;
        }
        if (f471u && A(context)) {
            return s.c(context) >= 15.0f ? D(i2) : j(i2);
        }
        return i2;
    }

    private static void x() {
        float fB = s.b();
        if (f451a || fB < 13.0f) {
            return;
        }
        try {
            m.b("VThemeIconUtilsDemestic", "init start vcore_6.0.1.8");
            y();
            ThemeIconManager themeIconManager = ThemeIconManager.getInstance();
            if (fB >= 14.0f) {
                SystemColorWheelListener systemColorWheelListener = new SystemColorWheelListener() { // from class: com.originui.core.utils.VThemeIconUtils.1
                    public void onSystemColorWheelChanged(int i2, int[] iArr) {
                        m.b("VThemeIconUtilsDemestic", "onSystemColorChanged mode = " + i2 + ", colorList = " + Arrays.toString(iArr));
                        int unused = VThemeIconUtils.f452b = i2;
                        int[] unused2 = VThemeIconUtils.f459i = iArr;
                        if (VThemeIconUtils.f458h != null) {
                            ((SystemColorWheelListener) VThemeIconUtils.f458h).onSystemColorWheelChanged(i2, iArr);
                        }
                    }
                };
                f457g = systemColorWheelListener;
                themeIconManager.registerSystemColorWheelChangeListener(systemColorWheelListener);
            } else {
                SystemColorListener systemColorListener = new SystemColorListener() { // from class: com.originui.core.utils.VThemeIconUtils.2
                    public void onSystemColorChanged(int i2, int i3, int i4) {
                        m.b("VThemeIconUtilsDemestic", "onSystemColorChanged mode = " + i2 + ", primaryColor = " + i3 + ", secondaryColor = " + i4);
                        int unused = VThemeIconUtils.f452b = i2;
                        int unused2 = VThemeIconUtils.f455e = i3;
                        int unused3 = VThemeIconUtils.f456f = i4;
                        if (VThemeIconUtils.f454d != null) {
                            ((SystemColorListener) VThemeIconUtils.f454d).onSystemColorChanged(i2, i3, i4);
                        }
                    }
                };
                f453c = systemColorListener;
                themeIconManager.registerSystemColorChangeListener(systemColorListener);
            }
            SystemFilletListener systemFilletListener = new SystemFilletListener() { // from class: com.originui.core.utils.VThemeIconUtils.3
                public void onSystemFilletChanged(int i2, int i3) {
                    m.b("VThemeIconUtilsDemestic", "onSystemFilletChanged level = " + i2 + ", fillet = " + i3);
                    int unused = VThemeIconUtils.f462l = i2;
                    int unused2 = VThemeIconUtils.f463m = i3;
                    if (VThemeIconUtils.f461k != null) {
                        ((SystemFilletListener) VThemeIconUtils.f461k).onSystemFilletChanged(i2, i3);
                    }
                }
            };
            f460j = systemFilletListener;
            themeIconManager.registerSystemFilletChangeListener(systemFilletListener);
            f451a = true;
            m.b("VThemeIconUtilsDemestic", "init end");
        } catch (Throwable th) {
            m.e("VThemeIconUtilsDemestic", th.toString());
        }
    }

    public static void y() {
        float fB = s.b();
        if (fB < 13.0f) {
            return;
        }
        try {
            m.b("VThemeIconUtilsDemestic", "resetThemeIconResource start");
            ThemeIconManager themeIconManager = ThemeIconManager.getInstance();
            f452b = themeIconManager.getSystemColorMode();
            m.b("VThemeIconUtilsDemestic", "sSystemColorMode = " + f452b);
            if (fB >= 14.0f) {
                f459i = themeIconManager.getSystemColorWheelIntArray();
                m.b("VThemeIconUtilsDemestic", "sSystemColorList = " + Arrays.toString(f459i));
            } else {
                f455e = themeIconManager.getSystemPrimaryColor();
                f456f = themeIconManager.getSystemSecondaryColor();
                m.b("VThemeIconUtilsDemestic", "sPrimaryColor = " + f455e + ", sSecondaryColor = " + f456f);
            }
            f462l = themeIconManager.getSystemFilletLevel();
            f463m = themeIconManager.getSystemFillet();
            m.b("VThemeIconUtilsDemestic", "sSystemFilletLevel = " + f462l + ", sSystemFillet = " + f463m);
            m.b("VThemeIconUtilsDemestic", "resetThemeIconResource end");
        } catch (Throwable th) {
            m.e("VThemeIconUtilsDemestic", th.toString());
        }
    }

    public static boolean z(int[] iArr) {
        return C(iArr) && iArr[1] == -1;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface ISystemColorRom14 {
        public static final int ERROR_CODE_COLOR_VALUE = 0;

        default void setMyDynamicColor() {
            m.a("setMyDynamicColor");
        }

        default void setMyDynamicColorNightMode() {
            m.a("setMyDynamicColorNightMode");
        }

        default void setSystemColorByDayModeRom14(int[] iArr) {
        }

        default void setSystemColorNightModeRom14(int[] iArr) {
        }

        default void setSystemColorRom13AndLess(float f2) {
        }

        default void setViewDefaultColor() {
        }
    }
}
