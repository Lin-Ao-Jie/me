package com.originui.core.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.view.View;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Method f585a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Method f586b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f587c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static float f588d = -1.0f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f589e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f590f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static Method f591g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static String f592h = "";

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static int f593i = 0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static boolean f594j = false;

    public static Field a(Class cls, String str) {
        while (cls != Object.class) {
            try {
                return cls.getDeclaredField(str);
            } catch (Exception unused) {
                cls = cls.getSuperclass();
            }
        }
        return null;
    }

    public static Method b(Object obj, String str, Class[] clsArr) {
        if (obj == null) {
            return null;
        }
        return c(obj.getClass(), str, clsArr);
    }

    public static Method c(Class cls, String str, Class[] clsArr) {
        while (cls != Object.class) {
            try {
                return cls.getDeclaredMethod(str, clsArr);
            } catch (Exception unused) {
                cls = cls.getSuperclass();
            }
        }
        return null;
    }

    public static String d() {
        try {
            if (!TextUtils.isEmpty(f592h)) {
                return f592h;
            }
            if (f591g == null) {
                Class[] clsArr = new Class[0];
                f591g = Class.forName("android.os.FtBuild").getDeclaredMethod("getOsName", null);
            }
            String str = (String) f591g.invoke(null, null);
            f592h = str;
            return str;
        } catch (Exception unused) {
            f592h = "Funtouch";
            return "Funtouch";
        }
    }

    public static int e(Context context) {
        try {
            if (!f594j && f593i == 0) {
                Class<?> cls = Class.forName("android.util.FtDeviceInfo");
                Method declaredMethod = cls.getDeclaredMethod(h.i() ? "getFoldedUpRoundRaidus" : "getUpRoundRaidus", Context.class);
                declaredMethod.setAccessible(true);
                f593i = ((Integer) declaredMethod.invoke(cls.newInstance(), context)).intValue();
                f594j = true;
            }
        } catch (Exception e2) {
            m.b("ReflectionUtils", "getRRadius stackTrace:" + e2);
        }
        return f593i;
    }

    public static float f() {
        try {
            float f2 = f588d;
            if (f2 > -1.0f) {
                return f2;
            }
            if (f586b == null) {
                Class[] clsArr = new Class[0];
                f586b = Class.forName("android.os.FtBuild").getDeclaredMethod("getRomVersion", null);
            }
            float fFloatValue = ((Float) f586b.invoke(null, null)).floatValue();
            f588d = fFloatValue;
            return fFloatValue;
        } catch (Exception unused) {
            m.e("ReflectionUtils", "getRomVersion failed: ");
            float fG = g();
            f588d = fG;
            return fG;
        }
    }

    private static float g() {
        String strB = w.b("ro.vivo.os.version", "");
        if (v.e(strB)) {
            strB = w.b("ro.vivo.rom.version", "");
        }
        if (v.e(strB)) {
            return 0.0f;
        }
        String[] strArrSplit = strB.split("_");
        return g.d(strArrSplit) >= 2 ? v.f(strArrSplit[1], 0.0f) : v.f(strB, 0.0f);
    }

    public static Object h(String str, String str2) {
        return i(str, str2, null);
    }

    public static Object i(String str, String str2, Object obj) {
        try {
            Field fieldA = a(Class.forName(str), str2);
            fieldA.setAccessible(true);
            return fieldA.get(null);
        } catch (Exception unused) {
            return obj;
        }
    }

    public static Object j(Object obj, String str, Class[] clsArr, Object[] objArr) {
        return k(obj, str, clsArr, objArr, null);
    }

    public static Object k(Object obj, String str, Class[] clsArr, Object[] objArr, Object obj2) {
        return obj == null ? obj2 : l(obj, b(obj, str, clsArr), objArr, obj2);
    }

    public static Object l(Object obj, Method method, Object[] objArr, Object obj2) {
        if (method != null) {
            try {
                if (!method.isAccessible()) {
                    method.setAccessible(true);
                }
                return method.invoke(obj, objArr);
            } catch (Exception unused) {
            }
        }
        return obj2;
    }

    public static Object m(Object obj, String str, Object... objArr) {
        Class<?>[] clsArr = new Class[objArr.length];
        int length = objArr.length;
        for (int i2 = 0; i2 < length; i2++) {
            if (objArr[i2].getClass() == Integer.class) {
                clsArr[i2] = Integer.TYPE;
            } else if (objArr[i2].getClass() == Float.class) {
                clsArr[i2] = Float.TYPE;
            } else if (objArr[i2].getClass() == Double.class) {
                clsArr[i2] = Double.TYPE;
            } else if (objArr[i2].getClass() == Boolean.class) {
                clsArr[i2] = Boolean.TYPE;
            } else {
                clsArr[i2] = objArr[i2].getClass();
            }
        }
        Method declaredMethod = null;
        for (Class<?> superclass = obj.getClass(); superclass != Object.class; superclass = superclass.getSuperclass()) {
            try {
                declaredMethod = superclass.getDeclaredMethod(str, clsArr);
                if (declaredMethod != null) {
                    break;
                }
            } catch (Exception unused) {
            }
        }
        if (declaredMethod != null) {
            declaredMethod.setAccessible(true);
            return declaredMethod.invoke(obj, objArr);
        }
        throw new AndroidRuntimeException("can not find method: " + str);
    }

    public static Object n(String str, String str2, Class[] clsArr, Object[] objArr) {
        return o(str, str2, clsArr, objArr, null);
    }

    public static Object o(String str, String str2, Class[] clsArr, Object[] objArr, Object obj) {
        try {
            Method methodC = c(Class.forName(str), str2, clsArr);
            if (methodC != null) {
                methodC.setAccessible(true);
                return methodC.invoke(null, objArr);
            }
        } catch (Exception unused) {
        }
        return obj;
    }

    public static boolean p() {
        if (f590f) {
            return f589e;
        }
        try {
            Class[] clsArr = new Class[0];
            f589e = ((Boolean) Class.forName("android.os.FtBuild").getDeclaredMethod("isOverSeas", null).invoke(null, null)).booleanValue();
            m.i("ReflectionUtils", "isOverSeas sOverSeas : " + f589e);
            f590f = true;
            return f589e;
        } catch (Exception unused) {
            return f589e;
        }
    }

    public static void q(Canvas canvas, int i2) {
        try {
            if (f587c == null) {
                Method declaredMethod = Class.forName("android.graphics.BaseCanvas").getDeclaredMethod("setNightMode", Integer.TYPE);
                f587c = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            f587c.invoke(canvas, Integer.valueOf(i2));
        } catch (Exception unused) {
        }
    }

    public static void r(View view, int i2) {
        try {
            if (f585a == null) {
                Method declaredMethod = Class.forName("android.view.View").getDeclaredMethod("setNightMode", Integer.TYPE);
                f585a = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            f585a.invoke(view, Integer.valueOf(i2));
        } catch (Exception unused) {
        }
    }
}
