package com.originui.core.utils;

import android.content.Context;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.TextView;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class x {

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private float f625a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private float f626b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private float f627c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private boolean f628d;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private int f630f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private int f631g;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f629e = 2;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private int f632h = -1;

        public a(float f2, float f3, float f4, boolean z2) {
            this.f625a = f2;
            this.f626b = f3;
            this.f627c = f4;
            this.f628d = z2;
        }

        public int b() {
            return this.f629e;
        }

        public float c() {
            return this.f626b;
        }

        public int d() {
            return this.f631g;
        }

        public int e() {
            return this.f630f;
        }

        public float f() {
            return this.f627c;
        }

        public float g() {
            return this.f625a;
        }

        public boolean h() {
            return this.f628d;
        }

        public a i(int i2) {
            this.f631g = i2;
            return this;
        }

        public void j(int i2) {
            this.f630f = i2;
        }
    }

    public static void a(Context context, TextView textView, float f2) {
        if (i(context)) {
            f(textView, f2);
        }
    }

    public static void b(TextView textView, float f2, float f3, int i2, boolean z2) {
        c(textView, new a(i2, f3, f2, z2));
    }

    public static void c(TextView textView, a aVar) {
        int maxLines;
        if (textView == null || textView.getContext() == null || aVar == null) {
            return;
        }
        CharSequence text = textView.getText();
        if (TextUtils.isEmpty(text)) {
            return;
        }
        if (m.f583b) {
            m.b("VTextUtils", "adjustMultiLineTextSize textView=" + ((Object) textView.getText()) + ",context=" + textView.getContext());
        }
        int iD = aVar.d();
        float f2 = textView.getContext().getResources().getConfiguration().fontScale;
        float fD = aVar.c() == -1.0f ? p.d(textView.getContext(), textView.getTextSize()) : aVar.c();
        float f3 = aVar.f();
        float fG = aVar.g();
        boolean zH = aVar.h();
        int iB = aVar.b();
        float fB = textView.getContext().getResources().getDisplayMetrics().scaledDensity;
        if (iD != 0 && j.a(textView.getContext()) > iD) {
            fB = textView.getContext().getResources().getDisplayMetrics().density * j.b(textView.getContext(), iD);
        }
        if (fD < f3) {
            m.i("VTextUtils", "minSp big maxSp");
            return;
        }
        float f4 = fG * fB;
        int iE = ((aVar.e() > 0 ? aVar.e() : textView.getMeasuredWidth()) - textView.getPaddingLeft()) - textView.getPaddingRight();
        int height = (textView.getHeight() - textView.getPaddingTop()) - textView.getPaddingBottom();
        if (iE <= 0 || height <= 0) {
            m.i("VTextUtils", "availableWidth <= 0 || availableHeight <= 0");
            return;
        }
        if (aVar.f632h != -1) {
            maxLines = aVar.f632h;
        } else {
            maxLines = textView.getMaxLines() > 0 ? textView.getMaxLines() : Integer.MAX_VALUE;
        }
        TextPaint textPaint = new TextPaint(textView.getPaint());
        textPaint.setTextSize(TypedValue.applyDimension(0, fD == -1.0f ? textView.getTextSize() : j(fD, fB), textView.getContext().getResources().getDisplayMetrics()));
        StaticLayout staticLayoutBuild = StaticLayout.Builder.obtain(text, 0, text.length(), textPaint, iE).setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(textView.getLineSpacingExtra(), textView.getLineSpacingMultiplier()).setIncludePad(textView.getIncludeFontPadding()).setEllipsize(textView.getEllipsize()).setMaxLines(maxLines > 0 ? maxLines : Integer.MAX_VALUE).build();
        int i2 = 0;
        int i3 = 0;
        int ellipsisCount = 0;
        while (i2 < staticLayoutBuild.getLineCount()) {
            float lineWidth = staticLayoutBuild.getLineWidth(i2);
            CharSequence charSequence = text;
            if (lineWidth > i3) {
                i3 = (int) lineWidth;
            }
            if (ellipsisCount < staticLayoutBuild.getEllipsisCount(i2)) {
                ellipsisCount = staticLayoutBuild.getEllipsisCount(i2);
            }
            i2++;
            text = charSequence;
        }
        CharSequence charSequence2 = text;
        if (staticLayoutBuild.getLineCount() <= maxLines && i3 <= iE && ellipsisCount == 0) {
            a0.o(textView, 0, j(fD, fB));
            textView.setEllipsize(textView.getEllipsize());
        } else {
            float fD2 = d(textView, textPaint, charSequence2, iE, iB, j(fD, fB), j(f3, fB), f4, zH);
            if (fD2 < j(fD, fB)) {
                a0.o(textView, 0, fD2);
            }
        }
    }

    private static float d(TextView textView, TextPaint textPaint, CharSequence charSequence, int i2, int i3, float f2, float f3, float f4, boolean z2) {
        int maxLines = textView.getMaxLines() > 0 ? textView.getMaxLines() : Integer.MAX_VALUE;
        float f5 = f2;
        while (f5 <= f2 && f5 > f3) {
            f5 -= f4;
            if (f5 < f3) {
                f5 = f3;
            }
            textPaint.setTextSize(f5);
            StaticLayout staticLayout = new StaticLayout(charSequence, textPaint, i2, Layout.Alignment.ALIGN_NORMAL, textView.getLineSpacingMultiplier(), textView.getLineSpacingExtra(), true);
            i3--;
            if (i3 <= 0 || z2 || (staticLayout.getLineCount() <= maxLines && staticLayout.getWidth() <= i2 && staticLayout.getEllipsisCount(staticLayout.getLineCount() - 1) == 0)) {
                return f5;
            }
        }
        return f3;
    }

    private static Locale e(Context context) {
        return context.getResources().getConfiguration().getLocales().get(0);
    }

    public static void f(TextView textView, float f2) {
        textView.setLineSpacing(TypedValue.applyDimension(2, f2, textView.getResources().getDisplayMetrics()), 1.0f);
    }

    public static boolean g(Locale locale) {
        String language = locale.getLanguage();
        return "zh".equals(language) || "ja".equals(language) || "ko".equals(language);
    }

    public static boolean h(Locale locale) {
        return new HashSet(Arrays.asList("ar", "lo", "my", "ta", "gu", "kn", "ml", "or", "te", "th")).contains(locale.getLanguage());
    }

    public static boolean i(Context context) {
        Locale localeE;
        return (!s.h(context, 6.0f) || (localeE = e(context)) == null || h(localeE) || g(localeE)) ? false : true;
    }

    public static int j(float f2, float f3) {
        float f4 = f3 * f2;
        if (Math.abs(f4) <= 0.2f) {
            return 0;
        }
        return Math.round(f4);
    }
}
