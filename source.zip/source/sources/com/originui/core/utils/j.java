package com.originui.core.utils;

import android.content.Context;
import android.text.TextUtils;
import android.widget.TextView;
import com.originui.core.R$id;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static float[] f569a;

    public static int a(Context context) {
        float f2 = context.getResources().getConfiguration().fontScale;
        float[] fArrD = d();
        for (int i2 = 0; i2 < fArrD.length; i2++) {
            if (f2 < fArrD[i2] + 0.001f) {
                return i2 + 1;
            }
        }
        return 3;
    }

    public static float b(Context context, int i2) {
        float[] fArrD = d();
        if (i2 <= fArrD.length && i2 > 0) {
            return fArrD[i2 - 1];
        }
        if (!m.f583b) {
            return 1.0f;
        }
        m.e("VFontSizeLimitUtils", "getCurrentLimitScale index error");
        return 1.0f;
    }

    public static float c(Context context, float f2, int i2) {
        int iA = a(context);
        float[] fArrD = d();
        if (i2 > 0 && iA > i2 && iA > 0) {
            try {
                if (iA <= fArrD.length) {
                    float f3 = fArrD[i2 - 1] * f2;
                    if (!m.f583b || !a0.b(context).getClass().getName().contains("VToolbarDemoMainActivity")) {
                        return f3;
                    }
                    StringBuffer stringBuffer = new StringBuffer();
                    stringBuffer.append("curFontLevel  = " + iA + ";");
                    stringBuffer.append("fontLimit  = " + i2 + ";");
                    stringBuffer.append("curTextSize  = " + f2 + ";");
                    stringBuffer.append("limitSize  = " + f3 + ";");
                    stringBuffer.append("sysFontLevel  = " + Arrays.toString(fArrD) + ";");
                    StringBuilder sb = new StringBuilder();
                    sb.append("resetFontsizeIfneeded-getTextSize: sb = ");
                    sb.append((Object) stringBuffer);
                    m.b("VFontSizeLimitUtils", sb.toString());
                    return f3;
                }
            } catch (Exception e2) {
                m.e("VFontSizeLimitUtils", "getFontSizeIfNeeded error=" + e2.getMessage());
                return f2;
            }
        }
        return f2 * context.getResources().getConfiguration().fontScale;
    }

    public static float[] d() {
        float[] fArr = f569a;
        if (fArr != null) {
            return fArr;
        }
        try {
            String strE = e("persist.vivo.font_size_level");
            m.b("VFontSizeLimitUtils", "getSysLevel: " + strE);
            if (strE != null) {
                String[] strArrSplit = strE.split(";");
                f569a = new float[strArrSplit.length];
                for (int i2 = 0; i2 < strArrSplit.length; i2++) {
                    f569a[i2] = Float.parseFloat(strArrSplit[i2]);
                }
                return f569a;
            }
        } catch (Exception e2) {
            m.e("VFontSizeLimitUtils", "getSysLevel error=" + e2.getMessage());
        }
        if (!q.p()) {
            f569a = new float[]{0.8f, 0.9f, 1.0f, 1.12f, 1.25f, 1.54f, 1.88f};
        } else if (TextUtils.equals(w.b("ro.product.customize.bbk", "N"), "EEA")) {
            f569a = new float[]{0.85f, 1.0f, 1.15f, 1.3f, 1.54f, 2.0f};
        } else {
            f569a = new float[]{0.85f, 1.0f, 1.15f, 1.3f, 1.54f};
        }
        return f569a;
    }

    public static String e(String str) {
        try {
            Method declaredMethod = Class.forName("android.os.SystemProperties").getDeclaredMethod("get", String.class);
            declaredMethod.setAccessible(true);
            return (String) declaredMethod.invoke(null, str);
        } catch (Exception unused) {
            return null;
        }
    }

    public static boolean f(Context context, TextView textView, int i2) {
        if (textView == null) {
            return false;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(textView);
        return g(context, arrayList, i2);
    }

    public static boolean g(Context context, List list, int i2) throws Throwable {
        String str;
        String str2;
        String str3;
        StringBuilder sb;
        float[] fArr;
        float f2;
        Iterator it;
        String str4 = "resetFontsizeIfneeded-s1: sb = ";
        String str5 = "VFontSizeLimitUtils";
        int iA = a(context);
        float[] fArrD = d();
        StringBuffer stringBuffer = new StringBuffer();
        try {
            float f3 = context.getResources().getConfiguration().fontScale;
            if (i2 <= 0 || iA < i2 || iA <= 0 || iA > fArrD.length || g.b(list)) {
                str3 = "resetFontsizeIfneeded-s1: sb = ";
                str2 = "VFontSizeLimitUtils";
                sb = new StringBuilder();
                sb.append(str3);
                sb.append((Object) stringBuffer);
                m.b(str2, sb.toString());
                return false;
            }
            stringBuffer.append("【");
            Iterator it2 = list.iterator();
            while (it2.hasNext()) {
                try {
                    TextView textView = (TextView) it2.next();
                    try {
                        try {
                            stringBuffer.append("textView = " + r.g(textView) + ";");
                            float textSize = textView.getTextSize();
                            float f4 = fArrD[i2 + (-1)];
                            float f5 = (textSize / f3) * f4;
                            int i3 = R$id.tag_last_set_fontlevel_curtextsize;
                            float fH = v.h(a0.d(textView, i3), -1.0f);
                            int i4 = R$id.tag_last_set_fontlevel_curfontlimit;
                            fArr = fArrD;
                            try {
                                f2 = f3;
                                try {
                                    int i5 = v.i(a0.d(textView, i4), -1);
                                    int i6 = R$id.tag_last_set_fontlevel_curtotextsize;
                                    it = it2;
                                    try {
                                        str4 = str4;
                                        try {
                                            float fH2 = v.h(a0.d(textView, i6), -1.0f);
                                            StringBuilder sb2 = new StringBuilder();
                                            str5 = str5;
                                            try {
                                                sb2.append("curTextSize  = ");
                                                sb2.append(textSize);
                                                sb2.append(";");
                                                stringBuffer.append(sb2.toString());
                                                stringBuffer.append("curFontLimit  =【" + i2 + "__" + f4 + "】;");
                                                StringBuilder sb3 = new StringBuilder();
                                                sb3.append("curTotextSize  = ");
                                                sb3.append(f5);
                                                sb3.append(";");
                                                stringBuffer.append(sb3.toString());
                                                stringBuffer.append("tagCurTextSize  = " + fH + ";");
                                                stringBuffer.append("tagCurFontLimit  = " + i5 + ";");
                                                stringBuffer.append("tagCurToTextSize  = " + fH2 + ";");
                                                String str6 = "===>do[0];";
                                                if (fH <= 0.0f || fH2 <= 0.0f || i5 <= 0) {
                                                    if (iA == i2) {
                                                        stringBuffer.append("===>do[curFontLevel == curFontLimit];");
                                                        it2 = it;
                                                        fArrD = fArr;
                                                        f3 = f2;
                                                        str4 = str4;
                                                        str5 = str5;
                                                    } else {
                                                        stringBuffer.append(str6);
                                                        a0.n(textView, i3, Float.valueOf(textSize));
                                                        a0.n(textView, i4, Integer.valueOf(i2));
                                                        a0.n(textView, i6, Float.valueOf(f5));
                                                        a0.o(textView, 0, f5);
                                                        str2 = str5;
                                                        it2 = it;
                                                        str5 = str2;
                                                        fArrD = fArr;
                                                        f3 = f2;
                                                        str4 = str4;
                                                    }
                                                } else if (textSize == fH2 && i5 == i2) {
                                                    stringBuffer.append("===>do[continue];");
                                                    it2 = it;
                                                    fArrD = fArr;
                                                    f3 = f2;
                                                    str4 = str4;
                                                    str5 = str5;
                                                } else {
                                                    if (fH2 == textSize && i5 != i2) {
                                                        f5 = (fH / f2) * f4;
                                                        str6 = "===>do[1];";
                                                        textSize = fH;
                                                    }
                                                    if (fH2 != textSize && i5 == i2) {
                                                        f5 = (textSize / f2) * f4;
                                                        str6 = "===>do[2];";
                                                    }
                                                    stringBuffer.append(str6);
                                                    a0.n(textView, i3, Float.valueOf(textSize));
                                                    a0.n(textView, i4, Integer.valueOf(i2));
                                                    a0.n(textView, i6, Float.valueOf(f5));
                                                    a0.o(textView, 0, f5);
                                                    str2 = str5;
                                                    it2 = it;
                                                    str5 = str2;
                                                    fArrD = fArr;
                                                    f3 = f2;
                                                    str4 = str4;
                                                }
                                            } catch (Exception e2) {
                                                e = e2;
                                                try {
                                                    str2 = str5;
                                                    try {
                                                        m.e(str2, "resetFontsizeIfneeded error=" + e.getMessage());
                                                    } catch (Exception unused) {
                                                        str3 = str4;
                                                        sb = new StringBuilder();
                                                        sb.append(str3);
                                                        sb.append((Object) stringBuffer);
                                                        m.b(str2, sb.toString());
                                                        return false;
                                                    } catch (Throwable th) {
                                                        th = th;
                                                        str = str4;
                                                        m.b(str2, str + ((Object) stringBuffer));
                                                        throw th;
                                                    }
                                                } catch (Exception unused2) {
                                                    str2 = str5;
                                                    str3 = str4;
                                                    sb = new StringBuilder();
                                                    sb.append(str3);
                                                    sb.append((Object) stringBuffer);
                                                    m.b(str2, sb.toString());
                                                    return false;
                                                } catch (Throwable th2) {
                                                    th = th2;
                                                    str2 = str5;
                                                    str = str4;
                                                    m.b(str2, str + ((Object) stringBuffer));
                                                    throw th;
                                                }
                                            } catch (Throwable th3) {
                                                th = th3;
                                                str = str4;
                                                str2 = str5;
                                                m.b(str2, str + ((Object) stringBuffer));
                                                throw th;
                                            }
                                        } catch (Exception e3) {
                                            e = e3;
                                            str5 = str5;
                                            str2 = str5;
                                            m.e(str2, "resetFontsizeIfneeded error=" + e.getMessage());
                                            it2 = it;
                                            str5 = str2;
                                            fArrD = fArr;
                                            f3 = f2;
                                            str4 = str4;
                                        } catch (Throwable th4) {
                                            th = th4;
                                            str5 = str5;
                                            str = str4;
                                            str2 = str5;
                                            m.b(str2, str + ((Object) stringBuffer));
                                            throw th;
                                        }
                                    } catch (Exception e4) {
                                        e = e4;
                                        str4 = str4;
                                    }
                                } catch (Exception e5) {
                                    e = e5;
                                    str4 = str4;
                                    str5 = str5;
                                    it = it2;
                                    str2 = str5;
                                    m.e(str2, "resetFontsizeIfneeded error=" + e.getMessage());
                                    it2 = it;
                                    str5 = str2;
                                    fArrD = fArr;
                                    f3 = f2;
                                    str4 = str4;
                                }
                            } catch (Exception e6) {
                                e = e6;
                                f2 = f3;
                                it = it2;
                                str2 = str5;
                                m.e(str2, "resetFontsizeIfneeded error=" + e.getMessage());
                                it2 = it;
                                str5 = str2;
                                fArrD = fArr;
                                f3 = f2;
                                str4 = str4;
                            }
                        } catch (Throwable th5) {
                            th = th5;
                            str4 = str4;
                        }
                    } catch (Exception e7) {
                        e = e7;
                        fArr = fArrD;
                    }
                } catch (Exception unused3) {
                    str4 = str4;
                    str2 = str5;
                } catch (Throwable th6) {
                    th = th6;
                    str4 = str4;
                    str2 = str5;
                }
            }
            str4 = str4;
            str2 = str5;
            stringBuffer.append("】");
            m.b(str2, str4 + ((Object) stringBuffer));
            return true;
        } catch (Exception unused4) {
            str3 = str4;
            str2 = str5;
        } catch (Throwable th7) {
            th = th7;
            str = str4;
            str2 = str5;
        }
        sb = new StringBuilder();
        sb.append(str3);
        sb.append((Object) stringBuffer);
        m.b(str2, sb.toString());
        return false;
    }
}
