package com.originui.core.utils;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static float f595a = -1.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static boolean f596b = false;

    public static String a() {
        return q.d();
    }

    public static float b() {
        return q.f();
    }

    public static float c(Context context) {
        Object obj;
        float f2 = f595a;
        if (f2 != -1.0f) {
            return f2;
        }
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null && (obj = bundle.get("originui.version.limit")) != null) {
                String string = obj.toString();
                if (!TextUtils.isEmpty(string)) {
                    if (Float.parseFloat(string) == -1.0f) {
                        f595a = Float.MAX_VALUE;
                    } else if (!q.p() || TextUtils.equals(a(), "vos")) {
                        f595a = Math.max(Float.parseFloat(string), b());
                    } else {
                        m.h("overseas is not vos");
                        f595a = 1.0f;
                    }
                    f596b = true;
                    m.h("getMergedRomVersion sMergedRomVersion : " + f595a + " , vcore_6.0.1.8");
                    return f595a;
                }
            }
        } catch (Exception e2) {
            m.f("VRomVersionUtils", "getMergedRomVersion error = ", e2);
        }
        f596b = false;
        float fB = b();
        f595a = fB;
        return fB;
    }

    public static boolean d() {
        return h.e();
    }

    public static boolean e(Context context) {
        return (!q.p() && c(context) >= 15.0f) || g(context);
    }

    public static boolean f(Context context) {
        return (!q.p() && c(context) >= 16.0f) || g(context);
    }

    public static boolean g(Context context) {
        if (!d()) {
            return false;
        }
        String strA = a();
        if (v.c("vos", strA)) {
            return c(context) > 6.0f;
        }
        return v.c("funtouch", strA) && c(context) > 15.0f;
    }

    public static boolean h(Context context, float f2) {
        return c(context) > f2 && "vos".equalsIgnoreCase(a());
    }

    public static boolean i() {
        return q.p();
    }
}
