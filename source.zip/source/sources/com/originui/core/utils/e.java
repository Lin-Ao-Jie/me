package com.originui.core.utils;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Process;
import android.os.ServiceManager;
import android.os.SystemProperties;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final int f532a = Process.myPid();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final Object f533b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static long f534c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int f535d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final boolean f536e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static final boolean f537f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f538g;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static IBinder f539a;

        public static long a(long j2, String str, String str2, int i2, int i3, int i4, int i5, int i6, int i7, boolean z2, int i8) {
            if (c() == null) {
                return -1L;
            }
            Parcel parcelObtain = Parcel.obtain();
            try {
                parcelObtain.writeLong(j2);
                parcelObtain.writeString(str);
                parcelObtain.writeString(str2);
                parcelObtain.writeInt(i2);
                parcelObtain.writeInt(i3);
                parcelObtain.writeInt(i4);
                parcelObtain.writeInt(i5);
                parcelObtain.writeInt(i6);
                parcelObtain.writeInt(i7);
                parcelObtain.writeInt(z2 ? 1 : 0);
                parcelObtain.writeInt(i8);
                f539a.transact(23, parcelObtain, null, 1);
                return j2;
            } catch (Exception e2) {
                m.e("RmsManager", "acquireRefreshRate failed: " + e2);
                return -1L;
            } finally {
                parcelObtain.recycle();
            }
        }

        public static long b(long j2, String str, String str2, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14) {
            if (c() == null) {
                return -1L;
            }
            Parcel parcelObtain = Parcel.obtain();
            try {
                parcelObtain.writeLong(j2);
                parcelObtain.writeString(str);
                parcelObtain.writeString(str2);
                parcelObtain.writeInt(i2);
                parcelObtain.writeInt(i3);
                parcelObtain.writeInt(i4);
                parcelObtain.writeInt(i5);
                parcelObtain.writeInt(i6);
                parcelObtain.writeInt(i7);
                parcelObtain.writeInt(i8);
                parcelObtain.writeInt(i9);
                parcelObtain.writeInt(i10);
                parcelObtain.writeInt(i11);
                parcelObtain.writeInt(i12);
                parcelObtain.writeInt(i13);
                parcelObtain.writeInt(i14);
                f539a.transact(31, parcelObtain, null, 1);
                return j2;
            } catch (Exception e2) {
                m.e("RmsManager", "acquireRefreshRateV2 failed: " + e2);
                return -1L;
            } finally {
                parcelObtain.recycle();
            }
        }

        private static IBinder c() {
            IBinder iBinder = f539a;
            if (iBinder != null) {
                return iBinder;
            }
            synchronized (a.class) {
                try {
                    if (f539a == null) {
                        f539a = ServiceManager.checkService("rms");
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return f539a;
        }

        public static boolean d() {
            if (c() == null) {
                return false;
            }
            Parcel parcelObtain = Parcel.obtain();
            Parcel parcelObtain2 = Parcel.obtain();
            try {
                try {
                    if (f539a.transact(31, parcelObtain, parcelObtain2, 0)) {
                        parcelObtain.recycle();
                        parcelObtain2.recycle();
                        return true;
                    }
                    parcelObtain.recycle();
                    parcelObtain2.recycle();
                    return false;
                } catch (Exception e2) {
                    m.e("RmsManager", "createRefreshRateScene failed: " + e2);
                    parcelObtain.recycle();
                    parcelObtain2.recycle();
                    return false;
                }
            } catch (Throwable th) {
                parcelObtain.recycle();
                parcelObtain2.recycle();
                throw th;
            }
        }

        public static boolean e(int i2, long j2) {
            if (c() == null) {
                return false;
            }
            Parcel parcelObtain = Parcel.obtain();
            try {
                parcelObtain.writeInt(i2);
                parcelObtain.writeLong(j2);
                f539a.transact(24, parcelObtain, null, 1);
                return true;
            } catch (Exception e2) {
                m.e("RmsManager", "releaseRefreshRate failed: " + e2);
                return false;
            } finally {
                parcelObtain.recycle();
            }
        }
    }

    static {
        boolean z2 = false;
        int i2 = SystemProperties.getInt("debug.rms.refresh_rate_adjuster_version", 0);
        f535d = i2;
        f536e = i2 >= 220903;
        if (SystemProperties.getBoolean("persist.sys.vivo.refresh_rate_adjuster", true) && SystemProperties.getBoolean("persist.sys.vivo.refresh_rate_manager", true)) {
            z2 = true;
        }
        f537f = z2;
        f538g = -1;
    }

    public static long a(String str, String str2, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13) {
        if (b()) {
            return a.b(c(), str, str2, i2, i3, i4, i5, i6, i7, i8, i9, f532a, i10, i11, i12, i13);
        }
        int i14 = i5 & 255;
        int i15 = i6 & 255;
        int i16 = i7 & 65535;
        boolean z2 = (i11 & 4) != 0;
        int i17 = (i11 & 2) == 0 ? 0 : 1;
        if ((i11 & 1) != 0) {
            i17 |= 8;
        }
        if ((i11 & 8) != 0) {
            i17 |= 16;
        }
        if (i15 > 0) {
            i17 = (i15 << 8) | i17 | 4;
        }
        if (i14 >= i4) {
            i14 = 0;
        }
        if (i14 > 0) {
            i17 = (i14 << 16) | i17 | 2;
        }
        return a.a(c(), str, str2, i4, i8, i9, f532a, i10, i16, z2, i17);
    }

    public static boolean b() {
        if (f538g == -1) {
            f538g = a.d() ? 1 : 0;
        }
        return f538g == 1;
    }

    private static long c() {
        long j2;
        synchronized (f533b) {
            j2 = f534c + 1;
            f534c = j2;
        }
        return j2;
    }

    public static boolean d(long j2) {
        if (j2 <= 0) {
            return true;
        }
        return a.e(f532a, j2);
    }
}
