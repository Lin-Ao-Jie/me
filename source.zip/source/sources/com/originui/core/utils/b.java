package com.originui.core.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final double f495a = Math.cos(0.4363323129985824d);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final double f496b = Math.sin(0.4363323129985824d);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final boolean f497c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Method f498d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static Method f499e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static Method f500f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static Method f501g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static Method f502h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static Method f503i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static Method f504j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static Method f505k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static Method f506l;

    static {
        f497c = w.a("com.originui.debug.g2path.style", 0) == 1;
        f498d = null;
        f499e = null;
        f500f = null;
        f501g = null;
        f502h = null;
        f503i = null;
        f504j = null;
        f505k = null;
        f506l = null;
    }

    public static boolean a(Context context, Canvas canvas, float f2, float f3, float f4, float f5, float[] fArr, Paint paint) {
        return b(context, canvas, f2, f3, f4, f5, fArr, paint, true);
    }

    public static boolean b(Context context, Canvas canvas, float f2, float f3, float f4, float f5, float[] fArr, Paint paint, boolean z2) {
        if (canvas == null) {
            return false;
        }
        boolean zL = context == null ? true : l(context);
        if (f500f == null && zL) {
            Class cls = Float.TYPE;
            f500f = q.b(canvas, "drawG2RoundRect", new Class[]{cls, cls, cls, cls, float[].class, Paint.class});
            if (m.f583b) {
                m.a("canvasDrawG2RoundRectRadii canvas:" + canvas + ",sMethodCanvasDrawG2RoundRectRadii:" + f500f);
            }
        }
        try {
            float fMax = Math.max(fArr[0], Math.max(fArr[2], Math.max(fArr[4], fArr[6])));
            int i2 = (int) (f4 - f2);
            int i3 = (int) (f5 - f3);
            if (f500f == null || (z2 && !k(i2, i3, h(i2, i3, fArr)))) {
                Path path = new Path();
                path.addRoundRect(f2, f3, f4, f5, fArr, Path.Direction.CW);
                canvas.drawPath(path, paint);
            } else {
                f500f.invoke(canvas, Float.valueOf(f2), Float.valueOf(f3), Float.valueOf(f4), Float.valueOf(f5), fArr, paint);
                d.a(canvas, f2, f3, f4, f5, fMax, "G2");
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static boolean c(Canvas canvas, float f2, float f3, float f4, float f5, float[] fArr, Paint paint) {
        return a(null, canvas, f2, f3, f4, f5, fArr, paint);
    }

    public static boolean d(Canvas canvas, float f2, float f3, float f4, float f5, float[] fArr, Paint paint, boolean z2) {
        return b(null, canvas, f2, f3, f4, f5, fArr, paint, z2);
    }

    public static int e(float f2, float f3) {
        return (int) f2;
    }

    public static Path f(float f2, float f3, float f4, float f5, float f6, boolean z2, boolean z3, boolean z4, boolean z5) {
        return g(null, f2, f3, f4, f5, f6, z2, z3, z4, z5);
    }

    public static Path g(Path path, float f2, float f3, float f4, float f5, float f6, boolean z2, boolean z3, boolean z4, boolean z5) {
        Path path2;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        float f15;
        float f16;
        if (path == null) {
            path2 = new Path();
        } else {
            path.reset();
            path2 = path;
        }
        float f17 = f4 - f2;
        float f18 = f5 - f3;
        if (f17 < 0.0f || f18 < 0.0f) {
            if (m.f583b) {
                m.h("getG2RoundConerPath is  null");
            }
            return path2;
        }
        float f19 = 2.2f * f6;
        if (f19 > f17 || f19 > f18) {
            if (m.f583b) {
                m.h("Return to normal rounded corners, g2 corner path radius max is " + f6);
            }
            return i(path2, f2, f3, f4, f5, f6, z2, z3, z4, z5);
        }
        double d2 = f6;
        float f20 = (float) (d2 - (f495a * d2));
        float f21 = (float) (d2 - (f496b * d2));
        float f22 = (-0.008f) * f6;
        float f23 = 0.4f * f6;
        float f24 = 1.1f * f6;
        if (Math.min(f17, f18) > 2.6f * f6) {
            f22 = f6 * (-0.013f);
            f23 = f6 * 0.61f;
            f24 = f6 * 1.3f;
        }
        float f25 = f22;
        float f26 = f23;
        float f27 = f24;
        float f28 = f3 + f27;
        path2.moveTo(f2, f28);
        if (z2) {
            float f29 = f2 + f20;
            float f30 = f3 + f21;
            f7 = f28;
            f9 = f20;
            f11 = 40.0f;
            path2.cubicTo(f2, f28 - f26, f29 - f25, f30, f29, f30);
            Path path3 = path2;
            float f31 = f6 * 2.0f;
            path3.arcTo(new RectF(f2, f3, f2 + f31, f31 + f3), 205.0f, 40.0f);
            path2 = path3;
            float f32 = f2 + f27;
            f10 = f2;
            path2.cubicTo(f2 + f21, (f3 + f9) - f25, f32 - f26, f3, f32, f3);
            f8 = f3;
        } else {
            f7 = f28;
            f8 = f3;
            f9 = f20;
            f10 = f2;
            f11 = 40.0f;
            path2.lineTo(f10, f8);
            path2.lineTo(f10 + f27, f8);
        }
        float f33 = f4 - f27;
        path2.lineTo(f33, f8);
        if (z3) {
            float f34 = f4 - f21;
            float f35 = f8 + f9;
            f12 = f33;
            path2.cubicTo(f33 + f26, f8, f34, f35 - f25, f34, f35);
            float f36 = f6 * 2.0f;
            path2.arcTo(new RectF(f4 - f36, f8, f4, f36 + f8), 295.0f, f11);
            f13 = f4;
            float f37 = f7;
            path2.cubicTo((f4 - f9) + f25, f8 + f21, f13, f7 - f26, f4, f37);
            f14 = f37;
        } else {
            f12 = f33;
            f13 = f4;
            f14 = f7;
            path2.lineTo(f13, f8);
            path2.lineTo(f13, f14);
        }
        float f38 = f5 - f27;
        path2.lineTo(f13, f38);
        if (z4) {
            float f39 = f13 - f9;
            float f40 = f5 - f21;
            path2.cubicTo(f4, f38 + f26, f39 + f25, f40, f39, f40);
            float f41 = f6 * 2.0f;
            path2.arcTo(new RectF(f4 - f41, f5 - f41, f4, f5), 25.0f, f11);
            f15 = f5;
            path2.cubicTo(f4 - f21, (f5 - f9) + f25, f12 + f26, f15, f12, f5);
        } else {
            f15 = f5;
            path2.lineTo(f13, f15);
            path2.lineTo(f12, f15);
        }
        float f42 = f10 + f27;
        path2.lineTo(f42, f15);
        if (z5) {
            float f43 = f10 + f21;
            float f44 = f15 - f9;
            path2.cubicTo(f42 - f26, f5, f43, f44 + f25, f43, f44);
            float f45 = f6 * 2.0f;
            path2.arcTo(new RectF(f10, f5 - f45, f45 + f10, f5), 115.0f, f11);
            float f46 = f10;
            path2.cubicTo((f10 + f9) - f25, f5 - f21, f46, f38 + f26, f2, f38);
            f16 = f46;
        } else {
            f16 = f10;
            path2.lineTo(f16, f15);
            path2.lineTo(f16, f38);
        }
        path2.lineTo(f16, f14);
        path2.close();
        n(path2, true);
        return path2;
    }

    public static float h(int i2, int i3, float[] fArr) {
        float fMax = Math.max(fArr[0], Math.max(fArr[2], Math.max(fArr[4], fArr[6])));
        if (Math.min(fArr[0], Math.min(fArr[2], Math.min(fArr[4], fArr[6]))) < 1.0f) {
            return (fMax > ((float) i2) / 2.0f || fMax > ((float) i3) / 2.0f) ? fMax / 2.0f : fMax;
        }
        return fMax;
    }

    public static Path i(Path path, float f2, float f3, float f4, float f5, float f6, boolean z2, boolean z3, boolean z4, boolean z5) {
        if (path == null) {
            path = new Path();
        } else {
            path.reset();
        }
        int i2 = (int) (f4 - f2);
        int i3 = (int) (f5 - f3);
        if (i2 < 0 || i3 < 0) {
            if (!m.f583b) {
                return null;
            }
            m.h("getNormalCornerPath is  null");
            return null;
        }
        float f7 = f6 * 2.0f;
        if (f7 > i2 || f7 > i3) {
            f6 = Math.min(i2, i3) / 2.0f;
            if (m.f583b) {
                m.h("normal corner path radius max is " + f6);
            }
        }
        float f8 = f3 + f6;
        path.moveTo(f2, f8);
        if (z2) {
            float f9 = f6 * 2.0f;
            path.arcTo(new RectF(f2, f3, f2 + f9, f9 + f3), 180.0f, 90.0f);
        } else {
            path.lineTo(f2, f3);
            path.lineTo(f2 + f6, f3);
        }
        float f10 = f4 - f6;
        path.lineTo(f10, f3);
        if (z3) {
            float f11 = f6 * 2.0f;
            path.arcTo(new RectF(f4 - f11, f3, f4, f11 + f3), 270.0f, 90.0f);
        } else {
            path.lineTo(f4, f3);
            path.lineTo(f4, f8);
        }
        float f12 = f5 - f6;
        path.lineTo(f4, f12);
        if (z4) {
            float f13 = f6 * 2.0f;
            path.arcTo(new RectF(f4 - f13, f5 - f13, f4, f5), 0.0f, 90.0f);
        } else {
            path.lineTo(f4, f5);
            path.lineTo(f10, f5);
        }
        path.lineTo(f2 + f6, f5);
        if (z5) {
            float f14 = f6 * 2.0f;
            path.arcTo(new RectF(f2, f5 - f14, f14 + f2, f5), 90.0f, 90.0f);
        } else {
            path.lineTo(f2, f5);
            path.lineTo(f2, f12);
        }
        path.lineTo(f2, f8);
        path.close();
        n(path, true);
        return path;
    }

    public static float[] j(float f2, boolean z2, boolean z3, boolean z4, boolean z5) {
        float f3 = z2 ? f2 : 0.0f;
        float f4 = z3 ? f2 : 0.0f;
        float f5 = z4 ? f2 : 0.0f;
        if (!z5) {
            f2 = 0.0f;
        }
        return new float[]{f3, f3, f4, f4, f5, f5, f2, f2};
    }

    public static boolean k(int i2, int i3, float f2) {
        boolean z2 = true;
        boolean z3 = (!q.p() && s.b() >= 16.0f) || ("vos".equalsIgnoreCase(s.a()) && s.b() > 6.0f);
        float fMin = Math.min(i2, i3);
        if (!z3 && fMin <= 2.0f * f2 * 1.4f) {
            z2 = false;
        }
        if (m.f583b) {
            m.b("isAlgorithmG2Support", "width=" + i2 + " height=" + i3 + " radius=" + f2 + " isGreaterThanOs6_0=" + z3 + " isG2Support：" + z2);
        }
        return z2;
    }

    private static boolean l(Context context) {
        if (q.p() || s.c(context) <= 14.0f) {
            return q.p() && s.c(context) > 6.0f;
        }
        return true;
    }

    public static boolean m(Outline outline, int i2, int i3, int i4, int i5, float f2, View view) {
        if (outline == null) {
            return false;
        }
        boolean zL = view == null ? true : l(view.getContext());
        if (f498d == null && zL) {
            Class cls = Integer.TYPE;
            f498d = q.b(outline, "setRoundRect", new Class[]{cls, cls, cls, cls, Float.TYPE, Boolean.TYPE});
            if (m.f583b) {
                m.a("setOutLineG2RoundRect outline:" + outline + ",sMethodOutlineSetRoundRect:" + f498d);
            }
        }
        try {
            if (f498d == null || !k(i4 - i2, i5 - i3, f2)) {
                outline.setRoundRect(i2, i3, i4, i5, e(f2, 1.0f));
                d.j(view, false, "G2");
            } else {
                f498d.invoke(outline, Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4), Integer.valueOf(i5), Float.valueOf(f2), Boolean.TRUE);
                d.j(view, true, "G2");
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static boolean n(Path path, boolean z2) {
        if (path == null || !f497c) {
            return false;
        }
        q.j(path, "setG2Style", new Class[]{Boolean.TYPE}, new Object[]{Boolean.valueOf(z2)});
        return true;
    }
}
