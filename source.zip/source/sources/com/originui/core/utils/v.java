package com.originui.core.utils;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class v {
    public static boolean a(String str, String str2) {
        return ((e(str) && e(str2)) || str == null || !str.equals(str2)) ? false : true;
    }

    public static boolean b(String str, String str2) {
        if (str == null && str2 == null) {
            return true;
        }
        return str != null && str.equals(str2);
    }

    public static boolean c(String str, String str2) {
        if (str == null && str2 == null) {
            return true;
        }
        return str != null && str.equalsIgnoreCase(str2);
    }

    public static String d(Object obj) {
        if (obj == null) {
            return null;
        }
        return obj.getClass().getSimpleName();
    }

    public static boolean e(String str) {
        return str == null || str.trim().isEmpty() || "null".equals(str);
    }

    public static float f(String str, float f2) {
        try {
            return Float.parseFloat(str);
        } catch (Exception unused) {
            return f2;
        }
    }

    public static boolean g(Object obj, boolean z2) {
        return obj instanceof Boolean ? ((Boolean) obj).booleanValue() : z2;
    }

    public static float h(Object obj, float f2) {
        return obj instanceof Float ? ((Float) obj).floatValue() : f2;
    }

    public static int i(Object obj, int i2) {
        return obj instanceof Integer ? ((Integer) obj).intValue() : i2;
    }
}
