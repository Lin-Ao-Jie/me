package com.originui.core.utils;

import android.content.Context;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class u {
    public static int a(Context context) {
        return r.c(context, k.d(context, "status_bar_height", "dimen", "android"));
    }
}
