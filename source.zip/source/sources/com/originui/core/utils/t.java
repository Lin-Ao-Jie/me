package com.originui.core.utils;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class t extends Drawable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f597a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f598b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f599c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f600d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f601e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f602f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ColorStateList f603g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f604h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Paint f605i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private ColorStateList f606j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f607k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Paint f608l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f609m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private c f610n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private c f611o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private Rect f612p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private int f613q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f614r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private Rect f615s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f616t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private boolean f617u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f618v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f619w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private Rect f620x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private Context f621y;

    public t() {
        this(0, 0, 0, 0);
    }

    private void a() {
        int i2 = this.f609m;
        this.f616t = i2 == 1;
        this.f608l.setStrokeWidth(i2);
    }

    private int b(ColorStateList colorStateList, int[] iArr, float f2) {
        if (colorStateList == null) {
            return 0;
        }
        return a0.a(colorStateList.getColorForState(iArr, 0), f2);
    }

    private void c() {
        Paint paint = new Paint(1);
        this.f605i = paint;
        paint.setStyle(Paint.Style.FILL);
        Paint paint2 = new Paint(1);
        this.f608l = paint2;
        paint2.setAntiAlias(true);
        this.f608l.setStyle(Paint.Style.STROKE);
        i();
    }

    private void i() {
        this.f605i.setColor(b(this.f603g, getState(), this.f604h));
        this.f608l.setColor(b(this.f606j, getState(), this.f607k));
        a();
    }

    public boolean d() {
        return (this.f597a & 1) != 0;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Canvas canvas2 = canvas;
        if (this.f619w) {
            q.q(canvas2, 0);
        }
        Rect bounds = getBounds();
        Rect rect = this.f615s;
        int i2 = bounds.left;
        Rect rect2 = this.f612p;
        rect.set(i2 + rect2.left, bounds.top + rect2.top, bounds.right - rect2.right, bounds.bottom - rect2.bottom);
        int iSave = canvas2.save();
        if (this.f605i.getColor() != 0) {
            if (this.f617u) {
                Context context = this.f621y;
                if (context != null) {
                    Rect rect3 = this.f615s;
                    b.b(context, canvas, rect3.left, rect3.top, rect3.right, rect3.bottom, b.j(this.f598b, this.f599c, this.f600d, this.f601e, this.f602f), this.f605i, this.f618v);
                } else {
                    Rect rect4 = this.f615s;
                    b.d(canvas, rect4.left, rect4.top, rect4.right, rect4.bottom, b.j(this.f598b, this.f599c, this.f600d, this.f601e, this.f602f), this.f605i, this.f618v);
                }
            } else {
                c cVar = this.f610n;
                float f2 = this.f598b;
                Rect rect5 = this.f615s;
                canvas2.drawPath(cVar.a(f2, rect5.left, rect5.top, rect5.right, rect5.bottom, this.f599c, this.f600d, this.f601e, this.f602f), this.f605i);
            }
            Rect rect6 = this.f615s;
            canvas2 = canvas;
            d.a(canvas2, rect6.left, rect6.top, rect6.right, rect6.bottom, this.f598b, "G2");
            canvas2.restoreToCount(iSave);
            iSave = canvas2.save();
        }
        Paint paint = this.f608l;
        if (paint != null && paint.getStrokeWidth() > 0.0f) {
            if (f()) {
                if (!this.f616t) {
                    float strokeWidth = this.f608l.getStrokeWidth() / 2.0f;
                    Rect rect7 = new Rect(this.f615s);
                    int i3 = (int) strokeWidth;
                    rect7.inset(i3, i3);
                    if (this.f617u) {
                        Context context2 = this.f621y;
                        if (context2 != null) {
                            b.b(context2, canvas, rect7.left, rect7.top, rect7.right, rect7.bottom, b.j(this.f598b, this.f599c, this.f600d, this.f601e, this.f602f), this.f608l, this.f618v);
                        } else {
                            b.d(canvas, rect7.left, rect7.top, rect7.right, rect7.bottom, b.j(this.f598b, this.f599c, this.f600d, this.f601e, this.f602f), this.f608l, this.f618v);
                        }
                    } else {
                        canvas2.drawPath(this.f611o.a(this.f598b, rect7.left, rect7.top, rect7.right, rect7.bottom, this.f599c, this.f600d, this.f601e, this.f602f), this.f608l);
                    }
                } else if (this.f617u) {
                    Rect rect8 = this.f615s;
                    b.d(canvas2, rect8.left, rect8.top, rect8.right, rect8.bottom, b.j(this.f598b, this.f599c, this.f600d, this.f601e, this.f602f), this.f608l, this.f618v);
                } else {
                    c cVar2 = this.f611o;
                    float f3 = this.f598b;
                    Rect rect9 = this.f615s;
                    canvas2.drawPath(cVar2.a(f3, rect9.left, rect9.top, rect9.right, rect9.bottom, this.f599c, this.f600d, this.f601e, this.f602f), this.f608l);
                }
                Rect rect10 = this.f615s;
                d.a(canvas, rect10.left, rect10.top, rect10.right, rect10.bottom, this.f598b, "G2");
            } else {
                float f4 = this.f609m / 2.0f;
                if (!e()) {
                    Rect rect11 = this.f615s;
                    int i4 = rect11.left;
                    canvas.drawLine(i4 + f4, rect11.top, i4 + f4, rect11.bottom, this.f608l);
                }
                if (!h()) {
                    Rect rect12 = this.f615s;
                    float f5 = rect12.left;
                    int i5 = rect12.top;
                    canvas.drawLine(f5, i5 + f4, rect12.right, i5 + f4, this.f608l);
                }
                if (!g()) {
                    Rect rect13 = this.f615s;
                    int i6 = rect13.right;
                    canvas.drawLine(i6 - f4, rect13.top, i6 - f4, rect13.bottom, this.f608l);
                }
                if (!d()) {
                    Rect rect14 = this.f615s;
                    float f6 = rect14.left;
                    int i7 = rect14.bottom;
                    canvas.drawLine(f6, i7 - f4, rect14.right, i7 - f4, this.f608l);
                    canvas2 = canvas;
                }
            }
            canvas2 = canvas;
        }
        canvas2.restoreToCount(iSave);
    }

    public boolean e() {
        return (this.f597a & 8) != 0;
    }

    public boolean f() {
        return this.f597a == 0;
    }

    public boolean g() {
        return (this.f597a & 2) != 0;
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        ColorStateList colorStateList = this.f603g;
        int changingConfigurations2 = changingConfigurations | (colorStateList != null ? colorStateList.getChangingConfigurations() : 0);
        ColorStateList colorStateList2 = this.f606j;
        return changingConfigurations2 | (colorStateList2 != null ? colorStateList2.getChangingConfigurations() : 0);
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        int i2 = this.f614r;
        return i2 < 0 ? super.getIntrinsicHeight() : i2;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        int i2 = this.f613q;
        return i2 < 0 ? super.getIntrinsicWidth() : i2;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        Rect rect2 = this.f620x;
        if (rect2 == null) {
            return super.getPadding(rect);
        }
        rect.set(rect2);
        return true;
    }

    public boolean h() {
        return (this.f597a & 4) != 0;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        if (super.isStateful()) {
            return true;
        }
        ColorStateList colorStateList = this.f603g;
        if (colorStateList != null && colorStateList.isStateful()) {
            return true;
        }
        ColorStateList colorStateList2 = this.f606j;
        return colorStateList2 != null && colorStateList2.isStateful();
    }

    public void j(int i2) {
        k(ColorStateList.valueOf(i2));
    }

    public void k(ColorStateList colorStateList) {
        this.f603g = colorStateList;
        i();
        invalidateSelf();
    }

    public void l(float f2) {
        m(f2);
    }

    public void m(float f2) {
        this.f598b = f2;
        invalidateSelf();
    }

    public void n(int i2, int i3) {
        this.f613q = i2;
        this.f614r = i3;
        invalidateSelf();
    }

    public void o(float f2) {
        if (this.f604h == f2) {
            return;
        }
        this.f604h = f2;
        i();
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        boolean z2;
        ColorStateList colorStateList;
        int iB;
        ColorStateList colorStateList2;
        int iB2;
        if (this.f605i == null || (colorStateList2 = this.f603g) == null || this.f605i.getColor() == (iB2 = b(colorStateList2, iArr, this.f604h))) {
            z2 = false;
        } else {
            this.f605i.setColor(iB2);
            z2 = true;
        }
        if (this.f608l != null && (colorStateList = this.f606j) != null && this.f608l.getColor() != (iB = b(colorStateList, iArr, this.f607k))) {
            this.f608l.setColor(iB);
            z2 = true;
        }
        if (!z2) {
            return false;
        }
        invalidateSelf();
        return true;
    }

    public void p(float f2) {
        if (this.f607k == f2) {
            return;
        }
        this.f607k = f2;
        i();
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        float f2 = i2;
        p(f2);
        o(f2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.f605i.setColorFilter(colorFilter);
        this.f608l.setColorFilter(colorFilter);
    }

    public t(int i2, int i3, int i4, int i5) {
        this(null, i2, i3, i4, i5);
    }

    public t(Context context, float f2, int i2, int i3, int i4) {
        this.f597a = 0;
        this.f598b = 10.0f;
        this.f599c = true;
        this.f600d = true;
        this.f601e = true;
        this.f602f = true;
        this.f604h = 1.0f;
        this.f607k = 1.0f;
        this.f609m = 0;
        this.f610n = new c();
        this.f611o = new c();
        this.f612p = new Rect();
        this.f613q = -1;
        this.f614r = -1;
        this.f615s = new Rect();
        this.f616t = false;
        this.f617u = false;
        this.f618v = true;
        this.f619w = true;
        this.f620x = null;
        this.f621y = context;
        this.f598b = f2;
        this.f603g = ColorStateList.valueOf(i2);
        this.f606j = ColorStateList.valueOf(i3);
        this.f609m = i4;
        c();
    }
}
