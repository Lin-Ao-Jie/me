package com.originui.core.utils;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.RectF;
import android.provider.Settings;
import android.view.View;
import com.originui.core.R$id;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Map f540a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Map f541b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Map f542c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Map f543d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f544e = true;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f545f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static boolean f546g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static boolean f547h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static Method f548i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static Method f549j = null;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static Method f550k = null;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static Method f551l = null;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private static Method f552m = null;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static Method f553n = null;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static Method f554o = null;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private static Method f555p = null;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private static Method f556q = null;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private static Method f557r = null;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private static Method f558s = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private static Method f559t = null;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private static int f560u = 0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private static boolean f561v = false;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private static boolean f562w = false;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private static boolean f563x = false;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private static int f564y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private static float f565z = p.a(16.0f);

    public static void A(View view, RectF rectF, float f2) {
        if (view == null) {
            return;
        }
        q.j(view, "setMaterialRegion", new Class[]{RectF.class, Float.TYPE}, new Object[]{rectF, Float.valueOf(f2)});
    }

    public static void B(View view, int i2) {
        if (m.f583b) {
            m.b("VBlurUtils", "setGrayClear-clearType:" + i2);
        }
        if (view == null) {
            return;
        }
        if (f555p == null) {
            f555p = q.b(view, "setGrayClear", new Class[]{Integer.TYPE});
        }
        try {
            f555p.invoke(view, Integer.valueOf(i2));
            m.b("VBlurUtils", "sMethodGrayClear success:" + i2);
        } catch (Exception e2) {
            m.b("VBlurUtils", "sMethodGrayClear fail:" + e2.getMessage());
        }
    }

    public static boolean C(View view, int i2, int i3) {
        boolean zBooleanValue = false;
        if (f548i == null) {
            Class<?> cls = view.getClass();
            Class cls2 = Integer.TYPE;
            f548i = q.c(cls, "setMaterial", new Class[]{cls2, cls2});
        }
        Method method = f548i;
        if (method == null) {
            m.b("VBlurUtils", "Method setBlurEffect is null");
            return false;
        }
        try {
            method.setAccessible(true);
            zBooleanValue = ((Boolean) f548i.invoke(view, Integer.valueOf(i2), Integer.valueOf(i3))).booleanValue();
            m.b("VBlurUtils", "blur result is " + zBooleanValue);
            return zBooleanValue;
        } catch (Exception e2) {
            m.e("VBlurUtils", "invoke setMaterial error " + e2.getMessage());
            return zBooleanValue;
        }
    }

    public static void D(Context context, View view, float f2) {
        if (m.f583b) {
            m.b("VBlurUtils", "setMaterialAlpha-alpha:" + f2);
        }
        if (view != null) {
            if (context == null) {
                context = view.getContext();
            }
            if (e(context)) {
                if (f554o == null) {
                    f554o = q.b(view, "setMaterialAlpha", new Class[]{Float.TYPE});
                }
                try {
                    f554o.invoke(view, Float.valueOf(f2));
                } catch (Exception e2) {
                    m.b("VBlurUtils", "sMethodSetMaterialAlpha fail:" + e2.getMessage());
                }
            }
        }
    }

    public static void E(View view, float f2) {
        D(null, view, f2);
    }

    public static void F(View view, boolean z2) {
        if (view == null) {
            return;
        }
        q.j(view, "setWindowBlurAutoClipToOutline", new Class[]{Boolean.TYPE}, new Object[]{Boolean.valueOf(z2)});
    }

    public static void G(View view, float f2) {
        if (view == null) {
            return;
        }
        q.j(view, "setMaterialDarkenPercent", new Class[]{Float.TYPE}, new Object[]{Float.valueOf(f2)});
    }

    public static void H(View view, int i2) {
        if (view == null) {
            return;
        }
        q.j(view, "setMaterialFPS", new Class[]{Integer.TYPE}, new Object[]{Integer.valueOf(i2)});
    }

    public static void I(View view, boolean z2) {
        if (view == null) {
            return;
        }
        q.j(view, "setMaterialForceUpdateBg", new Class[]{Boolean.TYPE}, new Object[]{Boolean.valueOf(z2)});
    }

    public static void J(View view, boolean z2) {
        if (m.f583b) {
            m.b("VBlurUtils", "setMaterialG2Style-enable:" + z2);
        }
        if (view == null || !e(view.getContext())) {
            return;
        }
        if (f550k == null) {
            f550k = q.b(view, "enableMaterialG2Style", new Class[]{Boolean.TYPE});
        }
        try {
            f550k.invoke(view, Boolean.valueOf(z2));
            d.j(view, z2, "G2");
        } catch (Exception e2) {
            m.e("VBlurUtils", "setMaterialG2Style fail:" + e2.getMessage());
        }
    }

    public static void K(View view, int i2) {
        if (view == null) {
            return;
        }
        q.j(view, "setMaterialGroupID", new Class[]{Integer.TYPE}, new Object[]{Integer.valueOf(i2)});
    }

    public static void L(View view, int i2) {
        if (view == null) {
            return;
        }
        q.j(view, "setWindowBlurMarkerColor", new Class[]{Integer.TYPE}, new Object[]{Integer.valueOf(i2)});
    }

    private static void M(b.b bVar, boolean z2) {
        if (bVar != null) {
            bVar.a(z2);
        }
    }

    public static void a(View view) {
        if (view == null) {
            return;
        }
        if (f552m == null) {
            f552m = q.b(view, "clearMaterial", new Class[0]);
        }
        try {
            f552m.invoke(view, null);
            if (m.f583b) {
                m.b("VBlurUtils", "clearMaterial success");
            }
        } catch (Exception e2) {
            m.b("VBlurUtils", "clearMaterial error:" + e2.getMessage());
        }
    }

    private static int b(Context context, boolean z2, int i2) {
        k();
        l();
        if (z2) {
            if (f543d.get(Integer.valueOf(i2)) != null) {
                return ((Integer) f543d.get(Integer.valueOf(i2))).intValue();
            }
            return -1;
        }
        if (f542c.get(Integer.valueOf(i2)) != null) {
            return ((Integer) f542c.get(Integer.valueOf(i2))).intValue();
        }
        return -1;
    }

    private static int c(Context context, View view, int i2, int i3) {
        int iB;
        int i4;
        if (context == null) {
            context = view.getContext();
        }
        if (i3 == 1 || ((f547h && i3 != 2) || ((i4 = f560u) == 1 && i3 != 2))) {
            iB = b(context, true, i2);
        } else if (i3 == 2 || i4 == 2) {
            iB = b(context, false, i2);
        } else {
            iB = (i3 == -1 || i4 == -1) ? b(context, true ^ o(context), i2) : b(context, o(context), i2);
        }
        if (m.f583b) {
            m.b("VBlurUtils", "getClearTypeByMode-view:" + view + ",type:" + i2 + ",materialNightMode:" + i3 + ",clearType:" + iB);
        }
        return iB;
    }

    public static boolean d() {
        return r() && f544e;
    }

    public static boolean e(Context context) {
        return f544e && s(context);
    }

    public static boolean f() {
        return f546g;
    }

    public static int g(Context context, boolean z2, int i2) {
        n();
        m();
        if (m.f583b) {
            m.b("VBlurUtils", "getMaterial-isNightMode:" + z2 + ",type:" + i2);
        }
        try {
            if (z2) {
                if (f541b.get(Integer.valueOf(i2)) != null) {
                    return ((Integer) f541b.get(Integer.valueOf(i2))).intValue();
                }
                return -1;
            }
            if (f540a.get(Integer.valueOf(i2)) != null) {
                return ((Integer) f540a.get(Integer.valueOf(i2))).intValue();
            }
            return -1;
        } catch (Exception unused) {
            m.b("VBlurUtils", "getMaterial error");
            return -1;
        }
    }

    private static int h(Context context, View view, int i2, int i3) {
        int iG;
        int i4;
        if (context == null) {
            context = view.getContext();
        }
        if (i3 == 1 || ((f547h && i3 != 2) || ((i4 = f560u) == 1 && i3 != 2))) {
            iG = g(context, true, i2);
        } else if (i3 == 2 || i4 == 2) {
            iG = g(context, false, i2);
        } else {
            iG = (i3 == -1 || i4 == -1) ? g(context, true ^ o(context), i2) : g(context, o(context), i2);
        }
        if (m.f583b) {
            m.b("VBlurUtils", "getMaterialByMode-view:" + view + ",type:" + i2 + ",materialNightMode:" + i3);
        }
        return iG;
    }

    private static int i(View view, int i2, int i3) {
        return h(null, view, i2, i3);
    }

    public static int j(Context context) {
        if (context == null) {
            m.b("VBlurUtils", "getSystemBlurSwitchByConfig-context is null");
            return 2;
        }
        Configuration configuration = context.getResources().getConfiguration();
        if (configuration == null) {
            m.b("VBlurUtils", "getSystemBlurSwitchByConfig-configuration is null");
            return 2;
        }
        try {
            if (f559t == null) {
                Class[] clsArr = new Class[0];
                Method declaredMethod = configuration.getClass().getDeclaredMethod("getSpaceSystemMode", null);
                f559t = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            int iIntValue = ((Integer) f559t.invoke(configuration, null)).intValue();
            if (m.f583b) {
                m.b("VBlurUtils", "GetSpaceSystemMode success-value:" + iIntValue);
            }
            return iIntValue;
        } catch (Exception unused) {
            if (m.f583b) {
                m.e("VBlurUtils", "GetSpaceSystemMode error");
            }
            return 2;
        }
    }

    private static void k() {
        if (f542c == null) {
            HashMap map = new HashMap();
            f542c = map;
            map.put(19, 1);
        }
    }

    private static void l() {
        if (f543d == null) {
            HashMap map = new HashMap();
            f543d = map;
            map.put(19, 2);
        }
    }

    private static void m() {
        if (f541b == null) {
            HashMap map = new HashMap();
            f541b = map;
            map.put(0, 256);
            f541b.put(1, 257);
            f541b.put(2, 252);
            f541b.put(3, 258);
            f541b.put(4, 254);
            f541b.put(5, 260);
            f541b.put(6, 251);
            f541b.put(7, 259);
            f541b.put(9, 255);
            f541b.put(10, 261);
            f541b.put(11, 253);
            f541b.put(12, 262);
            f541b.put(13, 263);
            f541b.put(18, 264);
            f541b.put(19, 265);
            f541b.put(20, 259);
            f541b.put(21, 254);
            f541b.put(14, 51);
            f541b.put(15, 52);
            f541b.put(16, 53);
            f541b.put(17, 54);
        }
    }

    private static void n() {
        if (f540a == null) {
            HashMap map = new HashMap();
            f540a = map;
            map.put(0, 206);
            f540a.put(1, 207);
            f540a.put(2, 202);
            f540a.put(3, 208);
            f540a.put(4, 204);
            f540a.put(5, 210);
            f540a.put(6, 201);
            f540a.put(7, 209);
            f540a.put(9, 205);
            f540a.put(10, 211);
            f540a.put(11, 203);
            f540a.put(12, 212);
            f540a.put(13, 213);
            f540a.put(18, 214);
            f540a.put(19, 215);
            f540a.put(20, 209);
            f540a.put(21, 254);
            f540a.put(14, 1);
            f540a.put(15, 2);
            f540a.put(16, 3);
            f540a.put(17, 4);
        }
    }

    private static boolean o(Context context) {
        try {
            m.b("VBlurUtils", "isNightMode-mJudgeNightModeBySettings=" + f563x);
            if (f563x) {
                return Settings.System.getInt(context.getContentResolver(), "vivo_nightmode_used", 0) == 1;
            }
            return VThemeIconUtils.A(context);
        } catch (Exception e2) {
            m.f("VBlurUtils", "isNightMode error", e2);
            return false;
        }
    }

    public static boolean p(Context context) {
        if (q.p()) {
            return false;
        }
        return e(context);
    }

    public static boolean q(Context context) {
        return j(context) == 2;
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0072  */
    public static boolean r() {
        if (f561v) {
            return f562w;
        }
        boolean z2 = true;
        f561v = true;
        try {
            Class<?> cls = Class.forName("android.util.FtFeature");
            if (f553n == null) {
                Method declaredMethod = cls.getDeclaredMethod("isFeatureSupport", String.class);
                f553n = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            Boolean bool = (Boolean) f553n.invoke(null, "vivo.software.spacesystem");
            if (bool == null || !bool.booleanValue()) {
                z2 = false;
            } else {
                if (f556q == null) {
                    Method declaredMethod2 = cls.getDeclaredMethod("getFeatureAttribute", String.class, String.class, String.class);
                    f556q = declaredMethod2;
                    declaredMethod2.setAccessible(true);
                }
                int i2 = Integer.parseInt((String) f556q.invoke(cls, "vivo.software.spacesystem", "version", "1"));
                f564y = i2;
                if (i2 < 2) {
                    z2 = false;
                }
            }
            f562w = z2;
        } catch (Exception e2) {
            m.e("VBlurUtils", "isFeatureSupport failed: " + e2.toString());
            f562w = false;
        }
        return f562w;
    }

    public static boolean s(Context context) {
        return r() && q(context);
    }

    public static void t(View view, float f2) {
        if (view == null) {
            return;
        }
        if (f551l == null) {
            f551l = q.c(view.getClass(), "setMaterialCornerRadius", new Class[]{Float.TYPE});
        }
        Method method = f551l;
        if (method != null) {
            try {
                method.setAccessible(true);
                f551l.invoke(view, Float.valueOf(f2));
            } catch (Exception e2) {
                m.e("VBlurUtils", "invoke setBlurCornerRadius error " + e2.getMessage());
            }
        }
    }

    public static void u(View view, float f2, float f3, float f4, float f5) {
        if (view == null) {
            return;
        }
        if (f549j == null) {
            Class<?> cls = view.getClass();
            Class cls2 = Float.TYPE;
            f549j = q.c(cls, "setMaterialCornerRadius", new Class[]{cls2, cls2, cls2, cls2});
        }
        Method method = f549j;
        if (method != null) {
            try {
                method.setAccessible(true);
                f549j.invoke(view, Float.valueOf(f2), Float.valueOf(f3), Float.valueOf(f4), Float.valueOf(f5));
            } catch (Exception e2) {
                m.e("VBlurUtils", "invoke setBlurCornerRadius error " + e2.getMessage());
            }
        }
    }

    public static void v(Context context, View view, int i2, b.e eVar, boolean z2, boolean z3, boolean z4, boolean z5, int i3, int i4, b.b bVar) {
        int iC;
        if (view == null || (i4 == 1 && q.p())) {
            m.b("VBlurUtils", "view == null");
            M(bVar, false);
            return;
        }
        if (eVar != null && eVar.D()) {
            z(view, eVar, z3, z4, z5, bVar);
            return;
        }
        if (context == null) {
            context = view.getContext();
        }
        boolean zE = e(context);
        if (m.f583b) {
            StringBuilder sb = new StringBuilder();
            sb.append("view:");
            sb.append(view);
            sb.append(",globalBlurEnabled:");
            sb.append(zE);
            sb.append(",sGlobalWindowBlurEnabled:");
            sb.append(f545f);
            sb.append(",sGlobalViewBlurEnabled:");
            sb.append(f546g);
            sb.append(",isVivoPhone:");
            sb.append(h.k());
            sb.append(",isViewBlurEnabled:");
            sb.append(z3);
            sb.append(",isApplyGlobalTheme:");
            sb.append(z4);
            sb.append(",hasCustomBackground:");
            sb.append(z5);
            sb.append(",clearMaterialTag:");
            int i5 = R$id.tag_child_view_clear_material;
            sb.append(v.g(a0.d(view, i5), false));
            sb.append(",materialTag:");
            sb.append(a0.d(view, i5));
            sb.append(",materialNightMode:");
            sb.append(i3);
            m.b("VBlurUtils", sb.toString());
        }
        if (!zE || ((z2 && !f545f) || (!(z2 || f546g) || !z3 || z4 || z5 || !h.k() || v.g(a0.d(view, R$id.tag_child_view_clear_material), false)))) {
            m.b("VBlurUtils", "can not setBlurEffect");
            a(view);
            M(bVar, false);
            return;
        }
        int iH = h(context, view, i2, i3);
        int iH2 = !z2 ? 1 : 0;
        if (eVar != null && eVar.f() != -1) {
            iH = i(view, eVar.f(), i3);
        }
        if (iH == -1) {
            M(bVar, false);
            return;
        }
        if (eVar != null && eVar.h() != -1) {
            m.b("VBlurUtils", "custom contentType:" + eVar.h());
            iH2 = eVar.h();
        }
        if (eVar != null && eVar.z() != -1) {
            iH = eVar.z();
        }
        if (m.f583b) {
            m.b("VBlurUtils", "final material:" + iH + ",final contentType:" + iH2);
        }
        boolean zC = C(view, iH, iH2);
        if (m.f583b) {
            m.b("VBlurUtils", "blur result:" + zC);
        }
        M(bVar, zC);
        if (eVar != null && eVar.G()) {
            eVar.y();
        }
        if (eVar == null || eVar.x() == -1) {
            H(view, 60);
        } else {
            H(view, eVar.x());
        }
        if (eVar != null) {
            if (eVar.m() != -1) {
                I(view, eVar.m() != 0);
            }
            if (eVar.i() != null) {
                b.a aVarI = eVar.i();
                u(view, aVarI.f147a, aVarI.f148b, aVarI.f149c, aVarI.f150d);
            }
            if (eVar.a() != -1.0f) {
                E(view, eVar.a());
            }
            if (eVar.d() != null) {
                A(view, eVar.d(), eVar.e());
            }
            if (eVar.n() != -1) {
                K(view, eVar.n());
            }
            if (eVar.j() != -1.0f) {
                G(view, eVar.j());
            }
            if (eVar.F()) {
                F(view, eVar.B());
            }
            if (eVar.b() != -1) {
                L(view, eVar.b());
            }
            if (eVar.f() == 19 && (iC = c(context, view, eVar.f(), i3)) != -1) {
                B(view, iC);
            }
            J(view, eVar.E() != -1);
        }
        if (z2) {
            if (i2 == 6 || i2 == 4) {
                q.j(view, "setMaterialIntersectBounds", new Class[]{Boolean.TYPE}, new Object[]{Boolean.TRUE});
            }
        }
    }

    public static void w(View view, int i2, b.e eVar, boolean z2, boolean z3, boolean z4, boolean z5, int i3, int i4, b.b bVar) {
        v(null, view, i2, eVar, z2, z3, z4, z5, i3, i4, bVar);
    }

    public static void x(View view, int i2, b.e eVar, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, int i3, b.b bVar) {
        w(view, i2, eVar, z2, z3, z4, z6, z5 ? 1 : 2, i3, bVar);
    }

    public static void y(View view, b.e eVar, boolean z2, boolean z3, boolean z4, int i2, b.b bVar) {
        if (view == null || eVar == null || ((i2 == 1 && q.p()) || !e(view.getContext()) || !z2 || z3 || z4 || !h.k())) {
            m.b("VBlurUtils", "can not setBlurEffectCustomized");
            a(view);
            M(bVar, false);
            return;
        }
        int iH = eVar.h() != -1 ? eVar.h() : 1;
        boolean zC = C(view, 0, iH);
        if (!zC) {
            M(bVar, false);
            return;
        }
        m.b("VBlurUtils", "setBlurEffectCustomized result:" + zC + ",contentType=" + iH + ",mSpaceFeatureVersion=" + f564y);
        if (f564y > 2) {
            if (f558s == null) {
                Class<?> cls = view.getClass();
                Class cls2 = Float.TYPE;
                Class cls3 = Integer.TYPE;
                f558s = q.c(cls, "setMaterialCustomized", new Class[]{cls2, cls2, cls3, cls2, cls3, cls3, cls2, cls3, cls3, cls2, cls3, cls2, cls3});
            }
            Method method = f558s;
            if (method == null) {
                m.b("VBlurUtils", "Method sMethodSetBlurEffectCustomizedVersion3_0 is null");
                M(bVar, false);
                return;
            }
            method.setAccessible(true);
        } else {
            if (f557r == null) {
                Class<?> cls4 = view.getClass();
                Class cls5 = Float.TYPE;
                Class cls6 = Integer.TYPE;
                f557r = q.c(cls4, "setMaterialCustomized", new Class[]{cls5, cls5, cls6, cls5, cls6, cls6, cls5, cls6, cls5, cls6});
            }
            Method method2 = f557r;
            if (method2 == null) {
                m.b("VBlurUtils", "Method setBlurEffectCustomized is null");
                M(bVar, false);
                return;
            }
            method2.setAccessible(true);
        }
        try {
            if (f564y > 2) {
                f558s.invoke(view, Float.valueOf(eVar.c()), Float.valueOf(eVar.A()), Integer.valueOf(eVar.o()), Float.valueOf(eVar.u()), Integer.valueOf(eVar.r()), Integer.valueOf(eVar.p()), Float.valueOf(eVar.v()), Integer.valueOf(eVar.s()), Integer.valueOf(eVar.q()), Float.valueOf(eVar.w()), Integer.valueOf(eVar.t()), Float.valueOf(eVar.l()), Integer.valueOf(eVar.k()));
            } else {
                f557r.invoke(view, Float.valueOf(eVar.c()), Float.valueOf(eVar.A()), Integer.valueOf(eVar.o()), Float.valueOf(eVar.u()), Integer.valueOf(eVar.r()), Integer.valueOf(eVar.p()), Float.valueOf(eVar.v()), Integer.valueOf(eVar.s()), Float.valueOf(eVar.l()), Integer.valueOf(eVar.k()));
            }
            m.b("VBlurUtils", "setBlurEffectCustomized success");
            I(view, false);
            M(bVar, true);
        } catch (Exception e2) {
            m.e("VBlurUtils", "invoke setMaterial error " + e2.getMessage());
            M(bVar, false);
        }
        if (eVar.G()) {
            eVar.y();
        }
        if (eVar.C() && eVar.g() != -1) {
            B(view, eVar.g());
        }
        if (eVar.m() != -1) {
            I(view, eVar.m() != 0);
        }
        if (eVar.i() != null) {
            b.a aVarI = eVar.i();
            u(view, aVarI.f147a, aVarI.f148b, aVarI.f149c, aVarI.f150d);
        }
        if (eVar.a() != -1.0f) {
            E(view, eVar.a());
        }
        if (eVar.d() != null) {
            A(view, eVar.d(), eVar.e());
        }
        if (eVar.n() != -1) {
            K(view, eVar.n());
        }
        if (eVar.j() != -1.0f) {
            G(view, eVar.j());
        }
        if (eVar.F()) {
            F(view, eVar.B());
        }
        if (eVar.b() != -1) {
            L(view, eVar.b());
        }
    }

    public static void z(View view, b.e eVar, boolean z2, boolean z3, boolean z4, b.b bVar) {
        y(view, eVar, z2, z3, z4, 0, bVar);
    }
}
