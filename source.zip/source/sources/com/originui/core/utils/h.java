package com.originui.core.utils;

import android.content.Context;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.originui.resmap.BuildConfig;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static String f566a = "EX";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static String f567b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Boolean f568c;

    private static boolean a(String str) {
        if (v.a(f567b, "unknown")) {
            return false;
        }
        if (v.e(f567b)) {
            Object objN = q.n("android.util.FtDeviceInfo", "getDeviceType", new Class[0], new Object[0]);
            f567b = objN != null ? String.valueOf(objN) : "unknown";
        }
        return v.a(str, f567b);
    }

    public static String b() {
        return Build.BRAND;
    }

    public static int c(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService("window");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }

    public static int d(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService("window");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }

    public static boolean e() {
        if (f568c == null) {
            f568c = Boolean.valueOf(f(BuildConfig.TAG_FLAVORS));
        }
        return f568c.booleanValue();
    }

    public static boolean f(String str) {
        return v.a(f566a, str);
    }

    public static boolean g() {
        return (j() || i() || h()) ? false : true;
    }

    public static boolean h() {
        return a("flip");
    }

    public static boolean i() {
        return a("foldable");
    }

    public static boolean j() {
        return a("tablet");
    }

    public static boolean k() {
        String lowerCase = b().toLowerCase();
        return "vivo".equals(lowerCase) || "iqoo".equals(lowerCase) || "jovi".equals(lowerCase);
    }
}
