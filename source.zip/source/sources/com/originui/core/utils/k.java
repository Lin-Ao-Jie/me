package com.originui.core.utils;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import java.lang.reflect.Method;
import java.util.HashMap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final HashMap f570a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static boolean f571b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static boolean f572c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Method f573d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static Boolean f574e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f575f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static long f576g = 0;

    private static boolean a(Context context) {
        try {
            Resources resources = context.getResources();
            if (f573d == null) {
                Class[] clsArr = new Class[0];
                Method declaredMethod = Resources.class.getDeclaredMethod("getGlobalThemeEnabled", null);
                f573d = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            boolean zBooleanValue = ((Boolean) f573d.invoke(resources, null)).booleanValue();
            m.b("VGlobalThemeUtils", "checkGlobalThemeEnabled sGlobalThemeEnabled = " + zBooleanValue);
            return zBooleanValue;
        } catch (Exception unused) {
            return true;
        }
    }

    private static boolean b(Context context) {
        if (q.p() || VThemeIconUtils.A(context) || !e(context)) {
            return false;
        }
        m.b("VGlobalThemeUtils", "isApplyGlobalTheme getActivityFromContext = " + a0.b(context) + ",checkGlobalThemeEnabled=" + a(context));
        if (a0.b(context) == null || a(context)) {
            return "whole".equals(b0.c(context) ? Settings.System.getStringForUser(context.getContentResolver(), "theme_style", b0.f507a) : Settings.System.getString(context.getContentResolver(), "theme_style"));
        }
        return false;
    }

    public static int c(Context context, int i2, boolean z2, String str, String str2, String str3) {
        int iD;
        return (!z2 || (iD = d(context, str, str2, str3)) <= 0) ? i2 : iD;
    }

    public static int d(Context context, String str, String str2, String str3) {
        int identifier;
        if (context == null || TextUtils.isEmpty(str)) {
            return 0;
        }
        StringBuilder sb = new StringBuilder(str);
        sb.append(str2);
        sb.append(str3);
        HashMap map = f570a;
        if (map.containsKey(sb.toString())) {
            identifier = ((Integer) map.get(sb.toString())).intValue();
        } else {
            identifier = context.getResources().getIdentifier(str, str2, str3);
            if (identifier > 0) {
                map.put(sb.toString(), Integer.valueOf(identifier));
            }
        }
        sb.setLength(0);
        return identifier;
    }

    public static boolean e(Context context) {
        Object obj;
        boolean zBooleanValue;
        if (f572c) {
            return f571b;
        }
        f572c = true;
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null && (obj = bundle.get("originui.version.globaltheme")) != null && (zBooleanValue = ((Boolean) obj).booleanValue())) {
                f571b = zBooleanValue;
            }
        } catch (Exception e2) {
            m.f("VGlobalThemeUtils", "isAdaptedGlobalTheme error = ", e2);
        }
        m.h("init isAdaptedGlobalTheme : " + f571b + " , : vcore_6.0.1.8");
        return f571b;
    }

    public static boolean f(Context context) {
        if (f574e == null) {
            f575f = b(context);
            f574e = Boolean.TRUE;
        }
        if (!g()) {
            f575f = b(context);
        }
        return f575f;
    }

    public static boolean g() {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (Math.abs(jCurrentTimeMillis - f576g) <= 100) {
            return true;
        }
        f576g = jCurrentTimeMillis;
        return false;
    }
}
