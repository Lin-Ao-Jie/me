package com.originui.core.utils;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.text.TextUtils;
import android.view.View;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final String f525a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final boolean f526b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final boolean f527c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final boolean f528d;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ View f529a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ boolean f530b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ String f531c;

        a(View view, boolean z2, String str) {
            this.f529a = view;
            this.f530b = z2;
            this.f531c = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            View view = this.f529a;
            if (view != null) {
                if (!this.f530b) {
                    view.getOverlay().clear();
                    return;
                }
                com.originui.core.utils.a aVar = new com.originui.core.utils.a(this.f531c);
                Rect rect = new Rect();
                this.f529a.getDrawingRect(rect);
                if (rect.width() == 0 && rect.height() == 0) {
                    if (this.f529a.getMeasuredWidth() == 0 || this.f529a.getMeasuredHeight() == 0) {
                        m.e("OriginUIDebugUtils", "setOriginUIDebugUtils ERROR !!! , badgeBounds : " + rect.toString() + " , view : " + this.f529a);
                    } else {
                        rect.set(0, 0, this.f529a.getMeasuredWidth(), this.f529a.getMeasuredHeight());
                    }
                }
                aVar.setBounds(rect);
                this.f529a.getOverlay().add(aVar);
            }
        }
    }

    static {
        String strB = w.b("persist.sys.originui.debug", "0");
        f525a = strB;
        f526b = strB.equalsIgnoreCase("1");
        f527c = strB.equalsIgnoreCase("11");
        f528d = strB.equalsIgnoreCase("2");
    }

    public static void a(Canvas canvas, float f2, float f3, float f4, float f5, float f6, String str) {
        if (f527c && "G2".equals(str) && f6 > 0.0f) {
            Paint paintH = h(str);
            paintH.setStyle(Paint.Style.STROKE);
            canvas.drawText(str, 20.0f, 20.0f, paintH);
            canvas.drawRect(f2, f3, f4, f5, paintH);
        }
    }

    public static CharSequence b(CharSequence charSequence, String str) {
        if (!f526b) {
            return charSequence;
        }
        return g(str) + ((Object) charSequence);
    }

    public static int c(String str) {
        if (str == null || TextUtils.isEmpty(str)) {
            return -65536;
        }
        if (str.startsWith("6.")) {
            return -16776961;
        }
        if (str.startsWith("G2")) {
            return -16711936;
        }
        return str.startsWith("GridView") ? -256 : -65536;
    }

    public static Drawable d(Drawable drawable, int i2, int i3) {
        if (drawable == null) {
            return null;
        }
        if (!f526b) {
            return drawable;
        }
        Drawable[] drawableArr = {drawable, null};
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setStroke(i2, i3);
        drawableArr[1] = gradientDrawable;
        return new LayerDrawable(drawableArr);
    }

    public static Drawable e(Drawable drawable, String str) {
        if (drawable == null) {
            return null;
        }
        return !f526b ? drawable : d(drawable, 5, c(str));
    }

    public static String f(CharSequence charSequence, String str) {
        if (!f526b) {
            return charSequence == null ? "" : charSequence.toString();
        }
        return g(str) + ((Object) charSequence);
    }

    public static String g(String str) {
        if (!f526b) {
            return "";
        }
        if (str != null && !TextUtils.isEmpty(str)) {
            if (str.startsWith("G2")) {
                return "G2";
            }
            if (str.startsWith("GridView")) {
                return "GridView";
            }
        }
        return str;
    }

    public static Paint h(String str) {
        Paint paint = new Paint(1);
        paint.setColor(c(str));
        paint.setTextSize(16.0f);
        return paint;
    }

    public static void i(View view, String str) {
        j(view, true, str);
    }

    public static void j(View view, boolean z2, String str) {
        if (view == null) {
            return;
        }
        if ((!f526b || "G2".equals(str)) && !((f527c && "G2".equals(str)) || (f528d && "GridView".equals(str)))) {
            return;
        }
        view.postDelayed(new a(view, z2, str), 33L);
    }
}
