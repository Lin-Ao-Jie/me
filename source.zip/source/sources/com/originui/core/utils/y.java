package com.originui.core.utils;

import android.graphics.Typeface;
import android.system.Os;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.TextView;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final ConcurrentHashMap f633a = new ConcurrentHashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final String f634b = "/data/vfonts/VivoFont.ttf";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final int f635c = w.a("persist.vivo.defaultsize", 550);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Typeface f636d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f637e = true;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f638f = true;

    public static int a(int i2) {
        if (i2 <= 25) {
            return 10;
        }
        if (i2 > 85) {
            return 80;
        }
        return ((i2 / 10) - 1) * 10;
    }

    public static int b(int i2) {
        if (i2 <= 20) {
            return 35;
        }
        if (i2 <= 30) {
            return 45;
        }
        if (i2 <= 40) {
            return 55;
        }
        if (i2 <= 50) {
            return 65;
        }
        if (i2 <= 60) {
            return 75;
        }
        return i2 <= 70 ? 85 : 95;
    }

    private static String c() {
        return "system/fonts/vivoSansENVF.ttf";
    }

    public static Typeface d(int i2) {
        return k() ? g(a(i2), 0) : f(i2, 0, 0, f637e, f638f);
    }

    private static Typeface e(int i2, int i3, int i4) {
        String str;
        if (i2 > 0) {
            int i5 = i2 * 10;
            if (i5 > 900) {
                i5 = 900;
            }
            str = "'wght' " + i5;
        } else {
            str = "";
        }
        if (i3 > 0) {
            if (TextUtils.isEmpty(str)) {
                str = str + "'wdth' " + (i3 * 100);
            } else {
                str = str + ",'wdth' " + (i3 * 100);
            }
        }
        if (i4 > 0) {
            if (i4 < 10) {
                i4 = 10;
            } else if (i4 > 22) {
                i4 = 22;
            }
            if (TextUtils.isEmpty(str)) {
                str = str + "'opsz' " + i4;
            } else {
                str = str + ",'opsz' " + i4;
            }
        }
        if (m.f583b) {
            m.b("TextWeightUtilsDemestic", "fontVariationSettings = " + str);
        }
        return str.isEmpty() ? j("system/fonts/HYLiLiangHeiJ.ttf", "") : j(c(), str);
    }

    public static Typeface f(int i2, int i3, int i4, boolean z2, boolean z3) {
        if (!z2) {
            return e(i2, i3, i4);
        }
        if (!s() && !l()) {
            return Typeface.DEFAULT;
        }
        if (z3 || s.b() >= 14.0f) {
            int i5 = f635c;
            i2 = (int) (i2 * ((w.a("persist.system.vivo.fontsize", i5) * 1.0f) / i5));
        }
        return e(i2, i3, i4);
    }

    public static Typeface g(int i2, int i3) {
        return k() ? f(i2, 0, i3, f637e, f638f) : d(b(i2));
    }

    public static Typeface h(int i2) {
        String str;
        if (i2 == 100) {
            str = "sans-serif-thin";
        } else if (i2 == 200) {
            str = "sans-serif-extralight";
        } else if (i2 == 300) {
            str = "sans-serif-light";
        } else if (i2 == 400) {
            str = "sans-serif";
        } else if (i2 == 500) {
            str = "sans-serif-medium";
        } else if (i2 == 600) {
            str = "sans-serif-semibold";
        } else if (i2 == 700) {
            str = "sans-serif-bold";
        } else if (i2 != 800) {
            str = i2 != 900 ? "" : "sans-serif-black";
        } else {
            str = "sans-serif-extrabold";
        }
        return !TextUtils.isEmpty(str) ? Typeface.create(str, 0) : Typeface.create(Typeface.DEFAULT, i2);
    }

    private static int i(TextView textView) {
        if (textView == null) {
            return 0;
        }
        return p.c(Math.round(TypedValue.applyDimension(0, textView.getTextSize(), textView.getResources().getDisplayMetrics())));
    }

    private static Typeface j(String str, String str2) {
        String str3 = str + str2;
        ConcurrentHashMap concurrentHashMap = f633a;
        if (concurrentHashMap.containsKey(str3)) {
            return (Typeface) concurrentHashMap.get(str3);
        }
        try {
            m.b("TextWeightUtilsDemestic", "getTypeface build and cache , key :  " + str3);
            Typeface typefaceBuild = !str2.isEmpty() ? new Typeface.Builder(str).setFontVariationSettings(str2).build() : new Typeface.Builder(str).build();
            concurrentHashMap.put(str3, typefaceBuild);
            return typefaceBuild;
        } catch (Exception e2) {
            m.b("TextWeightUtilsDemestic", "getTypeface exception: " + e2.getMessage());
            return null;
        }
    }

    public static boolean k() {
        return s.b() >= 14.0f && s();
    }

    public static boolean l() {
        try {
            return Os.readlink(f634b).contains("vivo旗黑");
        } catch (Exception unused) {
            return false;
        }
    }

    public static void m(TextView textView) {
        q(textView, 55);
    }

    public static void n(TextView textView) {
        q(textView, 60);
    }

    public static void o(TextView textView) {
        q(textView, 70);
    }

    public static void p(TextView textView) {
        q(textView, 75);
    }

    public static void q(TextView textView, int i2) {
        if (k()) {
            r(textView, a(i2), i(textView));
            return;
        }
        if (textView == null) {
            return;
        }
        try {
            if (s() || l()) {
                Typeface typefaceD = d(i2);
                if (typefaceD == null) {
                    typefaceD = i2 >= 65 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
                }
                textView.setTypeface(typefaceD);
                return;
            }
            if (i2 >= 65) {
                textView.setTypeface(Typeface.DEFAULT_BOLD);
            } else {
                textView.setTypeface(Typeface.DEFAULT);
            }
        } catch (Exception unused) {
        }
    }

    public static void r(TextView textView, int i2, int i3) {
        if (!k()) {
            q(textView, b(i2));
            return;
        }
        if (textView == null) {
            return;
        }
        try {
            boolean zS = s();
            if (zS || l()) {
                Typeface typefaceG = (!zS || s.b() < 15.0f) ? g(i2, i3) : h(i2 * 10);
                if (typefaceG == null) {
                    typefaceG = i2 >= 50 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
                }
                textView.setTypeface(typefaceG);
                return;
            }
            if (i2 >= 50) {
                textView.setTypeface(Typeface.DEFAULT_BOLD);
            } else {
                textView.setTypeface(Typeface.DEFAULT);
            }
        } catch (Exception unused) {
        }
    }

    public static boolean s() {
        try {
            return Os.readlink(f634b).contains("DroidSansFallbackBBK");
        } catch (Exception unused) {
            return false;
        }
    }
}
