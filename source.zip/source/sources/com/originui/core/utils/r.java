package com.originui.core.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.View;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class r {
    public static int a(int i2) {
        return p.a(i2);
    }

    public static int b(Context context, int i2) {
        if (context == null) {
            return 0;
        }
        try {
            if (l(i2)) {
                return context.getResources().getColor(i2);
            }
            return 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public static int c(Context context, int i2) {
        if (context == null) {
            return 0;
        }
        try {
            if (l(i2)) {
                return context.getResources().getDimensionPixelSize(i2);
            }
            return 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public static Drawable d(Context context, int i2) {
        return e(context, i2, false);
    }

    public static Drawable e(Context context, int i2, boolean z2) {
        if (context == null) {
            return null;
        }
        try {
            if (l(i2)) {
                return context.getDrawable(i2);
            }
        } catch (Exception unused) {
        }
        return null;
    }

    public static String f(Context context, int i2) {
        try {
            return context.getResources().getResourceName(i2);
        } catch (Exception unused) {
            return "0X" + Integer.toHexString(i2);
        }
    }

    public static String g(View view) {
        if (view == null) {
            return null;
        }
        return f(view.getContext(), view.getId());
    }

    public static int h(Context context, String str, String str2, String str3) {
        try {
            return context.getResources().getIdentifier(str, str2, str3);
        } catch (Exception unused) {
            return -1;
        }
    }

    public static int i(Context context, int i2) {
        try {
            if (l(i2)) {
                return context.getResources().getInteger(i2);
            }
            return 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public static String j(Context context, int i2) {
        if (context == null) {
            return null;
        }
        try {
            return !l(i2) ? "" : context.getString(i2);
        } catch (Exception unused) {
            return "";
        }
    }

    public static String k(Context context, int i2, Object... objArr) {
        if (context == null) {
            return null;
        }
        try {
            return !l(i2) ? "" : context.getString(i2, objArr);
        } catch (Exception unused) {
            return "";
        }
    }

    public static boolean l(int i2) {
        return (i2 == -1 || ((-16777216) & i2) == 0 || (i2 & 16711680) == 0) ? false : true;
    }

    public static int m(int i2) {
        return Math.round(i2 / Resources.getSystem().getDisplayMetrics().density);
    }

    public static int n(Context context, int i2) {
        return Math.round(i2 / context.getResources().getDisplayMetrics().scaledDensity);
    }
}
