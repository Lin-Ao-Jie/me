package com.originui.core.utils;

import vivo.util.VLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f582a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static boolean f583b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static boolean f584c;

    static {
        f583b = w.a("com.originui.debug", 0) == 1;
        f584c = false;
    }

    public static void a(String str) {
        if (f583b) {
            k();
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            VLog.d("OriginUI", (stackTraceElement.getClassName() + "#" + stackTraceElement.getMethodName() + "--> ") + str);
        }
    }

    public static void b(String str, String str2) {
        if (f583b) {
            k();
            VLog.d("OriginUI/" + str, str2);
        }
    }

    public static void c(String str, String str2, Throwable th) {
        if (f583b) {
            k();
            VLog.d("OriginUI/" + str, str2, th);
        }
    }

    public static void d(String str) {
        if (f582a) {
            k();
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            VLog.e("OriginUI", (stackTraceElement.getClassName() + "#" + stackTraceElement.getMethodName() + "--> ") + str);
        }
    }

    public static void e(String str, String str2) {
        if (f582a) {
            k();
            VLog.e("OriginUI/" + str, str2);
        }
    }

    public static void f(String str, String str2, Exception exc) {
        if (f582a) {
            k();
            VLog.e("OriginUI/" + str, str2, exc);
        }
    }

    public static void g(String str, String str2, Throwable th) {
        if (f582a) {
            k();
            VLog.e("OriginUI/" + str, str2, th);
        }
    }

    public static void h(String str) {
        if (f582a) {
            k();
            StackTraceElement stackTraceElement = Thread.currentThread().getStackTrace()[3];
            VLog.i("OriginUI", (stackTraceElement.getClassName() + "#" + stackTraceElement.getMethodName() + "--> ") + str);
        }
    }

    public static void i(String str, String str2) {
        if (f582a) {
            k();
            VLog.i("OriginUI/" + str, str2);
        }
    }

    private static void j(String str) {
        try {
            VLog.d("OriginUIWidget", "aar version: " + q.h(str, "LOG_TAG"));
        } catch (Exception e2) {
            VLog.e("OriginUIWidget", "error = " + e2);
        }
    }

    private static void k() {
        if (f584c || !f583b) {
            return;
        }
        f584c = true;
        j("com.originui.core.BuildConfig");
        j("com.originui.widget.responsive.BuildConfig");
        j("com.originui.widget.button.BuildConfig");
        j("com.originui.widget.selection.BuildConfig");
        j("com.originui.widget.vclickdrawable.BuildConfig");
        j("com.originui.widget.components.BuildConfig");
        j("com.originui.widget.edittext.BuildConfig");
        j("com.originui.widget.edittextlayout.BuildConfig");
        j("com.originui.widget.drawable.BuildConfig");
        j("com.originui.widget.navigation.BuildConfig");
        j("com.originui.widget.sidenavigation.BuildConfig");
        j("com.originui.widget.vlinearmenu.BuildConfig");
        j("androidx.preference.BuildConfig");
        j("com.originui.widget.vbadgedrawable.BuildConfig");
        j("com.originui.widget.components.indexbar.BuildConfig");
        j("com.originui.widget.listitem.BuildConfig");
        j("com.originui.widget.pageindicator.BuildConfig");
        j("com.originui.widget.recyclerview.BuildConfig");
        j("com.originui.widget.scrollbar.BuildConfig");
        j("com.originui.widget.vgearseekbar.BuildConfig");
        j("com.originui.widget.recommend.BuildConfig");
        j("com.originui.widget.sideslip.BuildConfig");
        j("com.originui.widget.timepicker.BuildConfig");
        j("com.originui.widget.tipscard.BuildConfig");
        j("com.originui.widget.launchersplash.BuildConfig");
        j("com.originui.widget.about.BuildConfig");
        j("com.originui.widget.blank.BuildConfig");
        j("com.vivo.privacycompliance.BuildConfig");
        j("com.originui.widget.address.BuildConfig");
        j("com.originui.widget.dialog.BuildConfig");
        j("com.originui.widget.popup.BuildConfig");
        j("com.originui.widget.sheet.BuildConfig");
        j("com.originui.widget.snackbar.BuildConfig");
        j("com.originui.widget.spinner.BuildConfig");
        j("com.originui.widget.tipspopupwindow.BuildConfig");
        j("com.vivo.widget.hover.BuildConfig");
        j("com.originui.widget.guide.BuildConfig");
        j("com.originui.widget.vcoordinatorlayout.BuildConfig");
        j("com.originui.widget.vholdinglayout.BuildConfig");
        j("com.originui.widget.search.BuildConfig");
        j("com.originui.widget.tabs.BuildConfig");
        j("com.originui.widget.toolbar.BuildConfig");
    }
}
