package com.originui.core.utils;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a extends GradientDrawable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private String f477a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Paint f478b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f479c;

    public a(String str) {
        b(str);
    }

    private void b(String str) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        this.f477a = d.g(str);
        this.f479c = d.c(str);
        Paint paint = new Paint();
        this.f478b = paint;
        paint.setColor(this.f479c);
        this.f478b.setTextSize(16.0f);
        setShape(0);
        setStroke(5, this.f479c);
    }

    public void a(Canvas canvas) {
        Paint paint;
        if (TextUtils.isEmpty(this.f477a) || (paint = this.f478b) == null) {
            return;
        }
        canvas.drawText(this.f477a, 20.0f, 20.0f, paint);
    }

    @Override // android.graphics.drawable.GradientDrawable, android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        a(canvas);
        super.draw(canvas);
    }
}
