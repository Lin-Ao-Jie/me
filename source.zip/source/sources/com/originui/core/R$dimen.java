package com.originui.core;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$dimen {
    public static final int originui_vblur_linearlayout_divider_height_rom13_0 = 2130968995;
    public static final int originui_vblur_linearlayout_divider_height_rom15_0 = 2130968996;
}
