package com.originui.core;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static final int fromDefault = 2131099672;
    public static final int fromOriginUI = 2131099673;
    public static final int keep_background = 2131099678;
    public static final int originui_vcore_animatedvectordrawable_listener_rom14 = 2131099700;
    public static final int originui_vcore_badge_drawable_attach_animator_rom14 = 2131099701;
    public static final int originui_vcore_badge_drawable_detach_animator_rom14 = 2131099702;
    public static final int originui_vcore_targetscrollview_itemdecoration_drawacontent_rom16_0 = 2131099703;
    public static final int originui_vcore_viewtouchlistener_alpha_rom14 = 2131099704;
    public static final int originui_vcore_viewtouchlistener_animType_rom14 = 2131099705;
    public static final int originui_vcore_viewtouchlistener_checkviewenable_animator_rom14 = 2131099706;
    public static final int originui_vcore_viewtouchlistener_customtouchlistener_rom14 = 2131099707;
    public static final int originui_vcore_viewtouchlistener_down_animator_animatorlistener_rom14 = 2131099708;
    public static final int originui_vcore_viewtouchlistener_down_animator_rom14 = 2131099709;
    public static final int originui_vcore_viewtouchlistener_scale_rom14 = 2131099710;
    public static final int originui_vcore_viewtouchlistener_up_animator_duration_time_rom14 = 2131099711;
    public static final int originui_vcore_viewtouchlistener_up_animator_rom14 = 2131099712;
    public static final int tag_child_view_clear_material = 2131099735;
    public static final int tag_child_view_material_blur_alpha = 2131099736;
    public static final int tag_child_view_show_divider = 2131099737;
    public static final int tag_last_set_fontlevel_curfontlimit = 2131099738;
    public static final int tag_last_set_fontlevel_curtextsize = 2131099739;
    public static final int tag_last_set_fontlevel_curtotextsize = 2131099740;
}
