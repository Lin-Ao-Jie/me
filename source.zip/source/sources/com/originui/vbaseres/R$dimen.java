package com.originui.vbaseres;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$dimen {
    public static final int originui_vbaseres_fillet_l_value_rom15_0 = 2130968991;
    public static final int originui_vbaseres_fillet_m_value_rom15_0 = 2130968992;
    public static final int originui_vbaseres_fillet_s_value_rom15_0 = 2130968993;
    public static final int originui_vbaseres_fillet_xl_value_rom15_0 = 2130968994;
}
