package com.originui.vbaseres;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static final int originui_g2_color_rom16_0 = 2130903100;
    public static final int originui_g5_color_rom16_0 = 2130903101;
    public static final int originui_g6_color_rom16_0 = 2130903102;
}
