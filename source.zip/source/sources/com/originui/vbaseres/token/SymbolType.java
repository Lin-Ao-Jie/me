package com.originui.vbaseres.token;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'VBANNERTIP_ARROW' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:485)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByField(EnumVisitor.java:399)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByWrappedInsn(EnumVisitor.java:364)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:349)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:284)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInvoke(EnumVisitor.java:315)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:288)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:153)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class SymbolType {
    private static final /* synthetic */ SymbolType[] $VALUES;
    public static final SymbolType RXUI_ICON;
    public static final SymbolType VBANNERTIP_ARROW;
    public static final SymbolType VBANNERTIP_CLOSE;
    public static final SymbolType VBOTTOMNAVIGATION_ICON;
    public static final SymbolType VBUTTON_BOTTOM_ICON;
    public static final SymbolType VBUTTON_EMPHASIZE_ICON;
    public static final SymbolType VBUTTON_FLOAT_ICON;
    public static final SymbolType VBUTTON_NORMAL_ICON;
    public static final SymbolType VBUTTON_STATE_ICON;
    public static final SymbolType VDIALOG_LISTITEM_ICON;
    public static final SymbolType VLINEARMENUVIEW_ICON;
    public static final SymbolType VLISTHEADING_ARROW;
    public static final SymbolType VLISTHEADING_ICON;
    public static final SymbolType VLISTITEM_ARROW;
    public static final SymbolType VLISTITEM_BUTTON;
    public static final SymbolType VLISTITEM_ICON;
    public static final SymbolType VLISTPOPUPWINDOW_ICON;
    public static final SymbolType VPROGRESSBAR_ICON;
    public static final SymbolType VSEARCHVIEW_ICON;
    public static final SymbolType VSHEET_CLOSE;
    public static final SymbolType VSIDE_NAVIGATION_ICON;
    public static final SymbolType VTABLAYOUT_SUBTITLE_ICON;
    public static final SymbolType VTABLAYOUT_TITLE_ICON;
    public static final SymbolType VTOOLBAR_EMPHASIZE_ICON;
    public static final SymbolType VTOOLBAR_ICON;
    public static final SymbolType VTOOLBAR_ICON_BUTTON;
    public static final SymbolType VTOOLBAR_ICON_SLIDE;
    private final int size;
    private final int wght;

    private static /* synthetic */ SymbolType[] $values() {
        return new SymbolType[]{VTOOLBAR_ICON, VTOOLBAR_ICON_SLIDE, VTOOLBAR_EMPHASIZE_ICON, VTOOLBAR_ICON_BUTTON, VDIALOG_LISTITEM_ICON, VTABLAYOUT_TITLE_ICON, VTABLAYOUT_SUBTITLE_ICON, VBUTTON_EMPHASIZE_ICON, VBUTTON_NORMAL_ICON, VBUTTON_BOTTOM_ICON, VBUTTON_FLOAT_ICON, VBUTTON_STATE_ICON, VLISTITEM_ICON, VLISTITEM_BUTTON, VLISTITEM_ARROW, VLISTHEADING_ICON, VLISTHEADING_ARROW, VBOTTOMNAVIGATION_ICON, VLINEARMENUVIEW_ICON, VLISTPOPUPWINDOW_ICON, VSEARCHVIEW_ICON, VBANNERTIP_CLOSE, VBANNERTIP_ARROW, VPROGRESSBAR_ICON, VSIDE_NAVIGATION_ICON, RXUI_ICON, VSHEET_CLOSE};
    }

    static {
        SymbolType symbolType = new SymbolType("VTOOLBAR_ICON", 0, 500, 20);
        VTOOLBAR_ICON = symbolType;
        VTOOLBAR_ICON_SLIDE = new SymbolType("VTOOLBAR_ICON_SLIDE", 1, 500, 18);
        VTOOLBAR_EMPHASIZE_ICON = new SymbolType("VTOOLBAR_EMPHASIZE_ICON", 2, 500, 18);
        VTOOLBAR_ICON_BUTTON = new SymbolType("VTOOLBAR_ICON_BUTTON", 3, 600, 15);
        VDIALOG_LISTITEM_ICON = new SymbolType("VDIALOG_LISTITEM_ICON", 4, 400, 16);
        VTABLAYOUT_TITLE_ICON = new SymbolType("VTABLAYOUT_TITLE_ICON", 5, 400, 20);
        VTABLAYOUT_SUBTITLE_ICON = new SymbolType("VTABLAYOUT_SUBTITLE_ICON", 6, 400, 14);
        VBUTTON_EMPHASIZE_ICON = new SymbolType("VBUTTON_EMPHASIZE_ICON", 7, 600, 16);
        VBUTTON_NORMAL_ICON = new SymbolType("VBUTTON_NORMAL_ICON", 8, 600, 16);
        VBUTTON_BOTTOM_ICON = new SymbolType("VBUTTON_BOTTOM_ICON", 9, 700, 16);
        VBUTTON_FLOAT_ICON = new SymbolType("VBUTTON_FLOAT_ICON", 10, 600, 16);
        VBUTTON_STATE_ICON = new SymbolType("VBUTTON_STATE_ICON", 11, 500, 13);
        SymbolType symbolType2 = new SymbolType("VLISTITEM_ICON", 12, 500, 16);
        VLISTITEM_ICON = symbolType2;
        VLISTITEM_BUTTON = new SymbolType("VLISTITEM_BUTTON", 13, 500, 16);
        VLISTITEM_ARROW = new SymbolType("VLISTITEM_ARROW", 14, 500, 13);
        VLISTHEADING_ICON = new SymbolType("VLISTHEADING_ICON", 15, 400, 20);
        VLISTHEADING_ARROW = new SymbolType("VLISTHEADING_ARROW", 16, 500, 13);
        VBOTTOMNAVIGATION_ICON = new SymbolType("VBOTTOMNAVIGATION_ICON", 17, 500, 16);
        VLINEARMENUVIEW_ICON = new SymbolType("VLINEARMENUVIEW_ICON", 18, 500, 16);
        VLISTPOPUPWINDOW_ICON = new SymbolType("VLISTPOPUPWINDOW_ICON", 19, 500, 15);
        VSEARCHVIEW_ICON = new SymbolType("VSEARCHVIEW_ICON", 20, 400, 15);
        VBANNERTIP_CLOSE = new SymbolType("VBANNERTIP_CLOSE", 21, 500, 14);
        VBANNERTIP_ARROW = new SymbolType("VBANNERTIP_ARROW", 22, symbolType2.wght, symbolType2.size);
        VPROGRESSBAR_ICON = new SymbolType("VPROGRESSBAR_ICON", 23, symbolType2.wght, symbolType2.size);
        VSIDE_NAVIGATION_ICON = new SymbolType("VSIDE_NAVIGATION_ICON", 24, symbolType.wght, symbolType.size);
        RXUI_ICON = new SymbolType("RXUI_ICON", 25, symbolType.wght, symbolType.size);
        VSHEET_CLOSE = new SymbolType("VSHEET_CLOSE", 26, symbolType.wght, symbolType.size);
        $VALUES = $values();
    }

    private SymbolType(String str, int i2, int i3, int i4) {
        super(str, i2);
        this.wght = i3;
        this.size = i4;
    }

    public static SymbolType valueOf(String str) {
        return (SymbolType) Enum.valueOf(SymbolType.class, str);
    }

    public static SymbolType[] values() {
        return (SymbolType[]) $VALUES.clone();
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return super.compareTo((Enum) obj);
    }

    public int getSize() {
        return this.size;
    }

    public int getWght() {
        return this.wght;
    }

    private SymbolType(String str, int i2, int i3, int i4, int i5) {
        super(str, i2);
        this.wght = i3;
        this.size = i4;
    }
}
