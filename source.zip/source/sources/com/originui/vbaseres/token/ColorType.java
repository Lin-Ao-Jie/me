package com.originui.vbaseres.token;

import com.originui.vbaseres.R$color;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public enum ColorType {
    ICON_G2(R$color.originui_g2_color_rom16_0),
    ICON_G5(R$color.originui_g5_color_rom16_0),
    ICON_G6(R$color.originui_g6_color_rom16_0);

    private final int colorRes;

    ColorType(int i2) {
        this.colorRes = i2;
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return super.compareTo((Enum) obj);
    }

    public int getColorRes() {
        return this.colorRes;
    }
}
