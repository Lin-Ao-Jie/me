package com.originui.resmap.map;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.util.SparseIntArray;
import com.originui.core.utils.m;
import com.originui.core.utils.q;
import com.originui.core.utils.s;
import com.originui.resmap.attr.ParserUtil;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class RomVersionResMap implements MapInterface {
    private static volatile RomVersionResMap INSTANCE = null;
    private static volatile RomVersionResMap INSTANCE_MERGED = null;
    private static final String TAG = "vresmap_6.0.0.7";
    private static Pattern romPattern;
    private static Pattern romPatternDemestic;
    private static String romPatternDemesticStr;
    private static String romPatternStr;
    private static String sPackageName;
    private static float sRomVersion;
    private static Pattern stylePatternDemestic;
    private static String stylePatternDemesticStr;
    private static Pattern styleRomPattern;
    private static String styleRomPatternStr;
    private static String styleTargetSuffix;
    private static String targetSuffix;
    private boolean mIsDemesticPattern;
    private final SparseIntArray targetResMap = new SparseIntArray();
    private final Set<Integer> noTargetResMap = new HashSet();
    private final Set<Integer> noTargetXmlMap = new HashSet();

    static {
        String str = q.p() ? "_vos\\d{1}(_\\d)?$" : "_rom\\d{2}(_\\d)?$";
        romPatternStr = str;
        romPattern = Pattern.compile(str);
        romPatternDemesticStr = "_rom\\d{2}(_\\d)?$";
        romPatternDemestic = Pattern.compile("_rom\\d{2}(_\\d)?$");
        String str2 = q.p() ? "\\.Vos\\d{1}(_\\d)?$" : "\\.Rom\\d{2}(_\\d)?$";
        styleRomPatternStr = str2;
        styleRomPattern = Pattern.compile(str2);
        stylePatternDemesticStr = "\\.Rom\\d{2}(_\\d)?$";
        stylePatternDemestic = Pattern.compile("\\.Rom\\d{2}(_\\d)?$");
        INSTANCE_MERGED = null;
        INSTANCE = null;
    }

    public RomVersionResMap(float f2) {
        sRomVersion = f2;
        if (q.p() && sRomVersion > 7.0d) {
            sRomVersion = 7.0f;
        }
        String strValueOf = String.valueOf(sRomVersion);
        StringBuilder sb = new StringBuilder();
        sb.append(q.p() ? "_vos" : "_rom");
        sb.append(strValueOf.replace('.', '_'));
        targetSuffix = sb.toString();
        StringBuilder sb2 = new StringBuilder();
        sb2.append(q.p() ? ".Vos" : ".Rom");
        sb2.append(strValueOf.replace('.', '_'));
        styleTargetSuffix = sb2.toString();
        m.i("vresmap_6.0.0.7", "RomVersionResMap<>(), romVer:" + targetSuffix);
    }

    private Boolean findBigger(String str, boolean z2) {
        String str2 = z2 ? styleTargetSuffix : targetSuffix;
        int iCompareTo = str2.compareTo(str);
        if (m.f583b) {
            m.i("vresmap_6.0.0.7", "findBigger(), currentSuffix:" + str + ", targetSuffix:" + str2 + "  compare:" + iCompareTo);
        }
        if (iCompareTo > 0) {
            return Boolean.TRUE;
        }
        if (iCompareTo == 0) {
            return null;
        }
        return Boolean.FALSE;
    }

    public static RomVersionResMap get(Context context) {
        if (INSTANCE_MERGED == null) {
            synchronized (RomVersionResMap.class) {
                try {
                    if (INSTANCE_MERGED == null) {
                        sPackageName = context.getPackageName();
                        INSTANCE_MERGED = new RomVersionResMap(s.c(context));
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return INSTANCE_MERGED;
    }

    public static RomVersionResMap getRealVer() {
        if (INSTANCE == null) {
            synchronized (RomVersionResMap.class) {
                try {
                    if (INSTANCE == null) {
                        INSTANCE = new RomVersionResMap(s.b());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:43:0x00a1 A[PHI: r7
      0x00a1: PHI (r7v3 java.util.regex.Matcher) = (r7v2 java.util.regex.Matcher), (r7v8 java.util.regex.Matcher) binds: [B:35:0x008a, B:41:0x009e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:45:0x00ad  */
    /* JADX WARN: Code duplicated, block: B:48:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:50:0x00dc A[LOOP:0: B:19:0x0052->B:50:0x00dc, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:64:0x00e5 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:65:0x00df A[SYNTHETIC] */
    /* JADX WARN: Instruction removed from duplicated block: B:45:0x00ad, please report this as an issue */
    private int getTarget(Resources resources, int i2, String str, Boolean bool, boolean z2) {
        StringBuilder sb;
        String str2;
        StringBuilder sb2;
        String str3;
        Boolean boolFindBigger;
        if (z2) {
            sb = new StringBuilder();
            sb.append(str);
            str2 = styleRomPatternStr;
        } else {
            sb = new StringBuilder();
            sb.append(str);
            str2 = romPatternStr;
        }
        sb.append(str2);
        Pattern patternCompile = Pattern.compile(sb.toString());
        if (z2) {
            sb2 = new StringBuilder();
            sb2.append(str);
            str3 = stylePatternDemesticStr;
        } else {
            sb2 = new StringBuilder();
            sb2.append(str);
            str3 = romPatternDemesticStr;
        }
        sb2.append(str3);
        Pattern patternCompile2 = Pattern.compile(sb2.toString());
        Pattern pattern = z2 ? styleRomPattern : romPattern;
        Pattern pattern2 = z2 ? stylePatternDemestic : romPatternDemestic;
        int i3 = 0;
        int i4 = i2;
        while (true) {
            i3 = bool.booleanValue() ? i3 + 1 : i3 - 1;
            int i5 = i2 + i3;
            try {
                String resourceEntryName = resources.getResourceEntryName(i5);
                if (!patternCompile.matcher(resourceEntryName).find() && (!q.p() || this.mIsDemesticPattern || !patternCompile2.matcher(resourceEntryName).find())) {
                    break;
                }
                Matcher matcher = pattern.matcher(resourceEntryName);
                if (matcher.find()) {
                    boolFindBigger = findBigger(matcher.group(), z2);
                    if (m.f583b) {
                        m.i("vresmap_6.0.0.7", "getTarget(), bigger:" + boolFindBigger + ", findBigger:" + bool + "  current:" + resourceEntryName);
                    }
                    if (boolFindBigger != null) {
                        if (boolFindBigger.equals(bool)) {
                            i4 = i5;
                        } else if (!bool.booleanValue()) {
                        }
                    }
                    return i5;
                }
                if (!q.p() || this.mIsDemesticPattern) {
                    break;
                }
                matcher = pattern2.matcher(resourceEntryName);
                if (!matcher.find()) {
                    break;
                }
                boolFindBigger = findBigger(matcher.group(), z2);
                if (m.f583b) {
                    m.i("vresmap_6.0.0.7", "getTarget(), bigger:" + boolFindBigger + ", findBigger:" + bool + "  current:" + resourceEntryName);
                }
                if (boolFindBigger != null) {
                    if (boolFindBigger.equals(bool)) {
                        i4 = i5;
                    } else if (!bool.booleanValue()) {
                    }
                }
                return i5;
            } catch (Resources.NotFoundException unused) {
            }
        }
        return i4;
    }

    @Override // com.originui.resmap.map.MapInterface
    public int getMapId(Resources resources, int i2) {
        if (m.f583b) {
            try {
                m.b("vresmap_6.0.0.7", i2 + "resName=" + resources.getResourceName(i2) + ",resId=" + Integer.toHexString(i2) + ",mIsDemesticPattern=" + this.mIsDemesticPattern);
            } catch (Exception unused) {
                m.b("vresmap_6.0.0.7", "resName error=" + Integer.toHexString(i2));
            }
        }
        if (sRomVersion >= 10.0f || q.p()) {
            if (ParserUtil.isValidResId(i2) && !this.noTargetResMap.contains(Integer.valueOf(i2))) {
                try {
                    int targetResMap = getTargetResMap(i2);
                    if (targetResMap != 0) {
                        return targetResMap;
                    }
                    String resourceEntryName = resources.getResourceEntryName(i2);
                    boolean zContains = resourceEntryName.contains(".");
                    Matcher matcher = (zContains ? styleRomPattern : romPattern).matcher(resourceEntryName);
                    if (!matcher.find()) {
                        if (!q.p() || this.mIsDemesticPattern) {
                            this.noTargetResMap.add(Integer.valueOf(i2));
                            m.b("vresmap_6.0.0.7", "getMapId(), resName:" + resourceEntryName + ", isStyle:" + zContains + ", no match.");
                            return i2;
                        }
                        matcher = (zContains ? stylePatternDemestic : romPatternDemestic).matcher(resourceEntryName);
                        if (!matcher.find()) {
                            this.noTargetResMap.add(Integer.valueOf(i2));
                            m.b("vresmap_6.0.0.7", "getMapId(), resName:" + resourceEntryName + ", isStyle:" + zContains + ", no match.");
                            return i2;
                        }
                    }
                    String strGroup = matcher.group();
                    String strReplace = resourceEntryName.replace(strGroup, "");
                    Boolean boolFindBigger = findBigger(strGroup, zContains);
                    if (m.f583b) {
                        m.b("vresmap_6.0.0.7", "getMapId(), resName:" + resourceEntryName + ", findBigger:" + boolFindBigger);
                    }
                    if (boolFindBigger == null) {
                        this.noTargetResMap.add(Integer.valueOf(i2));
                        return i2;
                    }
                    int target = getTarget(resources, i2, strReplace, boolFindBigger, zContains);
                    if (target == i2) {
                        this.noTargetResMap.add(Integer.valueOf(i2));
                    } else if (Objects.equals(resources.getResourceTypeName(i2), resources.getResourceTypeName(target))) {
                        this.targetResMap.put(i2, target);
                    } else {
                        this.noTargetResMap.add(Integer.valueOf(i2));
                        target = i2;
                    }
                    if (m.f583b) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("getMapId(), resName:");
                        sb.append(resourceEntryName);
                        sb.append(", target:");
                        sb.append(resources.getResourceEntryName(target));
                        sb.append(",  find?:");
                        sb.append(target != i2);
                        m.b("vresmap_6.0.0.7", sb.toString());
                    }
                    return target;
                } catch (Exception unused2) {
                }
            }
        } else if (m.f583b) {
            m.b("vresmap_6.0.0.7", "sRomVersion=" + sRomVersion);
        }
        return i2;
    }

    public synchronized int getTargetResMap(int i2) {
        int iIndexOfKey;
        iIndexOfKey = this.targetResMap.indexOfKey(i2);
        return iIndexOfKey >= 0 ? this.targetResMap.valueAt(iIndexOfKey) : 0;
    }

    @Override // com.originui.resmap.map.MapInterface
    public void loadIsolateResourceXml(Resources resources, int i2) {
        if (this.noTargetXmlMap.contains(Integer.valueOf(i2))) {
            m.b("vresmap_6.0.0.7", "has load IsolateResourceXml");
            return;
        }
        XmlResourceParser xml = resources.getXml(i2);
        while (true) {
            try {
                try {
                    int next = xml.next();
                    if (next == 1) {
                        this.noTargetXmlMap.add(Integer.valueOf(i2));
                        xml.close();
                        return;
                    }
                    if (next == 2 && "item".equals(xml.getName())) {
                        String attributeValue = null;
                        boolean z2 = true;
                        String attributeValue2 = null;
                        for (int i3 = 0; i3 < xml.getAttributeCount(); i3++) {
                            if ("name".equals(xml.getAttributeName(i3))) {
                                attributeValue = xml.getAttributeValue(i3);
                            } else if ("type".equals(xml.getAttributeName(i3))) {
                                attributeValue2 = xml.getAttributeValue(i3);
                            }
                            if ("resMap".equals(xml.getAttributeName(i3))) {
                                z2 = Boolean.parseBoolean(xml.getAttributeValue(i3));
                            }
                            if (!z2 && attributeValue != null && attributeValue2 != null) {
                                this.noTargetResMap.add(Integer.valueOf(resources.getIdentifier(attributeValue, attributeValue2, sPackageName)));
                            }
                        }
                    }
                } catch (Exception e2) {
                    if (m.f583b) {
                        m.f("vresmap_6.0.0.7", "Error parsing ResourceXml:", e2);
                    }
                    this.noTargetXmlMap.add(Integer.valueOf(i2));
                    xml.close();
                    return;
                }
            } catch (Throwable th) {
                this.noTargetXmlMap.add(Integer.valueOf(i2));
                xml.close();
                throw th;
            }
        }
    }

    @Override // com.originui.resmap.map.MapInterface
    public void setDemesticPattern(boolean z2) {
        if (this.mIsDemesticPattern != z2) {
            this.mIsDemesticPattern = z2;
            if (z2) {
                romPatternStr = "_rom\\d{2}(_\\d)?$";
                romPattern = Pattern.compile("_rom\\d{2}(_\\d)?$");
                styleRomPatternStr = "\\.Rom\\d{2}(_\\d)?$";
                styleRomPattern = Pattern.compile("\\.Rom\\d{2}(_\\d)?$");
                return;
            }
            String str = q.p() ? "_vos\\d{1}(_\\d)?$" : "_rom\\d{2}(_\\d)?$";
            romPatternStr = str;
            romPattern = Pattern.compile(str);
            String str2 = q.p() ? "\\.Vos\\d{1}(_\\d)?$" : "\\.Rom\\d{2}(_\\d)?$";
            styleRomPatternStr = str2;
            styleRomPattern = Pattern.compile(str2);
        }
    }
}
