package com.originui.resmap.map;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.view.Display;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.h;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.n;
import com.originui.core.utils.v;
import com.originui.resmap.attr.ViewAttrConstant;
import java.lang.reflect.Field;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class DeviceResMap extends BaseResMapHelper {
    private static volatile DeviceResMap INSTANCE = null;
    private static final String TAG = "DeviceResMap";
    private String deviceSuffix;
    protected final boolean enableMap;

    public DeviceResMap(Context context) {
        refreshDeviceConfig(context);
        this.enableMap = !h.g();
    }

    public static DeviceResMap get(Context context) {
        if (INSTANCE == null) {
            synchronized (DeviceResMap.class) {
                try {
                    if (INSTANCE == null) {
                        INSTANCE = new DeviceResMap(context);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (!v.b(INSTANCE.deviceSuffix, getDeviceSuffix(context))) {
            INSTANCE = new DeviceResMap(context);
        }
        return INSTANCE;
    }

    private static String getDeviceSuffix(Context context) {
        try {
            if (h.i()) {
                if (isFoldSecondaryScreen(context)) {
                    return "_4_fold";
                }
            } else if (h.h()) {
                if (isFlipOutsideScreen(context)) {
                    return "_4_flip";
                }
            } else if (h.j()) {
                return "_4_pad";
            }
            return "";
        } catch (Exception e2) {
            m.f(TAG, "getDeviceSuffix(), fail find FtDeviceInfo#getDeviceType() method", e2);
            return null;
        }
    }

    private static boolean isFlipOutsideScreen(Context context) {
        try {
            return h.h() && ((DisplayManager) context.getSystemService("display")).getDisplays(null)[0].getDisplayId() == 1;
        } catch (Exception unused) {
        }
    }

    private static boolean isFoldSecondaryScreen(Context context) {
        try {
            if (!h.i()) {
                return false;
            }
            Display display = ((DisplayManager) context.getSystemService("display")).getDisplay(0);
            Field declaredField = display.getClass().getDeclaredField("mDisplayInfo");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(display);
            Field declaredField2 = Class.forName("android.view.DisplayInfo").getDeclaredField("uniqueId");
            declaredField2.setAccessible(true);
            return !"local:secondary".equals((String) declaredField2.get(obj));
        } catch (Exception unused) {
            return false;
        }
    }

    @Override // com.originui.resmap.map.BaseResMapHelper
    protected boolean enableMap() {
        return this.enableMap;
    }

    @Override // com.originui.resmap.map.BaseResMapHelper
    protected String getTargetResName(String str) {
        return str + this.deviceSuffix;
    }

    public void refreshDeviceConfig(Context context) {
        this.deviceSuffix = getDeviceSuffix(context);
        ViewAttrConstant.isNightMode = n.a(context);
        ViewAttrConstant.isGlobalTheme = k.f(context);
        ViewAttrConstant.isFollowColor = VThemeIconUtils.B();
    }
}
