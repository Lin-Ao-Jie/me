package com.originui.resmap.map;

import android.content.res.Resources;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface MapInterface {
    int getMapId(Resources resources, int i2);

    default void setDemesticPattern(boolean z2) {
    }

    default void loadIsolateResourceXml(Resources resources, int i2) {
    }
}
