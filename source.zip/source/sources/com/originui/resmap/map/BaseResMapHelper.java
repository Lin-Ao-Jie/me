package com.originui.resmap.map;

import android.content.res.Resources;
import android.text.TextUtils;
import android.util.SparseIntArray;
import com.originui.core.utils.m;
import com.originui.resmap.attr.ParserUtil;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class BaseResMapHelper implements MapInterface {
    private static final String TAG = "BaseResMap";
    private final SparseIntArray targetResMap = new SparseIntArray();
    private final Set<Integer> noTargetResMap = new HashSet();

    protected boolean enableMap() {
        return true;
    }

    @Override // com.originui.resmap.map.MapInterface
    public final int getMapId(Resources resources, int i2) {
        if (!enableMap() || !ParserUtil.isValidResId(i2) || this.noTargetResMap.contains(Integer.valueOf(i2))) {
            return i2;
        }
        int i3 = this.targetResMap.get(i2);
        if (i3 != 0) {
            return i3;
        }
        String resourceEntryName = resources.getResourceEntryName(i2);
        String targetResName = getTargetResName(resourceEntryName);
        if (TextUtils.isEmpty(targetResName)) {
            this.noTargetResMap.add(Integer.valueOf(i2));
            return i2;
        }
        int identifier = resources.getIdentifier(targetResName, resources.getResourceTypeName(i2), resources.getResourcePackageName(i2));
        if (identifier != 0) {
            this.targetResMap.put(i2, identifier);
        } else {
            this.noTargetResMap.add(Integer.valueOf(i2));
            identifier = i2;
        }
        if (m.f583b) {
            StringBuilder sb = new StringBuilder();
            sb.append("getMapId(), resName:");
            sb.append(resourceEntryName);
            sb.append(", target:");
            sb.append(targetResName);
            sb.append(",  find?:");
            sb.append(identifier != i2);
            m.b(TAG, sb.toString());
        }
        return identifier;
    }

    protected abstract String getTargetResName(String str);
}
