package com.originui.resmap.attr;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ViewAttrConstant {
    private static final int ATTR_BASE_ENABLE = 1;
    public static final int ATTR_DEFAULT = 31;
    private static final int ATTR_FOLLOW_COLOR_ENABLE = 8;
    private static final int ATTR_GLOBAL_THEME_ENABLE = 16;
    private static final int ATTR_NIGHT_FOLLOW_ENABLE = 2;
    private static final int ATTR_NIGHT_MODE_ENABLE = 4;
    public static boolean isFollowColor = false;
    public static boolean isGlobalTheme = false;
    public static boolean isNightMode = false;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    public static int createActiveMode(boolean z2, boolean z3, boolean z4, boolean z5, boolean z6) {
        int i2;
        ?? r0 = z2;
        if (z3) {
            i2 = (z2 ? 1 : 0) | 2;
        }
        if (z4) {
            r0 = i2;
            r0 = (r0 == true ? 1 : 0) | 4;
        }
        if (z5) {
            r0 = (r0 == true ? 1 : 0) | '\b';
        }
        return z6 ? r0 | 16 : r0;
    }

    public static boolean isActive(int i2) {
        if ((i2 & 1) != 1) {
            return false;
        }
        boolean z2 = isNightMode;
        if (z2 && isFollowColor && (i2 & 2) != 2) {
            return false;
        }
        if (z2 && (i2 & 4) != 4) {
            return false;
        }
        if (!isFollowColor || (i2 & 8) == 8) {
            return !isGlobalTheme || (i2 & 16) == 16;
        }
        return false;
    }

    public static int createActiveMode(boolean z2) {
        return createActiveMode(z2, true, true, true, true);
    }

    public static int createActiveMode(boolean z2, boolean z3) {
        return createActiveMode(z2, z3, true, true, true);
    }

    public static int createActiveMode(boolean z2, boolean z3, boolean z4) {
        return createActiveMode(true, z2, z3, z4, true);
    }

    public static int createActiveMode(boolean z2, boolean z3, boolean z4, boolean z5) {
        return createActiveMode(true, z2, z3, z4, z5);
    }
}
