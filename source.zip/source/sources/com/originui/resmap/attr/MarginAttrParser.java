package com.originui.resmap.attr;

import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import com.originui.resmap.R;
import com.originui.resmap.bridge.ResourcesBridge;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class MarginAttrParser implements BaseAttrParser<View> {
    final ParserUtil.EdgeParam margins = new ParserUtil.EdgeParam();

    /* JADX INFO: Access modifiers changed from: private */
    public boolean doNewAttrs(View view, ResourcesBridge resourcesBridge) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            return false;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        ParserUtil.EdgeParam edgeParam = this.margins;
        if (edgeParam.useEdge) {
            ParserUtil.MapVal mapVal = new ParserUtil.MapVal(resourcesBridge, edgeParam.edge);
            if (!mapVal.changed()) {
                return false;
            }
            int mapDimen = mapVal.getMapDimen();
            marginLayoutParams.leftMargin = mapDimen;
            marginLayoutParams.rightMargin = mapDimen;
            marginLayoutParams.bottomMargin = mapDimen;
            marginLayoutParams.topMargin = mapDimen;
            return true;
        }
        ParserUtil.MapVal mapVal2 = new ParserUtil.MapVal(resourcesBridge, edgeParam.top);
        marginLayoutParams.topMargin = mapVal2.getMapDimen(marginLayoutParams.topMargin);
        boolean zChanged = mapVal2.changed();
        ParserUtil.MapVal mapVal3 = new ParserUtil.MapVal(resourcesBridge, this.margins.bottom);
        marginLayoutParams.bottomMargin = mapVal3.getMapDimen(marginLayoutParams.bottomMargin);
        boolean z2 = mapVal3.changed() || zChanged;
        ParserUtil.EdgeParam edgeParam2 = this.margins;
        if (!edgeParam2.fitRtl) {
            ParserUtil.MapVal mapVal4 = new ParserUtil.MapVal(resourcesBridge, edgeParam2.left);
            marginLayoutParams.leftMargin = mapVal4.getMapDimen(marginLayoutParams.leftMargin);
            boolean z3 = mapVal4.changed() || z2;
            ParserUtil.MapVal mapVal5 = new ParserUtil.MapVal(resourcesBridge, this.margins.right);
            marginLayoutParams.rightMargin = mapVal5.getMapDimen(marginLayoutParams.rightMargin);
            return mapVal5.changed() || z3;
        }
        ParserUtil.MapVal mapVal6 = new ParserUtil.MapVal(resourcesBridge, edgeParam2.start);
        if (mapVal6.changed()) {
            marginLayoutParams.setMarginStart(mapVal6.getMapDimen());
            z2 = true;
        }
        ParserUtil.MapVal mapVal7 = new ParserUtil.MapVal(resourcesBridge, this.margins.end);
        if (!mapVal7.changed()) {
            return z2;
        }
        marginLayoutParams.setMarginEnd(mapVal7.getMapDimen());
        return true;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public int[] getStyleableAttr() {
        return R.styleable.LayoutAttr;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public void parserAttrIds(View view, TypedArray typedArray, final ResourcesBridge resourcesBridge) {
        ParserUtil.EdgeParam edgeParam = this.margins;
        int i2 = R.styleable.LayoutAttr_android_layout_margin;
        edgeParam.useEdge = typedArray.hasValue(i2);
        this.margins.edge = typedArray.getResourceId(i2, 0);
        ParserUtil.EdgeParam edgeParam2 = this.margins;
        if (!edgeParam2.useEdge) {
            edgeParam2.left = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginLeft, 0);
            this.margins.right = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginRight, 0);
            this.margins.top = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginTop, 0);
            this.margins.bottom = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginBottom, 0);
            this.margins.start = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginStart, 0);
            this.margins.end = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginEnd, 0);
            ParserUtil.EdgeParam edgeParam3 = this.margins;
            if (edgeParam3.start != 0 || edgeParam3.end != 0) {
                edgeParam3.fitRtl = true;
            }
            int resourceId = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginHorizontal, 0);
            int resourceId2 = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_marginVertical, 0);
            if (ParserUtil.isValidResId(resourceId)) {
                ParserUtil.EdgeParam edgeParam4 = this.margins;
                edgeParam4.left = resourceId;
                edgeParam4.right = resourceId;
            }
            if (ParserUtil.isValidResId(resourceId2)) {
                ParserUtil.EdgeParam edgeParam5 = this.margins;
                edgeParam5.top = resourceId2;
                edgeParam5.bottom = resourceId2;
            }
        }
        view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() { // from class: com.originui.resmap.attr.MarginAttrParser.1
            @Override // android.view.View.OnAttachStateChangeListener
            public void onViewAttachedToWindow(View view2) {
                view2.removeOnAttachStateChangeListener(this);
                if (MarginAttrParser.this.doNewAttrs(view2, resourcesBridge)) {
                    view2.requestLayout();
                }
            }

            @Override // android.view.View.OnAttachStateChangeListener
            public void onViewDetachedFromWindow(View view2) {
            }
        });
        BaseViewAttr baseViewAttr = ParserUtil.getBaseViewAttr(view);
        if (baseViewAttr != null) {
            baseViewAttr.setMargins(this.margins.copy());
        }
    }
}
