package com.originui.resmap.attr;

import android.content.res.TypedArray;
import android.view.View;
import com.originui.resmap.R;
import com.originui.resmap.bridge.ResourcesBridge;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class PaddingAttrParser implements BaseAttrParser<View> {
    final ParserUtil.EdgeParam paddings = new ParserUtil.EdgeParam();

    private boolean doNewAttrs(View view, ResourcesBridge resourcesBridge) {
        ParserUtil.EdgeParam edgeParam = this.paddings;
        boolean z2 = true;
        if (edgeParam.useEdge) {
            if (!resourcesBridge.hasMapId(edgeParam.edge)) {
                return false;
            }
            int dimensionPixelSize = resourcesBridge.getDimensionPixelSize(this.paddings.edge);
            view.setPadding(dimensionPixelSize, dimensionPixelSize, dimensionPixelSize, dimensionPixelSize);
            return true;
        }
        ParserUtil.MapVal mapVal = new ParserUtil.MapVal(resourcesBridge, edgeParam.top);
        int mapDimen = mapVal.getMapDimen(view.getPaddingTop());
        boolean zChanged = mapVal.changed();
        ParserUtil.MapVal mapVal2 = new ParserUtil.MapVal(resourcesBridge, this.paddings.bottom);
        int mapDimen2 = mapVal2.getMapDimen(view.getPaddingBottom());
        boolean z3 = mapVal2.changed() || zChanged;
        ParserUtil.EdgeParam edgeParam2 = this.paddings;
        if (edgeParam2.fitRtl) {
            ParserUtil.MapVal mapVal3 = new ParserUtil.MapVal(resourcesBridge, edgeParam2.start);
            int mapDimen3 = mapVal3.getMapDimen(view.getPaddingStart());
            boolean z4 = mapVal3.changed() || z3;
            ParserUtil.MapVal mapVal4 = new ParserUtil.MapVal(resourcesBridge, this.paddings.end);
            int mapDimen4 = mapVal4.getMapDimen(view.getPaddingEnd());
            if (!mapVal4.changed() && !z4) {
                z2 = false;
            }
            if (z2) {
                view.setPaddingRelative(mapDimen3, mapDimen, mapDimen4, mapDimen2);
            }
            return z2;
        }
        ParserUtil.MapVal mapVal5 = new ParserUtil.MapVal(resourcesBridge, edgeParam2.left);
        int mapDimen5 = mapVal5.getMapDimen(view.getPaddingStart());
        boolean z5 = mapVal5.changed() || z3;
        ParserUtil.MapVal mapVal6 = new ParserUtil.MapVal(resourcesBridge, this.paddings.right);
        int mapDimen6 = mapVal6.getMapDimen(view.getPaddingEnd());
        if (!mapVal6.changed() && !z5) {
            z2 = false;
        }
        if (z2) {
            view.setPadding(mapDimen5, mapDimen, mapDimen6, mapDimen2);
        }
        return z2;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public int[] getStyleableAttr() {
        return R.styleable.LayoutAttr;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public void parserAttrIds(View view, TypedArray typedArray, ResourcesBridge resourcesBridge) {
        ParserUtil.EdgeParam edgeParam = this.paddings;
        int i2 = R.styleable.LayoutAttr_android_padding;
        edgeParam.edge = typedArray.getResourceId(i2, 0);
        this.paddings.useEdge = typedArray.hasValue(i2);
        ParserUtil.EdgeParam edgeParam2 = this.paddings;
        if (!edgeParam2.useEdge) {
            edgeParam2.top = typedArray.getResourceId(R.styleable.LayoutAttr_android_paddingTop, 0);
            this.paddings.bottom = typedArray.getResourceId(R.styleable.LayoutAttr_android_paddingBottom, 0);
            int i3 = R.styleable.LayoutAttr_android_paddingStart;
            if (typedArray.hasValue(i3) || typedArray.hasValue(R.styleable.LayoutAttr_android_paddingEnd)) {
                this.paddings.start = typedArray.getResourceId(i3, 0);
                this.paddings.end = typedArray.getResourceId(R.styleable.LayoutAttr_android_paddingEnd, 0);
                this.paddings.fitRtl = true;
            } else {
                this.paddings.left = typedArray.getResourceId(R.styleable.LayoutAttr_android_paddingLeft, 0);
                this.paddings.right = typedArray.getResourceId(R.styleable.LayoutAttr_android_paddingRight, 0);
            }
        }
        if (doNewAttrs(view, resourcesBridge)) {
            view.requestLayout();
        }
        BaseViewAttr baseViewAttr = ParserUtil.getBaseViewAttr(view);
        if (baseViewAttr != null) {
            baseViewAttr.setPaddings(this.paddings.copy());
        }
    }
}
