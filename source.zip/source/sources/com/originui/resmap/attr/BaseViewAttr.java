package com.originui.resmap.attr;

import android.content.res.Configuration;
import android.view.View;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class BaseViewAttr {
    private int background;
    private int globalBackground;
    private int height;
    private int minHeight;
    private int minWidth;
    private int width;
    private final Config config = new Config();
    private int sizeActiveMode = 31;
    private ParserUtil.EdgeParam paddings = new ParserUtil.EdgeParam();
    private int paddingActiveMode = 31;
    private ParserUtil.EdgeParam margins = new ParserUtil.EdgeParam();
    private int marginActiveMode = 31;
    private int backgroundActiveMode = 31;
    private boolean fitSymbol = false;
    private int fontLimit = 7;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Config {
        String screen;
        String uiMode;

        public static String getScreenInfo(View view) {
            if (view.getResources() == null) {
                return "360-765";
            }
            Configuration configuration = view.getResources().getConfiguration();
            return configuration.screenWidthDp + "-" + configuration.screenHeightDp;
        }

        public static String getUiModeInfo(View view) {
            return view.getResources() != null ? Integer.toHexString(view.getResources().getConfiguration().uiMode) : "11";
        }

        public String getScreen() {
            return this.screen;
        }

        public String getUiMode() {
            return this.uiMode;
        }

        public void setScreen(String str) {
            this.screen = str;
        }

        public void setUiMode(String str) {
            this.uiMode = str;
        }
    }

    public int getBackground() {
        return this.background;
    }

    public int getBackgroundActiveMode() {
        return this.backgroundActiveMode;
    }

    public Config getConfig() {
        return this.config;
    }

    public int getFontLimit() {
        return this.fontLimit;
    }

    public int getGlobalBackground() {
        return this.globalBackground;
    }

    public int getHeight() {
        return this.height;
    }

    public int getMarginActiveMode() {
        return this.marginActiveMode;
    }

    public ParserUtil.EdgeParam getMargins() {
        return this.margins;
    }

    public int getMinHeight() {
        return this.minHeight;
    }

    public int getMinWidth() {
        return this.minWidth;
    }

    public int getPaddingActiveMode() {
        return this.paddingActiveMode;
    }

    public ParserUtil.EdgeParam getPaddings() {
        return this.paddings;
    }

    public int getSizeActiveMode() {
        return this.sizeActiveMode;
    }

    public int getWidth() {
        return this.width;
    }

    public boolean isFitSymbol() {
        return this.fitSymbol;
    }

    public void setBackground(int i2) {
        this.background = i2;
    }

    public void setBackgroundActiveMode(int i2) {
        this.backgroundActiveMode = i2;
    }

    public void setFitSymbol(boolean z2) {
        this.fitSymbol = z2;
    }

    public void setFontLimit(int i2) {
        this.fontLimit = i2;
    }

    public void setGlobalBackground(int i2) {
        this.globalBackground = i2;
    }

    public void setHeight(int i2) {
        this.height = i2;
    }

    public void setMarginActiveMode(int i2) {
        this.marginActiveMode = i2;
    }

    public void setMargins(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            this.margins.left = i2;
        }
        if (i3 != 0) {
            this.margins.top = i3;
        }
        if (i4 != 0) {
            this.margins.right = i4;
        }
        if (i5 != 0) {
            this.margins.bottom = i5;
        }
    }

    public void setMinHeight(int i2) {
        this.minHeight = i2;
    }

    public void setMinWidth(int i2) {
        this.minWidth = i2;
    }

    public void setPaddingActiveMode(int i2) {
        this.paddingActiveMode = i2;
    }

    public void setPaddings(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            ParserUtil.EdgeParam edgeParam = this.paddings;
            if (edgeParam.fitRtl) {
                edgeParam.start = i2;
            } else {
                edgeParam.left = i2;
            }
        }
        if (i3 != 0) {
            this.paddings.top = i3;
        }
        if (i4 != 0) {
            ParserUtil.EdgeParam edgeParam2 = this.paddings;
            if (edgeParam2.fitRtl) {
                edgeParam2.end = i4;
            } else {
                edgeParam2.right = i4;
            }
        }
        if (i5 != 0) {
            this.paddings.bottom = i5;
        }
    }

    public void setSizeActiveMode(int i2) {
        this.sizeActiveMode = i2;
    }

    public void setWidth(int i2) {
        this.width = i2;
    }

    public void setMargins(ParserUtil.EdgeParam edgeParam) {
        this.margins = edgeParam;
    }

    public void setPaddings(ParserUtil.EdgeParam edgeParam) {
        this.paddings = edgeParam;
    }
}
