package com.originui.resmap.attr;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.originui.core.utils.m;
import com.originui.resmap.R;
import com.originui.resmap.bridge.ContextBridge;
import com.originui.resmap.bridge.ResourcesBridge;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ParserUtil {
    private static final String ID_PREFIX = "7f";
    private static final String ID_PREFIX_1 = "7e";
    private static final String ID_PREFIX_2 = "77";
    private static final String ID_PREFIX_3 = "8f";
    private static final String TAG = "ParserUtil";

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface Consumer<T> {
        boolean accept(T t2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class EdgeParam {
        int bottom;
        int edge;
        int end;
        int left;
        int right;
        int start;
        int top;
        boolean useEdge = false;
        boolean fitRtl = false;

        EdgeParam() {
        }

        EdgeParam copy() {
            EdgeParam edgeParam = new EdgeParam();
            edgeParam.edge = this.edge;
            edgeParam.useEdge = this.useEdge;
            edgeParam.left = this.left;
            edgeParam.right = this.right;
            edgeParam.top = this.top;
            edgeParam.bottom = this.bottom;
            edgeParam.start = this.start;
            edgeParam.end = this.end;
            edgeParam.fitRtl = this.fitRtl;
            return edgeParam;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface MapEach<K, V> {
        boolean accept(K k2, V v2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class MapVal {
        private final ResourcesBridge bridge;
        private final boolean hasMapId;
        private final int originId;

        MapVal(ResourcesBridge resourcesBridge, int i2) {
            this.originId = i2;
            this.hasMapId = ParserUtil.isValidResId(i2) && resourcesBridge.hasMapId(i2);
            this.bridge = resourcesBridge;
        }

        boolean changed() {
            return this.hasMapId;
        }

        int getMapDimen() {
            return this.bridge.getDimensionPixelSize(this.originId);
        }

        int getMapDimen(int i2) {
            return changed() ? getMapDimen() : i2;
        }
    }

    public static ContextBridge findBridge(Context context) {
        if (context instanceof ContextBridge) {
            return (ContextBridge) context;
        }
        if (context instanceof ContextWrapper) {
            return (ContextBridge) getContext((ContextWrapper) context, new HashSet(), new Consumer<Context>() { // from class: com.originui.resmap.attr.ParserUtil.2
                @Override // com.originui.resmap.attr.ParserUtil.Consumer
                public boolean accept(Context context2) {
                    return context2 instanceof ContextBridge;
                }
            });
        }
        return null;
    }

    public static <K, V> void forEach(Map<K, V> map, MapEach<? super K, ? super V> mapEach) {
        if (map == null || map.size() == 0) {
            return;
        }
        for (Map.Entry<K, V> entry : map.entrySet()) {
            try {
                if (mapEach.accept(entry.getKey(), entry.getValue())) {
                    return;
                }
            } catch (Exception e2) {
                m.f(TAG, "forEach(), fail", e2);
                return;
            }
        }
    }

    public static Activity getActivity(Context context) {
        if (context instanceof Activity) {
            return (Activity) context;
        }
        if (context instanceof ContextWrapper) {
            return (Activity) getContext((ContextWrapper) context, new HashSet(), new Consumer<Context>() { // from class: com.originui.resmap.attr.ParserUtil.1
                @Override // com.originui.resmap.attr.ParserUtil.Consumer
                public boolean accept(Context context2) {
                    return context2 instanceof Activity;
                }
            });
        }
        return null;
    }

    public static BaseViewAttr getBaseViewAttr(View view) {
        Object tag = view != null ? view.getTag(R.id.tag_origin_res_map_view_attrs) : null;
        if (tag instanceof BaseViewAttr) {
            return (BaseViewAttr) tag;
        }
        return null;
    }

    private static Context getContext(ContextWrapper contextWrapper, Set<String> set, Consumer<Context> consumer) {
        Context baseContext = contextWrapper.getBaseContext();
        if (consumer.accept(baseContext)) {
            return baseContext;
        }
        String objKey = getObjKey(contextWrapper);
        if (set.contains(objKey)) {
            return null;
        }
        set.add(objKey);
        if (baseContext instanceof ContextWrapper) {
            return getContext((ContextWrapper) baseContext, set, consumer);
        }
        return null;
    }

    private static ContextBridge getContextBridge(ContextWrapper contextWrapper, Set<String> set) {
        Context baseContext = contextWrapper.getBaseContext();
        if (baseContext instanceof ContextBridge) {
            return (ContextBridge) baseContext;
        }
        String objKey = getObjKey(contextWrapper);
        if (set.contains(objKey)) {
            return null;
        }
        set.add(objKey);
        if (baseContext instanceof ContextWrapper) {
            return getContextBridge((ContextWrapper) baseContext, set);
        }
        return null;
    }

    private static int getDimen(Resources resources, int i2) {
        if (isValidResId(i2)) {
            return resources.getDimensionPixelSize(i2);
        }
        return 0;
    }

    private static String getObjKey(Object obj) {
        if (obj == null) {
            return "";
        }
        return obj.getClass().getName() + "@" + Integer.toHexString(obj.hashCode());
    }

    public static BaseViewAttr getOrCreateViewAttr(View view) {
        BaseViewAttr baseViewAttr = getBaseViewAttr(view);
        if (baseViewAttr != null) {
            return baseViewAttr;
        }
        ContextBridge contextBridgeFindBridge = findBridge(view.getContext());
        if (contextBridgeFindBridge != null && contextBridgeFindBridge.isFitConfig()) {
            if (view instanceof TextView) {
                baseViewAttr = new TextViewAttr();
            } else {
                baseViewAttr = view instanceof ImageView ? new ImageViewAttr() : new BaseViewAttr();
            }
            view.setTag(R.id.tag_origin_res_map_view_attrs, baseViewAttr);
            String screenInfo = BaseViewAttr.Config.getScreenInfo(view);
            baseViewAttr.getConfig().setUiMode(BaseViewAttr.Config.getUiModeInfo(view));
            baseViewAttr.getConfig().setScreen(screenInfo);
        }
        return baseViewAttr;
    }

    public static boolean isValidResId(int i2) {
        if (i2 == 0 || i2 == -1) {
            return false;
        }
        String hexString = Integer.toHexString(i2);
        return hexString.startsWith(ID_PREFIX) || hexString.startsWith(ID_PREFIX_1) || hexString.startsWith(ID_PREFIX_2) || hexString.startsWith(ID_PREFIX_3);
    }

    public static void setViewMargin(View view, int i2, int i3, int i4, int i5) {
        BaseViewAttr orCreateViewAttr;
        if (view == null || (orCreateViewAttr = getOrCreateViewAttr(view)) == null) {
            return;
        }
        orCreateViewAttr.setMargins(i2, i3, i4, i5);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            Resources resources = view.getResources();
            EdgeParam margins = orCreateViewAttr.getMargins();
            marginLayoutParams.topMargin = getDimen(resources, margins.top);
            marginLayoutParams.bottomMargin = getDimen(resources, margins.bottom);
            if (margins.fitRtl) {
                marginLayoutParams.setMarginStart(getDimen(resources, margins.start));
                marginLayoutParams.setMarginEnd(getDimen(resources, margins.end));
            } else {
                marginLayoutParams.leftMargin = getDimen(resources, margins.left);
                marginLayoutParams.rightMargin = getDimen(resources, margins.right);
            }
            view.requestLayout();
        }
    }

    public static void setViewPadding(View view, int i2, int i3, int i4, int i5) {
        BaseViewAttr orCreateViewAttr;
        if (view == null || (orCreateViewAttr = getOrCreateViewAttr(view)) == null) {
            return;
        }
        orCreateViewAttr.setPaddings(i2, i3, i4, i5);
        EdgeParam paddings = orCreateViewAttr.getPaddings();
        Resources resources = view.getResources();
        if (paddings.fitRtl) {
            view.setPaddingRelative(getDimen(resources, paddings.start), getDimen(resources, paddings.top), getDimen(resources, paddings.end), getDimen(resources, paddings.bottom));
        } else {
            view.setPadding(getDimen(resources, paddings.left), getDimen(resources, paddings.top), getDimen(resources, paddings.right), getDimen(resources, paddings.bottom));
        }
    }
}
