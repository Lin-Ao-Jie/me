package com.originui.resmap.attr;

import android.content.res.TypedArray;
import android.view.View;
import com.originui.resmap.bridge.ResourcesBridge;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface BaseAttrParser<T extends View> {
    int[] getStyleableAttr();

    void parserAttrIds(T t2, TypedArray typedArray, ResourcesBridge resourcesBridge);
}
