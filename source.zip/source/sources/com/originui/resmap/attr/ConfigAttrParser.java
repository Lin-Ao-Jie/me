package com.originui.resmap.attr;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.a0;
import com.originui.core.utils.j;
import com.originui.core.utils.m;
import com.originui.core.utils.s;
import com.originui.resmap.R;
import com.originui.resmap.bridge.ResourcesBridge;
import java.util.Objects;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ConfigAttrParser implements BaseAttrParser<View> {
    private static final String TAG = "ConfigAttrParser";

    private static void applyViewGroup(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        onApplySubView(viewGroup);
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if (childAt instanceof ViewGroup) {
                applyViewGroup((ViewGroup) childAt);
            } else {
                onApplySubView(childAt);
            }
        }
    }

    private static int getDimen(Resources resources, int i2) {
        if (ParserUtil.isValidResId(i2)) {
            return resources.getDimensionPixelSize(i2);
        }
        return 0;
    }

    private static int getSizeByFontLimit(Context context, int i2, int i3) {
        return (context == null || !s.f(context) || a0.c() <= 1) ? i2 : (int) j.c(context, i2, i3);
    }

    private static boolean isValidResId(int... iArr) {
        for (int i2 : iArr) {
            if (ParserUtil.isValidResId(i2)) {
                return true;
            }
        }
        return false;
    }

    private static void onApplySubView(View view) {
        BaseViewAttr baseViewAttr = ParserUtil.getBaseViewAttr(view);
        if (ViewAttrConstant.isActive(baseViewAttr.getSizeActiveMode())) {
            onSizeChanged(view, baseViewAttr);
        }
    }

    public static void onApplyView(View view) {
        if (view instanceof ViewGroup) {
            applyViewGroup((ViewGroup) view);
        } else {
            onApplySubView(view);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static void onBackgroundChanged(View view, BaseViewAttr baseViewAttr) {
        Resources resources = view.getResources();
        if (ViewAttrConstant.isGlobalTheme && ParserUtil.isValidResId(baseViewAttr.getGlobalBackground())) {
            view.setBackground(resources.getDrawable(baseViewAttr.getGlobalBackground()));
            m.i(TAG, "onBackgroundChanged(), global [config-changed] view:" + view);
        } else if (ParserUtil.isValidResId(baseViewAttr.getBackground())) {
            view.setBackground(resources.getDrawable(baseViewAttr.getBackground()));
            m.i(TAG, "onBackgroundChanged(), [config-changed] view:" + view);
        }
        if (view instanceof IUpdateBlur) {
            ((IUpdateBlur) view).updateBlur();
        }
    }

    public static void onConfigurationChanged(View view) {
        onConfigurationChanged(view, true, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void onImageViewChanged(ImageView imageView, BaseViewAttr baseViewAttr) {
        if (baseViewAttr instanceof ImageViewAttr) {
            ImageViewAttr imageViewAttr = (ImageViewAttr) baseViewAttr;
            if (ParserUtil.isValidResId(imageViewAttr.getSrc())) {
                imageView.setImageResource(imageViewAttr.getSrc());
                m.i(TAG, "onImageViewChanged(), [config-changed] view:" + imageView);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:18:0x006b A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:19:0x006c  */
    /* JADX WARN: Code duplicated, block: B:25:0x007a  */
    /* JADX WARN: Code duplicated, block: B:30:0x0087  */
    /* JADX WARN: Code duplicated, block: B:37:0x0098  */
    /* JADX WARN: Code duplicated, block: B:38:0x009f  */
    public static void onMarginChanged(View view, BaseViewAttr baseViewAttr) {
        int dimen;
        int dimen2;
        int dimen3;
        int dimen4;
        int i2;
        ViewGroup.LayoutParams layoutParams;
        ViewGroup.MarginLayoutParams marginLayoutParams;
        Resources resources = view.getResources();
        ParserUtil.EdgeParam margins = baseViewAttr.getMargins();
        if (!margins.useEdge || !ParserUtil.isValidResId(margins.edge)) {
            if (isValidResId(margins.left, margins.right, margins.top, margins.bottom, margins.start, margins.end)) {
                int dimen5 = getDimen(resources, margins.top);
                dimen2 = getDimen(resources, margins.bottom);
                if (margins.fitRtl) {
                    dimen3 = getDimen(resources, margins.start);
                    dimen4 = getDimen(resources, margins.end);
                } else {
                    dimen3 = getDimen(resources, margins.left);
                    dimen4 = getDimen(resources, margins.right);
                }
                i2 = dimen4;
                dimen = dimen5;
            } else {
                dimen = 0;
            }
            layoutParams = view.getLayoutParams();
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
                if (marginLayoutParams.topMargin == dimen && marginLayoutParams.bottomMargin == dimen2) {
                    if (margins.fitRtl) {
                        if (marginLayoutParams.getMarginStart() == dimen3 && marginLayoutParams.getMarginEnd() == i2) {
                            return;
                        }
                    } else if (marginLayoutParams.leftMargin == dimen3 && marginLayoutParams.rightMargin == i2) {
                        return;
                    }
                }
                marginLayoutParams.topMargin = dimen;
                marginLayoutParams.bottomMargin = dimen2;
                if (margins.fitRtl) {
                    marginLayoutParams.setMarginStart(dimen3);
                    marginLayoutParams.setMarginEnd(i2);
                } else {
                    marginLayoutParams.leftMargin = dimen3;
                    marginLayoutParams.rightMargin = i2;
                }
                view.requestLayout();
                m.i(TAG, "onMarginChanged(), [config-changed] view:" + view);
            }
            return;
        }
        dimen = getDimen(resources, margins.edge);
        i2 = dimen;
        dimen2 = i2;
        dimen3 = dimen2;
        layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return;
        }
        marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        if (marginLayoutParams.topMargin == dimen) {
            if (margins.fitRtl) {
                if (marginLayoutParams.getMarginStart() == dimen3) {
                    return;
                }
            } else if (marginLayoutParams.leftMargin == dimen3) {
                return;
            }
        }
        marginLayoutParams.topMargin = dimen;
        marginLayoutParams.bottomMargin = dimen2;
        if (margins.fitRtl) {
            marginLayoutParams.setMarginStart(dimen3);
            marginLayoutParams.setMarginEnd(i2);
        } else {
            marginLayoutParams.leftMargin = dimen3;
            marginLayoutParams.rightMargin = i2;
        }
        view.requestLayout();
        m.i(TAG, "onMarginChanged(), [config-changed] view:" + view);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void onPaddingChanged(View view, BaseViewAttr baseViewAttr) {
        Resources resources = view.getResources();
        ParserUtil.EdgeParam paddings = baseViewAttr.getPaddings();
        if (paddings.useEdge && ParserUtil.isValidResId(paddings.edge)) {
            int dimen = getDimen(resources, paddings.edge);
            view.setPadding(dimen, dimen, dimen, dimen);
            return;
        }
        if (isValidResId(paddings.left, paddings.right, paddings.top, paddings.bottom, paddings.start, paddings.end)) {
            int paddingTop = view.getPaddingTop();
            if (isValidResId(paddings.top)) {
                paddingTop = getDimen(resources, paddings.top);
            }
            int paddingBottom = view.getPaddingBottom();
            if (isValidResId(paddings.bottom)) {
                paddingBottom = getDimen(resources, paddings.bottom);
            }
            int paddingStart = view.getPaddingStart();
            if (isValidResId(paddings.start)) {
                paddingStart = getDimen(resources, paddings.start);
            }
            int paddingEnd = view.getPaddingEnd();
            if (isValidResId(paddings.end)) {
                paddingEnd = getDimen(resources, paddings.end);
            }
            if (paddings.fitRtl) {
                view.setPaddingRelative(paddingStart, paddingTop, paddingEnd, paddingBottom);
            } else {
                view.setPadding(paddingStart, paddingTop, paddingEnd, paddingBottom);
            }
            m.i(TAG, "onPaddingChanged(), [config-changed] view:" + view);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void onSizeChanged(View view, BaseViewAttr baseViewAttr) {
        Resources resources = view.getResources();
        if (isValidResId(baseViewAttr.getWidth(), baseViewAttr.getHeight())) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams != null) {
                if (baseViewAttr.getWidth() != 0) {
                    int dimen = getDimen(resources, baseViewAttr.getWidth());
                    if (baseViewAttr.isFitSymbol()) {
                        dimen = getSizeByFontLimit(view.getContext(), dimen, baseViewAttr.getFontLimit());
                    }
                    layoutParams.width = dimen;
                }
                if (baseViewAttr.getHeight() != 0) {
                    int dimen2 = getDimen(resources, baseViewAttr.getHeight());
                    if (baseViewAttr.isFitSymbol()) {
                        dimen2 = getSizeByFontLimit(view.getContext(), dimen2, baseViewAttr.getFontLimit());
                    }
                    layoutParams.height = dimen2;
                }
            }
            view.setMinimumWidth(getDimen(resources, baseViewAttr.getMinWidth()));
            view.setMinimumHeight(getDimen(resources, baseViewAttr.getMinHeight()));
            view.requestLayout();
            m.i(TAG, "onSizeChanged(), [config-changed] view:" + view);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static void onTextColorChanged(TextView textView, BaseViewAttr baseViewAttr) {
        if (baseViewAttr instanceof TextViewAttr) {
            TextViewAttr textViewAttr = (TextViewAttr) baseViewAttr;
            Resources resources = textView.getResources();
            if (ViewAttrConstant.isGlobalTheme && ParserUtil.isValidResId(textViewAttr.getGlobalTextColor())) {
                textView.setTextColor(resources.getColor(textViewAttr.getGlobalTextColor()));
                m.i(TAG, "onTextColorChanged(), global [config-changed] view:" + textView);
            } else if (ParserUtil.isValidResId(textViewAttr.getTextColor())) {
                textView.setTextColor(resources.getColor(textViewAttr.getTextColor()));
                m.i(TAG, "onTextColorChanged(), [config-changed] view:" + textView);
            }
            if ((textView instanceof VThemeIconUtils.ISystemColorRom14) && s.i() && VThemeIconUtils.n()) {
                VThemeIconUtils.E(textView.getContext(), VThemeIconUtils.n(), (VThemeIconUtils.ISystemColorRom14) textView);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void onTextSizeChanged(TextView textView, BaseViewAttr baseViewAttr) {
        if (baseViewAttr instanceof TextViewAttr) {
            TextViewAttr textViewAttr = (TextViewAttr) baseViewAttr;
            Resources resources = textView.getResources();
            if (ParserUtil.isValidResId(textViewAttr.getTextSize())) {
                textView.setTextSize(0, resources.getDimensionPixelSize(textViewAttr.getTextSize()));
                m.i(TAG, "onTextSizeChanged(), [config-changed] view:" + textView);
            }
        }
    }

    private void parserImageViewAttr(View view, TypedArray typedArray, BaseViewAttr baseViewAttr) {
        if ((view instanceof ImageView) && (baseViewAttr instanceof ImageViewAttr)) {
            int resourceId = typedArray.getResourceId(R.styleable.ViewAttr_android_src, 0);
            if (ParserUtil.isValidResId(resourceId)) {
                ImageViewAttr imageViewAttr = (ImageViewAttr) baseViewAttr;
                if (imageViewAttr.getSrc() == 0) {
                    imageViewAttr.setSrc(resourceId);
                }
            }
        }
    }

    private void parserTextViewAttr(View view, TypedArray typedArray, BaseViewAttr baseViewAttr) {
        if ((view instanceof TextView) && (baseViewAttr instanceof TextViewAttr)) {
            int resourceId = typedArray.getResourceId(R.styleable.ViewAttr_android_textColor, 0);
            if (ParserUtil.isValidResId(resourceId)) {
                TextViewAttr textViewAttr = (TextViewAttr) baseViewAttr;
                if (textViewAttr.getTextColor() == 0) {
                    textViewAttr.setTextColor(resourceId);
                }
            }
            int resourceId2 = typedArray.getResourceId(R.styleable.ViewAttr_android_textSize, 0);
            if (ParserUtil.isValidResId(resourceId2)) {
                TextViewAttr textViewAttr2 = (TextViewAttr) baseViewAttr;
                if (textViewAttr2.getTextSize() == 0) {
                    textViewAttr2.setTextSize(resourceId2);
                }
            }
        }
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public int[] getStyleableAttr() {
        return R.styleable.ViewAttr;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public void parserAttrIds(View view, TypedArray typedArray, ResourcesBridge resourcesBridge) {
        BaseViewAttr baseViewAttr = ParserUtil.getBaseViewAttr(view);
        if (baseViewAttr == null) {
            return;
        }
        int resourceId = typedArray.getResourceId(R.styleable.ViewAttr_android_background, 0);
        if (ParserUtil.isValidResId(resourceId) && baseViewAttr.getBackground() == 0) {
            baseViewAttr.setBackground(resourceId);
        }
        parserTextViewAttr(view, typedArray, baseViewAttr);
        parserImageViewAttr(view, typedArray, baseViewAttr);
    }

    public static void onConfigurationChanged(final View view, boolean z2, boolean z3) {
        final BaseViewAttr baseViewAttr = ParserUtil.getBaseViewAttr(view);
        if (baseViewAttr == null) {
            return;
        }
        String screenInfo = BaseViewAttr.Config.getScreenInfo(view);
        if (z3 && !Objects.equals(screenInfo, baseViewAttr.getConfig().getScreen())) {
            if (ViewAttrConstant.isActive(baseViewAttr.getSizeActiveMode())) {
                view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.1
                    @Override // java.lang.Runnable
                    public void run() {
                        ConfigAttrParser.onSizeChanged(view, baseViewAttr);
                    }
                });
            }
            if (ViewAttrConstant.isActive(baseViewAttr.getPaddingActiveMode())) {
                view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.2
                    @Override // java.lang.Runnable
                    public void run() {
                        ConfigAttrParser.onPaddingChanged(view, baseViewAttr);
                    }
                });
            }
            if (ViewAttrConstant.isActive(baseViewAttr.getMarginActiveMode())) {
                view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.3
                    @Override // java.lang.Runnable
                    public void run() {
                        ConfigAttrParser.onMarginChanged(view, baseViewAttr);
                    }
                });
            }
            if ((baseViewAttr instanceof TextViewAttr) && (view instanceof TextView) && ViewAttrConstant.isActive(((TextViewAttr) baseViewAttr).getTextSizeActiveMode())) {
                view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.4
                    @Override // java.lang.Runnable
                    public void run() {
                        ConfigAttrParser.onTextSizeChanged((TextView) view, baseViewAttr);
                    }
                });
            }
            baseViewAttr.getConfig().setScreen(screenInfo);
        }
        String uiModeInfo = BaseViewAttr.Config.getUiModeInfo(view);
        if (!z2 || Objects.equals(uiModeInfo, baseViewAttr.getConfig().getUiMode())) {
            return;
        }
        if (ViewAttrConstant.isActive(baseViewAttr.getBackgroundActiveMode())) {
            view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.5
                @Override // java.lang.Runnable
                public void run() {
                    ConfigAttrParser.onBackgroundChanged(view, baseViewAttr);
                }
            });
        }
        if (view instanceof TextView) {
            if ((baseViewAttr instanceof TextViewAttr) && ViewAttrConstant.isActive(((TextViewAttr) baseViewAttr).getTextColorActiveMode())) {
                view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.6
                    @Override // java.lang.Runnable
                    public void run() {
                        ConfigAttrParser.onTextColorChanged((TextView) view, baseViewAttr);
                    }
                });
            }
        } else if ((view instanceof ImageView) && (baseViewAttr instanceof ImageViewAttr) && ViewAttrConstant.isActive(((ImageViewAttr) baseViewAttr).getSrcActiveMode())) {
            view.post(new Runnable() { // from class: com.originui.resmap.attr.ConfigAttrParser.7
                @Override // java.lang.Runnable
                public void run() {
                    ConfigAttrParser.onImageViewChanged((ImageView) view, baseViewAttr);
                }
            });
        }
        baseViewAttr.getConfig().setUiMode(uiModeInfo);
    }
}
