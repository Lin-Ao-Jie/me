package com.originui.resmap.attr;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ImageViewAttr extends BaseViewAttr {
    private int src;
    private int srcActiveMode = 31;

    public int getSrc() {
        return this.src;
    }

    public int getSrcActiveMode() {
        return this.srcActiveMode;
    }

    public void setSrc(int i2) {
        this.src = i2;
    }

    public void setSrcActiveMode(int i2) {
        this.srcActiveMode = i2;
    }
}
