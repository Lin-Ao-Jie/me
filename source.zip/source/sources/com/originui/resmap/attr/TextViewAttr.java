package com.originui.resmap.attr;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class TextViewAttr extends BaseViewAttr {
    private int globalTextColor;
    private int textColor;
    private int textSize;
    private int textSizeActiveMode = 31;
    private int textColorActiveMode = 31;

    public int getGlobalTextColor() {
        return this.globalTextColor;
    }

    public int getTextColor() {
        return this.textColor;
    }

    public int getTextColorActiveMode() {
        return this.textColorActiveMode;
    }

    public int getTextSize() {
        return this.textSize;
    }

    public int getTextSizeActiveMode() {
        return this.textSizeActiveMode;
    }

    public void setGlobalTextColor(int i2) {
        this.globalTextColor = i2;
    }

    public void setTextColor(int i2) {
        this.textColor = i2;
    }

    public void setTextColorActiveMode(int i2) {
        this.textColorActiveMode = i2;
    }

    public void setTextSize(int i2) {
        this.textSize = i2;
    }

    public void setTextSizeActiveMode(int i2) {
        this.textSizeActiveMode = i2;
    }
}
