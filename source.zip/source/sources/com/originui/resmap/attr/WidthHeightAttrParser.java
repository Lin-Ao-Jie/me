package com.originui.resmap.attr;

import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import com.originui.resmap.R;
import com.originui.resmap.bridge.ResourcesBridge;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class WidthHeightAttrParser implements BaseAttrParser<View> {
    int height;
    int minHeight;
    int minWidth;
    int width;

    private boolean doNewAttrs(View view, ResourcesBridge resourcesBridge) {
        ViewGroup.LayoutParams layoutParams;
        ParserUtil.MapVal mapVal = new ParserUtil.MapVal(resourcesBridge, this.width);
        ParserUtil.MapVal mapVal2 = new ParserUtil.MapVal(resourcesBridge, this.height);
        ParserUtil.MapVal mapVal3 = new ParserUtil.MapVal(resourcesBridge, this.minWidth);
        ParserUtil.MapVal mapVal4 = new ParserUtil.MapVal(resourcesBridge, this.minHeight);
        if (mapVal4.changed()) {
            view.setMinimumHeight(mapVal4.getMapDimen());
        }
        if (mapVal3.changed()) {
            view.setMinimumWidth(mapVal3.getMapDimen());
        }
        if ((!mapVal.changed() && !mapVal2.changed()) || (layoutParams = view.getLayoutParams()) == null) {
            return false;
        }
        layoutParams.width = mapVal.getMapDimen();
        layoutParams.height = mapVal2.getMapDimen();
        return true;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public int[] getStyleableAttr() {
        return R.styleable.LayoutAttr;
    }

    @Override // com.originui.resmap.attr.BaseAttrParser
    public void parserAttrIds(View view, TypedArray typedArray, ResourcesBridge resourcesBridge) {
        this.width = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_width, 0);
        this.height = typedArray.getResourceId(R.styleable.LayoutAttr_android_layout_height, 0);
        this.minWidth = typedArray.getResourceId(R.styleable.LayoutAttr_android_minWidth, 0);
        this.minHeight = typedArray.getResourceId(R.styleable.LayoutAttr_android_minHeight, 0);
        if (doNewAttrs(view, resourcesBridge)) {
            view.requestLayout();
        }
        BaseViewAttr baseViewAttr = ParserUtil.getBaseViewAttr(view);
        if (baseViewAttr != null) {
            baseViewAttr.setWidth(this.width);
            baseViewAttr.setHeight(this.height);
            baseViewAttr.setMinWidth(this.minWidth);
            baseViewAttr.setMinHeight(this.minHeight);
        }
    }
}
