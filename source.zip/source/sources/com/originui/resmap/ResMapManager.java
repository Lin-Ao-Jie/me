package com.originui.resmap;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.h;
import com.originui.core.utils.m;
import com.originui.resmap.attr.BaseAttrParser;
import com.originui.resmap.bridge.ContextBridge;
import com.originui.resmap.bridge.ResourcesBridge;
import com.originui.resmap.bridge.TypedArrayBridge;
import com.originui.resmap.map.DeviceResMap;
import com.originui.resmap.map.RomVersionResMap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ResMapManager {
    private static final String TAG = "vresmap_6.0.0.7";
    private static boolean sFitClassLoad;
    private static boolean sFitCustom;

    public static ContextBridge byDeviceType(Context context) {
        return new ContextBridge(context).setResourceHelper(DeviceResMap.get(context));
    }

    public static ContextBridge byRealRomVer(Context context) {
        return new ContextBridge(context).setResourceHelper(RomVersionResMap.getRealVer());
    }

    public static ContextBridge byRomVer(Context context) {
        return byRomVer(context, false);
    }

    private static void doLayoutAttrParser(View view, AttributeSet attributeSet, int i2, int i3) {
        if (view == null) {
            return;
        }
        int i4 = R.id.tag_origin_res_map_parser;
        if (view.getTag(i4) == null && (view.getContext().getResources() instanceof ResourcesBridge)) {
            view.setTag(i4, Boolean.TRUE);
            AttrParserFactory.get().doParser(view, attributeSet, i2, i3);
            m.b("vresmap_6.0.0.7", "doLayoutAttrParser(), View:" + view);
        }
    }

    public static ContextBridge from(Context context) {
        return new ContextBridge(context);
    }

    public static boolean isFitClassLoad() {
        return sFitClassLoad;
    }

    public static boolean isFitCustom() {
        return sFitCustom;
    }

    public static TypedArray obtainTypedArray(View view, AttributeSet attributeSet, int[] iArr, int i2, int i3) {
        Context context = view.getContext();
        return obtainTypedArray(context, context.obtainStyledAttributes(attributeSet, iArr, i2, i3));
    }

    public static void parseAttr(View view, AttributeSet attributeSet, int i2, int i3) {
        doLayoutAttrParser(view, attributeSet, i2, i3);
    }

    public static void registerParser(Class<? extends View> cls, Class<? extends BaseAttrParser<View>> cls2) {
        AttrParserFactory.get().registerParser(cls, cls2);
    }

    public static void setFitClassLoad(boolean z2) {
        sFitClassLoad = z2;
    }

    public static void setFitCustom(boolean z2) {
        sFitCustom = z2;
    }

    public static ContextBridge byRomVer(Context context, boolean z2) {
        ContextBridge resourceHelper = context.getApplicationContext() != null ? new ContextBridge(context).setResourceHelper(RomVersionResMap.get(context.getApplicationContext())) : new ContextBridge(context).setResourceHelper(RomVersionResMap.get(context));
        ((ResourcesBridge) resourceHelper.getResources()).setDemesticPattern(z2);
        return resourceHelper;
    }

    public static TypedArray obtainTypedArray(Context context, AttributeSet attributeSet, int[] iArr, int i2, int i3) {
        return obtainTypedArray(context, context.obtainStyledAttributes(attributeSet, iArr, i2, i3));
    }

    public static TypedArray obtainTypedArray(Context context, TypedArray typedArray) {
        try {
            return ((context instanceof ContextBridge) && h.k()) ? new TypedArrayBridge((ContextBridge) context, typedArray, context.getResources()) : typedArray;
        } catch (Throwable th) {
            m.g("vresmap_6.0.0.7", "obtainTypedArray()", th);
            return typedArray;
        }
    }
}
