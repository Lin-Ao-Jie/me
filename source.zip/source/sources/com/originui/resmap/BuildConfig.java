package com.originui.resmap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class BuildConfig {
    public static final String AAR_NAME = "vresmap";
    public static final String AAR_VERSION = "6.0.0.7";
    public static final String BUILD_TIME = "周四 下午 2025-10-16 16:14:26.164 CST +0800";
    public static final String BUILD_TYPE = "debug";
    public static final int CUR_MODEL = 100;
    public static final int CUR_VMODEL = 100;
    public static final boolean DEBUG = true;
    public static final String FLAVOR = "demesticAndroid_36";
    public static final String FLAVOR_area = "demestic";
    public static final String FLAVOR_platform = "android_36";
    public static final String LIBRARY_PACKAGE_NAME = "com.originui.resmap";
    public static final String LOG_TAG = "vresmap_6.0.0.7";
    public static final int MODEL1 = 1;
    public static final int MODEL2 = 2;
    public static final int MODEL3 = 3;
    public static final int MODEL4 = 4;
    public static final int MODEL5 = 5;
    public static final String TAG_FLAVORS = "Demestic";
    public static final int TARGET_SDK = 36;
    public static final int VMODEL0_1 = 1;
    public static final int VMODEL1 = 10;
    public static final int VMODEL2 = 20;
    public static final int VMODEL3 = 30;
    public static final int VMODEL4 = 40;
    public static final int VMODEL5 = 50;
}
