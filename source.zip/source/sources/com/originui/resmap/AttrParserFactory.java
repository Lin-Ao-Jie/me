package com.originui.resmap;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.m;
import com.originui.resmap.attr.BaseAttrParser;
import com.originui.resmap.attr.ConfigAttrParser;
import com.originui.resmap.attr.MarginAttrParser;
import com.originui.resmap.attr.PaddingAttrParser;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.WidthHeightAttrParser;
import com.originui.resmap.bridge.ResourcesBridge;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
class AttrParserFactory {
    private static final String TAG = "AttrParserFactory";
    private static volatile AttrParserFactory instance;
    private final Map<Class<? extends View>, List<Class<? extends BaseAttrParser<View>>>> parserMap = new HashMap();

    private AttrParserFactory() {
        registerParser(View.class, ConfigAttrParser.class);
        registerParser(View.class, WidthHeightAttrParser.class);
        registerParser(View.class, PaddingAttrParser.class);
        registerParser(View.class, MarginAttrParser.class);
    }

    private void addParserMap(Map<Class<? extends View>, List<Class<? extends BaseAttrParser<View>>>> map, Class<? extends View> cls, Class<? extends BaseAttrParser<View>> cls2) {
        List<Class<? extends BaseAttrParser<View>>> arrayList = map.get(cls);
        if (arrayList == null) {
            arrayList = new ArrayList<>();
            map.put(cls, arrayList);
        }
        arrayList.add(cls2);
    }

    private void doParserWithMap(Map<Class<? extends View>, List<Class<? extends BaseAttrParser<View>>>> map, final View view, final AttributeSet attributeSet, final int i2, final int i3, final ResourcesBridge resourcesBridge, final Context context, final Class<? extends View> cls) {
        ParserUtil.forEach(map, new ParserUtil.MapEach<Class<? extends View>, List<Class<? extends BaseAttrParser<View>>>>() { // from class: com.originui.resmap.AttrParserFactory.1
            @Override // com.originui.resmap.attr.ParserUtil.MapEach
            public boolean accept(Class<? extends View> cls2, List<Class<? extends BaseAttrParser<View>>> list) {
                if (!cls2.isAssignableFrom(cls)) {
                    return false;
                }
                Iterator<Class<? extends BaseAttrParser<View>>> it = list.iterator();
                while (it.hasNext()) {
                    try {
                        BaseAttrParser<View> baseAttrParserNewInstance = it.next().newInstance();
                        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, baseAttrParserNewInstance.getStyleableAttr(), i2, i3);
                        baseAttrParserNewInstance.parserAttrIds(view, typedArrayObtainStyledAttributes, resourcesBridge);
                        typedArrayObtainStyledAttributes.recycle();
                    } catch (IllegalAccessException | InstantiationException e2) {
                        m.f(AttrParserFactory.TAG, "doParser(), fail:", e2);
                    }
                }
                return false;
            }
        });
    }

    static AttrParserFactory get() {
        if (instance == null) {
            synchronized (AttrParserFactory.class) {
                try {
                    if (instance == null) {
                        instance = new AttrParserFactory();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return instance;
    }

    private ResourcesBridge getResourceBridge(View view) {
        Context context = view != null ? view.getContext() : null;
        Resources resources = context != null ? context.getResources() : null;
        if (resources instanceof ResourcesBridge) {
            return (ResourcesBridge) resources;
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    void doParser(View view, AttributeSet attributeSet, int i2, int i3) {
        ResourcesBridge resourceBridge = getResourceBridge(view);
        Context context = view.getContext();
        if (resourceBridge == null) {
            return;
        }
        ParserUtil.getOrCreateViewAttr(view);
        doParserWithMap(this.parserMap, view, attributeSet, i2, i3, resourceBridge, context, view.getClass());
    }

    void registerParser(Class<? extends View> cls, Class<? extends BaseAttrParser<View>> cls2) {
        synchronized (this.parserMap) {
            addParserMap(this.parserMap, cls, cls2);
        }
    }
}
