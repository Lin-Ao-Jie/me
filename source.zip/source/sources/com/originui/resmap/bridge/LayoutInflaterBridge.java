package com.originui.resmap.bridge;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import com.originui.resmap.ResMapManager;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class LayoutInflaterBridge extends LayoutInflater {
    private static final String[] CLASS_PREFIX_LIST = {"android.widget.", "android.webkit.", "android.app."};
    private final FactoryBox factoryBox;
    private LayoutInflater mOriginalLayoutInflater;

    protected LayoutInflaterBridge(Context context) {
        super(context);
        FactoryBox factoryBox = new FactoryBox(this);
        this.factoryBox = factoryBox;
        super.setFactory2(factoryBox);
    }

    static void doLayoutAttrParser(View view, AttributeSet attributeSet) {
        ResMapManager.parseAttr(view, attributeSet, 0, 0);
    }

    static LayoutInflater from(LayoutInflater layoutInflater, Context context) {
        return new LayoutInflaterBridge(layoutInflater, context);
    }

    @Override // android.view.LayoutInflater
    public LayoutInflater cloneInContext(Context context) {
        return ResMapManager.isFitCustom() ? new LayoutInflaterBridge(this, context) : new LayoutInflaterBridge(context);
    }

    View createViewWithPrefix(String str, AttributeSet attributeSet) {
        if (-1 == str.indexOf(46)) {
            return null;
        }
        try {
            return createView(str, null, attributeSet);
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }

    @Override // android.view.LayoutInflater
    protected View onCreateView(String str, AttributeSet attributeSet) throws ClassNotFoundException {
        for (String str2 : CLASS_PREFIX_LIST) {
            try {
                LayoutInflater layoutInflater = this.mOriginalLayoutInflater;
                if (layoutInflater != null) {
                    layoutInflater.createView(str, str2, attributeSet);
                }
                View viewCreateView = createView(str, str2, attributeSet);
                if (viewCreateView != null) {
                    doLayoutAttrParser(viewCreateView, attributeSet);
                    return viewCreateView;
                }
                continue;
            } catch (ClassNotFoundException unused) {
            }
        }
        return super.onCreateView(str, attributeSet);
    }

    @Override // android.view.LayoutInflater
    public void setFactory2(LayoutInflater.Factory2 factory2) {
        LayoutInflater layoutInflater = this.mOriginalLayoutInflater;
        if (layoutInflater != null) {
            layoutInflater.setFactory2(factory2);
        }
        LayoutInflater.Factory2 factory3 = getFactory2();
        if (factory3 instanceof FactoryBox) {
            if (((FactoryBox) factory3).setFactoryMain(factory2)) {
                return;
            }
        } else if (this.factoryBox.setFactoryMain(factory2)) {
            return;
        }
        super.setFactory2(factory2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class FactoryBox implements LayoutInflater.Factory2 {
        private LayoutInflater.Factory2 factoryMain;
        private final LayoutInflaterBridge inflater;

        public FactoryBox(LayoutInflaterBridge layoutInflaterBridge) {
            this.inflater = layoutInflaterBridge;
            this.factoryMain = layoutInflaterBridge.getFactory2();
        }

        @Override // android.view.LayoutInflater.Factory2
        public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
            LayoutInflater.Factory2 factory2 = this.factoryMain;
            View viewOnCreateView = factory2 != null ? factory2.onCreateView(view, str, context, attributeSet) : null;
            if (viewOnCreateView == null) {
                viewOnCreateView = this.inflater.createViewWithPrefix(str, attributeSet);
            }
            LayoutInflaterBridge.doLayoutAttrParser(viewOnCreateView, attributeSet);
            return viewOnCreateView;
        }

        boolean setFactoryMain(LayoutInflater.Factory2 factory2) {
            boolean z2 = this.factoryMain == null;
            if (z2) {
                this.factoryMain = factory2;
            }
            return z2;
        }

        @Override // android.view.LayoutInflater.Factory
        public View onCreateView(String str, Context context, AttributeSet attributeSet) {
            LayoutInflater.Factory2 factory2 = this.factoryMain;
            View viewOnCreateView = factory2 != null ? factory2.onCreateView(str, context, attributeSet) : null;
            if (viewOnCreateView == null) {
                viewOnCreateView = this.inflater.createViewWithPrefix(str, attributeSet);
            }
            LayoutInflaterBridge.doLayoutAttrParser(viewOnCreateView, attributeSet);
            return viewOnCreateView;
        }
    }

    protected LayoutInflaterBridge(LayoutInflater layoutInflater, Context context) {
        super(layoutInflater, context);
        FactoryBox factoryBox = new FactoryBox(this);
        this.factoryBox = factoryBox;
        if (ResMapManager.isFitCustom()) {
            factoryBox.setFactoryMain(layoutInflater.getFactory2());
        }
        super.setFactory2(factoryBox);
        if (ResMapManager.isFitCustom()) {
            this.mOriginalLayoutInflater = layoutInflater;
        }
    }

    @Override // android.view.LayoutInflater
    protected View onCreateView(View view, String str, AttributeSet attributeSet) throws ClassNotFoundException {
        if (this.mOriginalLayoutInflater != null) {
            for (String str2 : CLASS_PREFIX_LIST) {
                try {
                    View viewCreateView = this.mOriginalLayoutInflater.createView(str, str2, attributeSet);
                    if (viewCreateView != null) {
                        return viewCreateView;
                    }
                } catch (ClassNotFoundException unused) {
                }
            }
        }
        View viewOnCreateView = super.onCreateView(view, str, attributeSet);
        doLayoutAttrParser(viewOnCreateView, attributeSet);
        return viewOnCreateView;
    }
}
