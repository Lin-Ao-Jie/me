package com.originui.resmap.bridge;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import com.originui.core.utils.m;
import com.originui.resmap.ResMapManager;
import com.originui.resmap.map.MapInterface;
import java.io.InputStream;
import java.lang.reflect.Field;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ResourcesBridge extends Resources {
    static final String TAG = "ResourcesBridge";
    private static Field mResourcesImplField;
    private final Resources mBase;
    private boolean mIsDemesticPattern;
    private MapInterface mapHelper;

    public ResourcesBridge(Resources resources, Context context) {
        super(context.getClassLoader());
        this.mapHelper = ContextBridge.EmptyResHelper.INSTANCE;
        this.mBase = resources;
        checkImpl();
    }

    static ResourcesBridge from(Resources resources, Context context) {
        try {
            return ResMapManager.isFitClassLoad() ? new ResourcesBridge(resources, context) : new ResourcesBridge(resources);
        } catch (Exception | NoSuchMethodError e2) {
            m.g(TAG, "ResourcesBridge init error:", e2);
            return new ResourcesBridge(resources, true);
        }
    }

    void checkImpl() {
        try {
            if (mResourcesImplField == null) {
                Field declaredField = Resources.class.getDeclaredField("mResourcesImpl");
                mResourcesImplField = declaredField;
                declaredField.setAccessible(true);
            }
            Object obj = mResourcesImplField.get(this.mBase);
            if (obj != mResourcesImplField.get(this)) {
                mResourcesImplField.set(this, obj);
                m.b(TAG, "checkImpl(), impl changed");
            }
        } catch (Exception unused) {
        }
    }

    @Override // android.content.res.Resources
    public XmlResourceParser getAnimation(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getAnimation(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getAnimation exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getAnimation exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getAnimation(i2);
            }
        } catch (Exception unused2) {
            return getBase().getAnimation(i2);
        }
    }

    Resources getBase() {
        return this.mBase;
    }

    @Override // android.content.res.Resources
    public boolean getBoolean(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getBoolean(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getBoolean exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getBoolean exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getBoolean(i2);
            }
        } catch (Exception unused2) {
            return getBase().getBoolean(i2);
        }
    }

    @Override // android.content.res.Resources
    public int getColor(int i2, Resources.Theme theme) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getColor(getMapId(i2), theme);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getColor exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getColor exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getColor(i2, theme);
            }
        } catch (Exception unused2) {
            return getBase().getColor(i2, theme);
        }
    }

    @Override // android.content.res.Resources
    public ColorStateList getColorStateList(int i2, Resources.Theme theme) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getColorStateList(getMapId(i2), theme);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getColorStateList exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getColorStateList exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getColorStateList(i2, theme);
            }
        } catch (Exception unused2) {
            return getBase().getColorStateList(i2, theme);
        }
    }

    @Override // android.content.res.Resources
    public Configuration getConfiguration() {
        return getBase().getConfiguration();
    }

    @Override // android.content.res.Resources
    public float getDimension(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getDimension(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getDimension exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getDimension exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getDimension(i2);
            }
        } catch (Exception unused2) {
            return getBase().getDimension(i2);
        }
    }

    @Override // android.content.res.Resources
    public int getDimensionPixelOffset(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getDimensionPixelOffset(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getDimensionPixelOffset exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getDimensionPixelOffset exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getDimensionPixelOffset(i2);
            }
        } catch (Exception unused2) {
            return getBase().getDimensionPixelOffset(i2);
        }
    }

    @Override // android.content.res.Resources
    public int getDimensionPixelSize(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getDimensionPixelSize(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getDimensionPixelSize exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getDimensionPixelSize exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getDimensionPixelSize(i2);
            }
        } catch (Exception unused2) {
            return getBase().getDimensionPixelSize(i2);
        }
    }

    @Override // android.content.res.Resources
    public Drawable getDrawableForDensity(int i2, int i3, Resources.Theme theme) {
        try {
            try {
                return getBase().getDrawableForDensity(getMapId(i2), i3, theme);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getDrawableForDensity exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getDrawableForDensity exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getDrawableForDensity(i2, i3, theme);
            }
        } catch (Exception unused2) {
            return getBase().getDrawableForDensity(i2, i3, theme);
        }
    }

    @Override // android.content.res.Resources
    public float getFloat(int i2) {
        try {
            try {
                return getBase().getFloat(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getFloat exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getFloat exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getFloat(i2);
            }
        } catch (Exception unused2) {
            return getBase().getFloat(i2);
        }
    }

    @Override // android.content.res.Resources
    public Typeface getFont(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getFont(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getFont exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getFont exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getFont(i2);
            }
        } catch (Exception unused2) {
            return getBase().getFont(i2);
        }
    }

    @Override // android.content.res.Resources
    public int[] getIntArray(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getIntArray(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getIntArray exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getIntArray exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getIntArray(i2);
            }
        } catch (Exception unused2) {
            return getBase().getIntArray(i2);
        }
    }

    @Override // android.content.res.Resources
    public int getInteger(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getInteger(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getInteger exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getInteger exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getInteger(i2);
            }
        } catch (Exception unused2) {
            return getBase().getInteger(i2);
        }
    }

    @Override // android.content.res.Resources
    public XmlResourceParser getLayout(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getLayout(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getLayout exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getLayout exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getLayout(i2);
            }
        } catch (Exception unused2) {
            return getBase().getLayout(i2);
        }
    }

    int getMapId(int i2) {
        this.mapHelper.setDemesticPattern(this.mIsDemesticPattern);
        int mapId = this.mapHelper.getMapId(this.mBase, i2);
        if (mapId != i2 && m.f583b) {
            m.b(TAG, "getMapId(), origin:" + this.mBase.getResourceName(i2) + ",  dest:" + this.mBase.getResourceName(mapId));
        }
        return mapId;
    }

    @Override // android.content.res.Resources
    public String getQuantityString(int i2, int i3, Object... objArr) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getQuantityString(getMapId(i2), i3, objArr);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getQuantityString formatArgs exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getQuantityString formatArgs exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getQuantityString(i2, i3, objArr);
            }
        } catch (Exception unused2) {
            return getBase().getQuantityString(i2, i3, objArr);
        }
    }

    @Override // android.content.res.Resources
    public CharSequence getQuantityText(int i2, int i3) throws Resources.NotFoundException {
        return getBase().getQuantityText(i2, i3);
    }

    @Override // android.content.res.Resources
    public String getResourceName(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getResourceName(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getResourceName exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getResourceName exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getResourceName(i2);
            }
        } catch (Exception unused2) {
            return getBase().getResourceName(i2);
        }
    }

    @Override // android.content.res.Resources
    public String getString(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getString(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getString exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getString exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getString(i2);
            }
        } catch (Exception unused2) {
            return getBase().getString(i2);
        }
    }

    @Override // android.content.res.Resources
    public String[] getStringArray(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getStringArray(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getStringArray exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getStringArray exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getStringArray(i2);
            }
        } catch (Exception unused2) {
            return getBase().getStringArray(i2);
        }
    }

    @Override // android.content.res.Resources
    public CharSequence getText(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getText(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getText exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getText exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getText(i2);
            }
        } catch (Exception unused2) {
            return getBase().getText(i2);
        }
    }

    @Override // android.content.res.Resources
    public CharSequence[] getTextArray(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getTextArray(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getTextArray exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getTextArray exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getTextArray(i2);
            }
        } catch (Exception unused2) {
            return getBase().getTextArray(i2);
        }
    }

    @Override // android.content.res.Resources
    public void getValue(int i2, TypedValue typedValue, boolean z2) throws Resources.NotFoundException {
        getBase().getValue(i2, typedValue, z2);
    }

    @Override // android.content.res.Resources
    public void getValueForDensity(int i2, int i3, TypedValue typedValue, boolean z2) throws Resources.NotFoundException {
        getBase().getValueForDensity(i2, i3, typedValue, z2);
    }

    @Override // android.content.res.Resources
    public XmlResourceParser getXml(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getXml(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " getXml exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getXml exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getXml(i2);
            }
        } catch (Exception unused2) {
            return getBase().getXml(i2);
        }
    }

    public boolean hasMapId(int i2) {
        return getMapId(i2) != i2;
    }

    public void loadIsolateResourceXml(int i2) {
        this.mapHelper.loadIsolateResourceXml(this, i2);
    }

    @Override // android.content.res.Resources
    public TypedArray obtainTypedArray(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().obtainTypedArray(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " obtainTypedArray exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " obtainTypedArray exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().obtainTypedArray(i2);
            }
        } catch (Exception unused2) {
            return getBase().obtainTypedArray(i2);
        }
    }

    @Override // android.content.res.Resources
    public InputStream openRawResource(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().openRawResource(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " openRawResource exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " openRawResource exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().openRawResource(i2);
            }
        } catch (Exception unused2) {
            return getBase().openRawResource(i2);
        }
    }

    @Override // android.content.res.Resources
    public AssetFileDescriptor openRawResourceFd(int i2) throws Resources.NotFoundException {
        try {
            try {
                return getBase().openRawResourceFd(getMapId(i2));
            } catch (Exception unused) {
                m.i(TAG, i2 + " openRawResourceFd value exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " openRawResourceFd value exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().openRawResourceFd(i2);
            }
        } catch (Exception unused2) {
            return getBase().openRawResourceFd(i2);
        }
    }

    ResourcesBridge resMapHelper(MapInterface mapInterface) {
        if (mapInterface == null) {
            mapInterface = ContextBridge.EmptyResHelper.INSTANCE;
        }
        this.mapHelper = mapInterface;
        return this;
    }

    public void setDemesticPattern(boolean z2) {
        this.mIsDemesticPattern = z2;
        this.mapHelper.setDemesticPattern(z2);
    }

    @Override // android.content.res.Resources
    public void getValue(String str, TypedValue typedValue, boolean z2) throws Resources.NotFoundException {
        getBase().getValue(str, typedValue, z2);
    }

    public ResourcesBridge(Resources resources) {
        super(null);
        this.mapHelper = ContextBridge.EmptyResHelper.INSTANCE;
        this.mBase = resources;
        checkImpl();
    }

    @Override // android.content.res.Resources
    public String getQuantityString(int i2, int i3) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getQuantityString(getMapId(i2), i3);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getQuantityString exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getQuantityString exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getQuantityString(i2, i3);
            }
        } catch (Exception unused2) {
            return getBase().getQuantityString(i2, i3);
        }
    }

    @Override // android.content.res.Resources
    public String getString(int i2, Object... objArr) throws Resources.NotFoundException {
        try {
            try {
                return getBase().getString(getMapId(i2), objArr);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getString formatArgs exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getString formatArgs exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getString(i2, objArr);
            }
        } catch (Exception unused2) {
            return getBase().getString(i2, objArr);
        }
    }

    @Override // android.content.res.Resources
    public CharSequence getText(int i2, CharSequence charSequence) {
        try {
            try {
                return getBase().getText(getMapId(i2), charSequence);
            } catch (Exception unused) {
                m.i(TAG, i2 + " getText exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " getText exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().getText(i2, charSequence);
            }
        } catch (Exception unused2) {
            return getBase().getText(i2, charSequence);
        }
    }

    @Override // android.content.res.Resources
    public InputStream openRawResource(int i2, TypedValue typedValue) throws Resources.NotFoundException {
        try {
            try {
                return getBase().openRawResource(getMapId(i2), typedValue);
            } catch (Exception unused) {
                m.i(TAG, i2 + " openRawResource value exception:" + getResourceEntryName(i2));
                m.i(TAG, i2 + " openRawResource value exception mapID:" + getResourceEntryName(getMapId(i2)));
                return getBase().openRawResource(i2, typedValue);
            }
        } catch (Exception unused2) {
            return getBase().openRawResource(i2, typedValue);
        }
    }

    public ResourcesBridge(Resources resources, boolean z2) {
        super(resources.getAssets(), resources.getDisplayMetrics(), resources.getConfiguration());
        this.mapHelper = ContextBridge.EmptyResHelper.INSTANCE;
        this.mBase = resources;
        checkImpl();
    }
}
