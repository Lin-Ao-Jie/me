package com.originui.resmap.bridge;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.view.LayoutInflater;
import com.originui.resmap.ConfigMonitor;
import com.originui.resmap.map.MapInterface;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ContextBridge extends ContextWrapper {
    private boolean fitConfig;
    private MapInterface mResHelper;
    private ResourcesBridge resourceBridge;

    public ContextBridge(Context context) {
        super(context);
    }

    public ContextBridge fitConfig(boolean z2) {
        this.fitConfig = z2;
        if (z2) {
            ConfigMonitor.get().registerConfigChange(getBaseContext());
            return this;
        }
        ConfigMonitor.get().unregisterConfigChange(getBaseContext());
        return this;
    }

    public int getResMapId(int i2) {
        Resources resources = getResources();
        return resources instanceof ResourcesBridge ? ((ResourcesBridge) resources).getMapId(i2) : i2;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        Resources resources = super.getResources();
        ResourcesBridge resourcesBridge = this.resourceBridge;
        if (resourcesBridge == null || resourcesBridge.getBase() != resources) {
            this.resourceBridge = ResourcesBridge.from(resources, this).resMapHelper(this.mResHelper);
        } else {
            this.resourceBridge.checkImpl();
        }
        return this.resourceBridge;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Object getSystemService(String str) {
        Object systemService = getBaseContext().getSystemService(str);
        return (!(systemService instanceof LayoutInflater) || (systemService instanceof LayoutInflaterBridge)) ? systemService : LayoutInflaterBridge.from((LayoutInflater) systemService, this);
    }

    public boolean isFitConfig() {
        return this.fitConfig;
    }

    public ContextBridge loadIsolateResourceXml(int i2) {
        try {
            Resources resources = getResources();
            if (resources instanceof ResourcesBridge) {
                ((ResourcesBridge) resources).loadIsolateResourceXml(i2);
            }
        } catch (Exception unused) {
        }
        return this;
    }

    public ContextBridge setResourceHelper(MapInterface mapInterface) {
        if (mapInterface == null) {
            mapInterface = EmptyResHelper.INSTANCE;
        }
        this.mResHelper = mapInterface;
        Resources resources = getResources();
        if (resources instanceof ResourcesBridge) {
            ((ResourcesBridge) resources).resMapHelper(this.mResHelper);
        }
        return this;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class EmptyResHelper implements MapInterface {
        public static final EmptyResHelper INSTANCE = new EmptyResHelper();

        EmptyResHelper() {
        }

        @Override // com.originui.resmap.map.MapInterface
        public int getMapId(Resources resources, int i2) {
            return i2;
        }
    }
}
