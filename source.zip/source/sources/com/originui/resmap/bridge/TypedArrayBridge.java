package com.originui.resmap.bridge;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class TypedArrayBridge extends TypedArray {
    private static final int INVALID_ID = 0;
    private final ContextBridge contextBridge;
    TypedArray mBase;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static final class IndexInfo {
        private static final IndexInfo NULL = new IndexInfo(0, false);
        final boolean hasMap;
        final int id;

        private IndexInfo(int i2, boolean z2) {
            this.id = i2;
            this.hasMap = z2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static IndexInfo get(TypedArrayBridge typedArrayBridge, int i2) {
            int resourceId = typedArrayBridge.mBase.getResourceId(i2, 0);
            Resources resources = typedArrayBridge.getResources();
            if (resources instanceof ResourcesBridge) {
                return ((ResourcesBridge) resources).hasMapId(resourceId) ? new IndexInfo(resourceId, true) : NULL;
            }
            return NULL;
        }
    }

    public TypedArrayBridge(ContextBridge contextBridge, TypedArray typedArray, Resources resources) {
        super(resources);
        this.mBase = typedArray;
        this.contextBridge = contextBridge;
    }

    @Override // android.content.res.TypedArray, java.lang.AutoCloseable
    public void close() {
        this.mBase.close();
    }

    @Override // android.content.res.TypedArray
    public boolean getBoolean(int i2, boolean z2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getBoolean(indexInfo.id) : this.mBase.getBoolean(i2, z2);
    }

    @Override // android.content.res.TypedArray
    public int getChangingConfigurations() {
        return this.mBase.getChangingConfigurations();
    }

    @Override // android.content.res.TypedArray
    public int getColor(int i2, int i3) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getColor(indexInfo.id) : this.mBase.getColor(i2, i3);
    }

    @Override // android.content.res.TypedArray
    public ColorStateList getColorStateList(int i2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getColorStateList(indexInfo.id) : this.mBase.getColorStateList(i2);
    }

    @Override // android.content.res.TypedArray
    public float getDimension(int i2, float f2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getDimension(indexInfo.id) : this.mBase.getDimension(i2, f2);
    }

    @Override // android.content.res.TypedArray
    public int getDimensionPixelOffset(int i2, int i3) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getDimensionPixelOffset(indexInfo.id) : this.mBase.getDimensionPixelOffset(i2, i3);
    }

    @Override // android.content.res.TypedArray
    public int getDimensionPixelSize(int i2, int i3) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getDimensionPixelSize(indexInfo.id) : this.mBase.getDimensionPixelSize(i2, i3);
    }

    @Override // android.content.res.TypedArray
    public Drawable getDrawable(int i2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getDrawable(indexInfo.id) : this.mBase.getDrawable(i2);
    }

    @Override // android.content.res.TypedArray
    public float getFloat(int i2, float f2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getFloat(indexInfo.id) : this.mBase.getFloat(i2, f2);
    }

    @Override // android.content.res.TypedArray
    @TargetApi(26)
    public Typeface getFont(int i2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getFont(indexInfo.id) : this.mBase.getFont(i2);
    }

    @Override // android.content.res.TypedArray
    public float getFraction(int i2, int i3, int i4, float f2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getFraction(indexInfo.id, i3, i4) : this.mBase.getFraction(i2, i3, i4, f2);
    }

    @Override // android.content.res.TypedArray
    public int getIndex(int i2) {
        return this.mBase.getIndex(i2);
    }

    @Override // android.content.res.TypedArray
    public int getIndexCount() {
        return this.mBase.getIndexCount();
    }

    @Override // android.content.res.TypedArray
    public int getInt(int i2, int i3) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getInteger(indexInfo.id) : this.mBase.getInt(i2, i3);
    }

    @Override // android.content.res.TypedArray
    public int getInteger(int i2, int i3) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getInteger(indexInfo.id) : this.mBase.getInteger(i2, i3);
    }

    @Override // android.content.res.TypedArray
    public int getLayoutDimension(int i2, String str) {
        return this.mBase.getLayoutDimension(i2, str);
    }

    @Override // android.content.res.TypedArray
    public String getNonResourceString(int i2) {
        return this.mBase.getNonResourceString(i2);
    }

    @Override // android.content.res.TypedArray
    public String getPositionDescription() {
        return this.mBase.getPositionDescription();
    }

    @Override // android.content.res.TypedArray
    public int getResourceId(int i2, int i3) {
        int resourceId = this.mBase.getResourceId(i2, i3);
        Resources resources = getResources();
        return !(resources instanceof ResourcesBridge) ? resourceId : ((ResourcesBridge) resources).getMapId(resourceId);
    }

    @Override // android.content.res.TypedArray
    public Resources getResources() {
        return this.contextBridge.getResources();
    }

    @Override // android.content.res.TypedArray
    @TargetApi(29)
    public int getSourceResourceId(int i2, int i3) {
        return this.mBase.getSourceResourceId(i2, i3);
    }

    @Override // android.content.res.TypedArray
    public String getString(int i2) {
        return this.mBase.getString(i2);
    }

    @Override // android.content.res.TypedArray
    public CharSequence getText(int i2) {
        return this.mBase.getText(i2);
    }

    @Override // android.content.res.TypedArray
    public CharSequence[] getTextArray(int i2) {
        IndexInfo indexInfo = IndexInfo.get(this, i2);
        return indexInfo != IndexInfo.NULL ? getResources().getTextArray(indexInfo.id) : this.mBase.getTextArray(i2);
    }

    @Override // android.content.res.TypedArray
    public int getType(int i2) {
        return this.mBase.getType(i2);
    }

    @Override // android.content.res.TypedArray
    public boolean getValue(int i2, TypedValue typedValue) {
        return this.mBase.getValue(i2, typedValue);
    }

    @Override // android.content.res.TypedArray
    public boolean hasValue(int i2) {
        return this.mBase.hasValue(i2);
    }

    @Override // android.content.res.TypedArray
    @TargetApi(22)
    public boolean hasValueOrEmpty(int i2) {
        return this.mBase.hasValueOrEmpty(i2);
    }

    @Override // android.content.res.TypedArray
    public int length() {
        return this.mBase.length();
    }

    @Override // android.content.res.TypedArray
    public TypedValue peekValue(int i2) {
        return this.mBase.peekValue(i2);
    }

    @Override // android.content.res.TypedArray
    public void recycle() {
        this.mBase.recycle();
    }

    @Override // android.content.res.TypedArray
    public String toString() {
        return this.mBase.toString();
    }

    @Override // android.content.res.TypedArray
    public int getLayoutDimension(int i2, int i3) {
        return this.mBase.getLayoutDimension(i2, i3);
    }
}
