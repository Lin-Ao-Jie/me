package com.originui.resmap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R {

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static final class id {
        public static final int tag_origin_res_map_parser = 0x7f06005d;
        public static final int tag_origin_res_map_view_attrs = 0x7f06005e;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static final class styleable {
        public static final int LayoutAttr_android_layout_height = 0x00000006;
        public static final int LayoutAttr_android_layout_margin = 0x00000007;
        public static final int LayoutAttr_android_layout_marginBottom = 0x0000000b;
        public static final int LayoutAttr_android_layout_marginEnd = 0x00000011;
        public static final int LayoutAttr_android_layout_marginHorizontal = 0x00000012;
        public static final int LayoutAttr_android_layout_marginLeft = 0x00000008;
        public static final int LayoutAttr_android_layout_marginRight = 0x0000000a;
        public static final int LayoutAttr_android_layout_marginStart = 0x00000010;
        public static final int LayoutAttr_android_layout_marginTop = 0x00000009;
        public static final int LayoutAttr_android_layout_marginVertical = 0x00000013;
        public static final int LayoutAttr_android_layout_width = 0x00000005;
        public static final int LayoutAttr_android_minHeight = 0x0000000d;
        public static final int LayoutAttr_android_minWidth = 0x0000000c;
        public static final int LayoutAttr_android_padding = 0x00000000;
        public static final int LayoutAttr_android_paddingBottom = 0x00000004;
        public static final int LayoutAttr_android_paddingEnd = 0x0000000f;
        public static final int LayoutAttr_android_paddingLeft = 0x00000001;
        public static final int LayoutAttr_android_paddingRight = 0x00000003;
        public static final int LayoutAttr_android_paddingStart = 0x0000000e;
        public static final int LayoutAttr_android_paddingTop = 0x00000002;
        public static final int ViewAttr_android_background = 0x00000002;
        public static final int ViewAttr_android_lineSpacingExtra = 0x00000004;
        public static final int ViewAttr_android_src = 0x00000003;
        public static final int ViewAttr_android_textColor = 0x00000001;
        public static final int ViewAttr_android_textSize = 0;
        public static final int[] LayoutAttr = {android.R.attr.padding, android.R.attr.paddingLeft, android.R.attr.paddingTop, android.R.attr.paddingRight, android.R.attr.paddingBottom, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_margin, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.paddingStart, android.R.attr.paddingEnd, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, android.R.attr.layout_marginHorizontal, android.R.attr.layout_marginVertical};
        public static final int[] ViewAttr = {android.R.attr.textSize, android.R.attr.textColor, android.R.attr.background, android.R.attr.src, android.R.attr.lineSpacingExtra};
    }
}
