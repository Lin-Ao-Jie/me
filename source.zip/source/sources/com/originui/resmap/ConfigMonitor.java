package com.originui.resmap;

import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.originui.core.utils.m;
import com.originui.resmap.attr.ConfigAttrParser;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.map.DeviceResMap;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ConfigMonitor {
    private static volatile ConfigMonitor sInstance;
    private boolean mAdapterScreenInfo = true;
    private boolean mAdapterNightMode = true;
    private WeakComponentCallbacks componentCallbacks = null;

    private void applySubView(View view) {
        ConfigAttrParser.onConfigurationChanged(view, this.mAdapterNightMode, this.mAdapterScreenInfo);
    }

    private void applyViewGroup(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        applySubView(viewGroup);
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if (childAt instanceof ViewGroup) {
                applyViewGroup((ViewGroup) childAt);
            } else {
                applySubView(childAt);
            }
        }
    }

    public static ConfigMonitor get() {
        if (sInstance == null) {
            synchronized (ConfigMonitor.class) {
                try {
                    if (sInstance == null) {
                        sInstance = new ConfigMonitor();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return sInstance;
    }

    private WeakComponentCallbacks getComponentCallback(Context context) {
        initConfigChange(context);
        return this.componentCallbacks;
    }

    private synchronized void initConfigChange(Context context) {
        if (this.componentCallbacks == null && context != null) {
            Context applicationContext = context.getApplicationContext();
            WeakComponentCallbacks weakComponentCallbacks = new WeakComponentCallbacks();
            this.componentCallbacks = weakComponentCallbacks;
            if (applicationContext != null) {
                try {
                    applicationContext.registerComponentCallbacks(weakComponentCallbacks);
                } catch (Exception e2) {
                    m.f("ConfigMonitor", "registerComponentCallbacks error=", e2);
                }
            }
        }
    }

    public void applyConfig(View view) {
        if (view instanceof ViewGroup) {
            applyViewGroup((ViewGroup) view);
        } else {
            applySubView(view);
        }
    }

    public void onDialogCreate(Dialog dialog) {
        Window window = dialog != null ? dialog.getWindow() : null;
        View decorView = window != null ? window.getDecorView() : null;
        if (decorView != null) {
            getComponentCallback(decorView.getContext()).addView(decorView);
        }
    }

    public void onWindowCreate(Window window) {
        View decorView = window != null ? window.getDecorView() : null;
        if (decorView != null) {
            getComponentCallback(decorView.getContext()).addView(decorView);
        }
    }

    public void refreshConfig() {
        WeakComponentCallbacks weakComponentCallbacks = this.componentCallbacks;
        if (weakComponentCallbacks != null) {
            weakComponentCallbacks.onConfigurationChanged(null);
        }
    }

    public void refreshConfigImmediately() {
        WeakComponentCallbacks weakComponentCallbacks = this.componentCallbacks;
        if (weakComponentCallbacks != null) {
            weakComponentCallbacks.refreshImmediately();
        }
    }

    public void registerConfigChange(Context context) {
        Activity activity = ParserUtil.getActivity(context);
        if (activity == null || activity.isFinishing() || activity.isDestroyed() || activity.getWindow() == null) {
            return;
        }
        getComponentCallback(context).addView(activity.getWindow().getDecorView());
    }

    public void setAdapterNightMode(boolean z2) {
        this.mAdapterNightMode = z2;
    }

    public void setAdapterScreenInfo(boolean z2) {
        this.mAdapterScreenInfo = z2;
    }

    public void unregisterConfigChange(Context context) {
        Activity activity = ParserUtil.getActivity(context);
        if (activity == null || activity.getWindow() == null) {
            return;
        }
        getComponentCallback(context).removeView(activity.getWindow().getDecorView());
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class WeakComponentCallbacks implements ComponentCallbacks {
        private final Runnable configRun;
        private final Handler mainHandler;
        private final Set<View> viewCollections;

        private WeakComponentCallbacks() {
            this.viewCollections = Collections.newSetFromMap(new WeakHashMap());
            this.mainHandler = new Handler(Looper.getMainLooper());
            this.configRun = new Runnable() { // from class: com.originui.resmap.ConfigMonitor.WeakComponentCallbacks.1
                @Override // java.lang.Runnable
                public void run() {
                    boolean z2 = false;
                    for (View view : WeakComponentCallbacks.this.viewCollections) {
                        if (view != null) {
                            if (!z2) {
                                DeviceResMap.get(view.getContext()).refreshDeviceConfig(view.getContext());
                                z2 = true;
                            }
                            ConfigMonitor.get().applyConfig(view);
                        }
                    }
                }
            };
        }

        void addView(View view) {
            this.viewCollections.add(view);
        }

        @Override // android.content.ComponentCallbacks
        public void onConfigurationChanged(Configuration configuration) {
            this.mainHandler.removeCallbacks(this.configRun);
            this.mainHandler.postDelayed(this.configRun, 100L);
        }

        void refreshImmediately() {
            for (View view : this.viewCollections) {
                if (view != null) {
                    DeviceResMap.get(view.getContext()).refreshDeviceConfig(view.getContext());
                    ConfigMonitor.get().applyConfig(view);
                }
            }
        }

        void removeView(View view) {
            this.viewCollections.remove(view);
        }

        @Override // android.content.ComponentCallbacks
        public void onLowMemory() {
        }
    }
}
