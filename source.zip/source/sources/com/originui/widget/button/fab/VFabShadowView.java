package com.originui.widget.button.fab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VFabShadowView extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Paint f756a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f757b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f758c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f759d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f760e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private float f761f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float f762g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f763h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f764i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f765j;

    public VFabShadowView(Context context) {
        this(context, null);
    }

    private void b() {
        Paint paint = new Paint();
        this.f756a = paint;
        paint.setAntiAlias(true);
        this.f756a.setStyle(Paint.Style.FILL);
        this.f756a.setColor(0);
    }

    private void c(Context context, AttributeSet attributeSet, int i2) {
        this.f757b = context;
        b();
    }

    public int a(int i2, int i3) {
        return Color.argb((int) Math.round(((double) i3) * 2.55d), Color.red(i2), Color.green(i2), Color.blue(i2));
    }

    public void d(int i2, int i3) {
        float f2 = i2;
        this.f762g = f2;
        this.f763h = i3;
        this.f761f = f2 / 2.0f;
    }

    public void e(int i2) {
        this.f760e = i2;
        this.f764i = true;
        invalidate();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.f762g > 0.0f && this.f763h > 0.0f && this.f764i) {
            this.f756a.setShadowLayer(this.f761f * this.f765j, this.f759d, this.f758c, a(this.f760e, 40));
            float f2 = this.f761f;
            canvas.drawCircle(f2, f2, f2, this.f756a);
        }
        super.onDraw(canvas);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        d(i2, i3);
    }

    public void setEnableFabShadow(boolean z2) {
        this.f764i = z2;
        invalidate();
    }

    public VFabShadowView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VFabShadowView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f758c = p.a(6.0f);
        this.f759d = p.a(1.0f);
        this.f764i = false;
        this.f765j = 0.3f;
        c(context, attributeSet, i2);
    }
}
