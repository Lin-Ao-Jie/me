package com.originui.widget.button.fab;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.k;
import com.originui.core.utils.l;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.s;
import com.originui.core.utils.t;
import com.originui.resmap.ResMapManager;
import com.originui.widget.button.R$styleable;
import e.c;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VFabButton extends FrameLayout {
    public static float I = 0.7f;
    protected boolean A;
    private boolean B;
    protected String C;
    protected VFabShadowView D;
    protected boolean E;
    protected boolean F;
    protected boolean G;
    protected boolean H;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected Context f728a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected int f729b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected int f730c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected int f731d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected float f732e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    protected float f733f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected float f734g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected c f735h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected int f736i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    protected View f737j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    protected View f738k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    protected View f739l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    protected int f740m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    protected int f741n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    protected int f742o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    protected t f743p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    protected ImageView f744q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    protected View f745r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    protected Drawable f746s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    protected int f747t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected boolean f748u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    protected int f749v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    protected boolean f750w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    protected com.originui.widget.button.fab.a f751x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    protected boolean f752y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    protected boolean f753z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements VThemeIconUtils.ISystemColorRom14 {
        a() {
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setMyDynamicColor() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "fabButton setMyDynamicColor");
            }
            VFabButton vFabButton = VFabButton.this;
            vFabButton.f742o = VThemeIconUtils.p(vFabButton.f728a, VThemeIconUtils.f473w, VThemeIconUtils.F);
            VFabButton vFabButton2 = VFabButton.this;
            vFabButton2.f731d = VThemeIconUtils.p(vFabButton2.f728a, VThemeIconUtils.f473w, VThemeIconUtils.F);
            VFabButton.this.t();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setMyDynamicColorNightMode() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "fabButton setMyDynamicColorNightMode");
            }
            VFabButton vFabButton = VFabButton.this;
            vFabButton.f742o = VThemeIconUtils.p(vFabButton.f728a, VThemeIconUtils.f473w, VThemeIconUtils.J);
            VFabButton vFabButton2 = VFabButton.this;
            vFabButton2.f731d = VThemeIconUtils.p(vFabButton2.f728a, VThemeIconUtils.f473w, VThemeIconUtils.J);
            VFabButton.this.t();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setSystemColorByDayModeRom14(int[] iArr) {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "fabButton setSystemColorByDayModeRom14");
            }
            VFabButton vFabButton = VFabButton.this;
            int i2 = iArr[2];
            vFabButton.f742o = i2;
            vFabButton.f731d = i2;
            vFabButton.t();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setSystemColorNightModeRom14(int[] iArr) {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "fabButton setSystemColorNightModeRom14");
            }
            VFabButton.this.f742o = VThemeIconUtils.D(iArr[2]);
            VFabButton.this.f731d = VThemeIconUtils.D(iArr[2]);
            VFabButton.this.t();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setViewDefaultColor() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "fabButton setViewDefaultColor");
            }
            VFabButton vFabButton = VFabButton.this;
            vFabButton.f742o = vFabButton.f740m;
            vFabButton.f731d = vFabButton.f729b;
            vFabButton.t();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends View.AccessibilityDelegate {
        b() {
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
            if (TextUtils.isEmpty(VFabButton.this.C)) {
                return;
            }
            accessibilityNodeInfo.setContentDescription(VFabButton.this.C);
            accessibilityNodeInfo.setClassName(Button.class.getName());
            accessibilityNodeInfo.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
        }
    }

    public VFabButton(Context context) {
        this(context, null);
    }

    private void d(Context context, AttributeSet attributeSet, int i2, int i3) {
        TypedArray typedArrayObtainTypedArray = ResMapManager.obtainTypedArray(this.f728a, attributeSet, R$styleable.VFabButton, i2, i3);
        if (typedArrayObtainTypedArray == null) {
            return;
        }
        try {
            this.f732e = typedArrayObtainTypedArray.getDimension(R$styleable.VFabButton_vShadowLimit, p.a(15.0f));
            this.f733f = typedArrayObtainTypedArray.getDimension(R$styleable.VFabButton_vShadowDx, p.a(1.0f));
            this.f734g = typedArrayObtainTypedArray.getDimension(R$styleable.VFabButton_vShadowDy, p.a(8.0f));
            int color = this.f728a.getResources().getColor(d.c.r());
            if (!this.f748u) {
                color = VThemeIconUtils.v(this.f728a, "originui.button.main_color", color);
            }
            int i4 = R$styleable.VFabButton_vFabFillColor;
            this.f741n = typedArrayObtainTypedArray.getResourceId(i4, 0);
            int color2 = typedArrayObtainTypedArray.getColor(i4, color);
            this.f742o = color2;
            this.f740m = color2;
            int i5 = R$styleable.VFabButton_vShadowColor;
            this.f730c = typedArrayObtainTypedArray.getResourceId(i5, 0);
            int color3 = typedArrayObtainTypedArray.getColor(i5, color);
            this.f731d = color3;
            this.f729b = color3;
            this.f749v = typedArrayObtainTypedArray.getColor(R$styleable.VFabButton_vShadowBackColorClicked, -1);
            this.f750w = typedArrayObtainTypedArray.getBoolean(R$styleable.VFabButton_vShadowIsIntercept, true);
            this.f736i = (int) typedArrayObtainTypedArray.getDimension(R$styleable.VFabButton_vFabSize, p.a(46.0f));
            this.f747t = (int) typedArrayObtainTypedArray.getDimension(R$styleable.VFabButton_vFabIconSize, -1.0f);
            this.f746s = typedArrayObtainTypedArray.getDrawable(R$styleable.VFabButton_vFabIcon);
            this.f752y = typedArrayObtainTypedArray.getBoolean(R$styleable.VFabButton_vFollowColor, VThemeIconUtils.n());
            if (this.f749v != -1) {
                setClickable(true);
            }
            int i6 = R$styleable.VFabButton_android_contentDescription;
            if (typedArrayObtainTypedArray.hasValue(i6)) {
                this.C = typedArrayObtainTypedArray.getString(i6);
            }
            this.E = typedArrayObtainTypedArray.getBoolean(R$styleable.VFabButton_vShadowShow, true);
            this.F = typedArrayObtainTypedArray.getBoolean(R$styleable.VFabButton_vShadowAnimClose, false);
            this.G = typedArrayObtainTypedArray.getBoolean(R$styleable.VFabButton_vShouldAutoRefreshModeColor, true);
            this.H = typedArrayObtainTypedArray.getBoolean(R$styleable.VFabButton_vShouldAutoRefreshFollowColor, true);
        } finally {
            typedArrayObtainTypedArray.recycle();
        }
    }

    private void e() {
        if (this.f737j == null) {
            View view = new View(getContext());
            this.f737j = view;
            view.setId(View.generateViewId());
            this.f737j.setImportantForAccessibility(2);
            int i2 = this.f736i;
            addView(this.f737j, new FrameLayout.LayoutParams(i2, i2));
        }
    }

    private void f() {
        if (this.f738k == null) {
            View view = new View(getContext());
            this.f738k = view;
            view.setId(View.generateViewId());
            this.f738k.setImportantForAccessibility(2);
            int i2 = this.f736i;
            addView(this.f738k, new FrameLayout.LayoutParams(i2, i2));
        }
    }

    private void g() {
        com.originui.widget.button.fab.a aVar = this.f751x;
        if (aVar != null) {
            aVar.c(this.f737j);
            this.f751x.k(this.f737j);
            this.f751x.b(this.f738k);
            this.f751x.g(this.f738k);
        }
        s();
    }

    private void h() {
        if (this.f745r == null) {
            t tVar = new t();
            tVar.l(this.f736i / 2.0f);
            int i2 = this.f736i;
            tVar.n(i2, i2);
            tVar.j(Color.parseColor("#ffffff"));
            View view = new View(getContext());
            this.f745r = view;
            view.setImportantForAccessibility(2);
            this.f745r.setBackground(tVar);
            this.f745r.setAlpha(0.3f);
            this.f745r.setVisibility(8);
            int i3 = this.f736i;
            addView(this.f745r, new FrameLayout.LayoutParams(i3, i3));
        }
    }

    private void i() {
        if (this.f743p == null) {
            t tVar = new t();
            this.f743p = tVar;
            tVar.l(this.f736i / 2.0f);
            t tVar2 = this.f743p;
            int i2 = this.f736i;
            tVar2.n(i2, i2);
            this.f743p.j(this.f742o);
        }
    }

    private void j() {
        if (this.D == null) {
            VFabShadowView vFabShadowView = new VFabShadowView(this.f728a);
            this.D = vFabShadowView;
            vFabShadowView.setImportantForAccessibility(2);
            int i2 = this.f736i;
            addView(this.D, new FrameLayout.LayoutParams(i2, i2));
        }
    }

    private void k() {
        FrameLayout.LayoutParams layoutParams;
        if (this.f744q == null) {
            ImageView imageView = new ImageView(getContext());
            this.f744q = imageView;
            imageView.setImportantForAccessibility(2);
            if (this.f747t == -1) {
                layoutParams = new FrameLayout.LayoutParams(-2, -2);
            } else {
                int i2 = this.f747t;
                layoutParams = new FrameLayout.LayoutParams(i2, i2);
                setIcon(this.f746s);
            }
            layoutParams.gravity = 17;
            addView(this.f744q, layoutParams);
        }
    }

    private void l() {
        if (this.f739l == null) {
            View view = new View(getContext());
            this.f739l = view;
            view.setId(View.generateViewId());
            this.f739l.setImportantForAccessibility(2);
            int i2 = this.f736i;
            addView(this.f739l, new FrameLayout.LayoutParams(i2, i2));
        }
    }

    private void m(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f748u = k.f(context);
        this.f728a = ResMapManager.byRomVer(context);
        this.f735h = new c();
        d(context, attributeSet, i2, i3);
        b();
        j();
        i();
        e();
        f();
        l();
        k();
        h();
        c();
    }

    private void o() {
        setClipToPadding(false);
        setClipChildren(false);
        ViewParent parent = getParent();
        if (parent instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) parent;
            viewGroup.setClipToPadding(false);
            viewGroup.setClipChildren(false);
        }
    }

    private void r() {
        this.f751x.d(this, this.f732e, this.f731d, this.f736i, this.f734g, this.f733f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void t() {
        this.f743p.j(this.f742o);
        if (this.f751x != null) {
            r();
            p();
        } else {
            this.f737j.setBackground(this.f743p);
            this.D.e(this.f731d);
        }
    }

    protected void b() {
        if (s.f(this.f728a) && !this.f748u && this.B && this.f753z && this.A) {
            com.originui.widget.button.fab.a aVar = new com.originui.widget.button.fab.a(this.f728a);
            this.f751x = aVar;
            aVar.o(this.f753z);
            this.f751x.l(this.F);
            this.f751x.n(this.E);
        }
    }

    protected void c() {
        setImportantForAccessibility(1);
        setAccessibilityDelegate(new b());
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    public com.originui.widget.button.fab.a getAbsFabButtonHelper() {
        return this.f751x;
    }

    public ImageView getIconView() {
        return this.f744q;
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    public void n() {
        int color = this.f728a.getResources().getColor(d.c.r());
        if (!this.f748u) {
            color = VThemeIconUtils.v(this.f728a, "originui.button.main_color", color);
        }
        if (this.f741n != 0) {
            int color2 = this.f728a.getResources().getColor(this.f741n);
            this.f742o = color2;
            this.f740m = color2;
        } else {
            this.f742o = color;
            this.f740m = color;
        }
        if (this.f730c != 0) {
            int color3 = this.f728a.getResources().getColor(this.f730c);
            this.f731d = color3;
            this.f729b = color3;
        } else {
            this.f731d = color;
            this.f729b = color;
        }
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "refreshNightModeColor-----mShadowColor:" + Integer.toHexString(this.f731d) + "-------mBackGroundColor:" + Integer.toHexString(this.f742o));
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m.b("vbutton_6.0.1.8", "fab onConfigurationChanged----mShouldAutoRefreshModeColor:" + this.G + "---mShouldAutoRefreshFollowColor:" + this.H);
        if (this.G) {
            n();
        }
        if (this.H) {
            s();
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.f750w) {
            return true;
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        o();
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 <= 0 || i3 <= 0) {
            return;
        }
        g();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action == 0) {
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            Rect rect = new Rect();
            this.f737j.getHitRect(rect);
            if (!rect.contains((int) x2, (int) y2)) {
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "touch point not on view");
                }
                return false;
            }
            this.f735h.c(this);
        } else if (action == 1 || action == 3 || action == 4) {
            this.f735h.d(this);
        }
        if (this.f750w) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void p() {
        if (this.f737j.getBackground() != null) {
            this.f737j.setBackground(null);
        }
        this.f751x.f(this.f737j, this.f742o, this.f736i, this.f743p);
    }

    public void q(float f2, float f3, float f4, float f5, float f6) {
        com.originui.widget.button.fab.a aVar = this.f751x;
        if (aVar != null) {
            aVar.p(this, ((this.f736i * f6) * f2) / 2.0f, p.a(f3), this.f736i, p.a(f4), p.a(f5));
            invalidate();
        }
    }

    public void s() {
        VThemeIconUtils.F(this.f728a, this.f752y, new a(), 0);
    }

    public void setFabBorderHLShow(boolean z2) {
        com.originui.widget.button.fab.a aVar = this.f751x;
        if (aVar != null) {
            aVar.h(z2);
        }
    }

    public void setFabEnabled(boolean z2) {
        setEnabled(z2);
        View view = this.f745r;
        if (view != null) {
            view.setVisibility(!z2 ? 0 : 8);
        }
        setInterceptTouchEvent(z2);
    }

    public void setFabFillColor(int i2) {
        if (this.f742o != i2) {
            m.b("vbutton_6.0.1.8", "setFabFillColor:" + Integer.toHexString(i2));
            this.f742o = i2;
            this.f740m = i2;
            this.f743p.j(i2);
            if (this.f751x != null) {
                p();
            } else {
                this.f737j.setBackground(this.f743p);
            }
        }
    }

    public void setFabInnerShadowShow(boolean z2) {
        com.originui.widget.button.fab.a aVar = this.f751x;
        if (aVar != null) {
            aVar.i(z2);
        }
    }

    public void setFabShadowColor(int i2) {
        if (this.f731d != i2) {
            this.f731d = i2;
            this.f729b = i2;
            if (this.f751x != null) {
                r();
                return;
            }
            VFabShadowView vFabShadowView = this.D;
            if (vFabShadowView != null) {
                vFabShadowView.e(i2);
            }
        }
    }

    public void setFabShadowRadius(float f2) {
        if (this.f751x != null) {
            float fA = p.a(f2);
            this.f732e = fA;
            this.f751x.q(this, fA);
            invalidate();
        }
    }

    public void setFabShadowShow(boolean z2) {
        com.originui.widget.button.fab.a aVar = this.f751x;
        if (aVar != null) {
            this.E = z2;
            aVar.j(this, z2);
        }
    }

    public void setFollowColor(boolean z2) {
        if (this.f752y != z2) {
            this.f752y = z2;
            s();
        }
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = this.f744q;
        if (imageView != null) {
            if (drawable == null) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.f744q.setImageDrawable(drawable);
            }
        }
    }

    public void setInterceptTouchEvent(boolean z2) {
        this.f750w = z2;
    }

    public VFabButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VFabButton(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VFabButton(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f736i = 0;
        this.f747t = 0;
        this.f752y = VThemeIconUtils.n();
        this.f753z = l.a(getContext());
        this.A = l.c();
        this.B = true;
        this.C = "";
        this.E = true;
        this.F = false;
        m(context, attributeSet, i2, i3);
    }

    public void setOnFabClickListener(com.originui.widget.button.fab.a.InterfaceC0001a interfaceC0001a) {
    }
}
