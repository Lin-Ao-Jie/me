package com.originui.widget.button.fab;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import com.originui.core.utils.m;
import com.originui.core.utils.n;
import com.originui.core.utils.p;
import com.originui.core.utils.q;
import com.vivo.systemlighteffect.sdk.ViewEffect;
import f.b;
import f.c;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ViewEffect f766a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ViewEffect f767b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ViewEffect f768c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f769d = Color.parseColor("#dedede");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f770e = Color.parseColor("#ffffff");

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f771f = Color.parseColor("#f2f2f2");

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f772g = 125;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f773h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Context f774i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f775j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f776k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private c f777l;

    /* JADX INFO: renamed from: com.originui.widget.button.fab.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface InterfaceC0001a {
    }

    public a(Context context) {
        this.f774i = context;
        a();
    }

    private void a() {
        f.a aVar = new f.a();
        ArrayList arrayList = new ArrayList();
        arrayList.add(new b(6, new int[]{153, 153, 153}, 0.99f));
        arrayList.add(new b(13, new int[]{255, 255, 255}, 0.99f));
        arrayList.add(new b(0, new int[]{255, 255, 255}, 0.5f));
        arrayList.add(new b(11, new int[]{0, 122, 255}, 0.99f));
        arrayList.add(new b(4, new int[]{255, 255, 255}, 0.1f));
        aVar.f1612a = arrayList;
        f.a.b(aVar);
        this.f777l = new c(this.f774i);
    }

    public void b(View view) {
        this.f766a = ViewEffect.builder(view).addBorderHL().setBorderHLShapeType(1, 2, 2, 0).setBorderHLOpenClipPath(true).enableBorderLightVibrancy(this.f773h, 3);
    }

    public void c(View view) {
        this.f768c = ViewEffect.builder(view).addBorderHL().setBorderHLShapeType(1, 0, 1, 0).setBorderHLInnerAlpha(240).setBorderHLInnerBlurMaskFilter(new BlurMaskFilter(p.a(22.0f), BlurMaskFilter.Blur.NORMAL)).setBorderHLInnerColor(this.f771f).setBorderHLOpenClipPath(true).enableBorderLightVibrancy(this.f773h, 3);
    }

    public void d(View view, float f2, int i2, int i3, float f3, float f4) {
        float f5 = i3;
        float f6 = (VFabButton.I * f5) / 2.0f;
        ViewEffect viewEffectAddAmbientLight = ViewEffect.builder(view).setEffectDrawOrder(4, 0).addAmbientLight();
        this.f767b = viewEffectAddAmbientLight;
        viewEffectAddAmbientLight.addOvalAmbientEffect(view.getId(), f5, f5, f6, (view.getWidth() / 2.0f) + f4, (f5 / 2.0f) + f3);
        this.f767b.setAmbientLightEffectBlurRadius(view.getId(), f2);
        if (this.f776k) {
            this.f767b.setAmbientLightEffectAnimationDuration(view.getId(), 0);
        }
        m(view, i2);
        if (this.f775j) {
            this.f767b.showAmbientEffect(view.getId());
        }
    }

    public int[] e(int i2) {
        return new int[]{(i2 >> 16) & 255, (i2 >> 8) & 255, i2 & 255};
    }

    public void f(View view, int i2, int i3, Drawable drawable) {
        try {
            List list = f.a.a().f1612a;
            ((b) list.get(3)).d(e(i2));
            q.m(view, "setMaterial", 0, 1);
            float f2 = i3;
            float f3 = f2 / 2.0f;
            q.m(view, "setMaterialCornerRadius", Float.valueOf(f3));
            this.f777l.a(view);
            this.f777l.g(list);
            this.f777l.h(f3, f2, f2);
            q.m(view, "setVibrancyEffect", this.f777l.c(), 1);
        } catch (Exception e2) {
            if (m.f583b) {
                m.b("AbsFabButtonHelper", "serBackGroundBlur error" + e2.getMessage());
            }
            view.setBackground(drawable);
        }
    }

    public void g(View view) {
        try {
            q.m(view, "setMaterialCustomized", Float.valueOf(0.1f), Float.valueOf(0.4f), Integer.valueOf(this.f770e), Float.valueOf(0.4f), 6, 0, Float.valueOf(0.0f), 0, 0, Float.valueOf(0.0f), 0, Float.valueOf(1.0f), 0, 1);
        } catch (Exception e2) {
            if (m.f583b) {
                m.b("AbsFabButtonHelper", "serBackGroundBlur error" + e2.getMessage());
            }
        }
    }

    public void h(boolean z2) {
        ViewEffect viewEffect = this.f766a;
        if (viewEffect != null) {
            if (z2) {
                viewEffect.showBorderHL();
            } else {
                viewEffect.hideBorderHL();
            }
        }
    }

    public void i(boolean z2) {
        ViewEffect viewEffect = this.f768c;
        if (viewEffect != null) {
            if (z2) {
                viewEffect.showBorderHL();
            } else {
                viewEffect.hideBorderHL();
            }
        }
    }

    public void j(View view, boolean z2) {
        this.f775j = z2;
        ViewEffect viewEffect = this.f767b;
        if (viewEffect != null) {
            if (z2) {
                viewEffect.showAmbientEffect(view.getId());
            } else {
                viewEffect.hideAmbientLightEffect(view.getId());
            }
        }
    }

    public void k(View view) {
        try {
            q.m(view, "setMaterialCustomized", Float.valueOf(0.22f), Float.valueOf(0.0f), Integer.valueOf(this.f771f), Float.valueOf(0.99f), 11, 0, Float.valueOf(0.0f), 0, 0, Float.valueOf(0.0f), 0, Float.valueOf(1.0f), 0, 1);
        } catch (Exception e2) {
            if (m.f583b) {
                m.b("AbsFabButtonHelper", "serBackGroundBlur error" + e2.getMessage());
            }
        }
    }

    public void l(boolean z2) {
        this.f776k = z2;
    }

    public void m(View view, int i2) {
        if (this.f767b != null) {
            this.f767b.setAmbientLightEffectColors(view.getId(), new int[]{i2, i2}, n.a(this.f774i) ? new float[]{0.2f, 0.6f} : new float[]{1.0f, 1.0f}, new float[]{0.0f, 1.0f});
        }
    }

    public void n(boolean z2) {
        this.f775j = z2;
    }

    public void o(boolean z2) {
        this.f773h = z2;
    }

    public void p(View view, float f2, float f3, float f4, float f5, float f6) {
        ViewEffect viewEffect = this.f767b;
        if (viewEffect != null) {
            viewEffect.setAmbientLightEffectBlurRadius(view.getId(), f3);
            float f7 = f4 / 2.0f;
            this.f767b.updateAmbientLightSizeAndPosition(view.getId(), f2, f2, f2, f5 + f7, f6 + f7);
        }
    }

    public void q(View view, float f2) {
        ViewEffect viewEffect = this.f767b;
        if (viewEffect != null) {
            viewEffect.setAmbientLightEffectBlurRadius(view.getId(), f2);
        }
    }
}
