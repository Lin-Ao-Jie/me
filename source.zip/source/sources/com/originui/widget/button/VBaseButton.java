package com.originui.widget.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import com.originui.core.utils.d;
import com.originui.core.utils.m;
import com.originui.core.utils.q;
import j.c;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VBaseButton extends Button implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final b f641a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f642b;

    public VBaseButton(Context context) {
        this(context, null);
    }

    public void a(AttributeSet attributeSet, int i2, int i3) {
        i.a.i().l(getView(), attributeSet, i2, i3);
    }

    public void b(int i2, boolean z2) {
        super.setTextColor(i2);
    }

    public void c(ColorStateList colorStateList, boolean z2) {
        super.setTextColor(colorStateList);
    }

    public void d() {
        this.f641a.m1();
    }

    public int getDefaultTextColor() {
        return this.f641a.v();
    }

    public ColorStateList getDefaultTextColorList() {
        return this.f641a.w();
    }

    public int getDrawType() {
        return this.f641a.y();
    }

    public int getFillColor() {
        return this.f641a.A();
    }

    public int getFillet() {
        b bVar = this.f641a;
        if (bVar != null) {
            return bVar.f711x;
        }
        return -1;
    }

    public boolean getFollowColor() {
        return this.f641a.B();
    }

    @Override // j.c
    public j.a getGridRule() {
        return i.a.i().h(getView());
    }

    public boolean getSelectedMultipleAccess() {
        return this.f641a.D();
    }

    public boolean getStateDefaultSelected() {
        return this.f641a.E();
    }

    public int getStrokeColor() {
        return this.f641a.F();
    }

    public float getStrokeWidth() {
        return this.f641a.G();
    }

    public int getTextColor() {
        return this.f641a.t();
    }

    @Override // android.widget.TextView, android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f642b) {
            this.f641a.a0();
            invalidate();
        }
        d();
        b bVar = this.f641a;
        if (bVar.g1) {
            bVar.Z();
            this.f641a.g1();
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        this.f641a.V(canvas, getWidth(), getHeight(), isEnabled());
        super.onDraw(canvas);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action != 0) {
            if ((action == 1 || action == 3 || action == 4) && isEnabled() && this.f641a.z() && isClickable()) {
                this.f641a.e();
            }
        } else if (isEnabled() && this.f641a.z() && isClickable()) {
            this.f641a.d();
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView, android.view.View
    protected void onVisibilityChanged(View view, int i2) {
        super.onVisibilityChanged(view, i2);
        if (i2 == 0) {
            this.f641a.m1();
        }
    }

    public void setAnimType(int i2) {
        this.f641a.c0(i2);
    }

    public void setAutoAdjustMultiLine(boolean z2) {
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.d0(z2);
        }
    }

    public void setAutoAdjustRow(boolean z2) {
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.e0(z2);
        }
    }

    public void setAutoNightMode(int i2) {
        q.r(this, i2);
        this.f642b = i2 > 0;
    }

    public void setButtonAnimationListener(a.j jVar) {
        this.f641a.h0(jVar);
    }

    public void setButtonIconMargin(int i2) {
        this.f641a.j0(i2);
    }

    public void setDefaultAlpha(float f2) {
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.n0(f2);
        }
    }

    public void setDrawType(int i2) {
        this.f641a.v0(i2);
    }

    public void setEnableAnim(boolean z2) {
        this.f641a.w0(z2);
    }

    public void setEnableColor(float f2) {
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.x0(f2);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void setEnabled(boolean z2) {
        super.setEnabled(z2);
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.y0(z2);
        }
    }

    public void setFillColor(int i2) {
        this.f641a.z0(i2);
    }

    public void setFillet(int i2) {
        this.f641a.A0(i2);
    }

    public void setFollowColor(boolean z2) {
        setFollowSystemColor(z2);
    }

    public void setFollowFillet(boolean z2) {
        setFollowSystemFillet(z2);
    }

    public void setFollowSystemColor(boolean z2) {
        this.f641a.B0(z2);
    }

    public void setFollowSystemFillet(boolean z2) {
        this.f641a.C0(z2);
    }

    public void setIconSize(int i2) {
        this.f641a.H0(i2);
    }

    public void setIsInterceptStateColorComp(boolean z2) {
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.I0(z2);
        }
    }

    public void setLimitFontSize(int i2) {
        this.f641a.J0(i2);
    }

    public void setLoadingBtn(boolean z2) {
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.K0(z2);
        }
    }

    public void setNightMode(int i2) {
        try {
            super.setNightMode(i2);
        } catch (Throwable th) {
            if (m.f583b) {
                m.e("VBaseButton", "setNightMode error:" + th.getMessage());
            }
        }
        this.f642b = i2 > 0;
    }

    public void setSelectedMultipleAccess(boolean z2) {
        this.f641a.U0(z2);
    }

    public void setStateDefaultSelected(boolean z2) {
        this.f641a.X0(z2);
    }

    public void setStrokeColor(int i2) {
        this.f641a.Y0(i2);
    }

    public void setStrokeWidth(int i2) {
        this.f641a.Z0(i2);
    }

    @Override // android.widget.TextView
    public void setTextColor(int i2) {
        super.setTextColor(i2);
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.f0(i2);
        }
    }

    public void setTextMaxHeight(int i2) {
        this.f641a.N0(i2);
    }

    public void setTextMaxWidth(int i2) {
        this.f641a.Q0(i2);
    }

    @Override // android.widget.TextView
    public void setTextSize(int i2, float f2) {
        super.setTextSize(i2, f2);
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.p0(i2, f2);
        }
    }

    public VBaseButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VBaseButton(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VBaseButton(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        b bVar = new b();
        this.f641a = bVar;
        this.f642b = false;
        bVar.L(this);
        bVar.J(context, attributeSet, i2, i3);
        q.r(this, 0);
        d.i(this, "6.0.1.8");
        a(attributeSet, i2, i3);
    }

    @Override // android.widget.TextView
    public void setTextColor(ColorStateList colorStateList) {
        super.setTextColor(colorStateList);
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.g0(colorStateList);
        }
    }

    @Override // android.widget.TextView
    public void setTextSize(float f2) {
        super.setTextSize(f2);
        b bVar = this.f641a;
        if (bVar != null) {
            bVar.p0(2, f2);
        }
    }

    public View getView() {
        return this;
    }
}
