package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$dimen {
    public static final int originui_button_fab_icon_size_rom15_0 = 2130968576;
    public static final int originui_button_fab_icon_size_rom16_0 = 2130968577;
    public static final int originui_button_fab_size_rom15_0 = 2130968578;
    public static final int originui_button_fab_size_rom16_0 = 2130968579;
    public static final int originui_button_fading_edge_length_rom15_0 = 2130968580;
    public static final int originui_button_l_min_height = 2130968581;
    public static final int originui_button_l_min_height_4_pad = 2130968582;
    public static final int originui_button_l_radius_rom15_0 = 2130968583;
    public static final int originui_button_l_xl_down_padding_top_bottom = 2130968584;
    public static final int originui_button_l_xl_padding_top_bottom = 2130968585;
    public static final int originui_button_l_xl_padding_top_bottom_4_pad = 2130968586;
    public static final int originui_button_l_xl_text_size = 2130968587;
    public static final int originui_button_l_xl_text_size_4_pad = 2130968588;
    public static final int originui_button_m_l_xl_min_text_size_rom15_0 = 2130968589;
    public static final int originui_button_m_l_xl_row_min_text_size_rom15_0 = 2130968590;
    public static final int originui_button_m_radius_rom15_0 = 2130968591;
    public static final int originui_button_m_stroke_width_rom13_5 = 2130968592;
    public static final int originui_button_m_stroke_width_rom16_0 = 2130968593;
    public static final int originui_button_m_text_size = 2130968594;
    public static final int originui_button_min_sub_text_size_rom15_0 = 2130968595;
    public static final int originui_button_radius_rom13_0 = 2130968596;
    public static final int originui_button_s_min_text_size_rom15_0 = 2130968597;
    public static final int originui_button_s_radius_rom15_0 = 2130968598;
    public static final int originui_button_s_row_min_text_size_rom15_0 = 2130968599;
    public static final int originui_button_s_text_size = 2130968600;
    public static final int originui_button_state_fillet_rom15_0 = 2130968601;
    public static final int originui_button_state_padding_bottom_rom13_5 = 2130968602;
    public static final int originui_button_state_padding_bottom_rom16_0 = 2130968603;
    public static final int originui_button_state_padding_top_rom13_5 = 2130968604;
    public static final int originui_button_state_padding_top_rom16_0 = 2130968605;
    public static final int originui_button_state_single_fillet_rom15_0 = 2130968606;
    public static final int originui_button_stroke_end_width_rom13_0 = 2130968607;
    public static final int originui_button_stroke_fillet_rom13_0 = 2130968608;
    public static final int originui_button_stroke_radius_rom13_0 = 2130968609;
    public static final int originui_button_stroke_width_rom13_0 = 2130968610;
    public static final int originui_button_sub_text_size_rom15_0 = 2130968611;
    public static final int originui_button_xl_min_height_4_pad = 2130968612;
    public static final int originui_button_xl_min_height_rom13_0 = 2130968613;
    public static final int originui_button_xl_min_height_rom15_0 = 2130968614;
    public static final int originui_button_xl_min_height_text_rom13_0 = 2130968615;
}
