package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$anim {
    public static final int originui_anim_fab_down_rom14_0 = 2130771968;
    public static final int originui_anim_fab_up_rom14_0 = 2130771969;
    public static final int originui_anim_touch_down_interpolator_rom13_0 = 2130771970;
    public static final int originui_anim_touch_up_interpolator_rom13_0 = 2130771971;
}
