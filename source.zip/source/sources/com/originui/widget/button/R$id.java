package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static final int download = 2131099670;
    public static final int fill = 2131099671;
    public static final int none = 2131099692;
    public static final int size_l = 2131099727;
    public static final int size_m = 2131099728;
    public static final int size_s = 2131099729;
    public static final int size_xl = 2131099730;
    public static final int stroke = 2131099734;
    public static final int vbutton_icon = 2131099747;
    public static final int vbutton_sub_title = 2131099748;
    public static final int vbutton_title = 2131099749;
}
