package com.originui.widget.button;

import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.FrameLayout;
import com.originui.core.utils.p;
import com.originui.widget.button.VShadowLayout;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VShadowLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f647a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f648b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f649c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f650d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private float f651e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private float f652f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float f653g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f654h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f655i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f656j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f657k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f658l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private Paint f659m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private Paint f660n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f661o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f662p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private int f663q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f664r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private RectF f665s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private ValueAnimator f666t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private ValueAnimator f667u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private float f668v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f669w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f670x;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface a {
    }

    public VShadowLayout(Context context) {
        this(context, null);
    }

    public static /* synthetic */ void a(VShadowLayout vShadowLayout, ValueAnimator valueAnimator) {
        vShadowLayout.setPivotX(vShadowLayout.getWidth() >> 1);
        vShadowLayout.setPivotY(vShadowLayout.getHeight() >> 1);
        vShadowLayout.setScaleX(((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue());
        vShadowLayout.setScaleY(((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue());
        vShadowLayout.invalidate();
    }

    public static /* synthetic */ void b(VShadowLayout vShadowLayout, ValueAnimator valueAnimator) {
        vShadowLayout.setPivotX(vShadowLayout.getWidth() >> 1);
        vShadowLayout.setPivotY(vShadowLayout.getHeight() >> 1);
        vShadowLayout.setScaleX(((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue());
        vShadowLayout.setScaleY(((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue());
        vShadowLayout.invalidate();
    }

    private void c() {
        float fFloatValue;
        float fFloatValue2;
        if (this.f666t == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f666t = valueAnimator;
            valueAnimator.setDuration(200L);
            this.f666t.setInterpolator(com.originui.widget.button.a.j1);
            this.f666t.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: d.d
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    VShadowLayout.a(this.f1475a, valueAnimator2);
                }
            });
        }
        ValueAnimator valueAnimator2 = this.f667u;
        if (valueAnimator2 == null || !valueAnimator2.isRunning()) {
            fFloatValue = 1.0f;
            fFloatValue2 = 1.0f;
        } else {
            fFloatValue = ((Float) this.f667u.getAnimatedValue("scaleX")).floatValue();
            fFloatValue2 = ((Float) this.f667u.getAnimatedValue("scaleY")).floatValue();
            this.f667u.cancel();
        }
        this.f666t.setValues(PropertyValuesHolder.ofFloat("scaleX", fFloatValue, this.f668v), PropertyValuesHolder.ofFloat("scaleY", fFloatValue2, this.f669w));
        this.f666t.start();
    }

    private void d() {
        if (this.f667u == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f667u = valueAnimator;
            valueAnimator.setDuration(250L);
            this.f667u.setInterpolator(com.originui.widget.button.a.k1);
            this.f667u.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: d.e
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    VShadowLayout.b(this.f1476a, valueAnimator2);
                }
            });
        }
        float fFloatValue = this.f668v;
        float fFloatValue2 = this.f669w;
        ValueAnimator valueAnimator2 = this.f666t;
        if (valueAnimator2 != null && valueAnimator2.isRunning()) {
            fFloatValue = ((Float) this.f666t.getAnimatedValue("scaleX")).floatValue();
            fFloatValue2 = ((Float) this.f666t.getAnimatedValue("scaleY")).floatValue();
            this.f666t.cancel();
        }
        this.f667u.setValues(PropertyValuesHolder.ofFloat("scaleX", fFloatValue, 1.0f), PropertyValuesHolder.ofFloat("scaleY", fFloatValue2, 1.0f));
        this.f667u.start();
    }

    private Bitmap e(int i2, int i3, float f2, float f3, float f4, float f5, int i4, int i5) {
        float f6 = f4 / 4.0f;
        float f7 = f5 / 4.0f;
        int i6 = i2 / 4;
        int i7 = i3 / 4;
        float f8 = f2 / 4.0f;
        float f9 = f3 / 4.0f;
        if (i6 <= 0 || i7 <= 0) {
            return null;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(i6, i7, Bitmap.Config.ARGB_4444);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        RectF rectF = new RectF(f9, f9, i6 - f9, i7 - f9);
        if (f7 > 0.0f) {
            rectF.top += f7;
            rectF.bottom -= f7;
        } else if (f7 < 0.0f) {
            rectF.top += Math.abs(f7);
            rectF.bottom -= Math.abs(f7);
        }
        if (f6 > 0.0f) {
            rectF.left += f6;
            rectF.right -= f6;
        } else if (f6 < 0.0f) {
            rectF.left += Math.abs(f6);
            rectF.right -= Math.abs(f6);
        }
        this.f659m.setColor(i5);
        if (!isInEditMode()) {
            this.f659m.setShadowLayer(f9, f6, f7, i4);
        }
        canvas.drawRoundRect(rectF, f8, f8, this.f659m);
        return bitmapCreateBitmap;
    }

    private void f(AttributeSet attributeSet) {
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ShadowLayout);
        if (typedArrayObtainStyledAttributes == null) {
            return;
        }
        try {
            this.f655i = typedArrayObtainStyledAttributes.getBoolean(R$styleable.ShadowLayout_shadowLeftShow, true);
            this.f656j = typedArrayObtainStyledAttributes.getBoolean(R$styleable.ShadowLayout_shadowRightShow, true);
            this.f658l = typedArrayObtainStyledAttributes.getBoolean(R$styleable.ShadowLayout_shadowBottomShow, true);
            this.f657k = typedArrayObtainStyledAttributes.getBoolean(R$styleable.ShadowLayout_shadowTopShow, true);
            int i2 = R$styleable.ShadowLayout_shadowCornerRadius;
            TypedValue typedValuePeekValue = typedArrayObtainStyledAttributes.peekValue(i2);
            if (typedValuePeekValue != null && typedValuePeekValue.type == 5) {
                this.f651e = typedArrayObtainStyledAttributes.getDimension(i2, p.a(60.0f));
            } else if (typedValuePeekValue == null || typedValuePeekValue.type != 6) {
                this.f652f = typedArrayObtainStyledAttributes.getFraction(i2, 1, 1, 0.5f);
            } else {
                float fraction = typedArrayObtainStyledAttributes.getFraction(i2, 1, 1, 0.5f);
                this.f652f = fraction;
                if (fraction > 1.0f) {
                    this.f652f = 1.0f;
                }
                if (this.f652f < 0.0f) {
                    this.f652f = 0.0f;
                }
            }
            this.f650d = typedArrayObtainStyledAttributes.getDimension(R$styleable.ShadowLayout_shadowLimit, p.a(10.0f));
            this.f653g = typedArrayObtainStyledAttributes.getDimension(R$styleable.ShadowLayout_shadowDx, 0.0f);
            this.f654h = typedArrayObtainStyledAttributes.getDimension(R$styleable.ShadowLayout_shadowDy, 10.0f);
            this.f649c = typedArrayObtainStyledAttributes.getColor(R$styleable.ShadowLayout_shadowColor, getResources().getColor(R$color.default_shadow_color));
            this.f647a = typedArrayObtainStyledAttributes.getColor(R$styleable.ShadowLayout_shadowBackColor, getResources().getColor(R$color.default_shadowback_color));
            this.f648b = typedArrayObtainStyledAttributes.getColor(R$styleable.ShadowLayout_shadowBackColorClicked, -1);
            this.f670x = typedArrayObtainStyledAttributes.getBoolean(R$styleable.ShadowLayout_shadowmIsIntercept, true);
            if (this.f648b != -1) {
                setClickable(true);
            }
        } finally {
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    private void g(Context context, AttributeSet attributeSet) {
        f(attributeSet);
        Paint paint = new Paint();
        this.f659m = paint;
        paint.setAntiAlias(true);
        Paint paint2 = this.f659m;
        Paint.Style style = Paint.Style.FILL;
        paint2.setStyle(style);
        Paint paint3 = new Paint(1);
        this.f660n = paint3;
        paint3.setStyle(style);
        this.f660n.setColor(this.f647a);
        i();
    }

    private void h(int i2, int i3) {
        float f2 = this.f652f;
        if (f2 != 0.0f && this.f651e == 0.0f) {
            this.f651e = f2 * getWidth();
        }
        Bitmap bitmapE = e(i2, i3, this.f651e, this.f650d, this.f653g, this.f654h, this.f649c, 0);
        if (bitmapE != null) {
            setBackground(new BitmapDrawable(bitmapE));
        }
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    public float getCornerRadius() {
        return this.f651e;
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    public float getShadowLimit() {
        return this.f650d;
    }

    public void i() {
        int iAbs = (int) (this.f650d + Math.abs(this.f653g));
        int iAbs2 = (int) (this.f650d + Math.abs(this.f654h));
        if (this.f655i) {
            this.f661o = iAbs;
        } else {
            this.f661o = 0;
        }
        if (this.f657k) {
            this.f662p = iAbs2;
        } else {
            this.f662p = 0;
        }
        if (this.f656j) {
            this.f663q = iAbs;
        } else {
            this.f663q = 0;
        }
        if (this.f658l) {
            this.f664r = iAbs2;
        } else {
            this.f664r = 0;
        }
        setPadding(this.f661o, this.f662p, this.f663q, this.f664r);
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.f670x) {
            return true;
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 <= 0 || i3 <= 0) {
            return;
        }
        h(i2, i3);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action == 0) {
            c();
        } else if (action == 1 || action == 3 || action == 4) {
            d();
        }
        if (this.f670x) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setBottomShow(boolean z2) {
        this.f658l = z2;
        i();
    }

    public void setCornerRadius(int i2) {
        this.f651e = i2;
        if (getWidth() == 0 || getHeight() == 0) {
            return;
        }
        h(getWidth(), getHeight());
    }

    public void setInterceptTouchEvent(boolean z2) {
        this.f670x = z2;
    }

    public void setLeftShow(boolean z2) {
        this.f655i = z2;
        i();
    }

    public void setOffsetX(float f2) {
        float fAbs = Math.abs(f2);
        float f3 = this.f650d;
        if (fAbs <= f3) {
            this.f653g = f2;
        } else if (f2 > 0.0f) {
            this.f653g = f3;
        } else {
            this.f653g = -f3;
        }
        i();
    }

    public void setOffsetY(float f2) {
        float fAbs = Math.abs(f2);
        float f3 = this.f650d;
        if (fAbs <= f3) {
            this.f654h = f2;
        } else if (f2 > 0.0f) {
            this.f654h = f3;
        } else {
            this.f654h = -f3;
        }
        i();
    }

    public void setRightShow(boolean z2) {
        this.f656j = z2;
        i();
    }

    public void setShadowColor(int i2) {
        this.f649c = i2;
        if (getWidth() == 0 || getHeight() == 0) {
            return;
        }
        h(getWidth(), getHeight());
    }

    public void setShadowLimit(int i2) {
        this.f650d = i2;
        i();
    }

    public void setTopShow(boolean z2) {
        this.f657k = z2;
        i();
    }

    public VShadowLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VShadowLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f665s = new RectF();
        this.f668v = 0.9f;
        this.f669w = 0.9f;
        g(context, attributeSet);
    }

    public void setCornerRadius(float f2) {
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        this.f651e = f2 * getWidth();
        if (getWidth() == 0 || getHeight() == 0) {
            return;
        }
        h(getWidth(), getHeight());
    }

    public void setOnClickListener(a aVar) {
    }
}
