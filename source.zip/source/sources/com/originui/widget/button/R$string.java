package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static final int originui_accessibility_button_name = 2131361793;
    public static final int originui_accessibility_download_complete = 2131361794;
    public static final int originui_accessibility_download_pause_talkback = 2131361795;
    public static final int originui_accessibility_download_resume_talkback = 2131361796;
    public static final int originui_accessibility_download_state = 2131361797;
    public static final int originui_accessibility_downloading = 2131361798;
    public static final int originui_accessibility_selection_select_state = 2131361799;
    public static final int originui_accessibility_selection_select_talkback = 2131361800;
    public static final int originui_accessibility_selection_switch_talkback = 2131361801;
    public static final int originui_accessibility_selection_unselect = 2131361802;
    public static final int originui_accessibility_selection_unselect_state = 2131361803;
}
