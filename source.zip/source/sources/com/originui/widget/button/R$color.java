package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static final int default_shadow_color = 2130903040;
    public static final int default_shadowback_color = 2130903041;
    public static final int originui_button_fab_default_shadow_color = 2130903042;
    public static final int originui_button_fab_fill_main_color_rom16_0 = 2130903043;
    public static final int originui_button_fab_fill_white_color_rom16_0 = 2130903044;
    public static final int originui_button_fab_fill_white_shadow_color_rom16_0 = 2130903045;
    public static final int originui_button_fill_alpha_blue_color_rom13_0 = 2130903046;
    public static final int originui_button_fill_alpha_blue_color_rom15_0 = 2130903047;
    public static final int originui_button_fill_alpha_blue_text_color_rom13_0 = 2130903048;
    public static final int originui_button_fill_alpha_blue_text_color_rom15_0 = 2130903049;
    public static final int originui_button_fill_blue_color_rom13_0 = 2130903050;
    public static final int originui_button_fill_blue_color_rom15_0 = 2130903051;
    public static final int originui_button_fill_blue_text_color_rom13_0 = 2130903052;
    public static final int originui_button_fill_color_rom13_0 = 2130903053;
    public static final int originui_button_fill_color_rom15_0 = 2130903054;
    public static final int originui_button_fill_gray_color_4_pad = 2130903055;
    public static final int originui_button_fill_gray_color_rom13_0 = 2130903056;
    public static final int originui_button_fill_gray_color_rom15_0 = 2130903057;
    public static final int originui_button_fill_gray_text_color_rom13_0 = 2130903058;
    public static final int originui_button_fill_gray_text_color_rom15_0 = 2130903059;
    public static final int originui_button_line_color_rom13_0 = 2130903060;
    public static final int originui_button_line_color_rom15_0 = 2130903061;
    public static final int originui_button_multiline_main_title_text_color_rom15_0 = 2130903062;
    public static final int originui_button_multiline_main_title_text_color_rom16_0 = 2130903063;
    public static final int originui_button_multiline_sub_title_text_color_rom15_0 = 2130903064;
    public static final int originui_button_multiline_sub_title_text_color_rom16_0 = 2130903065;
    public static final int originui_button_shadow_color_end_rom13_0 = 2130903066;
    public static final int originui_button_state_default_text_color_rom16_0 = 2130903067;
    public static final int originui_button_state_fill_color_rom14_0 = 2130903068;
    public static final int originui_button_state_fill_color_rom15_0 = 2130903069;
    public static final int originui_button_state_fill_color_rom16_0 = 2130903070;
    public static final int originui_button_stroke_color_rom13_0 = 2130903071;
    public static final int originui_button_stroke_color_rom15_0 = 2130903072;
    public static final int originui_button_sub_title_rom15_0 = 2130903073;
    public static final int originui_button_vivo_blue_rom13_0 = 2130903074;
    public static final int originui_button_vivo_blue_rom15_0 = 2130903075;
    public static final int originui_fab_shadow_color_rom13_0 = 2130903099;
    public static final int white = 2130903112;
}
