package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static final int AnimLayout = 2131427328;
    public static final int AnimLayout_Alpha = 2131427329;
    public static final int AnimLayout_Alpha_Stroke = 2131427330;
    public static final int AnimLayout_Scale = 2131427331;
    public static final int AnimLayout_Scale_Shadow = 2131427332;
    public static final int AnimLayout_Scale_Small = 2131427333;
    public static final int AnimLayout_Scale_Stroke = 2131427334;
    public static final int AnimLayout_Shadow = 2131427335;
    public static final int AnimLayout_Small = 2131427336;
    public static final int VButton = 2131427348;
    public static final int VButton_L = 2131427349;
    public static final int VButton_M = 2131427350;
    public static final int VButton_PAD = 2131427351;
    public static final int VButton_S = 2131427352;
    public static final int VButton_State = 2131427353;
    public static final int VButton_XL = 2131427354;
    public static final int VFabButton = 2131427361;
    public static final int VFabButton_White = 2131427362;
}
