package com.originui.widget.button;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$integer {
    public static final int originui_button_down_duration_rom13_0 = 2131165184;
    public static final int originui_button_sub_text_font_rom13_0 = 2131165185;
    public static final int originui_button_text_font_rom13_0 = 2131165186;
    public static final int originui_button_up_duration_rom13_0 = 2131165187;
}
