package com.originui.widget.button;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.core.utils.x;
import com.originui.core.utils.y;
import com.originui.resmap.ResMapManager;
import com.originui.resmap.bridge.ContextBridge;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    static final Interpolator j1 = new PathInterpolator(0.25f, 0.45f, 0.3f, 1.0f);
    static final Interpolator k1 = new PathInterpolator(0.25f, 0.45f, 0.3f, 1.0f);
    static final Interpolator l1 = new PathInterpolator(0.25f, 0.1f, 0.25f, 1.0f);
    protected int A0;
    protected int B;
    protected int B0;
    protected int C0;
    protected int D0;
    protected int E0;
    protected int F0;
    protected int H0;
    protected ValueAnimator I;
    protected int I0;
    protected ValueAnimator J;
    private int J0;
    protected ValueAnimator K;
    protected ValueAnimator L;
    protected String L0;
    protected float M;
    protected String M0;
    protected float N;
    protected boolean Q;
    private boolean S0;
    protected boolean T;
    private boolean T0;
    protected String U0;
    protected boolean V;
    protected CharSequence V0;
    protected Context W;
    protected int W0;
    protected View X;
    protected boolean Y;
    private boolean Y0;
    protected int Z;
    private boolean Z0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected ImageView f671a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    protected int f672a0;
    private boolean a1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected View f673b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    protected int f674b0;
    protected boolean b1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected TextView f675c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    protected int f676c0;
    private x.a c1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f677d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    protected int f678d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected TextView f679e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    protected int f680e0;
    protected int e1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private NoTouchLinearLayout f681f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    protected int f682f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected float f683g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    protected int f684g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected float f685h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    protected int f686h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected float f687i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    protected int f688i0;
    protected boolean i1;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    protected int f689j;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    protected int f690j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    protected int f691k;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    protected boolean f692k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    protected int f693l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    protected int f695m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    protected int f697n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    protected int f699o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    protected int f700o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    protected int f701p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    protected int f703q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    protected boolean f704q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    protected int f705r;
    protected boolean r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    protected int f706s;
    protected int s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    protected int f707t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected int f708u;
    protected Resources u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    protected ColorStateList f709v;
    protected float v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    protected ColorStateList f710w;
    protected float w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    protected int f711x;
    protected boolean x0;
    protected int y0;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    protected int f713z;
    protected int z0;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    protected final int f712y = p.a(1.0f);
    protected int A = 2;
    protected final Paint C = new Paint(3);
    protected Path D = new Path();
    protected Path E = new Path();
    protected Path F = new Path();
    protected final Path G = new Path();
    protected final RectF H = new RectF();
    protected final float O = 0.3f;
    protected float P = 0.3f;
    protected float R = 1.0f;
    protected final int S = 11711154;
    protected boolean U = VThemeIconUtils.n();

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    protected boolean f694l0 = false;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    protected long f696m0 = 0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    protected boolean f698n0 = false;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    protected boolean f702p0 = false;
    protected float t0 = 1.0f;
    protected float G0 = 1.0f;
    protected float K0 = 1.0f;
    protected long N0 = 2000;
    protected boolean O0 = false;
    protected boolean P0 = false;
    private int Q0 = p.a(32.0f);
    private boolean R0 = com.originui.core.utils.i.a();
    private int X0 = -1;
    private boolean d1 = false;
    private Handler f1 = new e(Looper.getMainLooper());
    protected boolean g1 = false;
    protected boolean h1 = false;

    /* JADX INFO: renamed from: com.originui.widget.button.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0000a extends AnimatorListenerAdapter {
        C0000a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            a.this.f698n0 = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            a.this.f698n0 = false;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements ValueAnimator.AnimatorUpdateListener {
        b() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            a aVar = a.this;
            if ((aVar.B & 1) != 0) {
                View view = aVar.X;
                view.setPivotX(view.getWidth() >> 1);
                View view2 = a.this.X;
                view2.setPivotY(view2.getHeight() >> 1);
                a.this.X.setScaleX(((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue());
                a.this.X.setScaleY(((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue());
                a.this.f687i = ((Float) valueAnimator.getAnimatedValue("strokeWidth")).floatValue();
            }
            a aVar2 = a.this;
            if ((aVar2.B & 2) != 0 && aVar2.X.isEnabled()) {
                a.this.g(valueAnimator);
            }
            a.this.getClass();
            a aVar3 = a.this;
            aVar3.f698n0 = true;
            aVar3.X.invalidate();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends AnimatorListenerAdapter {
        c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            a.this.f698n0 = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            a.this.f698n0 = false;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements VThemeIconUtils.ISystemColorRom14 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f717a;

        d(int i2) {
            this.f717a = i2;
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setMyDynamicColor() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "setMyDynamicColor");
            }
            a.this.o1();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setMyDynamicColorNightMode() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "setMyDynamicColorNightMode");
            }
            a.this.p1();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setSystemColorByDayModeRom14(int[] iArr) {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "setSystemColorByDayModeRom14");
            }
            a aVar = a.this;
            if (aVar.B == 5) {
                aVar.f674b0 = aVar.m(iArr, aVar.f682f0, aVar.f674b0);
                a aVar2 = a.this;
                aVar2.f672a0 = aVar2.m(iArr, aVar2.f680e0, aVar2.f672a0);
                a aVar3 = a.this;
                aVar3.f678d0 = aVar3.k1(iArr, aVar3.f686h0, aVar3.f678d0);
                a aVar4 = a.this;
                aVar4.f676c0 = aVar4.k1(iArr, aVar4.f684g0, aVar4.f676c0);
                if (a.this.E()) {
                    a aVar5 = a.this;
                    aVar5.f697n = aVar5.f674b0;
                    aVar5.f708u = aVar5.f678d0;
                } else {
                    a aVar6 = a.this;
                    aVar6.f697n = aVar6.f672a0;
                    aVar6.f708u = aVar6.f676c0;
                }
                a.this.O();
                return;
            }
            if (aVar.A == 4) {
                aVar.f697n = iArr[2];
                if (VThemeIconUtils.z(iArr) && Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) == Color.parseColor("#000000")) {
                    a aVar7 = a.this;
                    int i2 = iArr[9];
                    aVar7.f689j = i2;
                    aVar7.b(aVar7.f675c, i2);
                    a aVar8 = a.this;
                    int i3 = aVar8.f689j;
                    aVar8.f708u = i3;
                    TextView textView = aVar8.f679e;
                    if (textView != null) {
                        aVar8.b(textView, i3);
                        return;
                    }
                    return;
                }
                return;
            }
            aVar.f689j = iArr[2];
            if (Color.rgb(Color.red(aVar.f697n), Color.green(a.this.f697n), Color.blue(a.this.f697n)) != Color.parseColor("#ffffff")) {
                a.this.f697n = iArr[2];
            }
            if (Color.alpha(a.this.f699o) == 0) {
                a aVar9 = a.this;
                aVar9.f697n = aVar9.f699o;
            } else {
                a aVar10 = a.this;
                if (aVar10.f699o == aVar10.W.getResources().getColor(d.c.v())) {
                    a aVar11 = a.this;
                    aVar11.f697n = aVar11.f699o;
                } else {
                    a aVar12 = a.this;
                    if (aVar12.f699o != aVar12.W.getResources().getColor(d.c.i()) && Color.alpha(a.this.f699o) != 255) {
                        a aVar13 = a.this;
                        if (aVar13.Y) {
                            int i4 = iArr[2];
                            aVar13.f697n = i4;
                            aVar13.f697n = aVar13.f(i4, 10);
                        }
                    }
                }
            }
            a aVar14 = a.this;
            if (aVar14.f699o == aVar14.W.getResources().getColor(d.c.v())) {
                a aVar15 = a.this;
                aVar15.f708u = aVar15.f706s;
            } else {
                if (Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) == Color.parseColor("#ffffff") || Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) == Color.parseColor("#333333") || Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) == Color.parseColor("#000000")) {
                    return;
                }
                a aVar16 = a.this;
                aVar16.b(aVar16.f675c, aVar16.f689j);
                a aVar17 = a.this;
                aVar17.f708u = aVar17.f689j;
            }
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setSystemColorNightModeRom14(int[] iArr) {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "setSystemColorNightModeRom14");
            }
            a aVar = a.this;
            if (aVar.B == 5) {
                aVar.f674b0 = aVar.n(iArr, aVar.f682f0, aVar.f674b0);
                a aVar2 = a.this;
                aVar2.f672a0 = aVar2.n(iArr, aVar2.f680e0, aVar2.f672a0);
                a aVar3 = a.this;
                aVar3.f678d0 = aVar3.l1(iArr, aVar3.f686h0, aVar3.f678d0, aVar3.f674b0);
                a aVar4 = a.this;
                aVar4.f676c0 = aVar4.l1(iArr, aVar4.f684g0, aVar4.f676c0, aVar4.f672a0);
                if (a.this.E()) {
                    a aVar5 = a.this;
                    aVar5.f697n = aVar5.f674b0;
                    aVar5.f708u = aVar5.f678d0;
                } else {
                    a aVar6 = a.this;
                    aVar6.f697n = aVar6.f672a0;
                    aVar6.f708u = aVar6.f676c0;
                }
                a.this.O();
                return;
            }
            if (aVar.A == 4) {
                if (VThemeIconUtils.z(iArr)) {
                    a.this.f697n = iArr[1];
                } else {
                    a.this.f697n = VThemeIconUtils.D(iArr[2]);
                }
                if (VThemeIconUtils.z(iArr) && Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) == Color.parseColor("#ffffff")) {
                    a aVar7 = a.this;
                    int i2 = iArr[8];
                    aVar7.f689j = i2;
                    aVar7.b(aVar7.f675c, i2);
                    a aVar8 = a.this;
                    int i3 = aVar8.f689j;
                    aVar8.f708u = i3;
                    TextView textView = aVar8.f679e;
                    if (textView != null) {
                        aVar8.b(textView, i3);
                        return;
                    }
                    return;
                }
                return;
            }
            if (VThemeIconUtils.z(iArr)) {
                a.this.f689j = iArr[1];
            } else {
                a.this.f689j = VThemeIconUtils.D(iArr[2]);
            }
            if (Color.rgb(Color.red(a.this.f699o), Color.green(a.this.f699o), Color.blue(a.this.f699o)) != Color.parseColor("#ffffff")) {
                if (VThemeIconUtils.z(iArr)) {
                    a.this.f697n = iArr[1];
                } else {
                    a.this.f697n = VThemeIconUtils.D(iArr[2]);
                }
            }
            if (Color.alpha(a.this.f699o) == 0) {
                a aVar9 = a.this;
                aVar9.f697n = aVar9.f699o;
            } else {
                a aVar10 = a.this;
                if (aVar10.f699o == aVar10.W.getResources().getColor(d.c.v())) {
                    a aVar11 = a.this;
                    aVar11.f697n = aVar11.f699o;
                } else {
                    a aVar12 = a.this;
                    if (aVar12.f699o != aVar12.W.getResources().getColor(d.c.i())) {
                        a aVar13 = a.this;
                        if (aVar13.f699o != VThemeIconUtils.j(aVar13.W.getResources().getColor(d.c.i())) && a.this.f699o != VThemeIconUtils.j(Color.parseColor("#579CF8")) && Color.alpha(a.this.f699o) != 255 && a.this.Y) {
                            if (VThemeIconUtils.z(iArr)) {
                                a aVar14 = a.this;
                                int i4 = iArr[1];
                                aVar14.f697n = i4;
                                aVar14.f697n = aVar14.f(i4, 30);
                            } else {
                                a aVar15 = a.this;
                                int i5 = iArr[2];
                                aVar15.f697n = i5;
                                aVar15.f697n = aVar15.f(i5, 20);
                            }
                        }
                    }
                }
            }
            a aVar16 = a.this;
            if (aVar16.f699o == aVar16.W.getResources().getColor(d.c.v())) {
                a aVar17 = a.this;
                aVar17.f708u = aVar17.f706s;
                return;
            }
            if (Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) != Color.parseColor("#ffffff") && Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) != Color.parseColor("#333333") && Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) != Color.parseColor("#000000")) {
                a aVar18 = a.this;
                aVar18.b(aVar18.f675c, aVar18.f689j);
                a aVar19 = a.this;
                aVar19.f708u = aVar19.f689j;
                return;
            }
            if (Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) != Color.parseColor("#ffffff") || Color.rgb(Color.red(a.this.f697n), Color.green(a.this.f697n), Color.blue(a.this.f697n)) != Color.parseColor("#ffffff") || Color.rgb(Color.red(a.this.f706s), Color.green(a.this.f706s), Color.blue(a.this.f706s)) == Color.parseColor("#000000") || !VThemeIconUtils.z(iArr)) {
                a aVar20 = a.this;
                aVar20.f708u = aVar20.f706s;
            } else {
                a.this.f708u = Color.parseColor("#000000");
                a aVar21 = a.this;
                aVar21.b(aVar21.f675c, aVar21.f708u);
            }
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setSystemColorRom13AndLess(float f2) {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "setSystemColorRom13AndLess");
            }
            a.this.q1(this.f717a);
            a.this.O();
        }

        @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
        public void setViewDefaultColor() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "setViewDefaultColor");
            }
            a.this.n1();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends Handler {
        e(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 1) {
                a.this.X.sendAccessibilityEvent(32768);
                a.this.f1.sendEmptyMessageDelayed(2, a.this.N0 + 2000);
                return;
            }
            if (i2 == 2) {
                if (TextUtils.isEmpty(a.this.L0)) {
                    View view = a.this.X;
                    StringBuilder sb = new StringBuilder();
                    a aVar = a.this;
                    sb.append(r.k(aVar.W, R$string.originui_accessibility_downloading, Integer.valueOf((int) (aVar.K0 * 100.0f))));
                    sb.append("%");
                    view.announceForAccessibility(sb.toString());
                } else {
                    a aVar2 = a.this;
                    aVar2.X.announceForAccessibility(aVar2.L0);
                }
                a.this.f1.sendEmptyMessageDelayed(2, a.this.N0 + 1500);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f implements Runnable {
        f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a aVar = a.this;
            if (aVar.g1 && !aVar.f702p0) {
                aVar.Z();
                a.this.Y();
            }
            a.this.g1();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g implements View.OnFocusChangeListener {
        g() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z2) {
            TextView textView;
            if (z2) {
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "View focus");
                    return;
                }
                return;
            }
            a aVar = a.this;
            if (aVar.B == 5 && (textView = aVar.f675c) != null && aVar.f692k0) {
                textView.setMaxLines(1);
                a.this.f675c.setEllipsize(TextUtils.TruncateAt.END);
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "View loses focus");
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class h implements View.OnTouchListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private long f722a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private float f723b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private float f724c;

        h() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.f722a = System.currentTimeMillis();
                this.f723b = motionEvent.getX();
                this.f724c = motionEvent.getY();
                return false;
            }
            if (action != 1) {
                return false;
            }
            long jCurrentTimeMillis = System.currentTimeMillis();
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            if (jCurrentTimeMillis - this.f722a >= 500 || Math.abs(x2 - this.f723b) >= 10.0f || Math.abs(y2 - this.f724c) >= 10.0f) {
                return false;
            }
            a aVar = a.this;
            if (aVar.B != 5 || aVar.f675c == null || aVar.f692k0) {
                return false;
            }
            aVar.L0();
            a.this.X.requestFocus();
            return false;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class i implements ValueAnimator.AnimatorUpdateListener {
        i() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            a aVar = a.this;
            if ((aVar.B & 1) != 0) {
                View view = aVar.X;
                view.setPivotX(view.getWidth() >> 1);
                View view2 = a.this.X;
                view2.setPivotY(view2.getHeight() >> 1);
                a.this.X.setScaleX(((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue());
                a.this.X.setScaleY(((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue());
                a.this.f687i = ((Float) valueAnimator.getAnimatedValue("strokeWidth")).floatValue();
            }
            a aVar2 = a.this;
            if ((aVar2.B & 2) != 0 && aVar2.X.isEnabled()) {
                a.this.g(valueAnimator);
            }
            a.this.getClass();
            a aVar3 = a.this;
            aVar3.f698n0 = true;
            aVar3.X.invalidate();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface j {
    }

    private void N(TypedArray typedArray) {
        int i2 = R$styleable.VButton_android_textColor;
        this.f707t = typedArray.getResourceId(i2, 0);
        int color = this.A == 1 ? this.W.getResources().getColor(d.c.C()) : this.W.getResources().getColor(d.c.c());
        TextView textView = this.f679e;
        if (textView != null && textView.getVisibility() == 0 && this.f707t == 0) {
            color = r.b(this.W, d.c.y());
        }
        int color2 = typedArray.getColor(i2, VThemeIconUtils.v(this.W, "originui.button.text_color", this.f702p0 ? this.f700o0 : color));
        this.f706s = color2;
        this.f708u = color2;
        if (this.Z0 && color2 != this.W.getResources().getColor(d.c.q()) && this.f706s != this.W.getResources().getColor(d.c.t()) && this.f706s != this.W.getResources().getColor(d.c.c())) {
            this.f706s = color;
            this.f708u = color;
        }
        e1(this.f706s);
        int color3 = typedArray.getColor(R$styleable.VButton_stateButtonDefaultColor, this.f699o);
        this.f672a0 = color3;
        this.f680e0 = color3;
        int color4 = typedArray.getColor(R$styleable.VButton_stateButtonSelectedColor, 0);
        this.f674b0 = color4;
        this.f682f0 = color4;
        int color5 = typedArray.getColor(R$styleable.VButton_stateButtonDefaultTextColor, this.f706s);
        this.f676c0 = color5;
        this.f684g0 = color5;
        int color6 = typedArray.getColor(R$styleable.VButton_stateButtonSelectedTextColor, this.f700o0);
        this.f678d0 = color6;
        this.f686h0 = color6;
        if (this.B == 5) {
            int i3 = this.f680e0;
            this.f697n = i3;
            this.f699o = i3;
            int i4 = this.f684g0;
            this.f706s = i4;
            this.f708u = i4;
            e1(i4);
            z0(this.f697n);
        }
    }

    private boolean u() {
        try {
            Class<?> cls = Class.forName("android.view.WindowManagerGlobal");
            Class[] clsArr = new Class[0];
            Method method = cls.getMethod("getWindowManagerService", null);
            method.setAccessible(true);
            Object objInvoke = method.invoke(cls, null);
            Method method2 = objInvoke.getClass().getMethod("getInitialDisplayDensity", Integer.TYPE);
            method2.setAccessible(true);
            int iIntValue = ((Integer) method2.invoke(objInvoke, 0)).intValue();
            WindowManager windowManager = (WindowManager) this.W.getSystemService("window");
            DisplayMetrics displayMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
            int i2 = displayMetrics.densityDpi;
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", "currentDensity=" + i2 + ",defaultDensityDpi=" + iIntValue);
            }
            return i2 > iIntValue;
        } catch (Exception e2) {
            if (m.f583b) {
                m.e("vbutton_6.0.1.8", "getDefaultDisplayDensity," + e2.getMessage());
            }
            return false;
        }
    }

    public int A() {
        return this.f697n;
    }

    public void A0(int i2) {
        if (this.f711x != i2) {
            this.f711x = i2;
            this.A0 = i2;
            this.y0 = i2;
            this.C0 = i2;
            this.E0 = i2;
            this.f713z = i2;
            this.B0 = i2;
            this.z0 = i2;
            this.D0 = i2;
            this.F0 = i2;
            this.X.invalidate();
        }
    }

    public boolean B() {
        return this.U;
    }

    public void B0(boolean z2) {
        if (this.U != z2) {
            this.U = z2;
            if (this.B == 5 && this.f698n0) {
                ValueAnimator valueAnimator = this.K;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.K.end();
                }
                ValueAnimator valueAnimator2 = this.L;
                if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                    this.L.end();
                }
            }
            m1();
        }
    }

    public float C() {
        return this.v0;
    }

    public void C0(boolean z2) {
        if (this.V != z2) {
            this.V = z2;
            m1();
        }
    }

    public boolean D() {
        return this.f694l0;
    }

    public void D0(boolean z2) {
        this.T0 = z2;
    }

    public boolean E() {
        return this.f697n == this.f674b0;
    }

    public void E0(int i2) {
        y.q(this.f675c, i2);
    }

    public int F() {
        return this.f689j;
    }

    public void F0(int i2) {
        if (i2 == this.f695m) {
            ImageView imageView = this.f671a;
            if (imageView != null) {
                imageView.setImageResource(i2);
                return;
            }
            return;
        }
        ImageView imageView2 = this.f671a;
        if (imageView2 != null) {
            if (i2 == -1) {
                imageView2.setVisibility(8);
            } else {
                this.f695m = i2;
                imageView2.setVisibility(0);
                this.f671a.setImageResource(i2);
                if ("layout".equals(this.W.getResources().getResourceTypeName(this.f695m))) {
                    l0(LayoutInflater.from(this.W).inflate(this.f695m, (ViewGroup) null, false));
                }
            }
            s1();
        }
    }

    public float G() {
        return this.f683g;
    }

    public void G0(Drawable drawable) {
        ImageView imageView = this.f671a;
        if (imageView != null) {
            if (drawable == null) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.f671a.setImageDrawable(drawable);
            }
            s1();
        }
    }

    public int H() {
        return this.J0;
    }

    public void H0(int i2) {
        this.f690j0 = i2;
        s1();
    }

    public void I0(boolean z2) {
        this.r0 = z2;
    }

    public void J(Context context, AttributeSet attributeSet, int i2, int i3) {
        int iW;
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "initButtonAttr");
        }
        this.a1 = s.c(context) >= 15.0f;
        boolean zF = k.f(context);
        this.Z0 = zF;
        if (zF) {
            this.W = ResMapManager.byRomVer(context).loadIsolateResourceXml(R$xml.resmap_isolate_button);
        } else {
            this.W = ResMapManager.byRomVer(context);
        }
        this.Q0 = k(this.W, 32.0f);
        this.Y0 = com.originui.core.utils.h.j();
        TypedArray typedArrayObtainTypedArray = ResMapManager.obtainTypedArray(this.W, attributeSet, R$styleable.VButton, i2, i3);
        this.Z0 &= typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vAutoApplyTheme, true);
        this.x0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vIsRightIcon, false);
        this.T0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vFollowNightSystemColor, false);
        this.s0 = typedArrayObtainTypedArray.getInt(R$styleable.VButton_vlimitFontSize, -1);
        this.M = typedArrayObtainTypedArray.getFloat(R$styleable.VButton_scaleX, 0.9f);
        this.N = typedArrayObtainTypedArray.getFloat(R$styleable.VButton_scaleY, 0.9f);
        this.v0 = typedArrayObtainTypedArray.getDimension(R$styleable.VButton_android_maxWidth, -1.0f);
        this.R = typedArrayObtainTypedArray.getFloat(R$styleable.VButton_android_alpha, 1.0f);
        float dimensionPixelSize = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_strokeWidth, k(this.W, 3.0f));
        this.f683g = dimensionPixelSize;
        this.f687i = dimensionPixelSize;
        this.f685h = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_strokeScaleWidth, k(this.W, 2.0f));
        int dimensionPixelSize2 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_fillet, this.Q0);
        this.f711x = dimensionPixelSize2;
        this.f713z = dimensionPixelSize2;
        this.Z = typedArrayObtainTypedArray.getInt(R$styleable.VButton_android_maxLines, 2);
        int iZ = d.c.z();
        if (iZ != 0) {
            this.I0 = typedArrayObtainTypedArray.getColor(R$styleable.VButton_vSubTextColor, this.W.getResources().getColor(iZ));
        }
        this.X0 = typedArrayObtainTypedArray.getInt(R$styleable.VButton_vButton_size, -1);
        int i4 = R$styleable.VButton_android_contentDescription;
        if (typedArrayObtainTypedArray.hasValue(i4)) {
            this.U0 = typedArrayObtainTypedArray.getString(i4);
        }
        TextView textView = this.f675c;
        if (textView != null) {
            textView.setMaxLines(this.Z);
            int i5 = R$styleable.VButton_android_singleLine;
            if (typedArrayObtainTypedArray.hasValue(i5)) {
                this.f675c.setSingleLine(typedArrayObtainTypedArray.getBoolean(i5, false));
            }
            int i6 = R$styleable.VButton_android_marqueeRepeatLimit;
            if (typedArrayObtainTypedArray.hasValue(i6)) {
                this.f675c.setMarqueeRepeatLimit(typedArrayObtainTypedArray.getInt(i6, -1));
            }
            int i7 = R$styleable.VButton_android_focusable;
            if (typedArrayObtainTypedArray.hasValue(i7)) {
                this.f675c.setFocusable(typedArrayObtainTypedArray.getBoolean(i7, false));
            }
            if (typedArrayObtainTypedArray.hasValue(i7)) {
                this.f675c.setFocusableInTouchMode(typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_android_focusableInTouchMode, false));
            }
            int i8 = R$styleable.VButton_android_ellipsize;
            if (typedArrayObtainTypedArray.hasValue(i8)) {
                int i9 = typedArrayObtainTypedArray.getInt(i8, 0);
                if (i9 == 1) {
                    this.f675c.setEllipsize(TextUtils.TruncateAt.START);
                } else if (i9 == 2) {
                    this.f675c.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                } else if (i9 == 3) {
                    this.f675c.setEllipsize(TextUtils.TruncateAt.END);
                } else if (i9 == 4) {
                    this.f675c.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                    this.f675c.setSelected(true);
                }
            }
        }
        this.A = typedArrayObtainTypedArray.getInt(R$styleable.VButton_drawType, this.A);
        if (!q.p()) {
            if (s.c(this.W) < 13.0f && this.f713z == this.Q0) {
                int iK = k(this.W, 12.0f);
                this.f711x = iK;
                this.f713z = iK;
                if (this.X.getMinimumHeight() > k(this.W, 40.0f) || this.X.getMinimumHeight() == 0) {
                    R0(k(this.W, 40.0f));
                }
            } else if (this.X0 == 4 && typedArrayObtainTypedArray.getResourceId(R$styleable.VButton_android_minHeight, 0) == 0) {
                int iX = d.c.x(this.Y0, this.A);
                R0(r.c(this.W, iX));
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "minHeightResId:" + iX + " minHeight:" + r.m(this.X.getMinimumHeight()) + " text:" + typedArrayObtainTypedArray.getString(R$styleable.VButton_android_text));
                }
            }
        }
        int dimensionPixelSize3 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_vLeftTopRadius, this.f713z);
        this.y0 = dimensionPixelSize3;
        this.z0 = dimensionPixelSize3;
        int dimensionPixelSize4 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_vLeftBottomRadius, this.f713z);
        this.A0 = dimensionPixelSize4;
        this.B0 = dimensionPixelSize4;
        int dimensionPixelSize5 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_vRightTopRadius, this.f713z);
        this.C0 = dimensionPixelSize5;
        this.D0 = dimensionPixelSize5;
        int dimensionPixelSize6 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_vRightBottomRadius, this.f713z);
        this.E0 = dimensionPixelSize6;
        this.F0 = dimensionPixelSize6;
        int i10 = R$styleable.VButton_strokeColor;
        this.f693l = typedArrayObtainTypedArray.getResourceId(i10, 0);
        if (q.p()) {
            iW = this.A == 1 ? this.W.getResources().getColor(d.c.C()) : this.W.getResources().getColor(d.c.i());
        } else {
            iW = VThemeIconUtils.w(this.W);
        }
        int color = this.Z0 ? this.W.getResources().getColor(d.c.i()) : VThemeIconUtils.v(this.W, "originui.button.main_color", iW);
        this.f700o0 = color;
        if (!this.Z0) {
            color = typedArrayObtainTypedArray.getColor(i10, color);
        }
        this.f689j = color;
        this.f691k = color;
        int i11 = R$styleable.VButton_fillColor;
        int color2 = typedArrayObtainTypedArray.getColor(i11, this.f700o0);
        this.f697n = color2;
        this.f699o = color2;
        if (this.Z0 && color2 != this.W.getResources().getColor(d.c.v()) && this.f699o != this.W.getResources().getColor(d.c.s()) && this.f699o != this.W.getResources().getColor(d.c.p())) {
            int i12 = this.f700o0;
            this.f697n = i12;
            this.f699o = i12;
        }
        this.f705r = typedArrayObtainTypedArray.getResourceId(i11, 0);
        this.T = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_enableAnim, true);
        int i13 = r.i(this.W, d.c.u());
        int i14 = r.i(this.W, d.c.B());
        E0(typedArrayObtainTypedArray.getInteger(R$styleable.VButton_fontWeight, i13));
        this.W0 = typedArrayObtainTypedArray.getInteger(R$styleable.VButton_subFontWeight, i14);
        this.f688i0 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_vbuttonIconMargin, k(this.W, 8.0f));
        this.f690j0 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VButton_iconSize, -1);
        int i15 = R$styleable.VButton_android_textSize;
        this.w0 = typedArrayObtainTypedArray.getDimensionPixelSize(i15, 16);
        if (this.Y0) {
            if (this.f697n == r.b(this.W, d.c.v())) {
                int iB = r.b(this.W, d.c.w());
                this.f697n = iB;
                this.f699o = iB;
            }
            ContextBridge contextBridgeByDeviceType = ResMapManager.byDeviceType(context);
            int resourceId = typedArrayObtainTypedArray.getResourceId(i15, 0);
            if (resourceId != 0) {
                this.w0 = r.c(contextBridgeByDeviceType, resourceId);
            }
            int resourceId2 = typedArrayObtainTypedArray.getResourceId(R$styleable.VButton_android_paddingTop, 0);
            int iC = resourceId2 != 0 ? r.c(contextBridgeByDeviceType, resourceId2) : -1;
            int resourceId3 = typedArrayObtainTypedArray.getResourceId(R$styleable.VButton_android_paddingBottom, 0);
            int iC2 = resourceId3 != 0 ? r.c(contextBridgeByDeviceType, resourceId3) : -1;
            View view = this.X;
            if (view != null && iC != -1 && iC2 != -1) {
                view.setPaddingRelative(view.getPaddingStart(), iC, this.X.getPaddingEnd(), iC2);
            }
            if (m.f583b) {
                m.i("vbutton_6.0.1.8", "textSizeResId:" + resourceId + " mDefaultSize:" + r.n(this.W, (int) this.w0) + " paddingTopResId:" + resourceId2 + " paddingTop: " + r.m(iC) + " paddingBottomResId:" + resourceId3 + " paddingBottom: " + r.m(iC2) + " text:" + typedArrayObtainTypedArray.getString(R$styleable.VButton_android_text));
            }
        }
        this.f675c.setTextSize(0, this.w0);
        this.f675c.setIncludeFontPadding(typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_android_includeFontPadding, true));
        if (TextUtils.equals(this.W.getResources().getConfiguration().locale.getLanguage(), "zh")) {
            this.f675c.setIncludeFontPadding(false);
        }
        if (s.c(this.W) >= 14.0f || this.A == 1 || q.p()) {
            this.B = typedArrayObtainTypedArray.getInt(R$styleable.VButton_vButtonAnimType, 2);
        } else if (s.c(this.W) <= 13.5f && this.A != 1) {
            this.B = typedArrayObtainTypedArray.getInt(R$styleable.VButton_vButtonAnimType, 1);
        }
        int i16 = R$styleable.VButton_icon;
        int resourceId4 = typedArrayObtainTypedArray.getResourceId(i16, 0);
        this.f695m = resourceId4;
        if (resourceId4 != 0) {
            try {
                if ("layout".equals(this.W.getResources().getResourceTypeName(this.f695m))) {
                    l0(LayoutInflater.from(this.W).inflate(this.f695m, (ViewGroup) null, false));
                } else {
                    G0(typedArrayObtainTypedArray.getDrawable(i16));
                }
            } catch (Exception e2) {
                if (m.f583b) {
                    m.f("vbutton_6.0.1.8", "setCustomIconView error " + this.W.getResources().getResourceName(this.f695m), e2);
                }
                G0(typedArrayObtainTypedArray.getDrawable(R$styleable.VButton_icon));
            }
        }
        this.g1 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vIsAutoAdjustMultiLine, true);
        this.h1 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vIsAutoAdjustRow, false);
        boolean z2 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_isDialogButton, false);
        this.f702p0 = z2;
        if (z2) {
            TextView textView2 = this.f675c;
            textView2.setPadding(textView2.getPaddingLeft(), this.f675c.getPaddingTop(), this.f675c.getPaddingRight(), this.f675c.getPaddingBottom() + k(this.W, 1.0f));
        }
        d1(typedArrayObtainTypedArray.getString(R$styleable.VButton_android_text));
        b1(typedArrayObtainTypedArray.getString(R$styleable.VButton_vSubText));
        N(typedArrayObtainTypedArray);
        M(typedArrayObtainTypedArray);
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + "======mDefaultLeftTopRadius: " + this.z0 + " mSubTitleColor: " + Integer.toHexString(this.I0) + " mTextColor:" + Integer.toHexString(this.f708u) + "padding start:" + r.m(this.X.getPaddingStart()) + " padding top:" + r.m(this.X.getPaddingTop()) + " padding end:" + r.m(this.X.getPaddingEnd()) + " padding bottom:" + r.m(this.X.getPaddingBottom()) + " minHeight:" + r.m(this.X.getMinimumHeight()) + " fill color:" + Integer.toHexString(A()) + " density:" + Resources.getSystem().getDisplayMetrics().density + " weight:" + typedArrayObtainTypedArray.getInteger(R$styleable.VButton_fontWeight, i13) + " textSize:" + r.n(this.W, (int) this.w0) + " fillColor:" + Integer.toHexString(this.f697n));
        }
        this.U = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_followColor, VThemeIconUtils.n());
        this.V = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_followFillet, VThemeIconUtils.o());
        this.Y = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vfollowColorAlpha, true);
        this.X.setEnabled(typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_android_enabled, true));
        this.f692k0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_stateButtonDefaultSelected, false);
        this.f694l0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_stateButtonMultipleAccess, false);
        this.f704q0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_isInterceptFastClick, false);
        this.r0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_isInterceptStateColorComp, false);
        this.S0 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vIsCoverCN, false);
        this.H0 = typedArrayObtainTypedArray.getInt(R$styleable.VButton_android_gravity, -1);
        this.b1 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vIsLoadingBtn, false);
        this.d1 = typedArrayObtainTypedArray.getBoolean(R$styleable.VButton_vIsOpenVibrancyEffect, false);
        this.e1 = typedArrayObtainTypedArray.getInteger(R$styleable.VButton_vOverSeaFillAlpha, -1);
        typedArrayObtainTypedArray.recycle();
        this.X.setWillNotDraw(false);
        O();
        P(this.S0);
        i();
        if (this.x0) {
            View view2 = this.X;
            if (view2 instanceof LinearLayout) {
                View childAt = ((LinearLayout) view2).getChildAt(0);
                View childAt2 = ((LinearLayout) this.X).getChildAt(1);
                ((LinearLayout) this.X).removeViewAt(0);
                ((LinearLayout) this.X).removeViewAt(0);
                ((LinearLayout) this.X).addView(childAt2, 0);
                ((LinearLayout) this.X).addView(childAt, 1);
            }
        }
        int i17 = this.H0;
        if (i17 != -1) {
            View view3 = this.X;
            if (view3 instanceof LinearLayout) {
                ((LinearLayout) view3).setGravity(i17);
            }
        }
        this.X.post(new f());
    }

    public void J0(int i2) {
        this.s0 = i2;
        if (i2 != -1) {
            if (this.g1) {
                Z();
            }
            g1();
        }
    }

    protected void K() {
        if (this.Q) {
            return;
        }
        this.P = VThemeIconUtils.A(this.W) ? 0.4f : 0.3f;
    }

    public void K0(boolean z2) {
        this.b1 = z2;
    }

    public void L(View view) {
        this.X = view;
        if (view instanceof LinearLayout) {
            ((LinearLayout) view).setOrientation(0);
            ((LinearLayout) this.X).setGravity(17);
            if (this.f671a == null) {
                ImageView imageView = new ImageView(((LinearLayout) this.X).getContext());
                this.f671a = imageView;
                imageView.setId(R$id.vbutton_icon);
                this.f671a.setVisibility(8);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                try {
                    ImageView imageView2 = this.f671a;
                    if (imageView2 != null) {
                        ((LinearLayout) this.X).addView(imageView2, layoutParams);
                    }
                } catch (Exception e2) {
                    m.b("vbutton_6.0.1.8", "mIconView init error:" + e2.toString());
                }
            }
            if (this.f681f == null) {
                NoTouchLinearLayout noTouchLinearLayout = new NoTouchLinearLayout(((LinearLayout) this.X).getContext());
                this.f681f = noTouchLinearLayout;
                noTouchLinearLayout.setOrientation(1);
                this.f681f.setGravity(17);
                this.f681f.setClickable(true);
                this.f681f.setFocusable(false);
                this.f681f.setFocusableInTouchMode(false);
                this.f681f.setImportantForAccessibility(2);
                ((LinearLayout) this.X).addView(this.f681f, new LinearLayout.LayoutParams(-2, -2));
            }
            if (this.f675c == null) {
                if (q.p() && this.i1) {
                    NoTouchTextView noTouchTextView = new NoTouchTextView(((LinearLayout) this.X).getContext());
                    this.f675c = noTouchTextView;
                    noTouchTextView.setClickable(true);
                    if (m.f583b) {
                        m.b("vbutton_6.0.1.8", "vIsAuthGoogle");
                    }
                } else {
                    this.f675c = new TextView(((LinearLayout) this.X).getContext());
                }
                this.f675c.setMaxLines(2);
                this.f675c.setEllipsize(TextUtils.TruncateAt.END);
                this.f675c.setId(R$id.vbutton_title);
                this.f675c.setVisibility(8);
                this.f675c.setGravity(17);
                this.f675c.setImportantForAccessibility(2);
                this.f681f.addView(this.f675c, new LinearLayout.LayoutParams(-2, -2));
            }
        } else if (view instanceof Button) {
            this.f675c = (Button) view;
        }
        I();
    }

    public void L0() {
        TextView textView;
        if (this.B != 5 || (textView = this.f675c) == null) {
            return;
        }
        textView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        this.f675c.setMarqueeRepeatLimit(3);
        this.f675c.setFocusable(true);
        this.f675c.setSingleLine(true);
        this.f675c.setFocusableInTouchMode(true);
        this.f675c.setHorizontalFadingEdgeEnabled(true);
        this.f675c.setFadingEdgeLength(this.W.getResources().getDimensionPixelSize(d.c.e()));
    }

    protected void M(TypedArray typedArray) {
        int color = typedArray.getColor(R$styleable.VButton_vDownBgColor, this.W.getResources().getColor(d.c.v()));
        this.f703q = color;
        this.f701p = color;
    }

    public void M0(boolean z2) {
        this.S0 = z2;
        P(z2);
    }

    public void N0(int i2) {
        TextView textView = this.f675c;
        if (textView != null) {
            textView.setMaxHeight(i2);
        }
    }

    protected void O() {
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "initStateButton mIsDefaultSelected=" + this.f692k0 + ",text=" + ((Object) s().getText()) + " mStateButtonSelectedColor:" + Integer.toHexString(this.f674b0) + " mStateButtonSelectedTextColor:" + Integer.toHexString(this.f678d0) + " mStateButtonUnSelectedColor:" + Integer.toHexString(this.f672a0) + " mStateButtonUnSelectedTextColor:" + Integer.toHexString(this.f676c0));
        }
        if (this.B == 5) {
            boolean z2 = this.f692k0;
            this.f697n = z2 ? this.f674b0 : this.f672a0;
            int i2 = z2 ? this.f678d0 : this.f676c0;
            this.f708u = i2;
            b(this.f675c, i2);
            this.X.postInvalidate();
        }
    }

    public void O0(int i2) {
        TextView textView = this.f675c;
        if (textView != null) {
            textView.setMaxLines(i2);
        }
    }

    public void P(boolean z2) {
        TextView textView;
        if (this.B != 5 || (textView = this.f675c) == null) {
            return;
        }
        textView.setMaxLines(1);
        this.f675c.setEllipsize(TextUtils.TruncateAt.END);
        this.f675c.setOnFocusChangeListener(new g());
        if ((TextUtils.equals(this.W.getResources().getConfiguration().locale.getCountry(), "CN") || !(this.X instanceof LinearLayout)) && !z2) {
            return;
        }
        this.X.setOnTouchListener(new h());
    }

    public void P0(float f2) {
        this.v0 = f2;
    }

    public void Q() {
        if ((this.X instanceof LinearLayout) && this.f679e == null && !TextUtils.isEmpty(this.V0)) {
            TextView textView = new TextView(((LinearLayout) this.X).getContext());
            this.f679e = textView;
            textView.setMaxLines(this.g1 ? 2 : 1);
            this.f679e.setEllipsize(TextUtils.TruncateAt.END);
            this.f679e.setId(R$id.vbutton_sub_title);
            this.f679e.setVisibility(8);
            this.f679e.setGravity(17);
            this.f679e.setTextSize(2, 12.0f);
            this.f679e.setFocusableInTouchMode(false);
            this.f679e.setFocusable(false);
            this.f679e.setImportantForAccessibility(2);
            this.f681f.addView(this.f679e, new LinearLayout.LayoutParams(-2, -2));
            if (!q.p() && this.A == 4) {
                com.originui.core.utils.j.f(this.W, this.f675c, 5);
                com.originui.core.utils.j.f(this.W, this.f679e, 4);
                int iC = r.c(this.W, d.c.d());
                int iC2 = r.c(this.W, d.c.d());
                View view = this.X;
                view.setPaddingRelative(view.getPaddingStart(), iC, this.X.getPaddingEnd(), iC2);
            }
            int i2 = this.H0;
            if (i2 != 0) {
                this.f681f.setGravity(i2);
            }
        }
    }

    public void Q0(int i2) {
        this.v0 = i2;
    }

    public boolean R() {
        return this.g1;
    }

    public void R0(int i2) {
        View view = this.X;
        if (view != null) {
            if (view instanceof VBaseButton) {
                ((VBaseButton) view).setMinHeight(i2);
            }
            this.X.setMinimumHeight(i2);
        }
    }

    public boolean S() {
        return this.O0;
    }

    public void S0(boolean z2) {
        this.O0 = z2;
    }

    public boolean T() {
        return false;
    }

    public void T0(float f2) {
        S0(false);
        this.K0 = f2;
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + "----setProgress：" + this.K0);
        }
        if (this.K0 >= 1.0f) {
            S0(true);
            if (X(this.W)) {
                if (TextUtils.isEmpty(this.M0)) {
                    this.X.announceForAccessibility(r.j(this.W, R$string.originui_accessibility_download_complete));
                } else {
                    this.X.announceForAccessibility(this.M0);
                }
            }
            this.K0 = 1.0f;
            j();
        }
        this.X.invalidate();
    }

    protected void U(Canvas canvas, int i2, int i3, boolean z2) {
        this.C.setStyle(Paint.Style.FILL);
        this.C.setStrokeWidth(0.0f);
        int iX = ((this.X instanceof Button) && this.f708u == Color.parseColor("#ffffff")) ? x(this.f697n, this.G0) : this.f697n;
        ColorStateList colorStateList = this.f710w;
        if (colorStateList != null) {
            c(this.f675c, colorStateList);
        } else {
            b(this.f675c, this.f708u);
        }
        this.C.setColor(this.f703q);
        this.D.reset();
        int i4 = this.y0;
        int i5 = this.C0;
        int i6 = this.E0;
        int i7 = this.A0;
        com.originui.core.utils.b.c(canvas, 0.0f, 0.0f, i2, i3, new float[]{i4, i4, i5, i5, i6, i6, i7, i7}, this.C);
        this.C.setColor(iX);
        this.D.reset();
        int i8 = this.J0;
        float f2 = i8 * this.K0;
        float f3 = i3;
        this.E = com.originui.core.utils.b.f(0.0f, 0.0f, i8, f3, this.f711x, this.y0 != 0, this.C0 != 0, this.E0 != 0, this.A0 != 0);
        boolean z3 = this.R0;
        float f4 = this.J0 - f2;
        if (!z3) {
            f4 = -f4;
        }
        if (z3) {
            f2 = (this.J0 * 2) - f2;
        }
        float f5 = f2;
        float f6 = f4;
        Path pathF = com.originui.core.utils.b.f(f6, 0.0f, f5, f3, this.f711x, this.y0 != 0, this.C0 != 0, this.E0 != 0, this.A0 != 0);
        this.F = pathF;
        this.G.op(this.E, pathF, Path.Op.INTERSECT);
        canvas.drawPath(this.G, this.C);
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "mDownloadPathBg bgLeft:0,bgRight:" + this.J0 + ",mDownloadPathProgress progressLeft:" + f6 + ",progressRight:" + f5 + " progress:" + this.K0);
        }
    }

    public void U0(boolean z2) {
        this.f694l0 = z2;
    }

    public void V(Canvas canvas, int i2, int i3, boolean z2) {
        char c2;
        char c3;
        char c4;
        char c5;
        char c6;
        int i4;
        K();
        float f2 = this.f683g / 2.0f;
        if (this.A == 3) {
            this.C.setStyle(Paint.Style.FILL_AND_STROKE);
            this.C.setStrokeWidth(0.0f);
            int iX = ((this.X instanceof Button) && this.f708u == Color.parseColor("#ffffff")) ? x(this.f697n, this.G0) : this.f697n;
            ColorStateList colorStateList = this.f710w;
            if (colorStateList != null) {
                c(this.f675c, colorStateList);
            } else {
                b(this.f675c, this.f708u);
            }
            if (this.d1 && s.f(this.W)) {
                iX = f(Color.rgb(Color.red(iX), Color.green(iX), Color.blue(iX)), 30);
            }
            this.C.setColor(iX);
            this.D.reset();
            boolean z3 = this.R0;
            c3 = 7;
            c4 = 6;
            c5 = 5;
            c6 = 0;
            c2 = 3;
            i4 = 4;
            com.originui.core.utils.b.c(canvas, 0.0f, 0.0f, i2, i3, new float[]{z3 ? this.C0 : this.y0, z3 ? this.C0 : this.y0, z3 ? this.y0 : this.C0, z3 ? this.y0 : this.C0, z3 ? this.A0 : this.E0, z3 ? this.A0 : this.E0, z3 ? this.E0 : this.A0, z3 ? this.E0 : this.A0}, this.C);
        } else {
            c2 = 3;
            c3 = 7;
            c4 = 6;
            c5 = 5;
            c6 = 0;
            i4 = 4;
        }
        if (this.A == 2) {
            int i5 = this.f689j;
            if (!q.p()) {
                b(this.f675c, i5);
            }
            this.C.setStyle(Paint.Style.STROKE);
            this.C.setStrokeWidth(this.f687i);
            this.C.setColor(i5);
            this.D.reset();
            int i6 = this.y0;
            int i7 = this.f712y;
            int i8 = this.C0;
            int i9 = this.E0;
            int i10 = this.A0;
            float[] fArr = new float[8];
            fArr[c6] = i6 - i7;
            fArr[1] = i6 - i7;
            fArr[2] = i8 - i7;
            fArr[c2] = i8 - i7;
            fArr[i4] = i9 - i7;
            fArr[c5] = i9 - i7;
            fArr[c4] = i10 - i7;
            fArr[c3] = i10 - i7;
            com.originui.core.utils.b.c(canvas, f2, f2, i2 - f2, i3 - f2, fArr, this.C);
        }
        if (this.A == 1) {
            ColorStateList colorStateList2 = this.f710w;
            if (colorStateList2 != null) {
                c(this.f675c, colorStateList2);
            } else {
                b(this.f675c, this.f708u);
            }
        }
        if (this.A == i4) {
            U(canvas, i2, i3, true);
        }
    }

    protected void V0(int i2, int i3) {
        if (this.f713z == i2) {
            this.f711x = i3;
        }
        if (this.z0 == i2) {
            this.y0 = i3;
        }
        if (this.B0 == i2) {
            this.A0 = i3;
        }
        if (this.D0 == i2) {
            this.C0 = i3;
        }
        if (this.F0 == i2) {
            this.E0 = i3;
        }
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " setSingleFillet mLeftTopRadius=" + this.y0 + ",mLeftBottomRadius=" + this.A0 + ",mRightTopRadius=" + this.C0 + ",mRightBottomRadius=" + this.E0 + ",defaultFillet=" + i2 + ",currentDefault=" + i3);
        }
    }

    protected void W() {
        if (X(this.W) && !this.f1.hasMessages(2) && this.P0) {
            this.f1.sendEmptyMessageDelayed(2, this.N0 + 7000);
        } else {
            if (!X(this.W) || this.K0 < 1.0f) {
                return;
            }
            this.f1.removeCallbacksAndMessages(null);
            this.X.sendAccessibilityEvent(32768);
        }
    }

    protected void W0(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (TextUtils.isEmpty(this.U0)) {
            StringBuilder sb = new StringBuilder();
            if (this.f694l0) {
                sb.append(this.f692k0 ? r.j(this.W, R$string.originui_accessibility_selection_select_state) : r.j(this.W, R$string.originui_accessibility_selection_unselect_state));
                if (this.f675c != null) {
                    sb.append(",");
                    sb.append(this.f675c.getText());
                }
            } else if (this.f692k0) {
                sb.append(r.j(this.W, R$string.originui_accessibility_selection_select_state));
                if (this.f675c != null) {
                    sb.append(",");
                    sb.append(this.f675c.getText());
                }
                accessibilityNodeInfo.setClickable(false);
            } else {
                TextView textView = this.f675c;
                if (textView != null) {
                    sb.append(textView.getText());
                }
                accessibilityNodeInfo.setClickable(true);
            }
            accessibilityNodeInfo.setContentDescription(sb.toString());
            sb.setLength(0);
        }
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public boolean X(Context context) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) context.getSystemService("accessibility");
        return accessibilityManager != null && accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled();
    }

    public void X0(boolean z2) {
        this.f692k0 = z2;
        O();
    }

    public void Y() {
        if (this.f679e == null) {
            return;
        }
        Context context = this.W;
        float fD = p.d(context, context.getResources().getDimensionPixelSize(d.c.o()));
        Context context2 = this.W;
        float fD2 = p.d(context2, context2.getResources().getDimensionPixelSize(d.c.n()));
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "subText----minSize：" + fD2 + "---maxSize：" + fD + "-----text：" + ((Object) this.f675c.getText()));
        }
        x.b(this.f679e, fD2, fD, 1, false);
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "subText----currentSize：" + p.d(this.W, this.f679e.getTextSize()) + "-----text：" + ((Object) this.f675c.getText()));
        }
    }

    public void Y0(int i2) {
        if (this.f689j != i2) {
            this.f689j = i2;
            this.f691k = i2;
            this.X.invalidate();
        }
    }

    public void Z() {
        float fD;
        if (this.f675c == null) {
            return;
        }
        float fD2 = p.d(this.W, this.w0);
        int i2 = this.X0;
        if (i2 == 2 || i2 == 3 || i2 == 4) {
            if (this.h1) {
                Context context = this.W;
                fD = p.d(context, context.getResources().getDimensionPixelSize(d.c.b()));
            } else {
                Context context2 = this.W;
                fD = p.d(context2, context2.getResources().getDimensionPixelSize(d.c.a()));
            }
        } else if (this.h1) {
            Context context3 = this.W;
            fD = p.d(context3, context3.getResources().getDimensionPixelSize(d.c.k()));
        } else {
            Context context4 = this.W;
            fD = p.d(context4, context4.getResources().getDimensionPixelSize(d.c.j()));
        }
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "buttonText----minSize：" + fD + "-----maxSize：" + fD2 + "-----text：" + ((Object) this.f675c.getText()));
        }
        x.a aVar = new x.a(1.0f, fD2, fD, false);
        this.c1 = aVar;
        int i3 = this.s0;
        if (i3 != -1) {
            aVar.i(i3);
        }
        this.c1.j(this.J0);
        x.c(this.f675c, this.c1);
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "buttonText----currentSize：" + p.d(this.W, this.f675c.getTextSize()) + "-----text：" + ((Object) this.f675c.getText()));
        }
    }

    public void Z0(int i2) {
        float f2 = i2;
        if (this.f683g != f2) {
            this.f683g = f2;
            this.f687i = f2;
            this.X.invalidate();
        }
    }

    public void a0() {
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + "refreshNightModeColor");
        }
        int i2 = this.f700o0;
        int color = q.p() ? this.W.getResources().getColor(d.c.i()) : VThemeIconUtils.w(this.W);
        if (this.f707t != 0) {
            int color2 = this.W.getResources().getColor(this.f707t);
            this.f708u = color2;
            this.f706s = color2;
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " mDefaultTextColorResourceId=" + Integer.toHexString(this.f706s) + ",=" + this.W.getResources().getResourceName(this.f707t) + " text:" + ((Object) s().getText()) + "  mDefaultTextColor:" + Integer.toHexString(this.f706s));
            }
            e1(this.f706s);
        } else if (i2 == this.f708u) {
            int iV = VThemeIconUtils.v(this.W, "originui.button.main_color", color);
            this.f700o0 = iV;
            Context context = this.W;
            if (!this.f702p0) {
                iV = context.getResources().getColor(d.c.c());
            }
            int iV2 = VThemeIconUtils.v(context, "originui.button.text_color", iV);
            this.f706s = iV2;
            this.f708u = iV2;
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " mTextColor=" + Integer.toHexString(this.f708u) + ",mButtonMainColor=" + Integer.toHexString(this.f700o0) + ",isDialogButton=" + this.f702p0 + " text:" + ((Object) s().getText()));
            }
            e1(this.f706s);
        }
        if (this.f693l != 0) {
            int color3 = this.W.getResources().getColor(this.f693l);
            this.f689j = color3;
            this.f691k = color3;
            Y0(color3);
        } else if (i2 == this.f691k) {
            int iV3 = VThemeIconUtils.v(this.W, "originui.button.main_color", color);
            this.f700o0 = iV3;
            this.f689j = iV3;
            this.f691k = iV3;
            Y0(iV3);
        }
        int i3 = this.f695m;
        if (i3 != 0) {
            F0(i3);
        }
        int i4 = this.f705r;
        if (i4 != 0) {
            z0(this.W.getResources().getColor(this.f705r));
        } else if (i2 == i4) {
            int iV4 = VThemeIconUtils.v(this.W, "originui.button.main_color", color);
            this.f700o0 = iV4;
            z0(iV4);
        }
        O();
    }

    public void a1(int i2) {
        Q();
        TextView textView = this.f679e;
        if (textView != null) {
            y.q(textView, i2);
        }
    }

    public void b(TextView textView, int i2) {
        if (textView instanceof VBaseButton) {
            ((VBaseButton) textView).b(i2, false);
        } else {
            textView.setTextColor(i2);
        }
    }

    public void b0(long j2) {
        this.N0 = j2;
    }

    public void b1(CharSequence charSequence) {
        TextView textView;
        this.V0 = charSequence;
        Q();
        if ((this.X instanceof LinearLayout) && (textView = this.f679e) != null) {
            textView.setVisibility(charSequence == null ? 8 : 0);
            if (charSequence == null) {
                return;
            }
        }
        TextView textView2 = this.f679e;
        if (textView2 != null) {
            textView2.setText(charSequence);
            this.f679e.setTextColor(this.I0);
            if (this.g1 && !this.f702p0) {
                Y();
            }
            a1(this.W0);
        }
    }

    public void c(TextView textView, ColorStateList colorStateList) {
        if (textView instanceof VBaseButton) {
            ((VBaseButton) textView).c(colorStateList, false);
        } else {
            textView.setTextColor(colorStateList);
        }
    }

    public void c0(int i2) {
        this.B = i2;
    }

    public void c1(int i2) {
        Q();
        this.I0 = i2;
        TextView textView = this.f679e;
        if (textView != null) {
            textView.setTextColor(i2);
        }
    }

    public void d() {
        int iIntValue;
        float fFloatValue;
        float fFloatValue2;
        float fFloatValue3;
        float fFloatValue4;
        if (this.B != 5) {
            if (this.I == null) {
                ValueAnimator valueAnimator = new ValueAnimator();
                this.I = valueAnimator;
                valueAnimator.setDuration(200L);
                this.I.setInterpolator(j1);
                this.I.addUpdateListener(new i());
                this.I.addListener(new C0000a());
            }
            float f2 = this.f683g;
            float fH = h();
            ValueAnimator valueAnimator2 = this.J;
            if (valueAnimator2 == null || !valueAnimator2.isRunning()) {
                iIntValue = 16777215;
                fFloatValue = fH;
                fFloatValue2 = 1.0f;
                fFloatValue3 = f2;
                fFloatValue4 = 1.0f;
            } else {
                fFloatValue4 = ((Float) this.J.getAnimatedValue("scaleX")).floatValue();
                fFloatValue2 = ((Float) this.J.getAnimatedValue("scaleY")).floatValue();
                fFloatValue3 = ((Float) this.J.getAnimatedValue("strokeWidth")).floatValue();
                fFloatValue = ((Float) this.J.getAnimatedValue("alpha")).floatValue();
                iIntValue = ((Integer) this.J.getAnimatedValue("shadow")).intValue();
                this.J.cancel();
            }
            PropertyValuesHolder propertyValuesHolderOfFloat = PropertyValuesHolder.ofFloat("scaleX", fFloatValue4, this.M);
            PropertyValuesHolder propertyValuesHolderOfFloat2 = PropertyValuesHolder.ofFloat("scaleY", fFloatValue2, this.N);
            PropertyValuesHolder propertyValuesHolderOfFloat3 = PropertyValuesHolder.ofFloat("strokeWidth", fFloatValue3, this.f685h);
            PropertyValuesHolder propertyValuesHolderOfFloat4 = PropertyValuesHolder.ofFloat("alpha", fFloatValue, 0.3f);
            PropertyValuesHolder propertyValuesHolderOfInt = PropertyValuesHolder.ofInt("shadow", iIntValue, 11711154);
            propertyValuesHolderOfInt.setEvaluator(new ArgbEvaluator());
            this.I.setValues(propertyValuesHolderOfFloat, propertyValuesHolderOfFloat2, propertyValuesHolderOfFloat3, propertyValuesHolderOfFloat4, propertyValuesHolderOfInt);
            this.I.start();
        }
    }

    public void d0(boolean z2) {
        this.g1 = z2;
        if (z2) {
            TextView textView = this.f675c;
            if (textView != null) {
                d1(textView.getText().toString());
                return;
            }
            return;
        }
        TextView textView2 = this.f675c;
        if (textView2 != null) {
            textView2.setTextSize(0, this.w0);
            s1();
        }
        TextView textView3 = this.f679e;
        if (textView3 != null) {
            textView3.setTextSize(0, this.W.getResources().getDimensionPixelSize(d.c.o()));
        }
    }

    public void d1(CharSequence charSequence) {
        if (this.X instanceof LinearLayout) {
            this.f675c.setVisibility(charSequence == null ? 8 : 0);
            if (charSequence == null) {
                return;
            }
        }
        this.f675c.setText(charSequence);
        if (this.g1 && !this.f702p0) {
            Z();
        }
        s1();
    }

    public void e() {
        float fFloatValue;
        int iIntValue;
        if (this.B != 5) {
            if (this.J == null) {
                ValueAnimator valueAnimator = new ValueAnimator();
                this.J = valueAnimator;
                valueAnimator.setDuration(250L);
                this.J.setInterpolator(k1);
                this.J.addUpdateListener(new b());
                this.J.addListener(new c());
            }
            float fFloatValue2 = this.M;
            float fFloatValue3 = this.N;
            float fFloatValue4 = this.f685h;
            ValueAnimator valueAnimator2 = this.I;
            if (valueAnimator2 == null || !valueAnimator2.isRunning()) {
                fFloatValue = 0.3f;
                iIntValue = 11711154;
            } else {
                fFloatValue2 = ((Float) this.I.getAnimatedValue("scaleX")).floatValue();
                fFloatValue3 = ((Float) this.I.getAnimatedValue("scaleY")).floatValue();
                fFloatValue4 = ((Float) this.I.getAnimatedValue("strokeWidth")).floatValue();
                fFloatValue = ((Float) this.I.getAnimatedValue("alpha")).floatValue();
                iIntValue = ((Integer) this.I.getAnimatedValue("shadow")).intValue();
                this.I.cancel();
            }
            PropertyValuesHolder propertyValuesHolderOfFloat = PropertyValuesHolder.ofFloat("scaleX", fFloatValue2, 1.0f);
            PropertyValuesHolder propertyValuesHolderOfFloat2 = PropertyValuesHolder.ofFloat("scaleY", fFloatValue3, 1.0f);
            PropertyValuesHolder propertyValuesHolderOfFloat3 = PropertyValuesHolder.ofFloat("strokeWidth", fFloatValue4, this.f683g);
            PropertyValuesHolder propertyValuesHolderOfFloat4 = PropertyValuesHolder.ofFloat("alpha", fFloatValue, h());
            PropertyValuesHolder propertyValuesHolderOfInt = PropertyValuesHolder.ofInt("shadow", iIntValue, 16777215);
            propertyValuesHolderOfInt.setEvaluator(new ArgbEvaluator());
            this.J.setValues(propertyValuesHolderOfFloat, propertyValuesHolderOfFloat2, propertyValuesHolderOfFloat3, propertyValuesHolderOfFloat4, propertyValuesHolderOfInt);
            this.J.start();
        }
    }

    public void e0(boolean z2) {
        TextView textView;
        this.h1 = z2;
        if (!this.g1 || (textView = this.f675c) == null) {
            return;
        }
        d1(textView.getText().toString());
    }

    public void e1(int i2) {
        this.f706s = i2;
        this.f708u = i2;
        b(this.f675c, i2);
    }

    public int f(int i2, int i3) {
        return Color.argb((int) Math.round(((double) Color.alpha(i2)) * (((double) ((int) Math.round(((double) i3) * 2.55d))) / 255.0d)), Color.red(i2), Color.green(i2), Color.blue(i2));
    }

    public void f0(int i2) {
        this.f706s = i2;
        this.f708u = i2;
    }

    public void f1(ColorStateList colorStateList) {
        this.f709v = colorStateList;
        this.f710w = colorStateList;
        c(this.f675c, colorStateList);
    }

    protected abstract void g(ValueAnimator valueAnimator);

    public void g0(ColorStateList colorStateList) {
        this.f709v = colorStateList;
        this.f710w = colorStateList;
    }

    public void g1() {
        if (this.s0 != -1) {
            Configuration configuration = this.W.getResources().getConfiguration();
            this.u0 = this.W.getResources();
            this.t0 = configuration.fontScale;
            this.f675c.setTextSize(0, (this.w0 / configuration.fontScale) * d.a.a(this.W, this.s0));
        }
        if ((this.t0 != 1.0f || u()) && this.y0 == this.E0 && this.A0 == this.Q0) {
            int iA = p.a(100.0f);
            this.f711x = iA;
            this.A0 = iA;
            this.y0 = iA;
            this.C0 = iA;
            this.E0 = iA;
        }
    }

    protected abstract float h();

    protected void h1(int i2) {
        if (this.d1 && s.f(this.W)) {
            try {
                boolean zBooleanValue = ((Boolean) q.m(s(), "setMaterial", 0, 1)).booleanValue();
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "VibrancyEffectIsSupport:" + zBooleanValue);
                }
                q.m(s(), "setVibrancyEffect", Integer.valueOf(i2), 0);
            } catch (Exception e2) {
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "initVButtonVibrancyEffect Error:" + e2.getMessage());
                }
            }
        }
    }

    protected void i0(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (this.X.isEnabled() && this.X.isClickable()) {
            int i2 = this.A;
            if (i2 == 4 && this.K0 < 1.0f) {
                if (S()) {
                    accessibilityNodeInfo.addAction(new AccessibilityNodeInfo.AccessibilityAction(16, r.j(this.W, R$string.originui_accessibility_download_resume_talkback)));
                    return;
                } else {
                    accessibilityNodeInfo.addAction(new AccessibilityNodeInfo.AccessibilityAction(16, r.j(this.W, R$string.originui_accessibility_download_pause_talkback)));
                    return;
                }
            }
            if (i2 == 4 && this.K0 >= 1.0f) {
                accessibilityNodeInfo.removeAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
                return;
            }
            if (this.B != 5) {
                if (this.b1) {
                    accessibilityNodeInfo.removeAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
                    return;
                } else {
                    accessibilityNodeInfo.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
                    return;
                }
            }
            if (this.f694l0) {
                accessibilityNodeInfo.addAction(new AccessibilityNodeInfo.AccessibilityAction(16, r.j(this.W, R$string.originui_accessibility_selection_switch_talkback)));
            } else if (this.f692k0) {
                accessibilityNodeInfo.removeAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
            } else {
                accessibilityNodeInfo.addAction(new AccessibilityNodeInfo.AccessibilityAction(16, r.j(this.W, R$string.originui_accessibility_selection_select_talkback)));
            }
        }
    }

    public void i1(int i2) {
        this.J0 = i2;
    }

    public void j() {
        Handler handler = this.f1;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    public void j0(int i2) {
        this.f688i0 = i2;
        s1();
    }

    protected int j1(int i2, int i3, int i4) {
        if (((Color.alpha(this.f699o) == 0 || y() == 1) && i4 == this.f676c0) || Color.rgb(Color.red(i3), Color.green(i3), Color.blue(i3)) == Color.parseColor("#ffffff") || Color.rgb(Color.red(i3), Color.green(i3), Color.blue(i3)) == Color.parseColor("#333333") || Color.rgb(Color.red(i3), Color.green(i3), Color.blue(i3)) == Color.parseColor("#000000")) {
            return i4;
        }
        b(this.f675c, i2);
        return i2;
    }

    public int k(Context context, float f2) {
        return Math.round(context.getResources().getDisplayMetrics().density * f2);
    }

    protected int k1(int[] iArr, int i2, int i3) {
        return (((Color.alpha(this.f699o) == 0 || y() == 1) && i3 == this.f676c0) || Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) == Color.parseColor("#ffffff") || Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) == Color.parseColor("#333333") || Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) == Color.parseColor("#000000")) ? i3 : iArr[2];
    }

    protected int l(int i2, int i3, int i4) {
        this.f689j = i2;
        if (Color.alpha(i3) == 0 || i3 == this.W.getResources().getColor(d.c.v()) || i3 == this.W.getResources().getColor(d.c.v())) {
            return i4;
        }
        return (i3 == this.W.getResources().getColor(d.c.i()) || Color.alpha(i3) == 255 || !this.Y) ? i2 : f(i2, 10);
    }

    public void l0(View view) {
        View view2;
        if (this.f673b == view) {
            return;
        }
        ImageView imageView = this.f671a;
        if (imageView != null) {
            View view3 = this.X;
            if (view3 instanceof LinearLayout) {
                int iIndexOfChild = ((LinearLayout) view3).indexOfChild(imageView);
                if (iIndexOfChild >= 0) {
                    this.f677d = iIndexOfChild;
                }
                ((LinearLayout) this.X).removeView(this.f671a);
                if (view != null || (view2 = this.f673b) == null) {
                    this.f673b = view;
                    ((LinearLayout) this.X).addView(view, this.f677d);
                } else {
                    ((LinearLayout) this.X).removeView(view2);
                    this.f673b = null;
                }
            }
        }
        s1();
    }

    protected int l1(int[] iArr, int i2, int i3, int i4) {
        if ((Color.alpha(this.f699o) != 0 && y() != 1) || i3 != this.f676c0) {
            if (Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) != Color.parseColor("#ffffff") && Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) != Color.parseColor("#333333") && Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) != Color.parseColor("#000000")) {
                return VThemeIconUtils.z(iArr) ? iArr[1] : VThemeIconUtils.D(iArr[2]);
            }
            if (Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) == Color.parseColor("#ffffff") && Color.rgb(Color.red(i4), Color.green(i4), Color.blue(i4)) == Color.parseColor("#ffffff") && Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)) != Color.parseColor("#000000") && VThemeIconUtils.z(iArr)) {
                return iArr[1];
            }
        }
        return i3;
    }

    protected int m(int[] iArr, int i2, int i3) {
        int i4;
        int i5;
        int i6 = iArr[2];
        if (Color.alpha(i2) == 0) {
            return i2;
        }
        if (i2 == this.W.getResources().getColor(d.c.v()) || i2 == this.W.getResources().getColor(d.c.A()) || i2 == Color.parseColor("#1FFFFFFF")) {
            return this.B == 5 ? f(iArr[5], 4) : iArr[12];
        }
        if (i2 == this.W.getResources().getColor(d.c.i()) || Color.alpha(i2) == 255 || !this.Y) {
            return (this.B == 5 && (i4 = iArr[2]) == -12304834) ? f(i4, 30) : i6;
        }
        return (this.B == 5 && (i5 = iArr[2]) == -12304834) ? f(i5, 30) : f(iArr[2], 10);
    }

    protected void m0(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32768) {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " play has focus.");
            }
            this.P0 = true;
            if (this.A != 4 || this.K0 >= 1.0f || S()) {
                return;
            }
            W();
            return;
        }
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " play has no focus.----isAccessibilityFocused:" + this.X.isAccessibilityFocused());
        }
        this.P0 = false;
        if (this.A != 4 || this.X.isAccessibilityFocused()) {
            return;
        }
        j();
    }

    public void m1() {
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "mFollowColor=" + this.U + ",getFollowSystemColor=" + VThemeIconUtils.n() + ",mFollowNightSystemColor=" + this.T0);
        }
        int iR = VThemeIconUtils.r();
        VThemeIconUtils.t();
        VThemeIconUtils.F(this.W, this.U, new d(iR), this.T0 ? 1 : 0);
        r1();
    }

    protected int n(int[] iArr, int i2, int i3) {
        int i4 = iArr[1];
        if (Color.alpha(i2) == 0) {
            return i2;
        }
        if (i2 == this.W.getResources().getColor(d.c.v()) || i2 == this.W.getResources().getColor(d.c.A()) || i2 == Color.parseColor("#1FFFFFFF")) {
            return f(iArr[12], 12);
        }
        if (i2 == this.W.getResources().getColor(d.c.i()) || i2 == VThemeIconUtils.j(this.W.getResources().getColor(d.c.i())) || i2 == VThemeIconUtils.j(Color.parseColor("#579CF8")) || Color.alpha(i2) == 255 || !this.Y) {
            return (this.B == 5 && VThemeIconUtils.z(iArr)) ? f(iArr[1], 30) : i4;
        }
        if (VThemeIconUtils.z(iArr)) {
            return this.B == 5 ? f(iArr[1], 30) : f(iArr[1], 20);
        }
        return VThemeIconUtils.D(f(iArr[2], 20));
    }

    public void n0(float f2) {
        this.R = f2;
    }

    protected abstract void n1();

    public int o() {
        return this.B;
    }

    protected void o0(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (TextUtils.isEmpty(this.U0)) {
            StringBuilder sb = new StringBuilder();
            TextView textView = this.f675c;
            if (textView != null) {
                sb.append(textView.getText());
            }
            TextView textView2 = this.f679e;
            if (textView2 != null && !TextUtils.isEmpty(textView2.getText())) {
                sb.append(",");
                sb.append(this.f679e.getText());
            }
            accessibilityNodeInfo.setContentDescription(sb.toString());
            sb.setLength(0);
        }
        if (this.b1) {
            accessibilityNodeInfo.setClickable(false);
        } else {
            accessibilityNodeInfo.setClickable(true);
            accessibilityNodeInfo.setClassName(Button.class.getName());
        }
    }

    public int p() {
        return this.f688i0;
    }

    protected void p0(int i2, float f2) {
        if (i2 == 2) {
            this.w0 = p.e(this.W, f2);
        } else {
            this.w0 = f2;
        }
    }

    public ImageView q() {
        return this.f671a;
    }

    public void q0(int i2) {
        if (this.f703q != i2) {
            this.f703q = i2;
            this.f701p = i2;
            this.X.invalidate();
        }
    }

    protected void q1(int i2) {
        int iU = VThemeIconUtils.u();
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", "updateColorRom13 color=" + Integer.toHexString(iU));
        }
        if (iU != -1) {
            if (this.B == 5) {
                this.f674b0 = l(iU, this.f682f0, this.f674b0);
                this.f672a0 = l(iU, this.f680e0, this.f672a0);
                this.f678d0 = j1(iU, this.f686h0, this.f678d0);
                this.f676c0 = j1(iU, this.f684g0, this.f676c0);
                if (E()) {
                    this.f697n = this.f674b0;
                    this.f708u = this.f678d0;
                } else {
                    this.f697n = this.f672a0;
                    this.f708u = this.f676c0;
                }
                O();
                return;
            }
            this.f689j = iU;
            if (Color.alpha(this.f699o) != 0 && this.f699o != this.W.getResources().getColor(d.c.v())) {
                if (this.f699o != this.W.getResources().getColor(d.c.i()) && Color.alpha(this.f699o) != 255 && this.Y) {
                    this.f697n = f(iU, 10);
                } else if (Color.rgb(Color.red(this.f697n), Color.green(this.f697n), Color.blue(this.f697n)) != Color.parseColor("#ffffff")) {
                    this.f697n = iU;
                }
            }
            if (Color.rgb(Color.red(this.f706s), Color.green(this.f706s), Color.blue(this.f706s)) == Color.parseColor("#ffffff") || Color.rgb(Color.red(this.f706s), Color.green(this.f706s), Color.blue(this.f706s)) == Color.parseColor("#333333") || Color.rgb(Color.red(this.f706s), Color.green(this.f706s), Color.blue(this.f706s)) == Color.parseColor("#000000") || this.B == 5) {
                return;
            }
            b(this.f675c, this.f689j);
            this.f708u = this.f689j;
        }
    }

    public TextView r() {
        return this.f679e;
    }

    public void r0(String str) {
        this.L0 = str;
    }

    public void r1() {
        GradientDrawable gradientDrawable;
        int iT = VThemeIconUtils.t();
        if (m.f583b) {
            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " updateFillet mDefaultFillet=" + this.f713z + ",dp2Px(mContext,32)=" + this.Q0 + ",level=" + iT + ",mFollowFillet=" + this.V);
        }
        if (this.V) {
            if (s.g(this.W) || this.a1) {
                if (m.f583b) {
                    m.b("vbutton_6.0.1.8", "mIsRom15_0mButtonSize:" + this.X0 + ",mFillet:" + p.c(this.f711x));
                }
                if (this.X0 == 1) {
                    V0(this.W.getResources().getDimensionPixelSize(d.c.h()), VThemeIconUtils.k(this.W, 102, this.V));
                }
                if (this.X0 == 2) {
                    V0(this.W.getResources().getDimensionPixelSize(d.c.g()), VThemeIconUtils.k(this.W, 102, this.V));
                }
                if (this.X0 == 3) {
                    V0(this.W.getResources().getDimensionPixelSize(d.c.f()), VThemeIconUtils.k(this.W, 103, this.V));
                }
                if (this.X0 == 4) {
                    V0(this.W.getResources().getDimensionPixelSize(d.c.f()), VThemeIconUtils.k(this.W, 103, this.V));
                }
                if (this.B == 5) {
                    V0(this.W.getResources().getDimensionPixelSize(d.c.l()), VThemeIconUtils.k(this.W, 101, this.V));
                    if (iT == 0) {
                        V0(this.W.getResources().getDimensionPixelSize(d.c.m()), k(this.W, 3.0f));
                    } else if (iT == 2) {
                        V0(this.W.getResources().getDimensionPixelSize(d.c.m()), k(this.W, 11.0f));
                    } else if (iT == 3) {
                        V0(this.W.getResources().getDimensionPixelSize(d.c.m()), k(this.W, 16.0f));
                    }
                }
            } else if (iT != 0) {
                if (iT != 2) {
                    if (iT != 3) {
                        this.y0 = this.z0;
                        this.A0 = this.B0;
                        this.C0 = this.D0;
                        this.E0 = this.F0;
                        this.f711x = this.f713z;
                        if (m.f583b) {
                            m.b("vbutton_6.0.1.8", ((Object) s().getText()) + " updateFillet default mLeftTopRadius=" + this.y0 + ",mLeftBottomRadius=" + this.A0 + ",mRightTopRadius=" + this.C0 + ",mRightBottomRadius=" + this.E0);
                        }
                    } else if (this.B == 5) {
                        V0(k(this.W, 18.0f), k(this.W, 35.0f));
                        V0(k(this.W, 8.0f), k(this.W, 16.0f));
                    } else {
                        V0(this.Q0, k(this.W, 63.0f));
                        V0(k(this.W, 24.0f), k(this.W, 48.0f));
                        V0(k(this.W, 24.0f), k(this.W, 48.0f));
                    }
                } else if (this.B == 5) {
                    V0(k(this.W, 18.0f), k(this.W, 25.0f));
                    V0(k(this.W, 8.0f), k(this.W, 11.0f));
                } else {
                    V0(this.Q0, k(this.W, 45.0f));
                    V0(k(this.W, 24.0f), k(this.W, 34.0f));
                    V0(k(this.W, 24.0f), k(this.W, 34.0f));
                }
            } else if (this.B == 5) {
                V0(k(this.W, 18.0f), k(this.W, 6.0f));
                if (this.a1) {
                    V0(k(this.W, 8.0f), k(this.W, 3.0f));
                } else {
                    V0(k(this.W, 8.0f), k(this.W, 4.0f));
                }
            } else {
                V0(this.Q0, k(this.W, 11.0f));
                V0(k(this.W, 24.0f), k(this.W, 8.0f));
                V0(k(this.W, 24.0f), k(this.W, 8.0f));
            }
            View view = this.X;
            if (view == null || !(view.getBackground() instanceof GradientDrawable)) {
                TextView textView = this.f675c;
                if (textView != null && (textView.getBackground() instanceof GradientDrawable) && (gradientDrawable = (GradientDrawable) this.f675c.getBackground().mutate()) != null) {
                    gradientDrawable.setCornerRadius(this.f711x);
                    this.X.setBackground(gradientDrawable);
                }
            } else {
                GradientDrawable gradientDrawable2 = (GradientDrawable) this.X.getBackground().mutate();
                if (gradientDrawable2 != null) {
                    gradientDrawable2.setCornerRadius(this.f711x);
                    this.X.setBackground(gradientDrawable2);
                }
            }
        }
        this.X.invalidate();
    }

    public TextView s() {
        return this.f675c;
    }

    public void s0(String str) {
        this.M0 = str;
    }

    protected void s1() {
        if (this.X instanceof LinearLayout) {
            boolean z2 = this.f671a.getVisibility() == 0;
            boolean z3 = this.f675c.getVisibility() == 0;
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f671a.getLayoutParams();
            View view = this.f673b;
            if (view != null) {
                z2 = view.getVisibility() == 0;
            }
            if (z2 && z3) {
                if (this.x0) {
                    layoutParams.setMarginStart(this.f688i0);
                } else {
                    layoutParams.setMarginEnd(this.f688i0);
                }
            } else if (z2) {
                layoutParams.setMarginEnd(0);
            }
            int i2 = this.f690j0;
            if (i2 != -1) {
                layoutParams.height = i2;
                layoutParams.width = i2;
            }
            this.f671a.setLayoutParams(layoutParams);
            View view2 = this.f673b;
            if (view2 != null) {
                view2.setLayoutParams(layoutParams);
            }
        }
    }

    public int t() {
        return this.f708u;
    }

    protected void t0(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (TextUtils.isEmpty(this.U0)) {
            if (S()) {
                TextView textView = this.f675c;
                if (textView != null) {
                    accessibilityNodeInfo.setContentDescription(textView.getText());
                }
            } else {
                accessibilityNodeInfo.setContentDescription(((int) (this.K0 * 100.0f)) + "%");
            }
            accessibilityNodeInfo.setClassName(Button.class.getName());
        }
        accessibilityNodeInfo.setClickable(true);
    }

    protected void u0(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (TextUtils.isEmpty(this.U0)) {
            if (TextUtils.isEmpty(this.M0)) {
                accessibilityNodeInfo.setContentDescription(r.j(this.W, R$string.originui_accessibility_download_complete));
            } else {
                accessibilityNodeInfo.setContentDescription(this.M0);
            }
        }
        accessibilityNodeInfo.setClickable(false);
    }

    public int v() {
        return this.f706s;
    }

    public void v0(int i2) {
        if (this.A != i2) {
            this.A = i2;
            this.X.invalidate();
        }
    }

    public ColorStateList w() {
        return this.f709v;
    }

    public void w0(boolean z2) {
        this.T = z2;
    }

    protected int x(int i2, float f2) {
        return (16777215 & i2) | (((int) (Color.alpha(i2) * f2)) << 24);
    }

    public void x0(float f2) {
        this.P = f2;
        this.Q = true;
    }

    public int y() {
        return this.A;
    }

    public void y0(boolean z2) {
        m1();
        i();
        this.X.setAlpha(z2 ? this.R : this.P);
        this.X.invalidate();
    }

    public boolean z() {
        return this.T;
    }

    public void z0(int i2) {
        if (this.f697n != i2) {
            this.f697n = i2;
            this.f699o = i2;
            this.X.invalidate();
        }
    }

    public void h0(j jVar) {
    }

    public void k0(int i2) {
    }

    protected void I() {
    }

    protected void i() {
    }

    protected void o1() {
    }

    protected void p1() {
    }

    protected void t1() {
    }
}
