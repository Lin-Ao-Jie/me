package com.originui.widget.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.originui.core.utils.d;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.q;
import j.c;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VButton extends LinearLayout implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final b f643a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f644b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ViewTreeObserver.OnWindowAttachListener f645c;

    public VButton(Context context) {
        this(context, null);
    }

    public void c(AttributeSet attributeSet, int i2, int i3) {
        i.a.i().l(getView(), attributeSet, i2, i3);
    }

    public boolean d() {
        return this.f643a.R();
    }

    public void e() {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.Z();
        }
    }

    public void f(int i2, float f2) {
        getButtonTextView().setTextSize(i2, f2);
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.p0(i2, f2);
        }
    }

    public void g() {
        this.f643a.m1();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    public int getAnimType() {
        return this.f643a.o();
    }

    public ImageView getButtonIconView() {
        return this.f643a.q();
    }

    public TextView getButtonSubTextView() {
        return this.f643a.r();
    }

    public TextView getButtonTextView() {
        return this.f643a.s();
    }

    public int getCurrentTextColor() {
        return this.f643a.t();
    }

    public int getDefaultTextColor() {
        return this.f643a.v();
    }

    public ColorStateList getDefaultTextColorList() {
        return this.f643a.w();
    }

    public int getDrawType() {
        return this.f643a.y();
    }

    public int getFillColor() {
        return this.f643a.A();
    }

    public int getFillet() {
        b bVar = this.f643a;
        if (bVar != null) {
            return bVar.f711x;
        }
        return -1;
    }

    public boolean getFollowColor() {
        return this.f643a.B();
    }

    @Override // j.c
    public j.a getGridRule() {
        return i.a.i().h(getView());
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    public boolean getSelectedMultipleAccess() {
        return this.f643a.D();
    }

    public boolean getStateDefaultSelected() {
        return this.f643a.E();
    }

    public int getStrokeColor() {
        return this.f643a.F();
    }

    public float getStrokeWidth() {
        return this.f643a.G();
    }

    public int getViewWidth() {
        b bVar = this.f643a;
        if (bVar == null) {
            return 0;
        }
        return bVar.H();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (m.f583b) {
            m.b("vbutton_6.0.1.8_VButton", "onAttachedToWindow addOnWindowAttachListener");
        }
        getViewTreeObserver().addOnWindowAttachListener(this.f645c);
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (m.f583b) {
            m.b("vbutton_6.0.1.8_VButton", "onConfigurationChanged shouldAutoUpdateColor:" + this.f644b);
        }
        if (this.f644b) {
            this.f643a.a0();
            invalidate();
        }
        g();
        b bVar = this.f643a;
        if (bVar.g1) {
            bVar.Z();
            this.f643a.g1();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (m.f583b) {
            m.b("vbutton_6.0.1.8_VButton", "onDetachedFromWindow removeOnWindowAttachListener");
        }
        getViewTreeObserver().removeOnWindowAttachListener(this.f645c);
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.j();
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onDraw(Canvas canvas) {
        this.f643a.V(canvas, getWidth(), getHeight(), isEnabled());
        super.onDraw(canvas);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        int measuredWidth;
        b bVar = this.f643a;
        if (bVar != null && bVar.C() != -1.0f && View.MeasureSpec.getMode(i2) != 1073741824) {
            i2 = View.MeasureSpec.makeMeasureSpec((int) this.f643a.C(), Integer.MIN_VALUE);
        }
        b bVar2 = this.f643a;
        if (bVar2 != null && bVar2.g1 && bVar2.f702p0) {
            bVar2.Z();
            this.f643a.Y();
        }
        super.onMeasure(i2, i3);
        b bVar3 = this.f643a;
        if (bVar3 != null && bVar3.s() != null && View.MeasureSpec.getMode(i2) != 1073741824) {
            if (getButtonIconView().getVisibility() == 0) {
                measureChild(getButtonIconView(), i2, i3);
                measuredWidth = getButtonIconView().getMeasuredWidth() + this.f643a.p();
            } else {
                measuredWidth = 0;
            }
            this.f643a.s().measure(View.MeasureSpec.makeMeasureSpec(((getMeasuredWidth() - getPaddingStart()) - getPaddingEnd()) - measuredWidth, Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(0, 0));
        }
        this.f643a.i1(getMeasuredWidth());
        b bVar4 = this.f643a;
        if (bVar4 == null || !bVar4.T() || this.f643a.s() == null || this.f643a.s().getLineCount() <= 1) {
            return;
        }
        setFillet(p.a(40.0f));
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (isEnabled() && this.f643a.z() && isClickable()) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.f643a.d();
            } else if (action == 1 || action == 3 || action == 4) {
                this.f643a.e();
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.view.View
    protected void onVisibilityChanged(View view, int i2) {
        super.onVisibilityChanged(view, i2);
        if (m.f583b) {
            StringBuilder sb = new StringBuilder();
            sb.append("onVisibilityChanged visibility:");
            sb.append(i2 == 0);
            m.b("vbutton_6.0.1.8_VButton", sb.toString());
        }
        if (i2 == 0) {
            this.f643a.m1();
        }
    }

    public void setAccessAnnInterval(long j2) {
        this.f643a.b0(j2);
    }

    public void setAnimType(int i2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.c0(i2);
        }
    }

    public void setAutoAdjustMultiLine(boolean z2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.d0(z2);
        }
    }

    public void setAutoAdjustRow(boolean z2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.e0(z2);
        }
    }

    public void setAutoNightMode(int i2) {
        q.r(this, i2);
        this.f644b = i2 > 0;
    }

    public void setButtonAnimationListener(com.originui.widget.button.a.j jVar) {
        this.f643a.h0(jVar);
    }

    public void setButtonIconMargin(int i2) {
        this.f643a.j0(i2);
    }

    public void setClickNightMode(int i2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.k0(i2);
        }
    }

    public void setCustomIconView(View view) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.l0(view);
        }
    }

    public void setDefaultAlpha(float f2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.n0(f2);
        }
    }

    public void setDownBgColor(int i2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.q0(i2);
        }
    }

    public void setDownLoadAccessName(String str) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.r0(str);
        }
    }

    public void setDownLoadFinishAccessName(String str) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.s0(str);
        }
    }

    public void setDrawType(int i2) {
        this.f643a.v0(i2);
    }

    public void setEnableAnim(boolean z2) {
        this.f643a.w0(z2);
    }

    public void setEnableColor(float f2) {
        this.f643a.x0(f2);
    }

    @Override // android.view.View
    public void setEnabled(boolean z2) {
        super.setEnabled(z2);
        if (m.f583b) {
            m.b("vbutton_6.0.1.8_VButton", "vButton setEnabled:" + z2);
        }
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.y0(z2);
        }
    }

    public void setFillColor(int i2) {
        this.f643a.z0(i2);
    }

    public void setFillet(int i2) {
        this.f643a.A0(i2);
        this.f643a.t1();
    }

    public void setFollowColor(boolean z2) {
        setFollowSystemColor(z2);
    }

    public void setFollowFillet(boolean z2) {
        setFollowSystemFillet(z2);
    }

    public void setFollowNightSystemColor(boolean z2) {
        this.f643a.D0(z2);
    }

    public void setFollowSystemColor(boolean z2) {
        this.f643a.B0(z2);
    }

    public void setFollowSystemFillet(boolean z2) {
        this.f643a.C0(z2);
    }

    public void setFontWeight(int i2) {
        this.f643a.E0(i2);
    }

    public void setIcon(Drawable drawable) {
        this.f643a.G0(drawable);
    }

    public void setIconSize(int i2) {
        this.f643a.H0(i2);
    }

    public void setIsInterceptStateColorComp(boolean z2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.I0(z2);
        }
    }

    public void setLimitFontSize(int i2) {
        this.f643a.J0(i2);
    }

    public void setLoadingBtn(boolean z2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.K0(z2);
        }
    }

    public void setMarqueeIsCoverCN(boolean z2) {
        this.f643a.M0(z2);
    }

    @Deprecated
    public void setMaxHeight(int i2) {
        this.f643a.N0(i2);
    }

    public void setMaxLines(int i2) {
        this.f643a.O0(i2);
    }

    @Deprecated
    public void setMaxWidth(int i2) {
        this.f643a.Q0(i2);
    }

    public void setMinHeight(int i2) {
        setMinimumHeight(i2);
    }

    public void setMinWidth(int i2) {
        setMinimumWidth(i2);
    }

    public void setNightMode(int i2) {
        try {
            super.setNightMode(i2);
        } catch (Throwable th) {
            if (m.f583b) {
                m.e("vbutton_6.0.1.8_VButton", "setNightMode error:" + th.getMessage());
            }
        }
        this.f644b = i2 > 0;
    }

    public void setPauseDownLoad(boolean z2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.S0(z2);
        }
    }

    public void setProgress(float f2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.T0(f2);
        }
    }

    public void setSelectedMultipleAccess(boolean z2) {
        this.f643a.U0(z2);
    }

    public void setShouldAutoUpdateColor(int i2) {
        this.f644b = i2 > 0;
    }

    public void setStateDefaultSelected(boolean z2) {
        this.f643a.X0(z2);
    }

    public void setStrokeColor(int i2) {
        this.f643a.Y0(i2);
    }

    public void setStrokeWidth(int i2) {
        this.f643a.Z0(i2);
    }

    public void setSubFontWeight(int i2) {
        this.f643a.a1(i2);
    }

    public void setSubText(CharSequence charSequence) {
        this.f643a.b1(charSequence);
    }

    public void setSubTextColor(int i2) {
        this.f643a.c1(i2);
    }

    public void setText(CharSequence charSequence) {
        this.f643a.d1(charSequence);
    }

    public void setTextColor(int i2) {
        this.f643a.e1(i2);
    }

    public void setTextMaxHeight(int i2) {
        this.f643a.N0(i2);
    }

    public void setTextMaxWidth(int i2) {
        this.f643a.Q0(i2);
    }

    public void setTextSize(float f2) {
        f(2, f2);
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.p0(2, f2);
        }
    }

    public void setVButtonVibrancyEffect(int i2) {
        b bVar = this.f643a;
        if (bVar != null) {
            bVar.h1(i2);
        }
    }

    public VButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.generateLayoutParams(layoutParams);
    }

    public void setIcon(int i2) {
        this.f643a.F0(i2);
    }

    public void setMaxWidth(float f2) {
        this.f643a.P0(f2);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f643a.f1(colorStateList);
    }

    public VButton(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VButton(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        b bVar = new b();
        this.f643a = bVar;
        this.f644b = false;
        this.f645c = new a();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VButton, i2, i3);
        bVar.i1 = typedArrayObtainStyledAttributes.getBoolean(R$styleable.VButton_vIsAuthGoogle, false);
        typedArrayObtainStyledAttributes.recycle();
        bVar.L(this);
        bVar.J(context, attributeSet, i2, i3);
        q.r(this, 0);
        d.i(this, "6.0.1.8");
        c(attributeSet, i2, i3);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements ViewTreeObserver.OnWindowAttachListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnWindowAttachListener
        public void onWindowDetached() {
            if (m.f583b) {
                m.b("vbutton_6.0.1.8_VButton", "onWindowDetached");
            }
            VButton.this.getViewTreeObserver().removeOnWindowAttachListener(VButton.this.f645c);
            if (VButton.this.f643a != null) {
                VButton.this.f643a.j();
            }
        }

        @Override // android.view.ViewTreeObserver.OnWindowAttachListener
        public void onWindowAttached() {
        }
    }

    public View getView() {
        return this;
    }
}
