package com.originui.widget.button;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b extends com.originui.widget.button.a {
    public static final int n1 = R$style.VButton;
    public static final int o1 = R$style.VButton_S;
    public static final int p1 = R$style.VButton_L;
    public static final int q1 = R$style.VButton_M;
    public static final int r1 = R$style.VButton_XL;
    public static final int s1 = R$style.AnimLayout_Small;
    public static final int t1 = R$style.AnimLayout_Scale_Small;
    public static final int u1 = R$style.AnimLayout_Alpha;
    public static final int v1 = R$style.AnimLayout_Shadow;
    public static final int w1 = R$style.AnimLayout_Scale_Shadow;
    public static final int x1 = R$style.AnimLayout_Scale_Stroke;
    public static final int y1 = R$style.AnimLayout_Alpha_Stroke;
    private LinearLayout m1;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends View.AccessibilityDelegate {
        a() {
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            b.this.m0(accessibilityEvent);
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
            b bVar = b.this;
            int i2 = bVar.A;
            if (i2 == 4 && bVar.K0 < 1.0f) {
                bVar.t0(accessibilityNodeInfo);
            } else if (i2 == 4 && bVar.K0 >= 1.0f) {
                bVar.u0(accessibilityNodeInfo);
            } else if (bVar.B == 5) {
                bVar.W0(accessibilityNodeInfo);
            } else {
                bVar.o0(accessibilityNodeInfo);
            }
            b.this.i0(accessibilityNodeInfo);
        }
    }

    @Override // com.originui.widget.button.a
    protected void I() {
        super.I();
        LinearLayout linearLayout = this.m1;
        if (linearLayout != null) {
            linearLayout.setFocusable(false);
            this.m1.setFocusableInTouchMode(false);
            this.m1.setImportantForAccessibility(2);
        }
        this.X.setAccessibilityDelegate(new a());
    }

    @Override // com.originui.widget.button.a
    protected void g(ValueAnimator valueAnimator) {
        if ((this.X instanceof Button) && this.A == 3 && this.f708u == Color.parseColor("#ffffff")) {
            this.G0 = ((Float) valueAnimator.getAnimatedValue("alpha")).floatValue();
        } else {
            this.X.setAlpha(((Float) valueAnimator.getAnimatedValue("alpha")).floatValue());
        }
    }

    @Override // com.originui.widget.button.a
    protected float h() {
        return 1.0f;
    }

    @Override // com.originui.widget.button.a
    protected void n1() {
        this.f689j = this.f691k;
        this.f697n = this.f699o;
        e1(this.f706s);
        if (this.f679e != null) {
            c1(this.I0);
        }
        if (this.B == 5) {
            this.f676c0 = this.f684g0;
            this.f678d0 = this.f686h0;
            this.f672a0 = this.f680e0;
            this.f674b0 = this.f682f0;
            O();
        }
    }
}
