package com.originui.widget.responsive;

import android.content.Context;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.ConstraintLayout;
import g.e;
import g.f;
import g.j;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VGridConstraintLayout extends ConstraintLayout implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private j f1106a;

    public VGridConstraintLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // g.f
    public e getGridContainer() {
        return this.f1106a;
    }

    public VGridConstraintLayout(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public VGridConstraintLayout(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f1106a = new j(this, context, attributeSet, i2, i3);
    }
}
