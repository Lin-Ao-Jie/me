package com.originui.widget.responsive;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static final int component = 2131099653;
    public static final int indent = 2131099677;
    public static final int margin_20 = 2131099686;
    public static final int margin_24 = 2131099687;
    public static final int margin_intent = 2131099688;
    public static final int padding_intent = 2131099717;
    public static final int permut = 2131099719;
    public static final int spring = 2131099732;
    public static final int window = 2131099750;
}
