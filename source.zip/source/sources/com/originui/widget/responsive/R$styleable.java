package com.originui.widget.responsive;

import com.vivo.vmdri.R;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$styleable {
    public static final int[] GridLayout = {R.attr.vCustomDefaultIndent, R.attr.vFoldPageMargin, R.attr.vGridAdapter, R.attr.vGridColumn, R.attr.vGridGutter, R.attr.vGridIndentOffset, R.attr.vGridMargin, R.attr.vGridReference, R.attr.vIndentType, R.attr.vIntentStyle, R.attr.vIsCardStyle, R.attr.vIsGridIndent, R.attr.vIsLeftSplitScreen, R.attr.vIsSplitScreen, R.attr.vLargeOp, R.attr.vMaxOp, R.attr.vMediumOp, R.attr.vMinOp, R.attr.vSmallOp, R.attr.vUseDisplayCutout, R.attr.vUseFullColumn};
    public static final int GridLayout_vCustomDefaultIndent = 0;
    public static final int GridLayout_vFoldPageMargin = 1;
    public static final int GridLayout_vGridAdapter = 2;
    public static final int GridLayout_vGridColumn = 3;
    public static final int GridLayout_vGridGutter = 4;
    public static final int GridLayout_vGridIndentOffset = 5;
    public static final int GridLayout_vGridMargin = 6;
    public static final int GridLayout_vGridReference = 7;
    public static final int GridLayout_vIndentType = 8;
    public static final int GridLayout_vIntentStyle = 9;
    public static final int GridLayout_vIsCardStyle = 10;
    public static final int GridLayout_vIsGridIndent = 11;
    public static final int GridLayout_vIsLeftSplitScreen = 12;
    public static final int GridLayout_vIsSplitScreen = 13;
    public static final int GridLayout_vLargeOp = 14;
    public static final int GridLayout_vMaxOp = 15;
    public static final int GridLayout_vMediumOp = 16;
    public static final int GridLayout_vMinOp = 17;
    public static final int GridLayout_vSmallOp = 18;
    public static final int GridLayout_vUseDisplayCutout = 19;
    public static final int GridLayout_vUseFullColumn = 20;
}
