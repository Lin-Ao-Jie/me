package com.originui.widget.responsive;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.LinearLayout;
import g.a;
import g.g;
import g.i;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ResLinearLayout extends LinearLayout implements g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private a f1104a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f1105b;

    public ResLinearLayout(Context context) {
        super(context);
        this.f1104a = new a();
        this.f1105b = context;
        c(this);
    }

    public void c(g gVar) {
        this.f1104a.b(gVar);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // g.g
    public /* bridge */ /* synthetic */ Context getResponsiveContext() {
        return super.getResponsiveContext();
    }

    @Override // g.g
    public Activity getResponsiveSubject() {
        Context context = this.f1105b;
        if (context instanceof Activity) {
            return (Activity) context;
        }
        return null;
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1104a.a(configuration);
    }

    @Override // g.g
    public /* bridge */ /* synthetic */ void setActivity(Activity activity) {
        super.setActivity(activity);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.generateLayoutParams(layoutParams);
    }

    public ResLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1104a = new a();
        this.f1105b = context;
        c(this);
    }

    public ResLinearLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1104a = new a();
        this.f1105b = context;
        c(this);
    }

    @Override // g.g
    public void b(i iVar) {
    }

    @Override // g.g
    public void a(Configuration configuration, i iVar, boolean z2) {
    }
}
