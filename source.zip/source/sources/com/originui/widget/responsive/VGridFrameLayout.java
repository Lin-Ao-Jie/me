package com.originui.widget.responsive;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.FrameLayout;
import g.a;
import g.d;
import g.e;
import g.f;
import g.i;
import g.j;
import k.b;
import k.g;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VGridFrameLayout extends FrameLayout implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private j f1107a;

    public VGridFrameLayout(Context context) {
        this(context, null);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ a getBaseStateManager() {
        return super.getBaseStateManager();
    }

    public b getBreakPointChangeListener() {
        return new g(this);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ int getCalculateBarHeight() {
        return super.getCalculateBarHeight();
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ int getCustomDefaultIndent() {
        return super.getCustomDefaultIndent();
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ int getFoldPageMargin() {
        return super.getFoldPageMargin();
    }

    @Override // g.f
    public e getGridContainer() {
        return this.f1107a;
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ int getGridIndent() {
        return super.getGridIndent();
    }

    @Override // g.f, j.c
    public /* bridge */ /* synthetic */ j.a getGridRule() {
        return super.getGridRule();
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ int getIndentType() {
        return super.getIndentType();
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ boolean getIsDisplayCutout() {
        return super.getIsDisplayCutout();
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ int getOffset() {
        return super.getOffset();
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ i getResponsiveState() {
        return super.getResponsiveState();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1107a.r(configuration);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setCardStyle(boolean z2) {
        super.setCardStyle(z2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setCustomDefaultIndent(int i2) {
        super.setCustomDefaultIndent(i2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setCustomResponsiveState(i iVar) {
        super.setCustomResponsiveState(iVar);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setFoldPageMargin(int i2) {
        super.setFoldPageMargin(i2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setFullColumn(boolean z2) {
        super.setFullColumn(z2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setGridIndent(boolean z2) {
        super.setGridIndent(z2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setGridIndentListener(d dVar) {
        super.setGridIndentListener(dVar);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setIndentStyle(int i2) {
        super.setIndentStyle(i2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setIndentType(int i2) {
        super.setIndentType(i2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setLeftSplitScreen(boolean z2) {
        super.setLeftSplitScreen(z2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setOffset(int i2) {
        super.setOffset(i2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setSplitScreen(boolean z2) {
        super.setSplitScreen(z2);
    }

    @Override // g.f, g.e
    public /* bridge */ /* synthetic */ void setUseDisplayCutout(boolean z2) {
        super.setUseDisplayCutout(z2);
    }

    public VGridFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VGridFrameLayout(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VGridFrameLayout(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f1107a = new j(this, context, attributeSet, i2, i3);
    }
}
