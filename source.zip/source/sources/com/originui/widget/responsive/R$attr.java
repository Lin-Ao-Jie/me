package com.originui.widget.responsive;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static final int vCustomDefaultIndent = 2130837692;
    public static final int vFoldPageMargin = 2130837698;
    public static final int vGridAdapter = 2130837701;
    public static final int vGridColumn = 2130837702;
    public static final int vGridGutter = 2130837703;
    public static final int vGridIndentOffset = 2130837704;
    public static final int vGridMargin = 2130837705;
    public static final int vGridReference = 2130837706;
    public static final int vIndentType = 2130837707;
    public static final int vIntentStyle = 2130837708;
    public static final int vIsCardStyle = 2130837712;
    public static final int vIsGridIndent = 2130837714;
    public static final int vIsLeftSplitScreen = 2130837715;
    public static final int vIsSplitScreen = 2130837719;
    public static final int vLargeOp = 2130837721;
    public static final int vMaxOp = 2130837724;
    public static final int vMediumOp = 2130837725;
    public static final int vMinOp = 2130837726;
    public static final int vSmallOp = 2130837740;
    public static final int vUseDisplayCutout = 2130837743;
    public static final int vUseFullColumn = 2130837744;
}
