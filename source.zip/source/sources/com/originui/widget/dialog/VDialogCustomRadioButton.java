package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import com.originui.core.utils.k;
import com.originui.widget.selection.VRadioButton;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogCustomRadioButton extends VRadioButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f894a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f895b;

    public VDialogCustomRadioButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VDialogCustomRadioButton(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VDialogCustomRadioButton(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f894a = 0;
        this.f895b = 0;
        this.f894a = context.getResources().getConfiguration().uiMode;
        if (i.i(context)) {
            int iD = k.d(context, "dialog_text_color", "color", "vivo");
            this.f895b = iD;
            if (iD != 0) {
                setTextColor(context.getResources().getColor(this.f895b));
            }
        }
    }
}
