package com.originui.widget.dialog;

import android.view.MotionEvent;
import android.view.ViewGroup;
import com.originui.widget.scrollbar.VFastScroller;
import com.originui.widget.scrollbar.VFastScrollerBuilder;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class e extends com.originui.widget.dialog.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private VFastScroller f1030b;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class a implements VFastScroller.ViewHelper {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final ViewGroup f1031a;

        a(ViewGroup viewGroup) {
            this.f1031a = viewGroup;
        }
    }

    public e(ViewGroup viewGroup) {
        super(viewGroup);
        this.f1030b = null;
        try {
            this.f1030b = (VFastScroller) this.f900a;
        } catch (Throwable unused) {
        }
    }

    @Override // com.originui.widget.dialog.a
    public Object b() {
        return this.f1030b;
    }

    @Override // com.originui.widget.dialog.a
    protected Object c(ViewGroup viewGroup) {
        try {
            VFastScroller vFastScrollerBuild = new VFastScrollerBuilder(viewGroup).setPadding(0, 0, 0, 0).setViewHelper(new a(viewGroup)).build();
            vFastScrollerBuild.setFastScrollBarEnabled(false);
            vFastScrollerBuild.setScrollBarEnabled(true);
            vFastScrollerBuild.setTextPopupViewEnabled(false);
            return vFastScrollerBuild;
        } catch (Throwable unused) {
            return null;
        }
    }

    @Override // com.originui.widget.dialog.a
    public void d() {
        VFastScroller vFastScroller = this.f1030b;
        if (vFastScroller != null) {
            vFastScroller.onScrollChanged();
        }
    }

    @Override // com.originui.widget.dialog.a
    public void e(float f2) {
        VFastScroller vFastScroller = this.f1030b;
        if (vFastScroller != null) {
            vFastScroller.onScrollChanged(f2);
        }
    }

    @Override // com.originui.widget.dialog.a
    public boolean f(MotionEvent motionEvent) {
        VFastScroller vFastScroller = this.f1030b;
        if (vFastScroller != null) {
            return vFastScroller.onTouchEvent(motionEvent);
        }
        return false;
    }

    @Override // com.originui.widget.dialog.a
    public void g() {
        VFastScroller vFastScroller = this.f1030b;
        if (vFastScroller != null) {
            vFastScroller.refreshColors();
        }
    }

    @Override // com.originui.widget.dialog.a
    public void h(int i2, int i3, int i4, int i5) {
        VFastScroller vFastScroller = this.f1030b;
        if (vFastScroller != null) {
            vFastScroller.setScrollbarPadding(i3, i5);
        }
    }

    @Override // com.originui.widget.dialog.a
    public void i(boolean z2) {
        VFastScroller vFastScroller = this.f1030b;
        if (vFastScroller != null) {
            vFastScroller.setScrollBarEnabled(z2);
        }
    }
}
