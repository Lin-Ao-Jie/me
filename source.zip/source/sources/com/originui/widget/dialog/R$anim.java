package com.originui.widget.dialog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$anim {
    public static final int originui_dialog_center_window_enter_interpolator_rom13_5 = 2130771972;
    public static final int originui_dialog_center_window_enter_interpolator_rom13_5_loading = 2130771973;
    public static final int originui_dialog_center_window_enter_interpolator_second_rom13_5 = 2130771974;
    public static final int originui_dialog_center_window_enter_rom_13_5 = 2130771975;
    public static final int originui_dialog_center_window_enter_rom_13_5_loading = 2130771976;
    public static final int originui_dialog_center_window_exit_interpolator_rom13_5 = 2130771977;
    public static final int originui_dialog_center_window_exit_rom13_5 = 2130771978;
    public static final int originui_dialog_center_window_exit_rom13_5_loading = 2130771979;
    public static final int originui_dialog_center_window_interpolator_rom13_5 = 2130771980;
    public static final int originui_dialog_menu_enter_interpolator_rom13_5 = 2130771981;
    public static final int originui_dialog_menu_enter_interpolator_rom14_0_ime = 2130771982;
    public static final int originui_dialog_menu_exit_interpolator_rom13_5 = 2130771983;
    public static final int originui_dialog_menu_exit_interpolator_rom14_0 = 2130771984;
    public static final int originui_dialog_menu_exit_interpolator_rom14_0_ime = 2130771985;
    public static final int originui_dialog_menu_exit_interpolator_rom14_0_ime_alpha = 2130771986;
    public static final int originui_dialog_menu_window_enter_rom13_5 = 2130771987;
    public static final int originui_dialog_menu_window_enter_rom14_0_ime = 2130771988;
    public static final int originui_dialog_menu_window_enter_special = 2130771989;
    public static final int originui_dialog_menu_window_enter_spring_back_interpolator_rom13_5 = 2130771990;
    public static final int originui_dialog_menu_window_exit_rom13_5 = 2130771991;
    public static final int originui_dialog_menu_window_exit_rom14_0 = 2130771992;
    public static final int originui_dialog_menu_window_exit_rom14_0_ime = 2130771993;
    public static final int originui_dialog_menu_window_exit_special = 2130771994;
    public static final int originui_dialog_menu_window_exit_spring_back_interpolator_rom13_5 = 2130771995;
}
