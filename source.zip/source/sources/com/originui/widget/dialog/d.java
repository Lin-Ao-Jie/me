package com.originui.widget.dialog;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.core.utils.y;
import com.originui.resmap.ResMapManager;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.ViewAttrConstant;
import com.originui.resmap.bridge.ContextBridge;
import com.originui.widget.button.VButton;
import com.originui.widget.vclickdrawable.VListItemSelectorDrawable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
class d {
    private Drawable A;
    private Drawable C;
    private ImageView D;
    private TextView E;
    private TextView F;
    private TextView G;
    private View H;
    private ImageButton I;
    ListAdapter J;
    private final int L;
    int M;
    int N;
    int O;
    int P;
    private final boolean Q;
    private VCustomRoundRectLayout S;
    private VDialogButtonPanel T;
    private VCustomScrollView U;
    private VBoundsCoverView V;
    private VCustomScrollView W;
    private View X;
    private View Y;
    private View Z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f910a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final Dialog f912b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Window f914c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final int f916d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private CharSequence f918e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private CharSequence f920f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    private View f921f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private CharSequence f922g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    private View f923g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    ListView f924h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    private int f925h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private View f926i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    private int f927i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f928j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f930k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f932l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f934m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    private boolean f935m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f936n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    private boolean f937n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    private boolean f939o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    VButton f940p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    private boolean f941p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private CharSequence f942q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    Handler f943q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    Message f944r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private Drawable f945s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    VButton f946t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private CharSequence f947u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    Message f948v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private Drawable f949w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    VButton f950x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private CharSequence f951y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    Message f952z;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private boolean f938o = false;
    private int B = 0;
    int K = -1;
    private int R = 3;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    private boolean f911a0 = true;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    private int f913b0 = -1;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    private final int f915c0 = p.a(60.0f);

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    private int f917d0 = -1;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    private int f919e0 = 150;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    private boolean f929j0 = false;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    private boolean f931k0 = false;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    private boolean f933l0 = false;
    private boolean r0 = false;
    private boolean s0 = true;
    private final View.OnClickListener t0 = new a();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Message messageObtain;
            Message message;
            Message message2;
            Message message3;
            m.i("VDialog/VController", "click button id:" + view.getId());
            d dVar = d.this;
            if (view == dVar.f940p && (message3 = dVar.f944r) != null) {
                messageObtain = Message.obtain(message3);
            } else if (view != dVar.f946t || (message2 = dVar.f948v) == null) {
                messageObtain = (view != dVar.f950x || (message = dVar.f952z) == null) ? null : Message.obtain(message);
            } else {
                messageObtain = Message.obtain(message2);
            }
            if (messageObtain != null) {
                messageObtain.sendToTarget();
            }
            d.this.f943q0.obtainMessage(1, null).sendToTarget();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements View.OnApplyWindowInsetsListener {
        b() {
        }

        @Override // android.view.View.OnApplyWindowInsetsListener
        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            d.this.h0();
            return windowInsets;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements View.OnLayoutChangeListener {
        c() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
            m.b("VDialog/VController", "dialogBackgroundLayout onLayoutChange layoutHeight = " + (i5 - i3));
            if (com.originui.widget.dialog.i.A(d.this.f910a) && d.this.s0) {
                if (com.originui.widget.dialog.i.a() > (((view.getMeasuredHeight() - d.this.W.getPaddingTop()) - d.this.W.getPaddingBottom()) - d.this.Y.getMeasuredHeight()) - d.this.Z.getMeasuredHeight()) {
                    if (d.this.f911a0) {
                        d.this.f911a0 = false;
                        d.this.W.setSupportScrollable(true);
                        d.this.U.setSupportScrollable(false);
                        d.this.U.requestLayout();
                        d.this.W.requestLayout();
                        return;
                    }
                    return;
                }
                if (d.this.f911a0) {
                    return;
                }
                d.this.f911a0 = true;
                d.this.W.setSupportScrollable(false);
                d.this.U.setSupportScrollable(true);
                d.this.W.requestLayout();
                d.this.U.requestLayout();
            }
        }
    }

    /* JADX INFO: renamed from: com.originui.widget.dialog.d$d, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0003d implements VCustomScrollView.b {
        C0003d() {
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void a() {
            if (d.this.f929j0) {
                d.this.f921f0.setVisibility(0);
                if (d.this.X != null) {
                    d.this.X.setVisibility(0);
                }
            }
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void b() {
            if (d.this.f929j0) {
                d.this.f921f0.setVisibility(4);
            }
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void c(boolean z2) {
            m.b("VDialog/VController", "topScrollView onScrollableChanged scrollable = " + z2);
            d.this.f929j0 = z2;
            d.this.U.setClickable(d.this.f929j0);
            d.this.U.setFocusable(d.this.f929j0);
            if (d.this.f929j0) {
                d.this.f921f0.setVisibility(0);
                if (d.this.X != null) {
                    d.this.X.setVisibility(0);
                }
                if (d.this.U.getScrollY() <= 0) {
                    if (d.this.X != null) {
                        d.this.X.setVisibility(4);
                    }
                } else if (d.this.U.getScrollY() >= d.this.U.getVerticalScrollRange() - d.this.U.getVerticalScrollExtent()) {
                    d.this.f921f0.setVisibility(4);
                }
            } else {
                d.this.f921f0.setVisibility(4);
                if (d.this.X != null) {
                    d.this.X.setVisibility(4);
                }
            }
            d dVar = d.this;
            Dialog dialog = dVar.f912b;
            if (dialog instanceof com.originui.widget.dialog.f) {
                ((com.originui.widget.dialog.f) dialog).h(dVar.f929j0, d.this.f931k0);
            }
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void d() {
            if (!d.this.f929j0 || d.this.X == null) {
                return;
            }
            d.this.X.setVisibility(4);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e implements VCustomScrollView.b {
        e() {
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void c(boolean z2) {
            m.b("VDialog/VController", "bottomScrollView onScrollableChanged scrollable = " + z2);
            d.this.f931k0 = z2;
            d.this.W.setClickable(d.this.f931k0);
            d.this.W.setFocusable(d.this.f931k0);
            if (d.this.f931k0) {
                d.this.f921f0.setVisibility(4);
                if (d.this.X != null) {
                    d.this.X.setVisibility(4);
                }
            }
            d dVar = d.this;
            Dialog dialog = dVar.f912b;
            if (dialog instanceof com.originui.widget.dialog.f) {
                ((com.originui.widget.dialog.f) dialog).h(dVar.f929j0, d.this.f931k0);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f implements View.OnLayoutChangeListener {
        f() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
            int i10 = i5 - i3;
            if (i10 == i9 - i7 && i3 == i7) {
                return;
            }
            m.b("VDialog/VController", "dialogBackgroundLayout onLayoutChange layoutHeight = " + i10);
            d.this.h0();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g implements VCustomRoundRectLayout.f {
        g() {
        }

        @Override // com.originui.widget.dialog.VCustomRoundRectLayout.f
        public void a(int i2) {
            if (d.this.U != null) {
                d.this.U.c(i2, d.this.f941p0 ? 0 : i2);
            }
            if (d.this.W != null) {
                d.this.W.c(0, i2);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class h implements VCustomScrollView.b {
        h() {
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void c(boolean z2) {
            m.b("VDialog/VController", "topScrollView onScrollableChanged scrollable = " + z2);
            d.this.f929j0 = z2;
            if (d.this.V != null) {
                d.this.V.a(d.this.f929j0);
            }
            d.this.U.setFocusable(d.this.f929j0);
            boolean z3 = d.this.f929j0 || d.this.f931k0;
            if (d.this.f933l0 != z3) {
                if (d.this.f921f0.getVisibility() == 0) {
                    d.this.f921f0.setVisibility(z3 ? 0 : 4);
                }
                d dVar = d.this;
                if (dVar.f924h != null && dVar.J != null) {
                    ViewGroup.LayoutParams layoutParams = dVar.f923g0.getLayoutParams();
                    layoutParams.height = z3 ? d.this.f927i0 : Math.max(0, d.this.f927i0 - d.this.f925h0);
                    d.this.f923g0.setLayoutParams(layoutParams);
                    d.this.S.requestLayout();
                }
                d.this.f933l0 = z3;
            }
            d dVar2 = d.this;
            Dialog dialog = dVar2.f912b;
            if (dialog instanceof com.originui.widget.dialog.f) {
                ((com.originui.widget.dialog.f) dialog).h(dVar2.f929j0, d.this.f931k0);
            }
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void e() {
            d.this.f921f0.setVisibility((d.this.f929j0 || d.this.f931k0) ? 0 : 4);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class i implements VCustomScrollView.b {
        i() {
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void c(boolean z2) {
            m.b("VDialog/VController", "bottomScrollView onScrollableChanged scrollable = " + z2);
            d.this.f931k0 = z2;
            d.this.W.setClickable(d.this.f931k0);
            d.this.W.setFocusable(d.this.f931k0);
            if (d.this.f921f0.getVisibility() == 0) {
                d.this.f921f0.setVisibility((d.this.f929j0 || d.this.f931k0) ? 0 : 4);
            }
            d dVar = d.this;
            Dialog dialog = dVar.f912b;
            if (dialog instanceof com.originui.widget.dialog.f) {
                ((com.originui.widget.dialog.f) dialog).h(dVar.f929j0, d.this.f931k0);
            }
            if (d.this.f931k0) {
                return;
            }
            d.this.O();
        }

        @Override // com.originui.widget.dialog.VCustomScrollView.b
        public void e() {
            d.this.f921f0.setVisibility((d.this.f929j0 || d.this.f931k0) ? 0 : 4);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class j {
        public View A;
        public int B;
        public int C;
        public int D;
        public int E;
        public boolean[] G;
        public boolean H;
        public boolean I;
        public DialogInterface.OnMultiChoiceClickListener L;
        public Cursor M;
        public String N;
        public String O;
        public AdapterView.OnItemSelectedListener P;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Context f962a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final LayoutInflater f963b;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public Drawable f965d;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public CharSequence f967f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public CharSequence f968g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public View f969h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public CharSequence f970i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public CharSequence f971j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public Drawable f972k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public DialogInterface.OnClickListener f973l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public CharSequence f974m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public Drawable f975n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public DialogInterface.OnClickListener f976o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public CharSequence f977p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public Drawable f978q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public DialogInterface.OnClickListener f979r;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public DialogInterface.OnCancelListener f981t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public DialogInterface.OnDismissListener f982u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public DialogInterface.OnKeyListener f983v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public CharSequence[] f984w;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public ListAdapter f985x;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        public DialogInterface.OnClickListener f986y;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        public int f987z;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f964c = 0;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f966e = 0;
        public boolean F = false;
        public int J = -1;
        public boolean K = false;
        public boolean Q = true;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public boolean f980s = true;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class a extends ArrayAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ RecycleListView f988a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ d f989b;

            /* JADX INFO: renamed from: com.originui.widget.dialog.d$j$a$a, reason: collision with other inner class name */
            /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
            class ViewOnClickListenerC0004a implements View.OnClickListener {

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                final /* synthetic */ int f991a;

                ViewOnClickListenerC0004a(int i2) {
                    this.f991a = i2;
                }

                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    int i2;
                    a aVar = a.this;
                    j jVar = j.this;
                    if (jVar.I && (i2 = this.f991a) != jVar.J) {
                        RecycleListView recycleListView = aVar.f988a;
                        if (recycleListView != null) {
                            recycleListView.setItemChecked(i2, true);
                            a.this.f988a.setSelection(this.f991a);
                        }
                        j.this.J = this.f991a;
                    }
                    a aVar2 = a.this;
                    DialogInterface.OnClickListener onClickListener = j.this.f986y;
                    if (onClickListener != null) {
                        onClickListener.onClick(aVar2.f989b.f912b, this.f991a);
                        a aVar3 = a.this;
                        if (j.this.I) {
                            return;
                        }
                        aVar3.f989b.f912b.dismiss();
                    }
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(Context context, int i2, int i3, List list, RecycleListView recycleListView, d dVar) {
                super(context, i2, i3, list);
                this.f988a = recycleListView;
                this.f989b = dVar;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i2, View view, ViewGroup viewGroup) {
                boolean z2;
                if (view != null) {
                    Configuration configuration = j.this.f962a.getResources().getConfiguration();
                    String str = configuration.screenWidthDp + "-" + configuration.screenHeightDp;
                    int i3 = R$id.originui_vdialog_single_choice_view_tag;
                    boolean zEquals = str.equals((String) view.getTag(i3));
                    z2 = !zEquals;
                    if (!zEquals) {
                        view.setTag(i3, str);
                    }
                } else {
                    z2 = false;
                }
                View view2 = z2 ? super.getView(i2, null, viewGroup) : super.getView(i2, view, viewGroup);
                TextView textView = (TextView) view2.findViewById(R.id.text1);
                if (com.originui.widget.dialog.i.k()) {
                    y.n(textView);
                } else {
                    y.q(textView, 400);
                    if (textView instanceof VCustomTextView) {
                        VCustomTextView vCustomTextView = (VCustomTextView) textView;
                        vCustomTextView.setSystemDayColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.C));
                        vCustomTextView.setSystemNightColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.K));
                    }
                }
                j jVar = j.this;
                if (!jVar.I) {
                    if (s.c(jVar.f962a) >= 15.0f) {
                        Context context = j.this.f962a;
                        view2.setBackground(new VListItemSelectorDrawable(context, context.getResources().getColor(R$color.originui_dialog_item_background_selector_color_rom15_0)));
                    } else {
                        view2.setBackground(new VListItemSelectorDrawable(j.this.f962a));
                    }
                }
                View viewFindViewById = view2.findViewById(R$id.divider);
                if ((com.originui.widget.dialog.i.w(j.this.f962a) || com.originui.widget.dialog.i.z(j.this.f962a)) && viewFindViewById != null) {
                    if (i2 == getCount() - 1) {
                        viewFindViewById.setVisibility(8);
                    } else {
                        viewFindViewById.setVisibility(0);
                    }
                }
                view2.setOnClickListener(new ViewOnClickListenerC0004a(i2));
                return view2;
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class b implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ d f993a;

            b(d dVar) {
                this.f993a = dVar;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                j.this.f986y.onClick(this.f993a.f912b, i2);
                if (j.this.I) {
                    return;
                }
                this.f993a.f912b.dismiss();
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class c implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ RecycleListView f995a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ d f996b;

            c(RecycleListView recycleListView, d dVar) {
                this.f995a = recycleListView;
                this.f996b = dVar;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                boolean[] zArr = j.this.G;
                if (zArr != null) {
                    zArr[i2] = this.f995a.isItemChecked(i2);
                }
                j.this.L.onClick(this.f996b.f912b, i2, this.f995a.isItemChecked(i2));
            }
        }

        /* JADX INFO: renamed from: com.originui.widget.dialog.d$j$d, reason: collision with other inner class name */
        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class C0005d extends ArrayAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ RecycleListView f998a;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C0005d(Context context, int i2, int i3, List list, RecycleListView recycleListView) {
                super(context, i2, i3, list);
                this.f998a = recycleListView;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i2, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i2, view, viewGroup);
                y.n((TextView) view2.findViewById(R.id.text1));
                boolean[] zArr = j.this.G;
                if (zArr != null && zArr[i2]) {
                    this.f998a.setItemChecked(i2, true);
                }
                return view2;
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class e extends CursorAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final int f1000a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            private final int f1001b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            final /* synthetic */ RecycleListView f1002c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            final /* synthetic */ d f1003d;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            e(Context context, Cursor cursor, boolean z2, RecycleListView recycleListView, d dVar) {
                super(context, cursor, z2);
                this.f1002c = recycleListView;
                this.f1003d = dVar;
                Cursor cursor2 = getCursor();
                this.f1000a = cursor2.getColumnIndexOrThrow(j.this.N);
                this.f1001b = cursor2.getColumnIndexOrThrow(j.this.O);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                CheckedTextView checkedTextView = (CheckedTextView) view.findViewById(R.id.text1);
                y.n(checkedTextView);
                checkedTextView.setText(cursor.getString(this.f1000a));
                this.f1002c.setItemChecked(cursor.getPosition(), cursor.getInt(this.f1001b) == 1);
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return j.this.f963b.inflate(this.f1003d.N, viewGroup, false);
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class f extends CursorAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final int f1005a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ int f1006b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            f(Context context, Cursor cursor, boolean z2, int i2) {
                super(context, cursor, z2);
                this.f1006b = i2;
                this.f1005a = getCursor().getColumnIndexOrThrow(j.this.N);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                CheckedTextView checkedTextView = (CheckedTextView) view.findViewById(R.id.text1);
                y.n(checkedTextView);
                checkedTextView.setText(cursor.getString(this.f1005a));
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return j.this.f963b.inflate(this.f1006b, viewGroup, false);
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class g extends ArrayAdapter {
            g(Context context, int i2, int i3, List list) {
                super(context, i2, i3, list);
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i2, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i2, view, viewGroup);
                y.n((TextView) view2.findViewById(R.id.text1));
                view2.setBackground(new VListItemSelectorDrawable(j.this.f962a));
                return view2;
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class h implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ d f1009a;

            /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
            class a implements Runnable {
                a() {
                }

                @Override // java.lang.Runnable
                public void run() {
                    h.this.f1009a.f912b.dismiss();
                }
            }

            h(d dVar) {
                this.f1009a = dVar;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                j.this.f986y.onClick(this.f1009a.f912b, i2);
                if (j.this.I) {
                    return;
                }
                view.postDelayed(new a(), 350L);
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class i implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ RecycleListView f1012a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ d f1013b;

            i(RecycleListView recycleListView, d dVar) {
                this.f1012a = recycleListView;
                this.f1013b = dVar;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                boolean[] zArr = j.this.G;
                if (zArr != null) {
                    zArr[i2] = this.f1012a.isItemChecked(i2);
                }
                j.this.L.onClick(this.f1013b.f912b, i2, this.f1012a.isItemChecked(i2));
            }
        }

        /* JADX INFO: renamed from: com.originui.widget.dialog.d$j$j, reason: collision with other inner class name */
        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class C0006j extends ArrayAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ d f1015a;

            /* JADX INFO: renamed from: com.originui.widget.dialog.d$j$j$a */
            /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
            class a implements View.OnClickListener {

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                final /* synthetic */ VCheckBoxTextView f1017a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                final /* synthetic */ int f1018b;

                a(VCheckBoxTextView vCheckBoxTextView, int i2) {
                    this.f1017a = vCheckBoxTextView;
                    this.f1018b = i2;
                }

                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    VCheckBoxTextView vCheckBoxTextView = this.f1017a;
                    vCheckBoxTextView.setChecked(!vCheckBoxTextView.isChecked());
                    j jVar = j.this;
                    if (jVar.L != null) {
                        boolean[] zArr = jVar.G;
                        if (zArr != null) {
                            zArr[this.f1018b] = this.f1017a.isChecked();
                        }
                        C0006j c0006j = C0006j.this;
                        j.this.L.onClick(c0006j.f1015a.f912b, this.f1018b, this.f1017a.isChecked());
                    }
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C0006j(Context context, int i2, int i3, List list, d dVar) {
                super(context, i2, i3, list);
                this.f1015a = dVar;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i2, View view, ViewGroup viewGroup) {
                boolean z2;
                if (view != null) {
                    Configuration configuration = j.this.f962a.getResources().getConfiguration();
                    String str = configuration.screenWidthDp + "-" + configuration.screenHeightDp;
                    int i3 = R$id.originui_vdialog_multi_choice_view_tag;
                    boolean zEquals = str.equals((String) view.getTag(i3));
                    z2 = !zEquals;
                    if (!zEquals) {
                        view.setTag(i3, str);
                    }
                } else {
                    z2 = false;
                }
                View view2 = z2 ? super.getView(i2, null, viewGroup) : super.getView(i2, view, viewGroup);
                VCheckBoxTextView vCheckBoxTextView = (VCheckBoxTextView) view2.findViewById(R.id.text1);
                View viewFindViewById = view2.findViewById(R$id.divider);
                if ((com.originui.widget.dialog.i.w(j.this.f962a) || com.originui.widget.dialog.i.z(j.this.f962a)) && viewFindViewById != null) {
                    if (i2 == getCount() - 1) {
                        viewFindViewById.setVisibility(8);
                    } else {
                        viewFindViewById.setVisibility(0);
                    }
                }
                y.n(vCheckBoxTextView);
                boolean[] zArr = j.this.G;
                if (zArr != null) {
                    vCheckBoxTextView.setChecked(zArr[i2]);
                }
                view2.setOnClickListener(new a(vCheckBoxTextView, i2));
                return view2;
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class k extends CursorAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final int f1020a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            private final int f1021b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            final /* synthetic */ RecycleListView f1022c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            final /* synthetic */ d f1023d;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            k(Context context, Cursor cursor, boolean z2, RecycleListView recycleListView, d dVar) {
                super(context, cursor, z2);
                this.f1022c = recycleListView;
                this.f1023d = dVar;
                Cursor cursor2 = getCursor();
                this.f1020a = cursor2.getColumnIndexOrThrow(j.this.N);
                this.f1021b = cursor2.getColumnIndexOrThrow(j.this.O);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                CheckedTextView checkedTextView = (CheckedTextView) view.findViewById(R.id.text1);
                y.n(checkedTextView);
                checkedTextView.setText(cursor.getString(this.f1020a));
                this.f1022c.setItemChecked(cursor.getPosition(), cursor.getInt(this.f1021b) == 1);
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return j.this.f963b.inflate(this.f1023d.N, viewGroup, false);
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class l extends CursorAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final int f1025a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ int f1026b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            l(Context context, Cursor cursor, boolean z2, int i2) {
                super(context, cursor, z2);
                this.f1026b = i2;
                this.f1025a = getCursor().getColumnIndexOrThrow(j.this.N);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                CheckedTextView checkedTextView = (CheckedTextView) view.findViewById(R.id.text1);
                y.n(checkedTextView);
                checkedTextView.setText(cursor.getString(this.f1025a));
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return j.this.f963b.inflate(this.f1026b, viewGroup, false);
            }
        }

        public j(Context context) {
            this.f962a = context;
            this.f963b = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        private void b(d dVar) {
            j jVar;
            d dVar2;
            ListAdapter lVar;
            ListAdapter aVar;
            RecycleListView recycleListView = (RecycleListView) this.f963b.inflate(dVar.M, (ViewGroup) null);
            recycleListView.setNeedSpecialMeasure(this.K);
            if (!this.H) {
                jVar = this;
                dVar2 = dVar;
                int i2 = jVar.I ? dVar2.O : dVar2.P;
                if (jVar.M != null) {
                    lVar = jVar.new l(jVar.f962a, jVar.M, false, i2);
                    jVar = jVar;
                } else {
                    lVar = jVar.f985x;
                    if (lVar == null) {
                        aVar = jVar.new a(jVar.f962a, i2, R.id.text1, new ArrayList(Arrays.asList(jVar.f984w)), recycleListView, dVar2);
                        recycleListView = recycleListView;
                        lVar = aVar;
                    }
                }
            } else if (this.M == null) {
                lVar = new C0006j(this.f962a, dVar.N, R.id.text1, new ArrayList(Arrays.asList(this.f984w)), dVar);
                jVar = this;
                dVar2 = dVar;
            } else {
                jVar = this;
                dVar2 = dVar;
                aVar = jVar.new k(jVar.f962a, jVar.M, false, recycleListView, dVar2);
                lVar = aVar;
            }
            dVar2.J = lVar;
            dVar2.K = jVar.J;
            if (jVar.f986y != null) {
                recycleListView.setOnItemClickListener(jVar.new b(dVar2));
            } else if (jVar.L != null) {
                recycleListView.setOnItemClickListener(jVar.new c(recycleListView, dVar2));
            }
            AdapterView.OnItemSelectedListener onItemSelectedListener = jVar.P;
            if (onItemSelectedListener != null) {
                recycleListView.setOnItemSelectedListener(onItemSelectedListener);
            }
            if (jVar.I) {
                recycleListView.setChoiceMode(1);
            } else if (jVar.H) {
                recycleListView.setChoiceMode(2);
            }
            dVar2.f924h = recycleListView;
        }

        private void c(d dVar) {
            d dVar2;
            RecycleListView recycleListView;
            j jVar;
            ListAdapter eVar;
            ListAdapter gVar;
            RecycleListView recycleListView2 = (RecycleListView) this.f963b.inflate(dVar.M, (ViewGroup) null);
            recycleListView2.setNeedSpecialMeasure(this.K);
            if (!this.H) {
                dVar2 = dVar;
                recycleListView = recycleListView2;
                int i2 = this.I ? dVar2.O : dVar2.P;
                if (this.M != null) {
                    jVar = this;
                    gVar = jVar.new f(jVar.f962a, jVar.M, false, i2);
                } else {
                    jVar = this;
                    eVar = jVar.f985x;
                    if (eVar == null) {
                        gVar = jVar.new g(jVar.f962a, i2, R.id.text1, new ArrayList(Arrays.asList(jVar.f984w)));
                    }
                }
                eVar = gVar;
            } else if (this.M == null) {
                eVar = new C0005d(this.f962a, dVar.N, R.id.text1, new ArrayList(Arrays.asList(this.f984w)), recycleListView2);
                dVar2 = dVar;
                jVar = this;
                recycleListView = recycleListView2;
            } else {
                eVar = new e(this.f962a, this.M, false, recycleListView2, dVar);
                recycleListView = recycleListView2;
                dVar2 = dVar;
                jVar = this;
            }
            dVar2.J = eVar;
            dVar2.K = jVar.J;
            if (jVar.f986y != null) {
                recycleListView.setOnItemClickListener(jVar.new h(dVar2));
            } else if (jVar.L != null) {
                recycleListView.setOnItemClickListener(jVar.new i(recycleListView, dVar2));
            }
            AdapterView.OnItemSelectedListener onItemSelectedListener = jVar.P;
            if (onItemSelectedListener != null) {
                recycleListView.setOnItemSelectedListener(onItemSelectedListener);
            }
            if (jVar.I) {
                recycleListView.setChoiceMode(1);
            } else if (jVar.H) {
                recycleListView.setChoiceMode(2);
            }
            dVar2.f924h = recycleListView;
        }

        public void a(d dVar) {
            d dVar2;
            View view = this.f969h;
            if (view != null) {
                dVar.S(view);
            } else {
                CharSequence charSequence = this.f967f;
                if (charSequence != null) {
                    dVar.X(charSequence);
                }
                CharSequence charSequence2 = this.f968g;
                if (charSequence2 != null) {
                    dVar.W(charSequence2);
                }
                Drawable drawable = this.f965d;
                if (drawable != null) {
                    dVar.U(drawable);
                }
                int i2 = this.f964c;
                if (i2 != 0) {
                    dVar.T(i2);
                }
                int i3 = this.f966e;
                if (i3 != 0) {
                    dVar.T(dVar.E(i3));
                }
            }
            CharSequence charSequence3 = this.f970i;
            if (charSequence3 != null) {
                dVar.V(charSequence3);
            }
            CharSequence charSequence4 = this.f971j;
            if (charSequence4 == null && this.f972k == null) {
                dVar2 = dVar;
            } else {
                dVar.R(-1, charSequence4, this.f973l, null, this.f972k);
                dVar2 = dVar;
            }
            CharSequence charSequence5 = this.f974m;
            if (charSequence5 != null || this.f975n != null) {
                dVar2.R(-2, charSequence5, this.f976o, null, this.f975n);
            }
            CharSequence charSequence6 = this.f977p;
            if (charSequence6 != null || this.f978q != null) {
                dVar2.R(-3, charSequence6, this.f979r, null, this.f978q);
            }
            if (this.f984w != null || this.M != null || this.f985x != null) {
                if (com.originui.widget.dialog.i.l(this.f962a)) {
                    b(dVar2);
                } else {
                    c(dVar2);
                }
            }
            View view2 = this.A;
            if (view2 != null) {
                if (this.F) {
                    dVar2.a0(view2, this.B, this.C, this.D, this.E);
                    return;
                } else {
                    dVar2.Z(view2);
                    return;
                }
            }
            int i4 = this.f987z;
            if (i4 != 0) {
                dVar2.Y(i4);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static final class k extends Handler {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final WeakReference f1028a;

        public k(DialogInterface dialogInterface) {
            this.f1028a = new WeakReference(dialogInterface);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            DialogInterface dialogInterface;
            if (message == null) {
                return;
            }
            m.i("VDialog/VController", "handleMessage msg = " + message.what);
            int i2 = message.what;
            if (i2 == -3 || i2 == -2 || i2 == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f1028a.get(), message.what);
            } else if (i2 == 1 && (dialogInterface = (DialogInterface) this.f1028a.get()) != null) {
                dialogInterface.dismiss();
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class l implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private DialogInterface.OnClickListener f1029a;

        l(DialogInterface.OnClickListener onClickListener) {
            this.f1029a = onClickListener;
        }

        static l a(DialogInterface.OnClickListener onClickListener) {
            if (onClickListener != null) {
                return new l(onClickListener);
            }
            return null;
        }

        void b() {
            if (this.f1029a != null) {
                m.i("VDialog/VController", "release(), [DialogLifecycle], base:" + this.f1029a);
            }
            this.f1029a = null;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            DialogInterface.OnClickListener onClickListener = this.f1029a;
            if (onClickListener != null) {
                onClickListener.onClick(dialogInterface, i2);
            }
        }
    }

    public d(Context context, Dialog dialog, Window window) {
        ContextBridge contextBridgeByRomVer = ResMapManager.byRomVer(context);
        this.f910a = contextBridgeByRomVer;
        this.f912b = dialog;
        this.f914c = window;
        this.f943q0 = new k(dialog);
        window.requestFeature(1);
        TypedArray typedArrayObtainTypedArray = ResMapManager.obtainTypedArray(contextBridgeByRomVer, (AttributeSet) null, R$styleable.VDialog, R$attr.alertDialogStyle, R$style.Vigour_VDialog_Alert);
        this.L = typedArrayObtainTypedArray.getResourceId(R$styleable.VDialog_android_layout, 0);
        this.M = typedArrayObtainTypedArray.getResourceId(R$styleable.VDialog_listLayout, 0);
        this.N = typedArrayObtainTypedArray.getResourceId(R$styleable.VDialog_multiChoiceItemLayout, 0);
        this.O = typedArrayObtainTypedArray.getResourceId(R$styleable.VDialog_singleChoiceItemLayout, 0);
        this.P = typedArrayObtainTypedArray.getResourceId(R$styleable.VDialog_listItemLayout, 0);
        if (com.originui.widget.dialog.i.k() && s.c(contextBridgeByRomVer) >= 15.0f) {
            this.P = R$layout.originui_dialog_list_item_singleline_rom15_0;
        }
        this.Q = typedArrayObtainTypedArray.getBoolean(R$styleable.VDialog_showTitle, true);
        this.f916d = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VDialog_buttonIconDimen, 0);
        this.f925h0 = r.a(4);
        this.f927i0 = typedArrayObtainTypedArray.getDimensionPixelSize(R$styleable.VDialog_dialogButtonPanelTopStub, 0);
        typedArrayObtainTypedArray.recycle();
        if (!com.originui.widget.dialog.i.l(contextBridgeByRomVer)) {
            window.setDimAmount(0.6f);
            window.setGravity(17);
            if (com.originui.widget.dialog.i.A(contextBridgeByRomVer)) {
                window.setWindowAnimations(R$style.VAnimation_Dialog_Center_Loading_Fos_Fos15);
                return;
            } else {
                window.setWindowAnimations(R$style.VAnimation_Dialog_Center_Loading_Fos);
                return;
            }
        }
        window.setDimAmount(VThemeIconUtils.A(contextBridgeByRomVer) ? 0.6f : 0.3f);
        q.j(window, "setDimEnterDuration", new Class[]{Long.TYPE}, new Object[]{300});
        if (com.originui.core.utils.h.j() || com.originui.widget.dialog.i.m(contextBridgeByRomVer)) {
            window.setGravity(17);
            window.setWindowAnimations(R$style.VAnimation_Dialog_Center);
            return;
        }
        window.setGravity(80);
        if (com.originui.widget.dialog.i.s()) {
            window.setWindowAnimations(R$style.VAnimation_Dialog_Menu_Special);
        } else if (com.originui.widget.dialog.i.v(contextBridgeByRomVer) || com.originui.widget.dialog.i.z(contextBridgeByRomVer)) {
            window.setWindowAnimations(R$style.VAnimation_Dialog_Menu_Rom14);
        }
    }

    private void H() {
        int iD;
        if (com.originui.widget.dialog.i.i(this.f910a) && (iD = com.originui.core.utils.k.d(this.f910a, "dialog_btn_text_normal_light", "color", "vivo")) != 0) {
            int color = this.f910a.getResources().getColor(iD);
            if (this.f940p.getDrawType() != 2 && this.f950x.getDrawType() != 2 && this.f946t.getDrawType() != 2) {
                this.f940p.setTextColor(color);
                this.f950x.setTextColor(color);
                this.f946t.setTextColor(color);
                return;
            }
            if (this.f940p.getDrawType() != 2 || this.f940p.getCurrentTextColor() == this.f910a.getResources().getColor(R$color.originui_dialog_btn_del)) {
                this.f940p.setTextColor(this.f910a.getResources().getColor(R$color.originui_vdialog_btn_default_text_color));
            } else {
                this.f940p.setTextColor(color);
                this.f940p.setStrokeColor(color);
            }
            if (this.f950x.getDrawType() == 2) {
                this.f950x.setTextColor(color);
                this.f950x.setStrokeColor(color);
            } else {
                this.f950x.setTextColor(this.f910a.getResources().getColor(R$color.originui_vdialog_btn_default_text_color));
            }
            if (this.f946t.getDrawType() != 2) {
                this.f946t.setTextColor(this.f910a.getResources().getColor(R$color.originui_vdialog_btn_default_text_color));
            } else {
                this.f946t.setTextColor(color);
                this.f946t.setStrokeColor(color);
            }
        }
    }

    private void I() {
        this.U = (VCustomScrollView) this.f914c.findViewById(R$id.originui_dialog_top_scroll_view);
        this.V = (VBoundsCoverView) this.f914c.findViewById(R$id.originui_dialog_top_cover_view);
        this.W = (VCustomScrollView) this.f914c.findViewById(R$id.originui_dialog_bottom_scroll_view);
        this.f921f0 = this.f914c.findViewById(R$id.originui_dialog_divider);
        this.f923g0 = this.f914c.findViewById(R$id.scroll_content_stub);
        ParserUtil.getOrCreateViewAttr(this.f921f0).setMarginActiveMode(ViewAttrConstant.createActiveMode(false));
        int iC = com.originui.widget.dialog.i.c(this.f910a, this.R);
        this.S.addOnLayoutChangeListener(new f());
        this.S.setOnFilletChangeListener(new g());
        VCustomScrollView vCustomScrollView = this.U;
        if (vCustomScrollView != null) {
            vCustomScrollView.c(iC, this.f941p0 ? 0 : iC);
            this.U.setOnScrollableChangeListener(new h());
        }
        VCustomScrollView vCustomScrollView2 = this.W;
        if (vCustomScrollView2 != null) {
            vCustomScrollView2.c(0, iC);
            this.W.setOnScrollableChangeListener(new i());
        }
    }

    private void J() {
        this.X = this.f914c.findViewById(R$id.originui_dialog_top_divider);
        this.f921f0 = this.f914c.findViewById(R$id.originui_dialog_divider);
        int iC = com.originui.widget.dialog.i.c(this.f910a, this.R);
        this.W.setSupportScrollable(false);
        this.U.setSupportScrollable(true);
        this.S.addOnLayoutChangeListener(new c());
        VCustomScrollView vCustomScrollView = this.U;
        if (vCustomScrollView != null) {
            vCustomScrollView.c(0, 0);
            this.U.setOnScrollableChangeListener(new C0003d());
        }
        VCustomScrollView vCustomScrollView2 = this.W;
        if (vCustomScrollView2 != null) {
            vCustomScrollView2.c(iC, iC);
            this.W.setOnScrollableChangeListener(new e());
        }
    }

    private void N(Message message) {
        Object obj = message != null ? message.obj : null;
        if (obj instanceof l) {
            ((l) obj).b();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void O() {
        VCustomScrollView vCustomScrollView = this.W;
        if (vCustomScrollView == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = vCustomScrollView.getLayoutParams();
        layoutParams.height = -2;
        this.W.setLayoutParams(layoutParams);
        VCustomRoundRectLayout vCustomRoundRectLayout = this.S;
        if (vCustomRoundRectLayout != null) {
            vCustomRoundRectLayout.requestLayout();
        }
    }

    private void P(int i2) {
        VCustomScrollView vCustomScrollView = this.W;
        if (vCustomScrollView == null) {
            return;
        }
        int i3 = this.f913b0;
        if (i2 > i3) {
            i2 = i3;
        }
        int i4 = this.f915c0;
        if (i2 < i4) {
            i2 = i4;
        }
        ViewGroup.LayoutParams layoutParams = vCustomScrollView.getLayoutParams();
        if (layoutParams.height != i2) {
            if (m.f583b) {
                m.b("VDialog/VController", "resetButtonScrollViewHeight height = " + i2);
            }
            layoutParams.height = i2;
            this.W.setLayoutParams(layoutParams);
            VCustomRoundRectLayout vCustomRoundRectLayout = this.S;
            if (vCustomRoundRectLayout != null) {
                vCustomRoundRectLayout.requestLayout();
            }
        }
    }

    private ViewGroup Q(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    private void b0(View view) {
        view.setOnApplyWindowInsetsListener(new b());
    }

    private void c0(ViewGroup viewGroup) {
        int i2;
        this.T = (VDialogButtonPanel) viewGroup.findViewById(R$id.buttonbarPanel);
        this.I = (ImageButton) viewGroup.findViewById(R$id.toggle_mode);
        VButton vButton = (VButton) viewGroup.findViewById(R.id.button1);
        this.f940p = vButton;
        vButton.setOnClickListener(this.t0);
        if (com.originui.widget.dialog.i.j()) {
            q.r(this.f940p, s.b() > 13.5f ? 11 : 1);
        }
        if (TextUtils.isEmpty(this.f942q) && this.f945s == null) {
            this.f940p.setVisibility(8);
            i2 = 0;
        } else {
            this.f940p.setText(this.f942q);
            Drawable drawable = this.f945s;
            if (drawable != null) {
                int i3 = this.f916d;
                drawable.setBounds(0, 0, i3, i3);
                this.f940p.setIcon(this.f945s);
            }
            this.f940p.setVisibility(0);
            i2 = 1;
        }
        VButton vButton2 = (VButton) viewGroup.findViewById(R.id.button2);
        this.f946t = vButton2;
        vButton2.setOnClickListener(this.t0);
        if (com.originui.widget.dialog.i.j()) {
            q.r(this.f946t, s.b() > 13.5f ? 11 : 1);
        }
        if (TextUtils.isEmpty(this.f947u) && this.f949w == null) {
            this.f946t.setVisibility(8);
        } else {
            this.f946t.setText(this.f947u);
            Drawable drawable2 = this.f949w;
            if (drawable2 != null) {
                int i4 = this.f916d;
                drawable2.setBounds(0, 0, i4, i4);
                this.f946t.setIcon(this.f949w);
            }
            this.f946t.setVisibility(0);
            i2 |= 2;
        }
        VButton vButton3 = (VButton) viewGroup.findViewById(R.id.button3);
        this.f950x = vButton3;
        vButton3.setOnClickListener(this.t0);
        if (com.originui.widget.dialog.i.j()) {
            q.r(this.f950x, s.b() <= 13.5f ? 1 : 11);
        }
        if (TextUtils.isEmpty(this.f951y) && this.A == null) {
            this.f950x.setVisibility(8);
        } else {
            this.f950x.setText(this.f951y);
            Drawable drawable3 = this.A;
            if (drawable3 != null) {
                int i5 = this.f916d;
                drawable3.setBounds(0, 0, i5, i5);
                this.f950x.setIcon(this.A);
            }
            this.f950x.setVisibility(0);
            i2 |= 4;
        }
        if (this.f940p.getVisibility() == 0 && this.f950x.getVisibility() == 0 && this.f946t.getVisibility() == 0 && com.originui.widget.dialog.i.m(this.f910a)) {
            if (this.f940p.getDrawType() != 2) {
                this.f940p.setMinHeight(p.a(40.0f));
            }
            if (this.f950x.getDrawType() != 2) {
                this.f950x.setMinHeight(p.a(40.0f));
            }
            if (this.f946t.getDrawType() != 2) {
                this.f946t.setMinHeight(p.a(40.0f));
            }
            VButton vButton4 = this.f940p;
            Context context = this.f910a;
            int i6 = R$dimen.originui_dialog_button_text_size;
            vButton4.f(0, r.c(context, i6));
            this.f946t.f(0, r.c(this.f910a, i6));
            this.f950x.f(0, r.c(this.f910a, i6));
        }
        if (com.originui.widget.dialog.i.l(this.f910a)) {
            if (i2 == 1) {
                z(this.f940p);
            }
            if (i2 == 2) {
                z(this.f946t);
            }
            if (i2 == 4) {
                z(this.f950x);
            }
        }
        if (i2 == 0) {
            viewGroup.setVisibility(8);
        }
    }

    private void d0(ViewGroup viewGroup) {
        TextView textView = (TextView) viewGroup.findViewById(R.id.message);
        this.G = textView;
        if (textView == null) {
            return;
        }
        CharSequence charSequence = this.f922g;
        if (charSequence != null) {
            textView.setText(charSequence);
            return;
        }
        textView.setVisibility(8);
        viewGroup.removeView(this.G);
        if (this.f924h == null) {
            viewGroup.setVisibility(8);
            return;
        }
        ViewGroup viewGroup2 = (ViewGroup) this.f914c.findViewById(R$id.contentPanel);
        viewGroup2.removeAllViews();
        viewGroup2.addView(this.f924h, new ViewGroup.LayoutParams(-1, -1));
    }

    private void e0(ViewGroup viewGroup) {
        View viewInflate = this.f926i;
        if (viewInflate == null) {
            viewInflate = this.f928j != 0 ? LayoutInflater.from(this.f910a).inflate(this.f928j, viewGroup, false) : null;
        }
        boolean z2 = viewInflate != null;
        boolean z3 = z2 && com.originui.widget.dialog.i.h(viewInflate);
        this.r0 = z3;
        this.S.setHasInputView(z3);
        if (!this.r0) {
            this.f914c.setFlags(131072, 131072);
        }
        if (!z2) {
            viewGroup.setVisibility(8);
            return;
        }
        FrameLayout frameLayout = (FrameLayout) this.f914c.findViewById(R$id.custom);
        frameLayout.addView(viewInflate, new ViewGroup.LayoutParams(-1, -1));
        if (this.f938o) {
            frameLayout.setPadding(this.f930k, this.f932l, this.f934m, this.f936n);
            ParserUtil.getOrCreateViewAttr(frameLayout).setPaddingActiveMode(ViewAttrConstant.createActiveMode(false));
        }
        if (this.f924h != null) {
            ((LinearLayout.LayoutParams) viewGroup.getLayoutParams()).weight = 0.0f;
        }
    }

    private void f0(ViewGroup viewGroup) {
        if (this.H != null) {
            viewGroup.removeAllViews();
            viewGroup.addView(this.H, 0, new ViewGroup.LayoutParams(-1, -2));
            return;
        }
        this.E = (TextView) this.f914c.findViewById(R$id.alertTitle);
        this.D = (ImageView) this.f914c.findViewById(R.id.icon);
        this.F = (TextView) this.f914c.findViewById(R$id.description_title);
        if (com.originui.widget.dialog.i.r()) {
            TextView textView = this.E;
            if (textView instanceof VCustomTextView) {
                ((VCustomTextView) textView).setSystemDayColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.C));
                ((VCustomTextView) this.E).setSystemNightColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.K));
            }
            TextView textView2 = this.F;
            if (textView2 instanceof VCustomTextView) {
                ((VCustomTextView) textView2).setSystemDayColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.I));
                ((VCustomTextView) this.F).setSystemNightColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.G));
            }
        }
        boolean zIsEmpty = TextUtils.isEmpty(this.f918e);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f920f);
        if ((zIsEmpty && this.B == 0 && this.C == null) || !this.Q) {
            viewGroup.setVisibility(8);
            return;
        }
        if (zIsEmpty) {
            this.E.setVisibility(8);
        } else {
            this.E.setText(this.f918e);
            if (com.originui.widget.dialog.i.z(this.f910a)) {
                y.q(this.E, 500);
            } else {
                y.p(this.E);
            }
        }
        if (zIsEmpty2) {
            this.F.setVisibility(8);
        } else {
            this.F.setText(this.f920f);
            this.F.setVisibility(0);
        }
        int i2 = this.B;
        if (i2 != 0 || this.C != null) {
            if (i2 != 0) {
                this.D.setImageResource(i2);
            } else {
                this.D.setImageDrawable(this.C);
            }
            this.D.setVisibility(0);
            return;
        }
        ParserUtil.getOrCreateViewAttr(this.E).setPaddingActiveMode(ViewAttrConstant.createActiveMode(false));
        this.E.setPadding(this.D.getPaddingLeft(), this.D.getPaddingTop(), this.D.getPaddingRight(), this.D.getPaddingBottom());
        if (!zIsEmpty2) {
            y.m(this.F);
        }
        this.D.setVisibility(8);
    }

    private void g0() {
        TextView textView;
        TextView textView2;
        ListAdapter listAdapter;
        TextView textView3;
        TextView textView4;
        View viewFindViewById = this.f914c.findViewById(R$id.parentPanel);
        int i2 = R$id.topPanel;
        this.Y = viewFindViewById.findViewById(i2);
        int i3 = R$id.buttonPanel;
        this.Z = viewFindViewById.findViewById(i3);
        Window window = this.f914c;
        int i4 = R$id.originui_dialog_top_scroll_view;
        this.U = (VCustomScrollView) window.findViewById(i4);
        this.W = (VCustomScrollView) this.f914c.findViewById(R$id.originui_dialog_bottom_scroll_view);
        if (viewFindViewById instanceof VCustomRoundRectLayout) {
            VCustomRoundRectLayout vCustomRoundRectLayout = (VCustomRoundRectLayout) viewFindViewById;
            this.S = vCustomRoundRectLayout;
            vCustomRoundRectLayout.setMaxFilletLevel(this.R);
            this.T = (VDialogButtonPanel) viewFindViewById.findViewById(R$id.buttonbarPanel);
        }
        View viewFindViewById2 = viewFindViewById.findViewById(i2);
        int i5 = R$id.contentPanel;
        View viewFindViewById3 = viewFindViewById.findViewById(i5);
        View viewFindViewById4 = viewFindViewById.findViewById(i3);
        ViewGroup viewGroup = (ViewGroup) viewFindViewById.findViewById(R$id.customPanel);
        e0(viewGroup);
        View viewFindViewById5 = viewGroup.findViewById(i2);
        View viewFindViewById6 = viewGroup.findViewById(i5);
        View viewFindViewById7 = viewGroup.findViewById(i3);
        ViewGroup viewGroupQ = Q(viewFindViewById5, viewFindViewById2);
        ViewGroup viewGroupQ2 = Q(viewFindViewById6, viewFindViewById3);
        ViewGroup viewGroupQ3 = Q(viewFindViewById7, viewFindViewById4);
        d0(viewGroupQ2);
        c0(viewGroupQ3);
        f0(viewGroupQ);
        H();
        this.f935m0 = viewGroup.getVisibility() != 8;
        this.f937n0 = (viewGroupQ2 == null || viewGroupQ2.getVisibility() == 8) ? false : true;
        this.f939o0 = (viewGroupQ == null || viewGroupQ.getVisibility() == 8) ? false : true;
        this.f941p0 = (viewGroupQ3 == null || viewGroupQ3.getVisibility() == 8) ? false : true;
        if (com.originui.widget.dialog.i.l(this.f910a)) {
            boolean z2 = this.f939o0;
            if (z2 && this.f941p0 && !this.f937n0 && !this.f935m0) {
                TypedArray typedArrayObtainStyledAttributes = this.f910a.obtainStyledAttributes(null, R$styleable.VDialog, 0, A());
                int resourceId = (this.C == null && this.B == 0) ? typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogTitleBottomMarginNoContent, R$dimen.originui_dialog_title_bottom_margin_no_content) : typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogTitleBottomMarginNoContentWithIcon, R$dimen.originui_dialog_title_bottom_margin_no_content_with_icon);
                typedArrayObtainStyledAttributes.recycle();
                ParserUtil.setViewPadding(viewGroupQ, 0, 0, 0, resourceId);
            } else if (z2 || !this.f937n0) {
                if (!z2 && this.f935m0) {
                    View viewFindViewById8 = viewGroup.findViewById(R$id.scroll_ll);
                    if ((viewFindViewById8 instanceof LinearLayout) && ((LinearLayout) viewFindViewById8).getChildCount() == 1) {
                        View viewFindViewById9 = viewFindViewById8.findViewById(R$id.message_custom);
                        if (viewFindViewById9 == null) {
                            viewFindViewById9 = viewFindViewById8.findViewById(R$id.message1);
                        }
                        if (viewFindViewById9 == null) {
                            viewFindViewById9 = viewFindViewById8.findViewById(R$id.message2);
                        }
                        if (viewFindViewById9 instanceof TextView) {
                            TypedArray typedArrayObtainStyledAttributes2 = this.f910a.obtainStyledAttributes(null, R$styleable.VDialog, 0, A());
                            int resourceId2 = typedArrayObtainStyledAttributes2.getResourceId(R$styleable.VDialog_dialogMessageTopPaddingNoTitle, R$dimen.originui_dialog_message_vigour_padding_top_no_title);
                            int resourceId3 = typedArrayObtainStyledAttributes2.getResourceId(R$styleable.VDialog_dialogMessageBottomPaddingNoTitle, R$dimen.originui_dialog_message_padding_bottom_no_title);
                            typedArrayObtainStyledAttributes2.recycle();
                            viewFindViewById9.setTextAlignment(4);
                            ParserUtil.setViewPadding(viewFindViewById9, 0, resourceId2, 0, resourceId3);
                        }
                    }
                    ParserUtil.setViewPadding(this.f914c.findViewById(i4), 0, R$dimen.originui_dialog_no_dp, 0, 0);
                }
            } else if (this.G != null) {
                TypedArray typedArrayObtainStyledAttributes3 = this.f910a.obtainStyledAttributes(null, R$styleable.VDialog, 0, A());
                int resourceId4 = typedArrayObtainStyledAttributes3.getResourceId(R$styleable.VDialog_dialogMessageTopPaddingNoTitle, R$dimen.originui_dialog_message_padding_top_no_title);
                int resourceId5 = typedArrayObtainStyledAttributes3.getResourceId(R$styleable.VDialog_dialogMessageBottomPaddingNoTitle, R$dimen.originui_dialog_message_padding_bottom_no_title);
                typedArrayObtainStyledAttributes3.recycle();
                this.G.setTextAlignment(4);
                ParserUtil.setViewPadding(this.G, 0, resourceId4, 0, resourceId5);
            }
            if (this.f939o0 && viewGroupQ != null && (textView3 = this.E) != null && textView3.getVisibility() == 8 && (textView4 = this.F) != null && textView4.getVisibility() == 8 && ((this.B != 0 || this.C != null) && (this.f935m0 || this.f937n0))) {
                ParserUtil.setViewPadding(viewGroupQ, 0, 0, 0, R$dimen.originui_dialog_no_dp);
            }
        } else {
            if (!this.f939o0 && this.f935m0) {
                View viewFindViewById10 = viewGroup.findViewById(R$id.scroll_ll);
                if ((viewFindViewById10 instanceof LinearLayout) && ((LinearLayout) viewFindViewById10).getChildCount() == 1) {
                    View viewFindViewById11 = viewFindViewById10.findViewById(R$id.message_custom);
                    if (viewFindViewById11 == null) {
                        viewFindViewById11 = viewFindViewById10.findViewById(R$id.message1);
                    }
                    if (viewFindViewById11 == null) {
                        viewFindViewById11 = viewFindViewById10.findViewById(R$id.message2);
                    }
                    if (viewFindViewById11 instanceof TextView) {
                        TypedArray typedArrayObtainStyledAttributes4 = this.f910a.obtainStyledAttributes(null, R$styleable.VDialog, 0, A());
                        int resourceId6 = typedArrayObtainStyledAttributes4.getResourceId(R$styleable.VDialog_dialogMessageTopPaddingNoTitle, R$dimen.originui_dialog_message_vigour_padding_top_no_title);
                        int resourceId7 = typedArrayObtainStyledAttributes4.getResourceId(R$styleable.VDialog_dialogMessageBottomPaddingNoTitle, R$dimen.originui_dialog_message_padding_bottom_no_title);
                        typedArrayObtainStyledAttributes4.recycle();
                        viewFindViewById11.setTextAlignment(4);
                        ParserUtil.setViewPadding(viewFindViewById11, 0, resourceId6, 0, resourceId7);
                    }
                }
                ParserUtil.setViewPadding(this.f914c.findViewById(i4), 0, R$dimen.originui_dialog_no_dp, 0, 0);
            }
            if (this.f939o0 && viewGroupQ != null && (textView = this.E) != null && textView.getVisibility() == 8 && (textView2 = this.F) != null && textView2.getVisibility() == 8) {
                if ((this.B != 0 || this.C != null) && (this.f935m0 || this.f937n0)) {
                    ParserUtil.setViewMargin(viewGroupQ, 0, 0, 0, R$dimen.originui_dialog_no_dp);
                }
                if (com.originui.widget.dialog.i.A(this.f910a) && (this.B != 0 || this.C != null)) {
                    ParserUtil.setViewMargin(this.D, 0, 0, 0, R$dimen.originui_dialog_no_dp);
                    viewGroupQ.setMinimumHeight(r.c(this.f910a, R$dimen.originui_dialog_title_minHeight_icon_fos15));
                }
            }
            if ((this.B != 0 || this.C != null) && viewGroupQ != null) {
                if (!com.originui.widget.dialog.i.A(this.f910a)) {
                    viewGroupQ.setPadding(viewGroupQ.getPaddingLeft(), r.c(this.f910a, R$dimen.originui_dialog_title_top_margin_scrollable_icon), viewGroupQ.getPaddingRight(), viewGroupQ.getPaddingBottom());
                }
                TextView textView5 = this.E;
                if (textView5 != null) {
                    textView5.setTextAlignment(4);
                }
                TextView textView6 = this.F;
                if (textView6 != null) {
                    textView6.setTextAlignment(4);
                }
            }
        }
        if (com.originui.widget.dialog.i.l(this.f910a)) {
            b0(this.f912b.getWindow().getDecorView());
        }
        if (com.originui.widget.dialog.i.l(this.f910a)) {
            I();
        } else {
            J();
        }
        ListView listView = this.f924h;
        if (listView instanceof RecycleListView) {
            ((RecycleListView) listView).a(this.f939o0, this.f941p0);
        }
        ListView listView2 = this.f924h;
        if (listView2 != null && (listAdapter = this.J) != null) {
            listView2.setAdapter(listAdapter);
            int i6 = this.K;
            if (i6 > -1) {
                listView2.setItemChecked(i6, true);
                listView2.setSelection(i6);
            }
        }
        if (com.originui.widget.dialog.i.r() && L() && !com.originui.widget.dialog.i.A(this.f910a)) {
            y();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void h0() {
        VCustomScrollView vCustomScrollView;
        if (this.U == null || (vCustomScrollView = this.W) == null) {
            return;
        }
        if (this.f913b0 <= 0) {
            this.f913b0 = vCustomScrollView.getMeasuredHeight();
            m.b("VDialog/VController", "originButtonHeight = " + this.f913b0);
        }
        if (this.f913b0 < this.f915c0) {
            return;
        }
        if (this.f929j0 || this.f931k0) {
            int verticalScrollRange = this.W.getVerticalScrollRange();
            int verticalScrollRange2 = this.U.getVerticalScrollRange();
            int height = this.U.getHeight();
            int height2 = this.W.getHeight();
            int i2 = height + height2;
            if (m.f583b) {
                m.b("VDialog/VController", "updateScrollViewState titleContentRange = " + verticalScrollRange2 + ", titleContentHeight = " + height + ", buttonHeight = " + height2 + ", totalHeight = " + i2 + ", originButtonHeight = " + this.f913b0 + ", currentBottomHeight = " + verticalScrollRange);
            }
            int i3 = i2 / 2;
            int iMax = Math.max(i3, height2 - (verticalScrollRange2 - height));
            if (this.f913b0 != verticalScrollRange) {
                this.f913b0 = verticalScrollRange;
                P(verticalScrollRange);
            }
            if (this.f929j0 && !this.f931k0) {
                if (height > this.f913b0 + 1) {
                    return;
                }
                if (verticalScrollRange2 > i3 + 1) {
                    P(i3);
                } else {
                    P(iMax);
                }
            }
            if (!this.f929j0 && this.f931k0) {
                int i4 = this.f913b0;
                if (height > i4 + 1) {
                    P(i4);
                } else {
                    if (height <= height2 + 1) {
                        int maxHeight = this.S.getMaxHeight();
                        if (m.f583b) {
                            m.b("VDialog/VController", "updateScrollViewState maxHeight = " + maxHeight);
                        }
                        if (i2 < maxHeight) {
                            int i5 = this.f913b0;
                            if (height + i5 < maxHeight) {
                                P(i5);
                                return;
                            } else {
                                P(maxHeight - height);
                                return;
                            }
                        }
                        return;
                    }
                    if (verticalScrollRange2 > i3 + 1) {
                        P(i3);
                    } else {
                        P(iMax);
                    }
                }
            }
            if (this.f929j0 && this.f931k0 && this.S.getMeasuredHeight() <= this.S.getMaxHeight()) {
                if (verticalScrollRange2 > i3 + 1) {
                    P(i3);
                } else {
                    P(iMax);
                }
            }
        }
    }

    private void y() {
        this.T.g();
    }

    private void z(VButton vButton) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) vButton.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        vButton.setLayoutParams(layoutParams);
    }

    public int A() {
        if (com.originui.widget.dialog.i.k()) {
            return R$style.Vigour_VDialog_Alert;
        }
        if (com.originui.widget.dialog.i.z(this.f910a)) {
            return R$style.Vigour_VDialog_Vos_Alert;
        }
        return com.originui.widget.dialog.i.A(this.f910a) ? R$style.Vigour_VDialog_Fos_Alert_Fos15 : R$style.Vigour_VDialog_Fos_Alert;
    }

    public VCustomRoundRectLayout B() {
        return this.S;
    }

    public VDialogButtonPanel C() {
        return this.T;
    }

    public View D() {
        return this.Y;
    }

    public int E(int i2) {
        TypedValue typedValue = new TypedValue();
        this.f910a.getTheme().resolveAttribute(i2, typedValue, true);
        return typedValue.resourceId;
    }

    public View F() {
        return this.V;
    }

    public boolean G() {
        return this.r0;
    }

    public void K() {
        this.f912b.setContentView(this.L);
        if (com.originui.widget.dialog.i.u(this.f910a)) {
            Window window = this.f914c;
            Context context = this.f910a;
            window.setTitle(context.getString(com.originui.core.utils.k.d(context, "popup_window_default_title", "string", "android")));
        }
        g0();
    }

    public boolean L() {
        View view = this.f926i;
        return (view == null || view.findViewById(R$id.content_loading_layout_progressbar) == null) ? false : true;
    }

    void M() {
        N(this.f944r);
        N(this.f948v);
        N(this.f952z);
    }

    public void R(int i2, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.f943q0.obtainMessage(i2, l.a(onClickListener));
        }
        if (i2 == -3) {
            this.f951y = charSequence;
            this.f952z = message;
            this.A = drawable;
        } else if (i2 == -2) {
            this.f947u = charSequence;
            this.f948v = message;
            this.f949w = drawable;
        } else {
            if (i2 != -1) {
                throw new IllegalArgumentException("Button does not exist");
            }
            this.f942q = charSequence;
            this.f944r = message;
            this.f945s = drawable;
        }
    }

    public void S(View view) {
        this.H = view;
    }

    public void T(int i2) {
        this.C = null;
        this.B = i2;
        ImageView imageView = this.D;
        if (imageView != null) {
            if (i2 == 0) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.D.setImageResource(this.B);
            }
        }
    }

    public void U(Drawable drawable) {
        this.C = drawable;
        this.B = 0;
        ImageView imageView = this.D;
        if (imageView != null) {
            if (drawable == null) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.D.setImageDrawable(drawable);
            }
        }
    }

    public void V(CharSequence charSequence) {
        this.f922g = charSequence;
        TextView textView = this.G;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void W(CharSequence charSequence) {
        this.f920f = charSequence;
        TextView textView = this.F;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void X(CharSequence charSequence) {
        this.f918e = charSequence;
        TextView textView = this.E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void Y(int i2) {
        this.f926i = null;
        this.f928j = i2;
        this.f938o = false;
    }

    public void Z(View view) {
        this.f926i = view;
        this.f928j = 0;
        this.f938o = false;
    }

    public void a0(View view, int i2, int i3, int i4, int i5) {
        this.f926i = view;
        this.f928j = 0;
        this.f938o = true;
        this.f930k = i2;
        this.f932l = i3;
        this.f934m = i4;
        this.f936n = i5;
    }
}
