package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import com.originui.core.utils.k;
import com.originui.core.utils.x;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.TextViewAttr;
import com.originui.widget.selection.VCheckBox;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogCustomCheckBox extends VCheckBox {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f891a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f892b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f893c;

    public VDialogCustomCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VDialogCustomCheckBox(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public VDialogCustomCheckBox(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f891a = 0;
        this.f892b = 0;
        this.f893c = false;
        this.f891a = context.getResources().getConfiguration().uiMode;
        boolean zI = i.i(context);
        this.f893c = zI;
        if (zI) {
            int iD = k.d(context, "dialog_text_color", "color", "vivo");
            this.f892b = iD;
            if (iD != 0) {
                setTextColor(context.getResources().getColor(this.f892b));
            }
            BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
            if (orCreateViewAttr instanceof TextViewAttr) {
                ((TextViewAttr) orCreateViewAttr).setGlobalTextColor(this.f892b);
            }
        }
        x.a(getContext(), this, 4.5f);
    }
}
