package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.hardware.display.DisplayManager;
import android.provider.Settings;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.core.utils.w;
import com.originui.resmap.BuildConfig;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f1086a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static boolean f1087b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static boolean f1088c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static boolean f1089d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f1090e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f1091f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f1092g = -1;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static int f1093h = -1;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static int f1094i = r.a(150);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static Method f1095j = null;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static Method f1096k = null;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static Method f1097l = null;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private static Field f1098m = null;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static boolean f1099n = false;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static boolean f1100o = false;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private static boolean f1101p = false;

    public static boolean A(Context context) {
        if (!r()) {
            return false;
        }
        if (com.originui.core.utils.h.k()) {
            return s.c(context) == 6.0f && "vos".equalsIgnoreCase(s.a());
        }
        return true;
    }

    public static void B() {
        f1089d = false;
    }

    public static void C(View view, boolean z2) {
        try {
            view.getClass().getMethod("setEdgeEffect", Boolean.TYPE).invoke(view, Boolean.valueOf(z2));
        } catch (Exception e2) {
            m.a("VDialogUtils reflect error: " + e2.getMessage());
        }
    }

    public static void D(View view, boolean z2) {
        try {
            view.getClass().getMethod("setSpringEffect", Boolean.TYPE).invoke(view, Boolean.valueOf(z2));
        } catch (Exception e2) {
            m.a("VDialogUtils reflect error: " + e2.getMessage());
        }
    }

    public static int a() {
        return f1094i;
    }

    private static int b(Context context, int i2, int i3) {
        Resources resources = context.getResources();
        int i4 = R$dimen.originui_dialog_corner_radius_level_2_rom14_0;
        int dimensionPixelSize = resources.getDimensionPixelSize(i4);
        if (i2 == 0) {
            return context.getResources().getDimensionPixelSize(R$dimen.originui_dialog_corner_radius_level_1_rom14_0);
        }
        if (i2 == 1) {
            return i2 > i3 ? b(context, i2 - 1, i3) : context.getResources().getDimensionPixelSize(i4);
        }
        if (i2 == 2) {
            return i2 > i3 ? b(context, i2 - 1, i3) : context.getResources().getDimensionPixelSize(R$dimen.originui_dialog_corner_radius_level_3_rom14_0);
        }
        if (i2 != 3) {
            return dimensionPixelSize;
        }
        return i2 > i3 ? b(context, i2 - 1, i3) : context.getResources().getDimensionPixelSize(R$dimen.originui_dialog_corner_radius_level_4_rom14_0);
    }

    public static int c(Context context, int i2) {
        Resources resources = context.getResources();
        int i3 = R$dimen.originui_dialog_corner_radius_rom13_5;
        int dimensionPixelSize = resources.getDimensionPixelSize(i3);
        if (r()) {
            if (z(context)) {
                return VThemeIconUtils.k(context, 103, VThemeIconUtils.o());
            }
            return A(context) ? context.getResources().getDimensionPixelSize(R$dimen.originui_dialog_corner_radius_fos15) : context.getResources().getDimensionPixelSize(R$dimen.originui_dialog_corner_radius_fos);
        }
        if (w(context)) {
            return VThemeIconUtils.k(context, 103, VThemeIconUtils.o());
        }
        if (VThemeIconUtils.o()) {
            if (s.c(context) >= 14.0f) {
                int iT = VThemeIconUtils.t();
                return iT != -1 ? b(context, iT, i2) : context.getResources().getDimensionPixelSize(R$dimen.originui_dialog_corner_radius_level_2_rom14_0);
            }
            if (s.c(context) >= 13.0f) {
                if (VThemeIconUtils.t() != 0) {
                    return context.getResources().getDimensionPixelSize(i3);
                }
                int iS = VThemeIconUtils.s();
                if (iS != -1) {
                    return iS;
                }
            }
        }
        return dimensionPixelSize;
    }

    public static int d() {
        return f1092g;
    }

    public static int e(Context context) {
        try {
            return Settings.Global.getInt(context.getContentResolver(), "multiwindow_dock_side", -1);
        } catch (Exception unused) {
            return -1;
        }
    }

    public static boolean f() {
        return f1091f;
    }

    public static int g() {
        return f1093h;
    }

    public static boolean h(View view) {
        if (view == null) {
            return false;
        }
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (h(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    public static boolean i(Context context) {
        if (!f1089d) {
            f1088c = k.f(context);
            f1089d = true;
        }
        return f1088c;
    }

    public static boolean j() {
        return f1087b;
    }

    public static boolean k() {
        return !r();
    }

    public static boolean l(Context context) {
        return k() || z(context);
    }

    public static boolean m(Context context) {
        try {
            return com.originui.core.utils.h.h() && ((DisplayManager) context.getSystemService("display")).getDisplays(null)[0].getDisplayId() == 1;
        } catch (Exception unused) {
        }
    }

    public static boolean n(Context context) {
        try {
            if (!com.originui.core.utils.h.i()) {
                return false;
            }
            Display display = ((DisplayManager) context.getSystemService("display")).getDisplay(0);
            Field declaredField = display.getClass().getDeclaredField("mDisplayInfo");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(display);
            Field declaredField2 = Class.forName("android.view.DisplayInfo").getDeclaredField("uniqueId");
            declaredField2.setAccessible(true);
            return !"local:secondary".equals((String) declaredField2.get(obj));
        } catch (Exception unused) {
            return false;
        }
    }

    public static boolean o() {
        return f1090e;
    }

    public static boolean p(Context context) {
        try {
            Field field = Configuration.class.getField("windowConfiguration");
            field.setAccessible(true);
            Object obj = field.get(context.getResources().getConfiguration());
            Class[] clsArr = new Class[0];
            int iIntValue = ((Integer) obj.getClass().getMethod("getWindowingMode", null).invoke(obj, null)).intValue();
            m.i("VDialogUtils", "isWindowInFreeFormByTaskInfo, windowingMode: " + iIntValue);
            return iIntValue == 106;
        } catch (Exception e2) {
            m.e("VDialogUtils", "Reflect failed, " + e2);
            return false;
        }
    }

    public static boolean q() {
        return f1086a;
    }

    public static boolean r() {
        return "overseas".equals(BuildConfig.FLAVOR_area);
    }

    public static boolean s() {
        if (f1100o) {
            return f1099n;
        }
        try {
            boolean zContains = w.b("ro.vivo.product.version", "").split("_")[0].contains("2236");
            f1099n = zContains;
            f1100o = true;
            return zContains;
        } catch (Exception unused) {
            return false;
        }
    }

    /* JADX WARN: Code duplicated, block: B:50:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:62:? A[RETURN, SYNTHETIC] */
    public static boolean t(Context context) {
        boolean z2;
        boolean z3 = false;
        if (com.originui.core.utils.h.i() && p(context)) {
            return false;
        }
        try {
            Class<?> cls = Class.forName("android.content.res.Configuration");
            if (f1098m == null) {
                f1098m = cls.getField("windowConfiguration");
            }
            Object obj = f1098m.get(context.getResources().getConfiguration());
            Class<?> cls2 = obj.getClass();
            if (f1095j == null) {
                Class[] clsArr = new Class[0];
                Method declaredMethod = cls2.getDeclaredMethod("isEmbedding", null);
                f1095j = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            if (f1096k == null) {
                Class[] clsArr2 = new Class[0];
                Method declaredMethod2 = cls2.getDeclaredMethod("getWindowingMode", null);
                f1096k = declaredMethod2;
                declaredMethod2.setAccessible(true);
            }
            try {
                try {
                    if (f1097l == null) {
                        Class[] clsArr3 = new Class[0];
                        Method declaredMethod3 = cls2.getDeclaredMethod("inSplitScreenMode", null);
                        f1097l = declaredMethod3;
                        declaredMethod3.setAccessible(true);
                    }
                } catch (Exception e2) {
                    if (m.f583b) {
                        m.f("VDialogUtils", "inSplitScreenMode error: ", e2);
                    }
                    if (((Boolean) f1095j.invoke(obj, null)).booleanValue() && ((Integer) f1096k.invoke(obj, null)).intValue() != 1 && ((Integer) f1096k.invoke(obj, null)).intValue() != 6) {
                        z2 = true;
                    }
                    return !((Boolean) f1095j.invoke(obj, null)).booleanValue() ? false : false;
                }
                if (!((Boolean) f1095j.invoke(obj, null)).booleanValue() && ((Integer) f1096k.invoke(obj, null)).intValue() != 1) {
                    return (((Boolean) f1097l.invoke(obj, null)).booleanValue() && ((Integer) f1096k.invoke(obj, null)).intValue() == 6) ? false : true;
                }
            } catch (Exception e3) {
                e = e3;
                z3 = z2;
                if (m.f583b) {
                    return z3;
                }
                m.f("VDialogUtils", "isSplitLayout error: ", e);
                return z3;
            }
            z2 = false;
        } catch (Exception e4) {
            e = e4;
            if (m.f583b) {
                return z3;
            }
            m.f("VDialogUtils", "isSplitLayout error: ", e);
            return z3;
        }
    }

    public static boolean u(Context context) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) context.getSystemService("accessibility");
        return accessibilityManager != null && accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled();
    }

    public static boolean v(Context context) {
        if (r()) {
            return false;
        }
        return !com.originui.core.utils.h.k() || s.c(context) >= 14.0f;
    }

    public static boolean w(Context context) {
        if (r()) {
            return false;
        }
        return !com.originui.core.utils.h.k() || s.c(context) >= 15.0f;
    }

    public static boolean x(Context context) {
        if (r()) {
            return false;
        }
        return !com.originui.core.utils.h.k() || s.c(context) >= 16.0f;
    }

    public static boolean y(Context context) {
        if (!r()) {
            return false;
        }
        if (com.originui.core.utils.h.k()) {
            return s.c(context) >= 6.0f && "vos".equalsIgnoreCase(s.a());
        }
        return true;
    }

    public static boolean z(Context context) {
        if (!r()) {
            return false;
        }
        if (com.originui.core.utils.h.k()) {
            return s.c(context) >= 7.0f && "vos".equalsIgnoreCase(s.a());
        }
        return true;
    }
}
