package com.originui.widget.dialog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$drawable {
    public static final int originui_dialog_background_rom13_5 = 2131034115;
    public static final int originui_dialog_scrollbar_vertical_rom13_5 = 2131034116;
}
