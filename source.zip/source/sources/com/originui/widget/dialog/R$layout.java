package com.originui.widget.dialog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$layout {
    public static final int originui_dialog_list_item_multichoice_rom13_0 = 2131230720;
    public static final int originui_dialog_list_item_multichoice_rom13_5 = 2131230721;
    public static final int originui_dialog_list_item_multiline_rom13_5 = 2131230722;
    public static final int originui_dialog_list_item_multiline_rom15_0 = 2131230723;
    public static final int originui_dialog_list_item_multitype_rom14_0 = 2131230724;
    public static final int originui_dialog_list_item_singlechoice_rom13_0 = 2131230725;
    public static final int originui_dialog_list_item_singlechoice_rom13_5 = 2131230726;
    public static final int originui_dialog_list_item_singleline_rom13_5 = 2131230727;
    public static final int originui_dialog_list_item_singleline_rom15_0 = 2131230728;
    public static final int originui_dialog_list_view_rom13_5 = 2131230729;
    public static final int originui_dialog_rom13_5 = 2131230730;
    public static final int originui_dialog_title_view_rom12_0 = 2131230731;
    public static final int originui_dialog_vigour_checkbox_message = 2131230732;
    public static final int originui_dialog_vigour_description_message = 2131230733;
    public static final int originui_dialog_vigour_icon_layout = 2131230734;
    public static final int originui_dialog_vigour_loading_layout = 2131230735;
    public static final int originui_dialog_vigour_message_custom = 2131230736;
    public static final int originui_dialog_vigour_message_first = 2131230737;
    public static final int originui_dialog_vigour_message_second = 2131230738;
    public static final int originui_dialog_vigour_progress_layout = 2131230739;
    public static final int originui_dialog_vigour_transport_message = 2131230740;
    public static final int originui_dialog_vigour_view_rom13_5 = 2131230741;
}
