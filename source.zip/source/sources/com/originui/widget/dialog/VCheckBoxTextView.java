package com.originui.widget.dialog;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CheckBox;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.r;
import com.originui.resmap.ResMapManager;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.TextViewAttr;
import com.originui.resmap.bridge.ContextBridge;
import com.originui.widget.selection.VCheckBox;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VCheckBoxTextView extends VCustomCheckedTextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private VCheckBox f817a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ContextBridge f818b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f819c;

    public VCheckBoxTextView(Context context) {
        this(context, null);
    }

    @Override // com.originui.widget.dialog.VCustomCheckedTextView
    protected void a() {
        super.a();
        this.f817a.resetDefaultColor(getContext(), true, true, true, true);
        setCheckMarkDrawable(this.f817a.getDrawable(VThemeIconUtils.n()));
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(CheckBox.class.getName());
        int iH = r.h(this.f818b, "checked", "string", "android");
        int iH2 = r.h(this.f818b, "not_checked", "string", "android");
        if (iH <= 0 || iH2 <= 0) {
            return;
        }
        accessibilityNodeInfo.setStateDescription(accessibilityNodeInfo.isChecked() ? this.f818b.getString(iH) : this.f818b.getString(iH2));
        setStateDescription(accessibilityNodeInfo.isChecked() ? this.f818b.getString(iH) : this.f818b.getString(iH2));
    }

    @Override // android.view.View
    public boolean performAccessibilityAction(int i2, Bundle bundle) {
        if (i.k() && i2 == 16) {
            if (isChecked()) {
                int iH = r.h(this.f818b, "not_checked", "string", "android");
                if (iH != -1) {
                    announceForAccessibility(r.j(this.f818b, iH));
                }
            } else {
                int iH2 = r.h(this.f818b, "checked", "string", "android");
                if (iH2 != -1) {
                    announceForAccessibility(r.j(this.f818b, iH2));
                }
            }
        }
        return super.performAccessibilityAction(i2, bundle);
    }

    @Override // android.view.View
    public boolean performClick() {
        return super.performClick();
    }

    public VCheckBoxTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VCheckBoxTextView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VCheckBoxTextView(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f817a = null;
        this.f819c = 0;
        this.f818b = ResMapManager.byRomVer(context);
        this.f817a = new VCheckBox(context, 0, i.g());
        a();
        if (!i.k() || i.i(context)) {
            return;
        }
        this.f819c = this.f818b.getResMapId(this.f818b.obtainStyledAttributes(attributeSet, R$styleable.VCustomTextView).getResourceId(R$styleable.VCustomTextView_android_textColor, R$color.originui_dialog_list_main_item_text_color_rom13_5));
        BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
        if (orCreateViewAttr instanceof TextViewAttr) {
            ((TextViewAttr) orCreateViewAttr).setTextColor(this.f819c);
        }
        if (this.f819c != 0) {
            setTextColor(context.getResources().getColor(this.f819c));
        }
    }
}
