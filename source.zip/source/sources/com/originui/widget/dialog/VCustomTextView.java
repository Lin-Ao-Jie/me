package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.TextView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.k;
import com.originui.core.utils.q;
import com.originui.core.utils.x;
import com.originui.resmap.R;
import com.originui.resmap.ResMapManager;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.TextViewAttr;
import com.originui.resmap.attr.ViewAttrConstant;
import com.originui.resmap.bridge.ContextBridge;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VCustomTextView extends TextView implements VThemeIconUtils.ISystemColorRom14 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f860a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f861b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private a f862c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private ContextBridge f863d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f864e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private c f865f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private c f866g;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface a {
        void a(int i2, boolean z2);

        void b(int i2, VCustomTextView vCustomTextView, boolean z2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface b {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        String f867a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int f868b;

        c(String str, int i2) {
            this.f867a = str;
            this.f868b = i2;
        }
    }

    public VCustomTextView(Context context) {
        this(context, null);
    }

    private int a(Context context, int i2) {
        if (i2 == R$id.alertTitle) {
            return k.d(context, "dialog_title_color", "color", "vivo");
        }
        if (i2 != R$id.transport_message) {
            return k.d(context, "dialog_text_color", "color", "vivo");
        }
        return 0;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (i.r() && VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f861b) {
            return;
        }
        if (!i.r() || i.y(getContext())) {
            int i4 = this.f860a;
            if (i4 == 16908299 || i4 == R$id.message_custom || i4 == R$id.message1 || i4 == R$id.message2 || i4 == R$id.content_description) {
                if (getLineCount() >= 2) {
                    super.setGravity(8388627);
                } else {
                    super.setGravity(17);
                }
                a aVar = this.f862c;
                if (aVar != null) {
                    aVar.a(getId(), getLineCount() >= 2);
                    this.f862c.b(getId(), this, getLineCount() >= 2);
                }
            }
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(com.originui.core.utils.d.e(drawable, "6.0.1.8"));
    }

    @Override // android.widget.TextView
    public void setGravity(int i2) {
        super.setGravity(i2);
        this.f861b = true;
    }

    public void setGravityInternal(int i2) {
        if (this.f861b) {
            return;
        }
        super.setGravity(i2);
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColor() {
        if (this.f865f != null) {
            Context context = getContext();
            c cVar = this.f865f;
            setTextColor(VThemeIconUtils.p(context, cVar.f867a, cVar.f868b));
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColorNightMode() {
        if (this.f866g != null) {
            Context context = getContext();
            c cVar = this.f866g;
            setTextColor(VThemeIconUtils.p(context, cVar.f867a, cVar.f868b));
        }
    }

    public void setOnTextViewChangeListener(a aVar) {
        this.f862c = aVar;
    }

    public void setSystemDayColor(c cVar) {
        this.f865f = cVar;
        if (!VThemeIconUtils.A(getContext()) && i.r() && VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    public void setSystemNightColor(c cVar) {
        this.f866g = cVar;
        if (VThemeIconUtils.A(getContext()) && i.r() && VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    @Override // android.widget.TextView
    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        if (charSequence == null) {
            charSequence = "";
        }
        super.setText(com.originui.core.utils.d.b(charSequence, "6.0.1.8"), bufferType);
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setViewDefaultColor() {
        if (this.f864e != 0) {
            setTextColor(getContext().getResources().getColor(this.f864e));
        }
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
    }

    public VCustomTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VCustomTextView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VCustomTextView(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f860a = 0;
        this.f861b = false;
        this.f862c = null;
        this.f864e = 0;
        this.f863d = ResMapManager.byRomVer(context);
        this.f860a = getId();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.ViewAttr, i2, i3);
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.ViewAttr_android_textSize, 0);
        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(R.styleable.ViewAttr_android_lineSpacingExtra, 0);
        if (ParserUtil.isValidResId(resourceId)) {
            setTextSize(0, getResources().getDimensionPixelSize(resourceId));
        }
        if (ParserUtil.isValidResId(resourceId2)) {
            setLineSpacing(getResources().getDimensionPixelSize(resourceId2), getLineSpacingMultiplier());
        }
        typedArrayObtainStyledAttributes.recycle();
        if (i.o()) {
            setForceDarkAllowed(i.f());
        } else {
            setForceDarkAllowed(false);
            q.r(this, 0);
        }
        if (i.i(context)) {
            int iA = a(context, this.f860a);
            this.f864e = iA;
            if (iA != 0) {
                setTextColor(context.getResources().getColor(this.f864e));
            }
            BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
            if (orCreateViewAttr instanceof TextViewAttr) {
                ((TextViewAttr) orCreateViewAttr).setGlobalTextColor(this.f864e);
            }
        } else {
            this.f864e = this.f863d.getResMapId(this.f863d.obtainStyledAttributes(attributeSet, R$styleable.VCustomTextView).getResourceId(R$styleable.VCustomTextView_android_textColor, R$color.originui_dialog_list_main_item_text_color_rom13_5));
            BaseViewAttr orCreateViewAttr2 = ParserUtil.getOrCreateViewAttr(this);
            if (orCreateViewAttr2 instanceof TextViewAttr) {
                TextViewAttr textViewAttr = (TextViewAttr) orCreateViewAttr2;
                textViewAttr.setTextColor(this.f864e);
                if (!i.j()) {
                    textViewAttr.setTextColorActiveMode(ViewAttrConstant.createActiveMode(false, false, false, false, true));
                }
            }
            if (this.f864e != 0) {
                setTextColor(context.getResources().getColor(this.f864e));
            }
        }
        int i4 = this.f860a;
        if (i4 == R$id.alertTitle || i4 == R$id.description_title) {
            return;
        }
        x.a(getContext(), this, 4.5f);
    }

    public void setOnVisibilityChangeListener(b bVar) {
    }
}
