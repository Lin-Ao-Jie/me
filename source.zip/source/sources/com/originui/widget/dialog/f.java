package com.originui.widget.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import com.originui.core.utils.m;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.resmap.ResMapManager;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class f extends Dialog implements DialogInterface, ComponentCallbacks {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final com.originui.widget.dialog.d f1032a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f1033b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private com.originui.widget.dialog.h f1034c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected boolean f1035d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f1036e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f1037f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f1038g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f1039h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final com.originui.widget.dialog.b f1040i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final Handler f1041j;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements View.OnTouchListener {
        a() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return f.this.d(motionEvent);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends VCustomRoundRectLayout.g {
        b() {
        }

        @Override // com.originui.widget.dialog.VCustomRoundRectLayout.g
        void a(boolean z2) {
            f.this.g(z2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ long f1044a;

        c(long j2) {
            this.f1044a = j2;
        }

        @Override // java.lang.Runnable
        public void run() {
            com.originui.core.utils.e.d(this.f1044a);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ long f1046a;

        d(long j2) {
            this.f1046a = j2;
        }

        @Override // java.lang.Runnable
        public void run() {
            com.originui.core.utils.e.d(this.f1046a);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ long f1048a;

        e(long j2) {
            this.f1048a = j2;
        }

        @Override // java.lang.Runnable
        public void run() {
            com.originui.core.utils.e.d(this.f1048a);
        }
    }

    /* JADX INFO: renamed from: com.originui.widget.dialog.f$f, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class C0007f {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final com.originui.widget.dialog.d.j f1050a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f1051b;

        public C0007f(Context context, int i2) {
            this.f1050a = new com.originui.widget.dialog.d.j(new ContextThemeWrapper(context, f.j(context, i2)));
            this.f1051b = i2;
        }

        public f a() {
            f fVar = new f(this.f1050a.f962a, this.f1051b);
            b(fVar);
            return fVar;
        }

        protected void b(f fVar) {
            this.f1050a.a(fVar.f1032a);
            fVar.setCancelable(this.f1050a.f980s);
            if (this.f1050a.f980s) {
                fVar.setCanceledOnTouchOutside(true);
            }
            fVar.setOnCancelListener(this.f1050a.f981t);
            fVar.setOnDismissListener(this.f1050a.f982u);
            DialogInterface.OnKeyListener onKeyListener = this.f1050a.f983v;
            if (onKeyListener != null) {
                fVar.setOnKeyListener(onKeyListener);
            }
        }

        public C0007f c(int i2, DialogInterface.OnClickListener onClickListener) {
            com.originui.widget.dialog.d.j jVar = this.f1050a;
            jVar.f974m = jVar.f962a.getText(i2);
            this.f1050a.f976o = onClickListener;
            return this;
        }

        public C0007f d(int i2, DialogInterface.OnClickListener onClickListener) {
            com.originui.widget.dialog.d.j jVar = this.f1050a;
            jVar.f971j = jVar.f962a.getText(i2);
            this.f1050a.f973l = onClickListener;
            return this;
        }

        public C0007f e(int i2) {
            com.originui.widget.dialog.d.j jVar = this.f1050a;
            jVar.f967f = jVar.f962a.getText(i2);
            return this;
        }

        public C0007f f(CharSequence charSequence) {
            this.f1050a.f967f = charSequence;
            return this;
        }

        public C0007f g(View view) {
            com.originui.widget.dialog.d.j jVar = this.f1050a;
            jVar.A = view;
            jVar.f987z = 0;
            jVar.F = false;
            return this;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface g {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface h {
    }

    protected f(Context context, int i2) {
        super(ResMapManager.byDeviceType(context).fitConfig(true), j(context, i2));
        this.f1033b = true;
        this.f1034c = null;
        this.f1035d = true;
        this.f1036e = true;
        this.f1037f = true;
        this.f1038g = true;
        this.f1039h = true;
        this.f1040i = new com.originui.widget.dialog.b(this);
        this.f1041j = new Handler();
        m.i("VDialog", "version info = vdialog_6.0.1.8");
        m.i("VDialog", "romVersion info = " + s.c(context));
        m.i("VDialog", "context = " + context.toString());
        m.i("VDialog", "context = " + context.getResources().getConfiguration().toString());
        i.B();
        this.f1032a = new com.originui.widget.dialog.d(getContext(), this, getWindow());
        if (this.f1034c == null) {
            this.f1034c = new com.originui.widget.dialog.h(this, getWindow(), getContext());
        }
        this.f1034c.p();
    }

    private void c() {
        if (this.f1032a.B() != null) {
            this.f1032a.B().setBlurEnable(this.f1038g);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean d(MotionEvent motionEvent) {
        if (!this.f1033b) {
            return false;
        }
        if (this.f1034c == null) {
            this.f1034c = new com.originui.widget.dialog.h(this, getWindow(), getContext());
        }
        this.f1034c.F(motionEvent);
        return this.f1034c.v(motionEvent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g(boolean z2) {
        Point point = new Point();
        WindowManager windowManager = (WindowManager) getContext().getSystemService("window");
        if (windowManager == null || com.originui.core.utils.h.j()) {
            return;
        }
        if (i.w(getContext()) || i.z(getContext())) {
            windowManager.getDefaultDisplay().getRealSize(point);
            if (this.f1039h && z2 && point.x > r.c(getContext(), R$dimen.originui_dialog_500dp)) {
                getWindow().setLayout(-1, -2);
            } else {
                getWindow().setLayout(-2, -2);
            }
        }
    }

    private void i() {
        this.f1032a.B().setSplitChangedCallback(new b());
    }

    static int j(Context context, int i2) {
        if (((i2 >>> 24) & 255) >= 1) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R$attr.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void cancel() {
        if (i.k() && s.b() >= 15.0f) {
            try {
                long jA = com.originui.core.utils.e.a("Animation", "VDialogExit for SystemAnimation", -1, 0, 500, 0, 0, 0, 0, 600, Process.myPid(), 0, 0, 0);
                m.i("VDialog", "RefreshRateRequester result =" + jA);
                if (jA != -1) {
                    this.f1041j.postDelayed(new e(jA), 650L);
                }
            } catch (Throwable unused) {
            }
        }
        super.cancel();
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void dismiss() {
        if (getContext() instanceof Activity) {
            Activity activity = (Activity) getContext();
            if (activity.isFinishing() || activity.isDestroyed()) {
                return;
            }
        }
        if (this.f1036e) {
            if (i.k() && s.b() >= 15.0f) {
                try {
                    long jA = com.originui.core.utils.e.a("Animation", "VDialogExit for SystemAnimation", -1, 0, 500, 0, 0, 0, 0, 600, Process.myPid(), 0, 0, 0);
                    m.i("VDialog", "RefreshRateRequester result =" + jA);
                    if (jA != -1) {
                        this.f1041j.postDelayed(new d(jA), 650L);
                    }
                } catch (Throwable unused) {
                }
            }
            super.dismiss();
        }
        m.i("VDialog", "dismiss dialog = " + hashCode());
    }

    public View e() {
        return this.f1032a.B();
    }

    public View f() {
        return this.f1032a.D();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        com.originui.widget.dialog.h hVar = this.f1034c;
        if (hVar != null) {
            hVar.w();
        }
    }

    @Override // android.app.Dialog
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle bundle) {
        WindowManager.LayoutParams attributes;
        super.onCreate(bundle);
        this.f1032a.K();
        this.f1032a.B().setFullScreenStyle(this.f1039h);
        this.f1032a.C().setFullScreenStyle(this.f1039h);
        i();
        if (this.f1032a.G() && !com.originui.core.utils.h.j() && !i.m(getContext()) && ((i.k() && s.c(getContext()) >= 13.0f) || i.z(getContext()))) {
            getWindow().setWindowAnimations(R$style.VAnimation_Dialog_Menu_Ime);
        } else if (this.f1032a.L() && (attributes = getWindow().getAttributes()) != null && attributes.gravity == 17) {
            getWindow().setWindowAnimations(R$style.VAnimation_Dialog_Center_Loading);
        }
        if (this.f1032a.F() != null) {
            this.f1032a.F().setOnTouchListener(new a());
        }
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        com.originui.widget.dialog.h hVar = this.f1034c;
        if (hVar != null) {
            hVar.y();
        }
    }

    @Override // android.app.Dialog
    protected void onStart() {
        super.onStart();
        c();
        g(i.t(getContext()));
    }

    @Override // android.app.Dialog
    protected void onStop() {
        super.onStop();
    }

    @Override // android.app.Dialog
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if ((i.x(getContext()) || i.z(getContext())) && motionEvent.getAction() == 0 && f() != null && this.f1034c.s(getContext(), motionEvent, f())) {
            return false;
        }
        if (d(motionEvent)) {
            return true;
        }
        if (!this.f1035d || !isShowing() || !this.f1037f || !this.f1034c.s(getContext(), motionEvent, e()) || motionEvent.getAction() != 1) {
            return false;
        }
        cancel();
        return true;
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
    }

    public void setCancelOnSlideDown(boolean z2) {
        com.originui.widget.dialog.h hVar = this.f1034c;
        if (hVar != null) {
            hVar.B(z2);
        }
    }

    @Override // android.app.Dialog
    public void setCancelable(boolean z2) {
        this.f1035d = z2;
        super.setCancelable(z2);
        com.originui.widget.dialog.h hVar = this.f1034c;
        if (hVar != null) {
            hVar.E(z2);
        }
    }

    @Override // android.app.Dialog
    public void setCanceledOnTouchOutside(boolean z2) {
        this.f1037f = z2;
        super.setCanceledOnTouchOutside(z2);
        if (this.f1034c != null) {
            if (z2 && !this.f1035d) {
                setCancelable(true);
            }
            this.f1034c.C(z2);
        }
    }

    @Override // android.app.Dialog
    public void setOnCancelListener(DialogInterface.OnCancelListener onCancelListener) {
        super.setOnCancelListener(com.originui.widget.dialog.b.f(onCancelListener));
    }

    @Override // android.app.Dialog
    public void setOnDismissListener(DialogInterface.OnDismissListener onDismissListener) {
        super.setOnDismissListener(com.originui.widget.dialog.b.g(onDismissListener));
    }

    @Override // android.app.Dialog
    public void setOnShowListener(DialogInterface.OnShowListener onShowListener) {
        super.setOnShowListener(com.originui.widget.dialog.b.h(onShowListener));
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f1032a.X(charSequence);
    }

    public void setWindowSlide(boolean z2) {
        this.f1033b = z2;
    }

    @Override // android.app.Dialog
    public void show() {
        com.originui.widget.dialog.h hVar = this.f1034c;
        if (hVar != null) {
            hVar.A();
        }
        if (i.k() && s.b() >= 15.0f) {
            try {
                long jA = com.originui.core.utils.e.a("Animation", "VDialogEnter for SystemAnimation", -1, 0, 500, 0, 0, 0, 0, 600, Process.myPid(), 0, 0, 0);
                m.i("VDialog", "RefreshRateRequester result =" + jA);
                if (jA != -1) {
                    this.f1041j.postDelayed(new c(jA), 650L);
                }
            } catch (Throwable unused) {
            }
        }
        super.show();
        if (i.q()) {
            this.f1040i.c();
        }
        m.i("VDialog", "show dialog = " + hashCode() + ", windowAttributes = " + getWindow().getAttributes().toString());
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
    }

    public void setOnDialogBackPressedListener(g gVar) {
    }

    public void setOnWindowFocusChangeListener(h hVar) {
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
    }

    public void h(boolean z2, boolean z3) {
    }
}
