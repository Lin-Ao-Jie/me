package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.ScrollView;
import com.originui.core.utils.m;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VCustomScrollView extends ScrollView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private com.originui.widget.dialog.a f851a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f852b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private b f853c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f854d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f855e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f856f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f857g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f858h;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (VCustomScrollView.this.f851a != null) {
                VCustomScrollView.this.f851a.d();
            }
        }
    }

    public VCustomScrollView(Context context) {
        this(context, null);
    }

    private void b(boolean z2) {
        if (this.f856f) {
            i.D(this, this.f857g);
        } else {
            i.D(this, z2);
        }
    }

    public void c(int i2, int i3) {
        com.originui.widget.dialog.a aVar = this.f851a;
        if (aVar != null) {
            aVar.h(0, i2, 0, i3);
        }
    }

    @Override // android.widget.ScrollView, android.view.View
    public void computeScroll() {
        super.computeScroll();
        if (getScrollY() == 0) {
            this.f852b = getVerticalScrollRange();
        }
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    public Object getFastScroller() {
        return this.f851a.b();
    }

    public int getHorizontalScrollOExtent() {
        return computeHorizontalScrollExtent();
    }

    public int getHorizontalScrollOffset() {
        return computeHorizontalScrollOffset();
    }

    public int getHorizontalScrollRange() {
        return computeHorizontalScrollRange();
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    public int getVerticalScrollExtent() {
        return computeVerticalScrollExtent();
    }

    public int getVerticalScrollOffset() {
        return computeVerticalScrollOffset();
    }

    public int getVerticalScrollRange() {
        return computeVerticalScrollRange();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        int i2 = configuration.uiMode;
        if (this.f858h != i2) {
            com.originui.widget.dialog.a aVar = this.f851a;
            if (aVar != null) {
                aVar.g();
            }
            this.f858h = i2;
        }
    }

    @Override // android.widget.ScrollView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.f855e) {
            return super.onInterceptTouchEvent(motionEvent);
        }
        return false;
    }

    @Override // android.widget.ScrollView, android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (!this.f855e) {
            this.f854d = false;
            this.f851a.i(false);
            return;
        }
        View childAt = getChildAt(0);
        this.f854d = true;
        b(true);
        if (childAt != null) {
            boolean z3 = getHeight() < (childAt.getHeight() + getPaddingTop()) + getPaddingBottom();
            this.f854d = z3;
            b(z3);
            this.f851a.i(this.f854d);
        }
        com.originui.widget.dialog.a aVar = this.f851a;
        if (aVar != null) {
            aVar.i(this.f854d);
            this.f851a.d();
        }
        b bVar = this.f853c;
        if (bVar != null) {
            bVar.c(this.f854d);
        }
        if (m.f583b) {
            m.b("VDialog/VCustomScrollView", "onLayout springEffect = " + this.f854d);
        }
    }

    @Override // android.widget.ScrollView, android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f855e || getChildCount() <= 0) {
            return;
        }
        getChildAt(0).measure((i2 - getPaddingLeft()) - getPaddingRight(), (i3 - getPaddingTop()) - getPaddingBottom());
    }

    @Override // android.view.View
    protected void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
        if (this.f851a != null && i3 != i5) {
            if (getScrollY() < 0) {
                this.f851a.e(-getScrollY());
            } else {
                int verticalScrollRange = getVerticalScrollRange();
                int i6 = this.f852b;
                if (verticalScrollRange > i6) {
                    this.f851a.e(i6 - getVerticalScrollRange());
                } else {
                    this.f851a.d();
                }
            }
        }
        b bVar = this.f853c;
        if (bVar != null) {
            bVar.e();
            if (getScrollY() <= 0) {
                this.f853c.d();
            } else if (getScrollY() >= this.f852b - getVerticalScrollExtent()) {
                this.f853c.b();
            } else {
                this.f853c.a();
            }
        }
    }

    @Override // android.widget.ScrollView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        com.originui.widget.dialog.a aVar;
        if (!this.f855e) {
            return false;
        }
        if (this.f854d && (aVar = this.f851a) != null && aVar.f(motionEvent)) {
            return true;
        }
        try {
            super.onTouchEvent(motionEvent);
        } catch (Exception unused) {
            m.e("VDialog/VCustomScrollView", "exception in onTouchEvent");
        }
        return this.f854d;
    }

    public void setOnScrollableChangeListener(b bVar) {
        this.f853c = bVar;
    }

    @Deprecated
    public void setScrollable(boolean z2) {
        setSupportScrollable(z2);
    }

    public void setSpringEffectEnable(boolean z2) {
        this.f856f = true;
        this.f857g = z2;
    }

    public void setSupportScrollable(boolean z2) {
        this.f855e = z2;
    }

    public VCustomScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VCustomScrollView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VCustomScrollView(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f851a = null;
        this.f852b = 0;
        this.f853c = null;
        this.f854d = true;
        this.f855e = true;
        this.f856f = false;
        this.f857g = false;
        this.f858h = -1;
        b(true);
        i.C(this, false);
        setVerticalScrollBarEnabled(false);
        setScrollContainer(true);
        this.f851a = com.originui.widget.dialog.a.a(this);
        post(new a());
        this.f858h = getResources().getConfiguration().uiMode;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface b {
        void c(boolean z2);

        default void a() {
        }

        default void b() {
        }

        default void d() {
        }

        default void e() {
        }
    }
}
