package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import com.originui.core.utils.VThemeIconUtils;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogContentMessageTextView extends VCustomTextView {
    public VDialogContentMessageTextView(Context context) {
        this(context, null);
    }

    @Override // com.originui.widget.dialog.VCustomTextView, com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColor() {
        setTextColor(VThemeIconUtils.p(getContext(), VThemeIconUtils.f476z, VThemeIconUtils.C));
    }

    @Override // com.originui.widget.dialog.VCustomTextView, com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColorNightMode() {
        setTextColor(VThemeIconUtils.p(getContext(), VThemeIconUtils.f476z, VThemeIconUtils.K));
    }

    @Override // com.originui.widget.dialog.VCustomTextView, com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setViewDefaultColor() {
        super.setViewDefaultColor();
    }

    public VDialogContentMessageTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Deprecated
    public void setResetWordWidth(boolean z2) {
    }
}
