package com.originui.widget.dialog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static final int originui_dialog_background = 2130903076;
    public static final int originui_dialog_btn_default_text_color = 2130903077;
    public static final int originui_dialog_btn_del = 2130903078;
    public static final int originui_dialog_btn_del_no_fill = 2130903079;
    public static final int originui_dialog_btn_text_color = 2130903080;
    public static final int originui_dialog_button_divider = 2130903081;
    public static final int originui_dialog_content_description_rom13_5 = 2130903082;
    public static final int originui_dialog_content_description_rom15_0 = 2130903083;
    public static final int originui_dialog_divider_default_rom13_0 = 2130903084;
    public static final int originui_dialog_item_background_selector_color_rom15_0 = 2130903085;
    public static final int originui_dialog_list_item_background_pressed = 2130903086;
    public static final int originui_dialog_list_main_item_text_color_rom13_5 = 2130903087;
    public static final int originui_dialog_list_main_item_text_color_rom15_0 = 2130903088;
    public static final int originui_dialog_list_sub_item_text_color_rom13_5 = 2130903089;
    public static final int originui_dialog_list_sub_item_text_color_rom15_0 = 2130903090;
    public static final int originui_dialog_list_sub_item_text_color_rom16_0 = 2130903091;
    public static final int originui_dialog_message_text_color = 2130903092;
    public static final int originui_dialog_progress_text = 2130903093;
    public static final int originui_dialog_scrollbar_color_rom13_5 = 2130903094;
    public static final int originui_dialog_select_item_divider = 2130903095;
    public static final int originui_dialog_title_color = 2130903096;
    public static final int originui_dialog_transparent = 2130903097;
    public static final int originui_dialog_transport_text_color = 2130903098;
    public static final int originui_loading_desc_rom14_0 = 2130903103;
    public static final int originui_loading_desc_rom15_0 = 2130903104;
    public static final int originui_vdialog_btn_default_text_color = 2130903107;
    public static final int primary_text_dark_disable_only = 2130903110;
}
