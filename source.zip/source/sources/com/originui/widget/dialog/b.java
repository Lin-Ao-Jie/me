package com.originui.widget.dialog;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import com.originui.core.utils.m;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
class b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final Map f901c = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Dialog f902a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final d f903b = new a();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements d {
        a() {
        }

        @Override // com.originui.widget.dialog.b.d
        public void a() {
            b.this.b();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class c implements DialogInterface.OnDismissListener, DialogInterface.OnCancelListener, DialogInterface.OnShowListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private Object f906a;

        c(Object obj) {
            b(obj);
        }

        void a() {
            this.f906a = null;
        }

        void b(Object obj) {
            this.f906a = obj;
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialogInterface) {
            Object obj = this.f906a;
            if (obj instanceof DialogInterface.OnCancelListener) {
                ((DialogInterface.OnCancelListener) obj).onCancel(dialogInterface);
            }
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            Object obj = this.f906a;
            if (obj instanceof DialogInterface.OnDismissListener) {
                ((DialogInterface.OnDismissListener) obj).onDismiss(dialogInterface);
            }
        }

        @Override // android.content.DialogInterface.OnShowListener
        public void onShow(DialogInterface dialogInterface) {
            Object obj = this.f906a;
            if (obj instanceof DialogInterface.OnShowListener) {
                ((DialogInterface.OnShowListener) obj).onShow(dialogInterface);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private interface d {
        void a();
    }

    b(Dialog dialog) {
        this.f902a = dialog;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        m.i("DialogLifecycle", "callDestroy(), for-release");
        e();
        n();
        d();
    }

    private void d() {
        try {
            Field fieldJ = j("mListenersHandler");
            if (fieldJ != null && this.f902a != null) {
                fieldJ.setAccessible(true);
                Handler handler = (Handler) fieldJ.get(this.f902a);
                if (handler != null) {
                    handler.removeCallbacksAndMessages(null);
                }
                m.i("DialogLifecycle", "clearHandler(), for-release");
            }
        } catch (IllegalAccessException e2) {
            m.f("DialogLifecycle", "getListenerHandler(), failed.", e2);
        }
    }

    private void e() {
        Dialog dialog = this.f902a;
        if (dialog != null && dialog.isShowing()) {
            this.f902a.dismiss();
            m.i("DialogLifecycle", "dismiss(), for-release");
        }
        Dialog dialog2 = this.f902a;
        com.originui.widget.dialog.d dVar = dialog2 instanceof f ? ((f) dialog2).f1032a : null;
        if (dVar != null) {
            dVar.M();
        }
    }

    static DialogInterface.OnCancelListener f(DialogInterface.OnCancelListener onCancelListener) {
        if (onCancelListener != null) {
            return new c(onCancelListener);
        }
        return null;
    }

    static DialogInterface.OnDismissListener g(DialogInterface.OnDismissListener onDismissListener) {
        if (onDismissListener != null) {
            return new c(onDismissListener);
        }
        return null;
    }

    static DialogInterface.OnShowListener h(DialogInterface.OnShowListener onShowListener) {
        if (onShowListener != null) {
            return new c(onShowListener);
        }
        return null;
    }

    private Activity i(ContextWrapper contextWrapper, Set set) {
        Context baseContext = contextWrapper.getBaseContext();
        if (baseContext instanceof Activity) {
            return (Activity) baseContext;
        }
        String strL = l(contextWrapper);
        if (set.contains(strL)) {
            return null;
        }
        set.add(strL);
        if (baseContext instanceof ContextWrapper) {
            return i((ContextWrapper) baseContext, set);
        }
        return null;
    }

    private static Field j(String str) {
        Field declaredField = (Field) f901c.get(str);
        if (declaredField == null) {
            try {
                declaredField = Dialog.class.getDeclaredField(str);
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e2) {
                m.f("DialogLifecycle", "getField(), failed.", e2);
            }
            f901c.put(str, declaredField);
        }
        return declaredField;
    }

    private static Message k(Dialog dialog, String str) {
        try {
            Field fieldJ = j(str);
            if (fieldJ == null || dialog == null) {
                return null;
            }
            return (Message) fieldJ.get(dialog);
        } catch (IllegalAccessException e2) {
            m.f("DialogLifecycle", "getMessage(), failed.", e2);
            return null;
        }
    }

    private String l(Object obj) {
        if (obj == null) {
            return "";
        }
        return obj.getClass().getName() + "@" + Integer.toHexString(obj.hashCode());
    }

    private Activity m() {
        Activity ownerActivity = this.f902a.getOwnerActivity();
        if (ownerActivity != null) {
            return ownerActivity;
        }
        Context context = this.f902a.getContext();
        if (context instanceof Activity) {
            return (Activity) context;
        }
        if (context instanceof ContextWrapper) {
            return i((ContextWrapper) context, new HashSet());
        }
        return null;
    }

    private void n() {
        if (i.q()) {
            o(this.f902a, "mDismissMessage");
            o(this.f902a, "mCancelMessage");
            o(this.f902a, "mShowMessage");
            m.i("DialogLifecycle", "releaseMsg(), for-release");
        }
    }

    private static void o(Dialog dialog, String str) {
        Message messageK = k(dialog, str);
        if (messageK != null) {
            Object obj = messageK.obj;
            if (obj instanceof c) {
                ((c) obj).a();
                m.i("DialogLifecycle", "releaseMsg(), name:" + str);
            }
        }
    }

    void c() {
        C0002b c0002b;
        Activity activityM = m();
        if (activityM == null) {
            return;
        }
        if (activityM.isFinishing() || activityM.isDestroyed()) {
            b();
            return;
        }
        View decorView = activityM.getWindow().getDecorView();
        int i2 = R$id.originui_dialog_lifecycle_listener;
        Object tag = decorView.getTag(i2);
        if (tag instanceof C0002b) {
            c0002b = (C0002b) tag;
        } else {
            c0002b = new C0002b(null);
            activityM.getWindow().getDecorView().setTag(i2, c0002b);
            activityM.registerActivityLifecycleCallbacks(c0002b);
        }
        c0002b.a(this.f903b);
    }

    /* JADX INFO: renamed from: com.originui.widget.dialog.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class C0002b implements Application.ActivityLifecycleCallbacks {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Set f905a;

        private C0002b() {
            this.f905a = Collections.newSetFromMap(new WeakHashMap());
        }

        void a(d dVar) {
            this.f905a.add(dVar);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            for (d dVar : this.f905a) {
                if (dVar != null) {
                    dVar.a();
                }
            }
        }

        /* synthetic */ C0002b(a aVar) {
            this();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }
    }
}
