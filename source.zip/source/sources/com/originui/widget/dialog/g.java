package com.originui.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.view.View;
import android.widget.ScrollView;
import com.originui.resmap.ConfigMonitor;
import com.originui.resmap.attr.ParserUtil;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class g extends BaseDialogBuilder {
    private f.C0007f B;

    public g(Context context, int i2) {
        super(context, i2);
        this.B = null;
        this.f778a = 1;
        i2 = i2 <= 0 ? g(i2) : i2;
        this.f782e = i2;
        this.B = v(this.f781d, i2);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: A, reason: merged with bridge method [inline-methods] */
    public g p(View view) {
        this.f779b |= 524288;
        this.B = this.B.g(view);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: B, reason: merged with bridge method [inline-methods] */
    public g q(CharSequence charSequence) {
        return (g) super.q(charSequence);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: C, reason: merged with bridge method [inline-methods] */
    public g r(CharSequence charSequence) {
        return (g) super.r(charSequence);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    public void s(Dialog dialog) {
        int resourceId;
        int resourceId2;
        super.s(dialog);
        if (this.f783f == null || !i.l(this.f781d) || j()) {
            return;
        }
        Context context = this.f781d;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, R$styleable.VDialog, 0, BaseDialogBuilder.f(context));
        if ((this.f779b & 8192) == 8192) {
            resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogLoadingTopPaddingNoTitle, R$dimen.originui_dialog_loading_padding_top_no_title);
            resourceId2 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogLoadingBottomPaddingNoButton, R$dimen.originui_dialog_loading_content_padding_bottom_no_button);
        } else {
            resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogContentTopPaddingNoTitle, R$dimen.originui_dialog_center_content_padding_top_no_title);
            resourceId2 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogContentBottomPaddingNoButton, R$dimen.originui_dialog_center_content_padding_bottom_no_button);
        }
        typedArrayObtainStyledAttributes.recycle();
        ScrollView scrollView = this.f783f;
        int i2 = R$dimen.originui_dialog_no_dp;
        if (k()) {
            resourceId = i2;
        }
        if (i()) {
            resourceId2 = i2;
        }
        ParserUtil.setViewPadding(scrollView, i2, resourceId, i2, resourceId2);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    public void t(Dialog dialog) {
        super.t(dialog);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: u, reason: merged with bridge method [inline-methods] */
    public f c() {
        f fVarA = this.B.a();
        s(fVarA);
        fVarA.setOnShowListener(this.f803z);
        ConfigMonitor.get().onDialogCreate(fVarA);
        return fVarA;
    }

    protected f.C0007f v(Context context, int i2) {
        return new f.C0007f(context, i2);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
    public g l(int i2, DialogInterface.OnClickListener onClickListener) {
        this.f779b |= 2097152;
        this.B = this.B.c(i2, onClickListener);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
    public g m(int i2, DialogInterface.OnClickListener onClickListener) {
        this.f779b |= 1048576;
        this.B = this.B.d(i2, onClickListener);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
    public g n(int i2) {
        this.f779b |= 1;
        this.B = this.B.e(i2);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: z, reason: merged with bridge method [inline-methods] */
    public g o(CharSequence charSequence) {
        this.f779b |= 1;
        this.B = this.B.f(charSequence);
        return this;
    }
}
