package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.k;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.ViewAttrConstant;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogItemDivider extends View {
    public VDialogItemDivider(Context context) {
        this(context, null);
    }

    public VDialogItemDivider(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VDialogItemDivider(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VDialogItemDivider(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        q.r(this, 0);
        setForceDarkAllowed(false);
        if (i.i(context)) {
            int iD = k.d(context, "vigour_linear_view_divider_light", "drawable", "vivo");
            if (iD != 0) {
                setBackground(r.d(getContext(), iD));
            }
            BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
            if (orCreateViewAttr != null) {
                orCreateViewAttr.setGlobalBackground(iD);
                return;
            }
            return;
        }
        BaseViewAttr orCreateViewAttr2 = ParserUtil.getOrCreateViewAttr(this);
        if (orCreateViewAttr2 == null || i.j()) {
            return;
        }
        orCreateViewAttr2.setBackgroundActiveMode(ViewAttrConstant.createActiveMode(false, false, false, false, true));
    }
}
