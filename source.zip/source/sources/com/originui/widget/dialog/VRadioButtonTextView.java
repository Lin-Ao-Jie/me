package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.RadioButton;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.r;
import com.originui.resmap.ResMapManager;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.TextViewAttr;
import com.originui.resmap.bridge.ContextBridge;
import com.originui.widget.selection.VRadioButton;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VRadioButtonTextView extends VCustomCheckedTextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private VRadioButton f897a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ContextBridge f898b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f899c;

    public VRadioButtonTextView(Context context) {
        this(context, null);
    }

    @Override // com.originui.widget.dialog.VCustomCheckedTextView
    protected void a() {
        super.a();
        this.f897a.resetDefaultColor(getContext(), true, true, true);
        setCheckMarkDrawable(this.f897a.getDrawable(VThemeIconUtils.n()));
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setCollectionItemInfo(null);
        int iH = r.h(this.f898b, "selected", "string", "android");
        int iH2 = r.h(this.f898b, "not_selected", "string", "android");
        if (iH > 0 && iH2 > 0) {
            accessibilityNodeInfo.setStateDescription(accessibilityNodeInfo.isChecked() ? this.f898b.getString(iH) : this.f898b.getString(iH2));
        }
        if (iH > 0 && iH2 > 0) {
            setStateDescription(accessibilityNodeInfo.isChecked() ? this.f898b.getString(iH) : this.f898b.getString(iH2));
        }
        accessibilityNodeInfo.setClassName(RadioButton.class.getName());
        if (accessibilityNodeInfo.isEnabled() && accessibilityNodeInfo.isChecked()) {
            accessibilityNodeInfo.setClickable(false);
            accessibilityNodeInfo.setCheckable(false);
            accessibilityNodeInfo.removeAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SELECT);
            accessibilityNodeInfo.removeAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
        }
    }

    public VRadioButtonTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VRadioButtonTextView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VRadioButtonTextView(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f897a = null;
        this.f899c = 0;
        this.f898b = ResMapManager.byRomVer(context);
        this.f897a = new VRadioButton(context, i.g());
        a();
        if (!i.k() || i.i(context)) {
            return;
        }
        this.f899c = this.f898b.getResMapId(this.f898b.obtainStyledAttributes(attributeSet, R$styleable.VCustomTextView).getResourceId(R$styleable.VCustomTextView_android_textColor, R$color.originui_dialog_list_main_item_text_color_rom13_5));
        BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
        if (orCreateViewAttr instanceof TextViewAttr) {
            ((TextViewAttr) orCreateViewAttr).setTextColor(this.f899c);
        }
        if (this.f899c != 0) {
            setTextColor(context.getResources().getColor(this.f899c));
        }
    }
}
