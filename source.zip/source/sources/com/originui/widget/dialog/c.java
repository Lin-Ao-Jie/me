package com.originui.widget.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.s;
import com.originui.core.utils.y;
import com.originui.resmap.ConfigMonitor;
import com.originui.resmap.attr.ParserUtil;
import com.vivo.widget.theme.R;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c extends BaseDialogBuilder {
    private AlertDialog.Builder B;
    private boolean C;
    private boolean D;
    private boolean[] E;
    private CharSequence F;
    private View G;
    private DialogInterface.OnMultiChoiceClickListener H;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements AdapterView.OnItemClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ ListView f907a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ Dialog f908b;

        a(ListView listView, Dialog dialog) {
            this.f907a = listView;
            this.f908b = dialog;
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
            if (c.this.E != null) {
                c.this.E[i2] = this.f907a.isItemChecked(i2);
            }
            c.this.H.onClick(this.f908b, i2, this.f907a.isItemChecked(i2));
        }
    }

    public c(Context context, int i2) {
        super(context, i2);
        this.B = null;
        this.C = false;
        this.D = false;
        this.E = null;
        this.F = null;
        this.G = null;
        this.H = null;
        this.f778a = 2;
        if (i2 <= 0) {
            this.C = i2 == -3 || i2 == -6;
            this.D = i2 == -2 || i2 == -5;
            if (!i.r()) {
                i2 = this.f781d.getResources().getIdentifier("Theme.Vigour.Light.Dialog.Alert", "style", "vivo");
            }
        }
        if (i2 <= 0) {
            this.B = new AlertDialog.Builder(this.f781d);
        } else {
            this.f782e = i2;
            this.B = new AlertDialog.Builder(this.f781d, i2);
        }
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: A, reason: merged with bridge method [inline-methods] */
    public c o(CharSequence charSequence) {
        this.f779b |= 1;
        this.F = charSequence;
        View view = this.G;
        if (view == null) {
            this.B = this.B.setTitle(charSequence);
            return this;
        }
        int i2 = R$id.alertTitle;
        ((TextView) view.findViewById(i2)).setText(this.F);
        this.G.findViewById(i2).setVisibility(0);
        y.p((TextView) this.G.findViewById(i2));
        this.B = this.B.setCustomTitle(this.G);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: B, reason: merged with bridge method [inline-methods] */
    public c p(View view) {
        this.f779b |= 524288;
        if (this.f783f == view) {
            this.B = this.B.setView(view);
            return this;
        }
        LinearLayout linearLayout = new LinearLayout(this.f781d);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(1);
        int i2 = R$dimen.originui_dialog_no_dp;
        ParserUtil.setViewPadding(linearLayout, i2, i2, i2, R$dimen.originui_dialog_button_panel_top_stub);
        linearLayout.addView(view);
        this.B = this.B.setView(linearLayout);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: C, reason: merged with bridge method [inline-methods] */
    public c q(CharSequence charSequence) {
        return (c) super.q(charSequence);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: D, reason: merged with bridge method [inline-methods] */
    public c r(CharSequence charSequence) {
        return (c) super.r(charSequence);
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    public void s(Dialog dialog) {
        int resourceId;
        int resourceId2;
        super.s(dialog);
        if (this.f783f != null && !j()) {
            TypedArray typedArrayObtainStyledAttributes = this.f781d.obtainStyledAttributes(null, R$styleable.VDialog, 0, R$style.Vigour_VDialog_Alert);
            if ((this.f779b & 8192) == 8192) {
                resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogLoadingTopPaddingNoTitle, R$dimen.originui_dialog_loading_padding_top_no_title);
                resourceId2 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogLoadingBottomPaddingNoButton, R$dimen.originui_dialog_loading_content_padding_bottom_no_button);
            } else {
                resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogContentTopPaddingNoTitle, R$dimen.originui_dialog_center_content_padding_top_no_title);
                resourceId2 = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogContentBottomPaddingNoButton, R$dimen.originui_dialog_center_content_padding_bottom_no_button);
            }
            typedArrayObtainStyledAttributes.recycle();
            ScrollView scrollView = this.f783f;
            int i2 = R$dimen.originui_dialog_no_dp;
            if (k()) {
                resourceId = i2;
            }
            ParserUtil.setViewPadding(scrollView, i2, resourceId, i2, resourceId2);
        }
        if (dialog.getWindow().getAttributes().dimAmount == 0.0f) {
            dialog.getWindow().setDimAmount(VThemeIconUtils.A(d()) ? 0.6f : 0.3f);
        }
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    public void t(Dialog dialog) {
        super.t(dialog);
        try {
            if (dialog instanceof AlertDialog) {
                int i2 = 0;
                int iD = i.i(this.f781d) ? k.d(this.f781d, "dialog_btn_text_normal_light", "color", "vivo") : 0;
                if (s.c(d()) < 13.0f) {
                    int iW = VThemeIconUtils.w(this.f781d);
                    if (this.C) {
                        ((AlertDialog) dialog).getButton(-1).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_del));
                    } else {
                        ((AlertDialog) dialog).getButton(-1).setTextColor(iW);
                    }
                    ((AlertDialog) dialog).getButton(-2).setTextColor(iD != 0 ? this.f781d.getResources().getColor(iD) : iW);
                    Button button = ((AlertDialog) dialog).getButton(-3);
                    if (iD != 0) {
                        iW = this.f781d.getResources().getColor(iD);
                    }
                    button.setTextColor(iW);
                } else if (VThemeIconUtils.f472v && iD == 0 && (!VThemeIconUtils.n() || !VThemeIconUtils.B())) {
                    int iW2 = VThemeIconUtils.w(this.f781d);
                    if (this.D || this.C) {
                        if (this.C) {
                            ((AlertDialog) dialog).getButton(-1).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_del));
                            ((AlertDialog) dialog).getButton(-1).setBackground(d().getResources().getDrawable(R.drawable.vigour_alert_dialog_btn_background_del));
                        } else {
                            ((AlertDialog) dialog).getButton(-1).setTextColor(iW2);
                            Drawable drawable = d().getResources().getDrawable(R.drawable.vigour_alert_dialog_btn_background_ok);
                            if (drawable instanceof GradientDrawable) {
                                ((GradientDrawable) drawable).setStroke(p.a(3.0f), iW2);
                            }
                            ((AlertDialog) dialog).getButton(-1).setBackground(drawable);
                        }
                        ((AlertDialog) dialog).getButton(-2).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_cancel));
                        ((AlertDialog) dialog).getButton(-3).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_cancel));
                    } else {
                        ((AlertDialog) dialog).getButton(-1).setTextColor(iD != 0 ? this.f781d.getResources().getColor(iD) : iW2);
                        ((AlertDialog) dialog).getButton(-2).setTextColor(iD != 0 ? this.f781d.getResources().getColor(iD) : iW2);
                        Button button2 = ((AlertDialog) dialog).getButton(-3);
                        if (iD != 0) {
                            iW2 = this.f781d.getResources().getColor(iD);
                        }
                        button2.setTextColor(iW2);
                    }
                } else if (this.D || this.C) {
                    if (this.C) {
                        ((AlertDialog) dialog).getButton(-1).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_del));
                        ((AlertDialog) dialog).getButton(-1).setBackground(d().getResources().getDrawable(R.drawable.vigour_alert_dialog_btn_background_del));
                    } else {
                        ((AlertDialog) dialog).getButton(-1).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_ok));
                        ((AlertDialog) dialog).getButton(-1).setBackground(d().getResources().getDrawable(R.drawable.vigour_alert_dialog_btn_background_ok));
                    }
                    y.o(((AlertDialog) dialog).getButton(-1));
                    ((AlertDialog) dialog).getButton(-2).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_cancel));
                    ((AlertDialog) dialog).getButton(-3).setTextColor(d().getResources().getColor(R.color.vigour_alert_dialog_btn_cancel));
                } else {
                    y.n(((AlertDialog) dialog).getButton(-1));
                }
                int i3 = this.f779b;
                if ((i3 & 131072) != 131072) {
                    if ((i3 & 262144) == 262144) {
                        ((AlertDialog) dialog).getListView().setChoiceMode(1);
                        return;
                    }
                    return;
                }
                ListView listView = ((AlertDialog) dialog).getListView();
                listView.setChoiceMode(2);
                while (true) {
                    boolean[] zArr = this.E;
                    if (i2 >= zArr.length) {
                        break;
                    }
                    boolean z2 = zArr[i2];
                    if (z2) {
                        listView.setItemChecked(i2, z2);
                    }
                    i2++;
                }
                if (this.H != null) {
                    listView.setOnItemClickListener(new a(listView, dialog));
                }
            }
        } catch (Throwable th) {
            m.d("error = " + th.toString());
        }
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
    public AlertDialog c() {
        AlertDialog alertDialogCreate = this.B.create();
        s(alertDialogCreate);
        alertDialogCreate.setOnShowListener(this.f803z);
        ConfigMonitor.get().onDialogCreate(alertDialogCreate);
        return alertDialogCreate;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
    public c l(int i2, DialogInterface.OnClickListener onClickListener) {
        this.f779b |= 2097152;
        this.B = this.B.setNegativeButton(i2, onClickListener);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
    public c m(int i2, DialogInterface.OnClickListener onClickListener) {
        this.f779b |= 1048576;
        this.B = this.B.setPositiveButton(i2, onClickListener);
        return this;
    }

    @Override // com.originui.widget.dialog.BaseDialogBuilder
    /* JADX INFO: renamed from: z, reason: merged with bridge method [inline-methods] */
    public c n(int i2) {
        this.f779b |= 1;
        return o(this.f781d.getText(i2));
    }
}
