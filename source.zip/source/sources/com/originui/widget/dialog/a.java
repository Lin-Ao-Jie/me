package com.originui.widget.dialog;

import android.view.MotionEvent;
import android.view.ViewGroup;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f900a;

    public a(ViewGroup viewGroup) {
        this.f900a = null;
        this.f900a = c(viewGroup);
    }

    public static a a(ViewGroup viewGroup) {
        return new e(viewGroup);
    }

    public abstract Object b();

    protected abstract Object c(ViewGroup viewGroup);

    public abstract void d();

    public abstract void e(float f2);

    public abstract boolean f(MotionEvent motionEvent);

    public abstract void g();

    public abstract void h(int i2, int i3, int i4, int i5);

    public abstract void i(boolean z2);
}
