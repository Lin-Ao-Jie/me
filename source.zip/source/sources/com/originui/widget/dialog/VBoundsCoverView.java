package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VBoundsCoverView extends View {
    public VBoundsCoverView(Context context) {
        this(context, null);
    }

    public void a(boolean z2) {
        setVisibility(z2 ? 0 : 4);
    }

    public VBoundsCoverView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VBoundsCoverView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VBoundsCoverView(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
    }
}
