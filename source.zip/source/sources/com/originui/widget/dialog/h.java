package com.originui.widget.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class h {
    private VelocityTracker B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private DialogInterface f1052a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f1053b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Window f1054c;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private p.b f1056e;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f1055d = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f1057f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f1058g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f1059h = 0.0f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float f1060i = 0.0f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1061j = 0.0f;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f1062k = 0.0f;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1063l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1064m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private WindowManager.LayoutParams f1065n = null;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f1066o = 0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1067p = 0.0f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private long f1068q = 0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private Choreographer f1069r = null;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private boolean f1070s = false;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private Handler f1071t = null;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private long f1072u = 0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f1073v = false;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f1074w = true;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f1075x = false;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private int f1076y = -1;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private boolean f1077z = false;
    private int A = 0;
    private boolean C = true;
    private final int[] D = new int[2];
    private Choreographer.FrameCallback E = new a();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements Choreographer.FrameCallback {
        a() {
        }

        @Override // android.view.Choreographer.FrameCallback
        public void doFrame(long j2) {
            if (h.this.f1056e != null) {
                h.this.f1056e.b((System.currentTimeMillis() - h.this.f1068q) / 1000.0f);
                int iC = (int) h.this.f1056e.c();
                if (m.f583b) {
                    m.b("VDialog/VDialogSlideHelper", "doFrame curY:" + iC);
                }
                h.this.m(iC);
                if (h.this.f1056e.i() || iC == h.this.f1066o) {
                    return;
                }
                h.this.f1069r.postFrameCallback(this);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements n.b.r {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ float f1079a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ float f1080b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ int f1081c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ int f1082d;

        b(float f2, float f3, int i2, int i3) {
            this.f1079a = f2;
            this.f1080b = f3;
            this.f1081c = i2;
            this.f1082d = i3;
        }

        @Override // n.b.r
        public void a(n.b bVar, float f2, float f3) {
            float f4 = this.f1079a;
            float f5 = f4 - this.f1080b;
            int i2 = this.f1081c;
            float f6 = f4 - ((f5 * (i2 - f2)) / (i2 - this.f1082d));
            if (h.this.f1065n != null) {
                h.this.f1065n.y = (int) f2;
                h.this.f1065n.dimAmount = f6;
                h.this.f1054c.setAttributes(h.this.f1065n);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements n.b.q {
        c() {
        }

        @Override // n.b.q
        public void a(n.b bVar, boolean z2, float f2, float f3) {
            h.this.f1052a.cancel();
            if (h.this.f1065n == null || !h.this.C) {
                return;
            }
            h.this.f1065n.y = h.this.f1066o;
            h.this.f1065n.dimAmount = h.this.f1067p;
            h.this.f1054c.setAttributes(h.this.f1065n);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class d extends Handler {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private WeakReference f1085a;

        public d(h hVar) {
            this.f1085a = new WeakReference(hVar);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            h hVar = (h) this.f1085a.get();
            if (hVar == null) {
                return;
            }
            hVar.n(message.arg1);
            super.handleMessage(message);
        }
    }

    public h(DialogInterface dialogInterface, Window window, Context context) {
        this.f1054c = null;
        this.f1052a = dialogInterface;
        this.f1053b = context;
        this.f1054c = window;
    }

    private void D(float f2, float f3) {
        p.b bVar = this.f1056e;
        if (bVar == null || (bVar != null && bVar.i())) {
            p.b bVar2 = new p.b();
            this.f1056e = bVar2;
            bVar2.w(new p.c(300.0d, 120.0d));
            this.f1056e.o(f2);
            this.f1056e.q(f3);
            this.f1056e.x(0.0d);
            this.f1068q = System.currentTimeMillis();
            this.f1069r.postFrameCallback(this.E);
        }
    }

    private void G(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f1059h = motionEvent.getRawX();
            this.f1060i = motionEvent.getRawY();
            this.f1063l = this.f1054c.getAttributes().x;
            this.f1064m = this.f1054c.getAttributes().y;
            this.f1061j = motionEvent.getRawX();
            this.f1062k = motionEvent.getRawY();
            this.f1077z = false;
            p.b bVar = this.f1056e;
            if (bVar != null && !bVar.i()) {
                this.f1056e.m();
            }
            this.B = VelocityTracker.obtain();
            if (System.currentTimeMillis() - this.f1072u > 600) {
                this.f1073v = true;
                return;
            }
            return;
        }
        if (action != 1) {
            if (action == 2) {
                VelocityTracker velocityTracker = this.B;
                if (velocityTracker != null) {
                    velocityTracker.addMovement(motionEvent);
                    this.B.computeCurrentVelocity(1000, 1500.0f);
                }
                z(motionEvent);
                return;
            }
            if (action != 3) {
                return;
            }
        }
        this.f1059h = 0.0f;
        this.f1060i = 0.0f;
        x(motionEvent);
        this.f1058g = false;
        VelocityTracker velocityTracker2 = this.B;
        if (velocityTracker2 != null) {
            velocityTracker2.recycle();
        }
    }

    private int k(float f2, float f3) {
        float f4 = this.f1054c.getAttributes().y - this.f1064m;
        float fAbs = 0.0f;
        if (f4 == 0.0f) {
            fAbs = f2 * 0.3f;
        } else {
            float f5 = 350;
            if (Math.abs(f4) < f5) {
                fAbs = (1.0f - (Math.abs(f4) / f5)) * f2 * 0.3f;
            }
        }
        return (int) fAbs;
    }

    private void l(int i2) {
        this.A = 0;
        VelocityTracker velocityTracker = this.B;
        if (velocityTracker != null) {
            this.A = (int) Math.abs(velocityTracker.getYVelocity());
        }
        int i3 = this.A;
        int i4 = i3 > 150 ? i3 : 0;
        this.A = i4;
        float fAbs = 300.0f - (((Math.abs(i4) * 1.0f) / 15000.0f) * 50.0f);
        float fAbs2 = 0.95f - (((Math.abs(this.A) * 1.0f) / 15000.0f) * 0.15f);
        if (fAbs < 160.0f && fAbs2 < 0.5d) {
            fAbs = 163.0f;
            fAbs2 = 0.54f;
        }
        float f2 = this.f1054c.getAttributes().dimAmount;
        int height = (this.f1054c.getDecorView().getHeight() + 400) * (-1);
        float f3 = height;
        n.c cVar = new n.c(new v.b(f3));
        cVar.k(i2);
        n.d dVar = new n.d(f3);
        dVar.d(fAbs2);
        dVar.f(fAbs);
        cVar.r(dVar);
        cVar.l(this.A);
        cVar.c(new b(f2, 0.0f, i2, height));
        cVar.b(new c());
        cVar.m();
        this.f1068q = System.currentTimeMillis();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void m(int i2) {
        if (Looper.myLooper() != this.f1071t.getLooper()) {
            m.b("VDialog/VDialogSlideHelper", "post doFrameCallback to UI thread");
            Message messageObtain = Message.obtain();
            messageObtain.arg1 = i2;
            this.f1071t.sendMessage(messageObtain);
            return;
        }
        WindowManager.LayoutParams layoutParams = this.f1065n;
        if (layoutParams == null || !this.f1055d) {
            return;
        }
        layoutParams.y = i2;
        this.f1054c.setAttributes(layoutParams);
    }

    private boolean q(MotionEvent motionEvent) {
        return (this.f1053b == null || this.f1054c == null || motionEvent.getAction() != 0 || r(this.f1053b, motionEvent)) ? false : true;
    }

    private boolean t() {
        int i2;
        boolean zContains = this.f1053b.getResources().getConfiguration().toString().contains("multi-window");
        try {
            i2 = Settings.Secure.getInt(this.f1053b.getContentResolver(), "navigation_gesture_on", 1);
        } catch (Exception e2) {
            m.e("VDialog/VDialogSlideHelper", "error = " + e2.toString());
            i2 = 1;
        }
        return zContains && !i.t(this.f1053b) && (i2 == 0 || i.w(this.f1053b) || i.z(this.f1053b));
    }

    private boolean u() {
        Window window = this.f1054c;
        if (window == null || this.f1053b == null || window.getAttributes().gravity != 80) {
            return false;
        }
        return (this.f1054c.getDecorView().getRootWindowInsets() == null || !this.f1054c.getDecorView().getRootWindowInsets().isVisible(WindowInsets.Type.ime())) && !t();
    }

    private void x(MotionEvent motionEvent) {
        int i2 = this.f1054c.getAttributes().y;
        if (m.f583b) {
            m.b("VDialog/VDialogSlideHelper", "onBackDownAnimator windowFrom: " + i2 + " windowTo:" + this.f1066o);
        }
        int i3 = this.f1066o;
        if (i2 == i3) {
            return;
        }
        if (i2 - i3 < -200 && !r(this.f1053b, motionEvent) && this.f1074w && this.f1075x && this.f1057f) {
            l(i2);
        } else {
            D(i2, this.f1066o);
        }
    }

    private void z(MotionEvent motionEvent) {
        float rawY = motionEvent.getRawY() - this.f1060i;
        if (rawY >= 0.0f || this.f1076y <= 0 || this.f1054c.getDecorView().getHeight() <= this.f1076y) {
            float rawY2 = motionEvent.getRawY() - this.f1062k;
            this.f1070s = true;
            if (rawY < -10.0f) {
                this.f1077z = true;
            }
            WindowManager.LayoutParams attributes = this.f1054c.getAttributes();
            int iK = k(rawY2, rawY) * (-1);
            int i2 = attributes.y + iK;
            int i3 = this.f1064m;
            if (i2 > i3) {
                attributes.y = i2;
            } else if (this.f1073v) {
                if (!this.f1074w && (i.v(this.f1053b) || i.z(this.f1053b))) {
                    attributes.y = i2;
                } else if (this.f1077z) {
                    attributes.y = (int) (attributes.y - rawY2);
                } else {
                    attributes.y = (int) (this.f1064m - rawY);
                }
                this.f1062k = motionEvent.getRawY();
                this.f1054c.setFlags(512, 512);
            } else {
                attributes.y = i3;
            }
            this.f1054c.setAttributes(attributes);
            if (iK != 0) {
                if (rawY2 < -3.5f || rawY2 > 0.0f) {
                    this.f1062k = motionEvent.getRawY();
                }
            }
        }
    }

    public void A() {
        Window window = this.f1054c;
        if (window != null) {
            WindowManager.LayoutParams attributes = window.getAttributes();
            this.f1065n = attributes;
            this.f1066o = attributes.y;
            this.f1067p = attributes.dimAmount;
        }
        this.f1072u = System.currentTimeMillis();
    }

    public void B(boolean z2) {
        this.f1074w = z2;
    }

    public void C(boolean z2) {
        this.f1075x = z2;
    }

    public void E(boolean z2) {
        this.f1057f = z2;
    }

    public void F(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            o();
        }
        if (this.f1069r == null) {
            this.f1069r = Choreographer.getInstance();
        }
        if (q(motionEvent) && u()) {
            this.f1058g = true;
        }
        if (this.f1058g) {
            G(motionEvent);
        }
    }

    protected void n(int i2) {
        WindowManager.LayoutParams layoutParams = this.f1065n;
        if (layoutParams == null || !this.f1055d) {
            return;
        }
        layoutParams.y = i2;
        this.f1054c.setAttributes(layoutParams);
    }

    public void o() {
        Context context = this.f1053b;
        if (context == null) {
            return;
        }
        WindowManager windowManager = (WindowManager) context.getSystemService("window");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        this.f1076y = displayMetrics.heightPixels - p.a(50.0f);
    }

    public void p() {
        WindowManager.LayoutParams attributes = this.f1054c.getAttributes();
        this.f1065n = attributes;
        this.f1066o = attributes.y;
        this.f1067p = attributes.dimAmount;
        if (this.f1069r == null) {
            this.f1069r = Choreographer.getInstance();
        }
        this.f1071t = new d(this);
    }

    public boolean r(Context context, MotionEvent motionEvent) {
        if (System.currentTimeMillis() - this.f1072u < 550) {
            return false;
        }
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        int scaledWindowTouchSlop = ViewConfiguration.get(context).getScaledWindowTouchSlop();
        View decorView = this.f1054c.getDecorView();
        int i2 = -scaledWindowTouchSlop;
        return x2 < i2 || y2 < i2 || x2 > decorView.getWidth() + scaledWindowTouchSlop || y2 > decorView.getHeight() + scaledWindowTouchSlop;
    }

    public boolean s(Context context, MotionEvent motionEvent, View view) {
        if (System.currentTimeMillis() - this.f1072u < 550) {
            return false;
        }
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        int scaledWindowTouchSlop = ViewConfiguration.get(context).getScaledWindowTouchSlop();
        view.getLocationInWindow(this.D);
        int[] iArr = this.D;
        int i2 = iArr[0];
        return x2 < i2 - scaledWindowTouchSlop || y2 < iArr[1] - scaledWindowTouchSlop || x2 > (i2 + view.getWidth()) + scaledWindowTouchSlop || y2 > (this.D[1] + view.getHeight()) + scaledWindowTouchSlop;
    }

    public boolean v(MotionEvent motionEvent) {
        boolean z2 = this.f1070s;
        if (motionEvent.getAction() != 1 && motionEvent.getAction() != 3) {
            return z2;
        }
        this.f1070s = false;
        return z2;
    }

    public void w() {
        this.f1055d = true;
    }

    public void y() {
        this.f1055d = false;
    }
}
