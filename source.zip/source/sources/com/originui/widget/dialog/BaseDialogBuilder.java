package com.originui.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.GradientDrawable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.m;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.core.utils.y;
import com.originui.resmap.ResMapManager;
import com.originui.widget.vclickdrawable.VListItemSelectorDrawable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class BaseDialogBuilder {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected int f778a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected Context f780c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected Context f781d;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected int f779b = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected int f782e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    protected ScrollView f783f = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected LinearLayout f784g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected VCustomTextView f785h = null;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected VCustomTextView f786i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    protected VCustomTextView f787j = null;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    protected LinearLayout f788k = null;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private RelativeLayout f789l = null;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private ViewGroup f790m = null;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    protected TextView f791n = null;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    protected VCustomTextView f792o = null;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    protected VDialogContentMessageTextView f793p = null;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    protected VDialogContentMessageTextView f794q = null;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    protected VCustomTextView f795r = null;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    protected TextView f796s = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    protected ImageView f797t = null;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected List f798u = new ArrayList();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    protected Map f799v = new HashMap();

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    protected DialogInterface.OnShowListener f800w = null;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private HashMap f801x = new HashMap();

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private HashMap f802y = new HashMap();

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    protected DialogInterface.OnShowListener f803z = new a();
    private final VCustomTextView.a A = new b();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class CheckedSubItemAdapter extends BaseAdapter {
        private boolean clickable;
        private boolean isSystemDialog;
        private int layoutId;
        private Context mContext;
        private final List<CharSequence[]> mData;
        private final LayoutInflater mLayoutInflater;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class a extends View.AccessibilityDelegate {
            a() {
            }

            @Override // android.view.View.AccessibilityDelegate
            public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
                super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
                accessibilityNodeInfo.removeAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK);
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        static class b {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            View f805a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            View f806b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            TextView f807c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            TextView f808d;

            /* JADX INFO: renamed from: e, reason: collision with root package name */
            View f809e;

            b() {
            }
        }

        public CheckedSubItemAdapter(Context context, List<CharSequence[]> list) {
            this(context, list, false);
        }

        private int getDefaultThemeId() {
            if (i.k()) {
                return R$style.Vigour_VDialog_Alert;
            }
            if (i.z(this.mContext)) {
                return R$style.Vigour_VDialog_Vos_Alert;
            }
            return i.A(this.mContext) ? R$style.Vigour_VDialog_Fos_Alert_Fos15 : R$style.Vigour_VDialog_Fos_Alert;
        }

        private void resolveContentPaddingRes() {
            try {
                TypedArray typedArrayObtainStyledAttributes = this.mContext.obtainStyledAttributes(null, R$styleable.VDialog, 0, getDefaultThemeId());
                this.layoutId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_multiListItemLayout, R$layout.originui_dialog_list_item_multiline_rom13_5);
                if (i.w(this.mContext) || i.z(this.mContext)) {
                    this.layoutId = R$layout.originui_dialog_list_item_multiline_rom15_0;
                }
                typedArrayObtainStyledAttributes.recycle();
            } catch (Exception e2) {
                m.d(e2.toString());
            }
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return this.mData.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i2) {
            return this.mData.get(i2);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            b bVar;
            if (view == null) {
                view = this.mLayoutInflater.inflate(this.layoutId, (ViewGroup) null);
                bVar = new b();
                bVar.f805a = view;
                bVar.f806b = view.findViewById(R$id.list_main_content);
                TextView textView = (TextView) view.findViewById(R$id.list_main_item);
                bVar.f807c = textView;
                y.n(textView);
                TextView textView2 = (TextView) view.findViewById(R$id.list_sub_item);
                bVar.f808d = textView2;
                y.n(textView2);
                bVar.f809e = view.findViewById(R$id.divider);
                view.setTag(bVar);
            } else {
                bVar = (b) view.getTag();
            }
            CharSequence[] charSequenceArr = this.mData.get(i2);
            if (!this.clickable) {
                bVar.f805a.setAccessibilityDelegate(new a());
            } else if (s.c(this.mContext) >= 15.0f) {
                View view2 = bVar.f805a;
                Context context = this.mContext;
                view2.setBackground(new VListItemSelectorDrawable(context, context.getResources().getColor(R$color.originui_dialog_item_background_selector_color_rom15_0)));
            } else {
                bVar.f805a.setBackground(new VListItemSelectorDrawable(this.mContext));
            }
            bVar.f807c.setText(charSequenceArr[0]);
            bVar.f808d.setText(charSequenceArr[1]);
            bVar.f808d.setVisibility(charSequenceArr[1] == null ? 8 : 0);
            if (i.r()) {
                TextView textView3 = bVar.f807c;
                if (textView3 instanceof VCustomTextView) {
                    ((VCustomTextView) textView3).setSystemDayColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.C));
                    ((VCustomTextView) bVar.f807c).setSystemNightColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.K));
                }
                TextView textView4 = bVar.f808d;
                if (textView4 instanceof VCustomTextView) {
                    ((VCustomTextView) textView4).setSystemDayColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.I));
                    ((VCustomTextView) bVar.f808d).setSystemNightColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.G));
                }
            }
            if (this.isSystemDialog) {
                bVar.f809e.setVisibility(8);
                return view;
            }
            if (!i.z(this.mContext) && !i.w(this.mContext)) {
                bVar.f809e.setVisibility(0);
                return view;
            }
            if (i2 == this.mData.size() - 1) {
                bVar.f809e.setVisibility(8);
                return view;
            }
            bVar.f809e.setVisibility(0);
            return view;
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public boolean hasStableIds() {
            return true;
        }

        public CheckedSubItemAdapter(Context context, List<CharSequence[]> list, boolean z2) {
            this.clickable = true;
            this.mContext = context;
            this.mData = list;
            this.isSystemDialog = z2;
            this.mLayoutInflater = LayoutInflater.from(context);
            resolveContentPaddingRes();
        }

        public CheckedSubItemAdapter(Context context, List<CharSequence[]> list, boolean z2, boolean z3) {
            this(context, list, z2);
            this.clickable = z3;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements DialogInterface.OnShowListener {
        a() {
        }

        @Override // android.content.DialogInterface.OnShowListener
        public void onShow(DialogInterface dialogInterface) {
            BaseDialogBuilder.this.t((Dialog) dialogInterface);
            DialogInterface.OnShowListener onShowListener = BaseDialogBuilder.this.f800w;
            if (onShowListener != null) {
                onShowListener.onShow(dialogInterface);
            }
        }
    }

    public BaseDialogBuilder(Context context, int i2) {
        this.f780c = context;
        if (i2 <= 0) {
            this.f781d = new ContextThemeWrapper(context, g(i2));
        } else {
            this.f781d = new ContextThemeWrapper(context, i2);
        }
        this.f781d = ResMapManager.byDeviceType(this.f781d).fitConfig(true);
    }

    public static int f(Context context) {
        if (i.k()) {
            return R$style.Vigour_VDialog_Alert;
        }
        if (i.z(context)) {
            return R$style.Vigour_VDialog_Vos_Alert;
        }
        return i.A(context) ? R$style.Vigour_VDialog_Fos_Alert_Fos15 : R$style.Vigour_VDialog_Fos_Alert;
    }

    private void h() {
        TypedArray typedArrayObtainStyledAttributes = d().obtainStyledAttributes(null, R$styleable.VDialog, 0, f(this.f781d));
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_vigourContentLayout, R$layout.originui_dialog_vigour_view_rom13_5);
        int i2 = R$styleable.VDialog_dialogVigourItemDividerHeight;
        Resources resources = d().getResources();
        int i3 = R$dimen.originui_dialog_vigour_item_divider_height;
        int dimension = (int) typedArrayObtainStyledAttributes.getDimension(i2, resources.getDimension(i3));
        typedArrayObtainStyledAttributes.recycle();
        if (com.originui.core.utils.h.j()) {
            dimension = r.c(d(), i3);
        }
        ScrollView scrollView = (ScrollView) View.inflate(d(), resourceId, null);
        this.f783f = scrollView;
        LinearLayout linearLayout = (LinearLayout) scrollView.findViewById(R$id.scroll_ll);
        this.f784g = linearLayout;
        linearLayout.setShowDividers(2);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setSize(1, dimension);
        this.f784g.setDividerDrawable(gradientDrawable);
    }

    public abstract Dialog c();

    public Context d() {
        return this.f781d;
    }

    public TextView e() {
        return this.f792o;
    }

    public int g(int i2) {
        if (i2 == -30) {
            if (i.k()) {
                return R$style.Vigour_VDialog_Alert_Mark_Del;
            }
            if (i.z(this.f781d)) {
                return R$style.Vigour_VDialog_Vos_Alert_Del;
            }
            return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_Del : R$style.Vigour_VDialog_Fos_Alert;
        }
        switch (i2) {
            case -18:
            case -17:
            case -16:
            case -15:
                break;
            default:
                switch (i2) {
                    case -13:
                    case -12:
                    case -11:
                    case -10:
                    case -5:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_List_Mark;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_List_Mark;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_List_Mark : R$style.Vigour_VDialog_Fos_Alert_List;
                    case -9:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_ProgressDialog;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_ProgressDialog;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_ProgressDialog : R$style.Vigour_VDialog_Fos_Alert_ProgressDialog;
                    case -8:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_List_Mark_Double;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_List_Mark_Double;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_List_Mark_Double : R$style.Vigour_VDialog_Fos_Alert_List;
                    case -7:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_Mark_Double;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_Mark_Double;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_Mark_Double : R$style.Vigour_VDialog_Fos_Alert;
                    case -6:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_List_Mark_Del;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_List_Mark_Del;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_List_Mark_Del : R$style.Vigour_VDialog_Fos_Alert_List;
                    case -4:
                        break;
                    case -3:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_Mark_Del;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_Mark_Del;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_Mark_Del : R$style.Vigour_VDialog_Fos_Alert;
                    case -2:
                        if (i.k()) {
                            return R$style.Vigour_VDialog_Alert_Mark;
                        }
                        if (i.z(this.f781d)) {
                            return R$style.Vigour_VDialog_Vos_Alert_Mark;
                        }
                        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_Mark : R$style.Vigour_VDialog_Fos_Alert;
                    default:
                        return f(this.f781d);
                }
                break;
        }
        if (i.k()) {
            return R$style.Vigour_VDialog_Alert_List;
        }
        if (i.z(this.f781d)) {
            return R$style.Vigour_VDialog_Vos_Alert_List;
        }
        return i.A(this.f781d) ? R$style.Vigour_VDialog_Fos_Alert_Fos15_List : R$style.Vigour_VDialog_Fos_Alert_List;
    }

    public boolean i() {
        return this.f779b > 1048576;
    }

    public boolean j() {
        return this.f779b % 524288 > 32768;
    }

    public boolean k() {
        return this.f779b % 16 > 0;
    }

    public abstract BaseDialogBuilder l(int i2, DialogInterface.OnClickListener onClickListener);

    public abstract BaseDialogBuilder m(int i2, DialogInterface.OnClickListener onClickListener);

    public abstract BaseDialogBuilder n(int i2);

    public abstract BaseDialogBuilder o(CharSequence charSequence);

    public abstract BaseDialogBuilder p(View view);

    public BaseDialogBuilder q(CharSequence charSequence) {
        this.f779b |= 32;
        if (this.f783f == null) {
            h();
        }
        TypedArray typedArrayObtainStyledAttributes = d().obtainStyledAttributes(null, R$styleable.VDialog, 0, f(this.f781d));
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_vigourDescriptionMessageLayout, R$layout.originui_dialog_vigour_description_message);
        typedArrayObtainStyledAttributes.recycle();
        View viewInflate = View.inflate(d(), resourceId, null);
        VCustomTextView vCustomTextView = (VCustomTextView) viewInflate.findViewById(R$id.content_description);
        this.f795r = vCustomTextView;
        vCustomTextView.setText(charSequence);
        this.f795r.setOnTextViewChangeListener(this.A);
        if (i.r()) {
            this.f795r.setSystemDayColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.I));
            this.f795r.setSystemNightColor(new VCustomTextView.c(VThemeIconUtils.f476z, VThemeIconUtils.G));
        }
        this.f784g.addView(viewInflate);
        return p(this.f783f);
    }

    public BaseDialogBuilder r(CharSequence charSequence) {
        this.f779b |= 256;
        if (this.f783f == null) {
            h();
        }
        TypedArray typedArrayObtainStyledAttributes = d().obtainStyledAttributes(null, R$styleable.VDialog, 0, f(this.f781d));
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_vigourMessageLayout3, R$layout.originui_dialog_vigour_message_custom);
        typedArrayObtainStyledAttributes.recycle();
        View viewInflate = View.inflate(d(), resourceId, null);
        VCustomTextView vCustomTextView = (VCustomTextView) viewInflate.findViewById(R$id.message_custom);
        this.f792o = vCustomTextView;
        vCustomTextView.setText(charSequence);
        this.f792o.setOnTextViewChangeListener(this.A);
        this.f784g.addView(viewInflate);
        return p(this.f783f);
    }

    public void s(Dialog dialog) {
        VCustomTextView vCustomTextView;
        if ((this.f779b & 8192) == 8192 && !i() && i.k() && s.c(d()) < 14.0f && s.c(d()) >= 13.0f) {
            dialog.getWindow().setWindowAnimations(R$style.VAnimation_Dialog_Center);
            dialog.getWindow().setGravity(17);
        }
        int i2 = this.f779b;
        if (((i2 & 1024) == 1024 || (i2 & 512) == 512 || (i2 & 4096) == 4096 || (i2 & 8192) == 8192) && (vCustomTextView = this.f795r) != null) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) vCustomTextView.getLayoutParams();
            layoutParams.gravity = 8388611;
            this.f795r.setLayoutParams(layoutParams);
        }
    }

    public void setOnDialogShowListener(DialogInterface.OnShowListener onShowListener) {
        this.f800w = onShowListener;
    }

    public void t(Dialog dialog) {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements VCustomTextView.a {
        b() {
        }

        @Override // com.originui.widget.dialog.VCustomTextView.a
        public void b(int i2, VCustomTextView vCustomTextView, boolean z2) {
            m.b("VDialog/BaseDialogBuilder", "onViewChange isMultiLine" + z2);
            if (i.l(BaseDialogBuilder.this.f781d) || i.A(BaseDialogBuilder.this.f781d)) {
                BaseDialogBuilder.this.f801x.put(vCustomTextView, Boolean.valueOf(z2));
                BaseDialogBuilder.this.f802y.put(vCustomTextView, vCustomTextView);
                Iterator it = BaseDialogBuilder.this.f801x.keySet().iterator();
                boolean z3 = false;
                while (it.hasNext()) {
                    if (((Boolean) BaseDialogBuilder.this.f801x.get((View) it.next())).booleanValue()) {
                        z3 = true;
                    }
                }
                if (z3 || BaseDialogBuilder.this.f802y.size() > 1) {
                    Iterator it2 = BaseDialogBuilder.this.f802y.keySet().iterator();
                    while (it2.hasNext()) {
                        ((VCustomTextView) BaseDialogBuilder.this.f802y.get((View) it2.next())).setGravityInternal(8388611);
                    }
                }
                BaseDialogBuilder baseDialogBuilder = BaseDialogBuilder.this;
                if ((baseDialogBuilder.f784g == null || !z3) && baseDialogBuilder.f802y.size() <= 1) {
                    BaseDialogBuilder baseDialogBuilder2 = BaseDialogBuilder.this;
                    if (baseDialogBuilder2.f784g != null) {
                        Iterator it3 = baseDialogBuilder2.f798u.iterator();
                        while (it3.hasNext()) {
                            b.c.a(it3.next());
                        }
                        return;
                    }
                    return;
                }
                Iterator it4 = BaseDialogBuilder.this.f798u.iterator();
                while (it4.hasNext()) {
                    b.c.a(it4.next());
                }
                VCustomTextView vCustomTextView2 = BaseDialogBuilder.this.f795r;
                if (vCustomTextView2 != null) {
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) vCustomTextView2.getLayoutParams();
                    layoutParams.gravity = 8388611;
                    BaseDialogBuilder.this.f795r.setLayoutParams(layoutParams);
                }
            }
        }

        @Override // com.originui.widget.dialog.VCustomTextView.a
        public void a(int i2, boolean z2) {
        }
    }
}
