package com.originui.widget.dialog;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.Checkable;
import android.widget.RelativeLayout;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CheckableRelativeLayout extends RelativeLayout implements Checkable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private VRadioButtonTextView f812a;

    public CheckableRelativeLayout(Context context) {
        this(context, null);
    }

    @Override // android.widget.RelativeLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        VRadioButtonTextView vRadioButtonTextView = this.f812a;
        if (vRadioButtonTextView != null) {
            return vRadioButtonTextView.isChecked();
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view.getId() == 16908308 && (view instanceof VRadioButtonTextView)) {
            this.f812a = (VRadioButtonTextView) view;
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z2) {
        VRadioButtonTextView vRadioButtonTextView = this.f812a;
        if (vRadioButtonTextView != null) {
            vRadioButtonTextView.setChecked(z2);
        }
    }

    @Override // android.widget.Checkable
    public void toggle() {
        VRadioButtonTextView vRadioButtonTextView = this.f812a;
        if (vRadioButtonTextView != null) {
            setChecked(!vRadioButtonTextView.isChecked());
        }
    }

    public CheckableRelativeLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CheckableRelativeLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
    }
}
