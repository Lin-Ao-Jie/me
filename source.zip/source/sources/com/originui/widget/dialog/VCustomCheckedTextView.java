package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckedTextView;
import android.widget.TextView;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.s;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.TextViewAttr;
import com.originui.widget.vclickdrawable.VListItemSelectorDrawable;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VCustomCheckedTextView extends CheckedTextView {
    public VCustomCheckedTextView(Context context) {
        this(context, null);
    }

    @Override // android.widget.TextView, android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        a();
        if (i.r()) {
            setBackground(new VListItemSelectorDrawable(getContext()));
        } else if (s.c(getContext()) >= 15.0f) {
            setBackground(new VListItemSelectorDrawable(getContext(), getContext().getResources().getColor(R$color.originui_dialog_item_background_selector_color_rom15_0)));
        } else {
            setBackground(new VListItemSelectorDrawable(getContext()));
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(com.originui.core.utils.d.e(drawable, "6.0.1.8"));
    }

    @Override // android.widget.TextView
    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        super.setText(com.originui.core.utils.d.f(charSequence, "6.0.1.8"), bufferType);
    }

    public VCustomCheckedTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VCustomCheckedTextView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VCustomCheckedTextView(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        try {
            if (i.r()) {
                setBackground(new VListItemSelectorDrawable(getContext()));
            } else if (s.c(context) >= 15.0f) {
                setBackground(new VListItemSelectorDrawable(context, context.getResources().getColor(R$color.originui_dialog_item_background_selector_color_rom15_0)));
            } else {
                setBackground(new VListItemSelectorDrawable(context));
            }
            if (i.i(context)) {
                int iD = k.d(context, "dialog_text_color", "color", "vivo");
                if (iD != 0) {
                    setTextColor(context.getResources().getColor(iD));
                }
                BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
                if (orCreateViewAttr instanceof TextViewAttr) {
                    ((TextViewAttr) orCreateViewAttr).setGlobalTextColor(iD);
                }
            }
        } catch (Exception e2) {
            m.d("error = " + e2);
        }
    }

    protected void a() {
    }
}
