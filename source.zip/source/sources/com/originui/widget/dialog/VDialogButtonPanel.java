package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.originui.core.utils.m;
import com.originui.core.utils.r;
import com.originui.widget.button.VButton;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogButtonPanel extends LinearLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f871a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f872b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f873c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f874d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private GradientDrawable f875e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final Point f876f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final Point f877g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final WindowManager f878h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final boolean f879i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f880j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f881k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final Map f882l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private TextView f883m;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            boolean zT = i.t(((LinearLayout) VDialogButtonPanel.this).mContext);
            if (VDialogButtonPanel.this.f881k != zT) {
                VDialogButtonPanel.this.f881k = zT;
                VDialogButtonPanel.this.requestLayout();
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f885a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private float f886b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f887c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f888d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f889e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private int f890f;

        public int a() {
            return this.f885a;
        }

        public int b() {
            return this.f888d;
        }

        public int c() {
            return this.f887c;
        }

        public int d() {
            return this.f890f;
        }

        public int e() {
            return this.f889e;
        }

        public float f() {
            return this.f886b;
        }

        public void g(int i2) {
            this.f885a = i2;
        }

        public void h(int i2) {
            this.f888d = i2;
        }

        public void i(int i2) {
            this.f887c = i2;
        }

        public void j(int i2) {
            this.f890f = i2;
        }

        public void k(int i2) {
            this.f889e = i2;
        }

        public void l(float f2) {
            this.f886b = f2;
        }
    }

    public VDialogButtonPanel(Context context) {
        this(context, null);
    }

    private int d(int i2) {
        int childCount = getChildCount();
        while (i2 < childCount) {
            if (getChildAt(i2).getVisibility() == 0) {
                return i2;
            }
            i2++;
        }
        return -1;
    }

    private boolean e() {
        return getOrientation() == 1;
    }

    private void f() {
        if (this.f874d == 0) {
            setDividerDrawable(null);
            return;
        }
        int dimensionPixelSize = getResources().getDimensionPixelSize(this.f874d);
        if (dimensionPixelSize == 0) {
            setDividerDrawable(null);
        } else {
            this.f875e.setSize(1, dimensionPixelSize);
            setDividerDrawable(this.f875e);
        }
    }

    private void h(boolean z2, int i2) {
        setOrientation(z2 ? 1 : 0);
        setGravity(z2 ? 17 : 80);
        if (z2) {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setSize(1, r.c(getContext(), R$dimen.originui_dialog_button_divider_height_fos));
            setDividerDrawable(gradientDrawable);
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if ((childAt instanceof VButton) && childAt.getVisibility() == 0) {
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
                    if (!this.f882l.containsKey(Integer.valueOf(i3))) {
                        b bVar = new b();
                        bVar.h(layoutParams.getMarginEnd());
                        bVar.i(layoutParams.getMarginStart());
                        bVar.l(layoutParams.weight);
                        bVar.g(layoutParams.gravity);
                        bVar.k(childAt.getPaddingStart());
                        bVar.j(childAt.getPaddingEnd());
                        this.f882l.put(Integer.valueOf(i3), bVar);
                    }
                    layoutParams.setMarginEnd(0);
                    layoutParams.setMarginStart(0);
                    layoutParams.weight = 0.0f;
                    layoutParams.gravity = 1;
                    if (i.A(getContext())) {
                        VButton vButton = (VButton) childAt;
                        vButton.setMinWidth(r.c(getContext(), R$dimen.originui_dialog_button_max_width_fos15));
                        if (vButton.getDrawType() == 1) {
                            vButton.setPaddingRelative(0, vButton.getPaddingTop(), 0, vButton.getPaddingBottom());
                        }
                        layoutParams.width = -2;
                    } else {
                        ((VButton) childAt).setMinWidth(i2);
                    }
                    childAt.setLayoutParams(layoutParams);
                }
            }
        } else {
            setDividerDrawable(null);
        }
        View viewFindViewById = findViewById(R$id.spacer);
        View viewFindViewById2 = findViewById(R$id.divider);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility((z2 || i.A(getContext())) ? 8 : 4);
        }
        if (viewFindViewById2 != null) {
            viewFindViewById2.setVisibility(8);
        }
        for (int childCount = getChildCount() - 2; childCount >= 0; childCount--) {
            bringChildToFront(getChildAt(childCount));
        }
    }

    public void g() {
        if (this.f871a) {
            return;
        }
        this.f871a = true;
        if (getOrientation() == 0) {
            h(true, getWidth());
        }
        requestLayout();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    @Override // android.view.View
    public int getMinimumHeight() {
        return Math.max(this.f873c, super.getMinimumHeight());
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        f();
        postDelayed(new a(), 100L);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        int iMakeMeasureSpec;
        boolean z2;
        int paddingBottom = 0;
        if (i.l(((LinearLayout) this).mContext)) {
            super.onMeasure(i2, i3);
            try {
                this.f878h.getDefaultDisplay().getRealSize(this.f876f);
                this.f878h.getDefaultDisplay().getSize(this.f877g);
            } catch (Exception unused) {
                m.e("VDialogButtonPanel", "exception in measure");
            }
            while (paddingBottom < getChildCount()) {
                View childAt = getChildAt(paddingBottom);
                if (childAt instanceof VButton) {
                    if (!this.f879i && (i.w(((LinearLayout) this).mContext) || i.z(((LinearLayout) this).mContext))) {
                        int i4 = this.f877g.x;
                        Context context = ((LinearLayout) this).mContext;
                        int i5 = R$dimen.originui_dialog_500dp;
                        if (i4 > r.c(context, i5) || (this.f880j && this.f881k && this.f876f.x > r.c(((LinearLayout) this).mContext, i5))) {
                            ((VButton) childAt).setMinWidth(r.c(((LinearLayout) this).mContext, i.k() ? R$dimen.originui_dialog_button_min_width_m : R$dimen.originui_dialog_button_min_width_m_vos));
                        } else {
                            ((VButton) childAt).setMinWidth(r.c(((LinearLayout) this).mContext, i.k() ? R$dimen.originui_dialog_button_min_width : R$dimen.originui_dialog_button_min_width_vos));
                        }
                    }
                    VButton vButton = (VButton) childAt;
                    if (vButton.d()) {
                        vButton.e();
                    }
                }
                paddingBottom++;
            }
            return;
        }
        int size = View.MeasureSpec.getSize(i2);
        if (!this.f871a) {
            if (size > this.f872b && e()) {
                h(false, size);
            }
            this.f872b = size;
        }
        if (e() || View.MeasureSpec.getMode(i2) != 1073741824) {
            iMakeMeasureSpec = i2;
            z2 = false;
        } else {
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size, Integer.MIN_VALUE);
            z2 = true;
        }
        super.onMeasure(iMakeMeasureSpec, i3);
        if (!e()) {
            int measuredWidthAndState = getMeasuredWidthAndState() & (-16777216);
            int i6 = 0;
            boolean z3 = false;
            for (int i7 = 0; i7 < getChildCount(); i7++) {
                View childAt2 = getChildAt(i7);
                if ((childAt2 instanceof VButton) && childAt2.getVisibility() == 0) {
                    VButton vButton2 = (VButton) childAt2;
                    this.f883m.setText(vButton2.getButtonTextView().getText());
                    this.f883m.setTextSize(0, vButton2.getButtonTextView().getTextSize());
                    int paddingEnd = (((size / 2) - childAt2.getPaddingEnd()) - childAt2.getPaddingStart()) - r.c(getContext(), R$dimen.originui_dialog_button_gutter_fos15);
                    this.f883m.measure(View.MeasureSpec.makeMeasureSpec(paddingEnd, Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(536870911, Integer.MIN_VALUE));
                    z3 |= (this.f883m.getLineCount() > 2) || ((this.f883m.getLineCount() > 1) && (paddingEnd < r.c(getContext(), R$dimen.originui_dialog_button_two_line_min_width_fos15)));
                    i6++;
                }
            }
            if (!i.A(getContext()) ? measuredWidthAndState == 16777216 || i6 == 3 || this.f871a : (i6 == 2 && z3) || i6 == 3 || this.f871a) {
                h(true, size);
                z2 = true;
            } else {
                View viewFindViewById = findViewById(R$id.spacer);
                View viewFindViewById2 = findViewById(R$id.divider);
                if (i.A(getContext())) {
                    if (viewFindViewById != null) {
                        setGravity(1);
                        viewFindViewById.setVisibility(8);
                        if (i6 == 1) {
                            viewFindViewById2.setVisibility(8);
                        }
                    }
                    for (int i8 = 0; i8 < getChildCount(); i8++) {
                        View childAt3 = getChildAt(i8);
                        if ((childAt3 instanceof VButton) && childAt3.getVisibility() == 0) {
                            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt3.getLayoutParams();
                            layoutParams.setMargins(0, 0, 0, 0);
                            if (i6 == 1) {
                                layoutParams.setMarginStart(0);
                                layoutParams.setMarginEnd(0);
                            } else if (i6 == 2 && this.f882l.containsKey(Integer.valueOf(i8))) {
                                b bVar = (b) this.f882l.get(Integer.valueOf(i8));
                                if (bVar != null) {
                                    layoutParams.setMarginStart(bVar.c());
                                    layoutParams.setMarginEnd(bVar.b());
                                    layoutParams.weight = bVar.f();
                                    layoutParams.gravity = bVar.a();
                                    VButton vButton3 = (VButton) childAt3;
                                    if (vButton3.getDrawType() == 1) {
                                        vButton3.setPaddingRelative(bVar.e(), vButton3.getPaddingTop(), bVar.d(), vButton3.getPaddingBottom());
                                    }
                                }
                                viewFindViewById2.setVisibility(0);
                            }
                            childAt3.setLayoutParams(layoutParams);
                        }
                    }
                } else if (viewFindViewById2 != null) {
                    viewFindViewById2.setVisibility(8);
                }
            }
        }
        if (z2) {
            super.onMeasure(i2, i3);
        }
        int iD = d(0);
        if (iD >= 0) {
            View childAt4 = getChildAt(iD);
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) childAt4.getLayoutParams();
            int paddingTop = getPaddingTop() + childAt4.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
            if (e()) {
                int iD2 = d(iD + 1);
                if (iD2 >= 0) {
                    paddingTop += getChildAt(iD2).getPaddingTop() + ((int) (getResources().getDisplayMetrics().density * 16.0f));
                }
                paddingBottom = paddingTop;
            } else {
                paddingBottom = paddingTop + getPaddingBottom();
            }
        }
        if (getMinimumHeight() != paddingBottom) {
            setMinimumHeight(paddingBottom);
        }
    }

    public void setFullScreenStyle(boolean z2) {
        this.f880j = z2;
    }

    public VDialogButtonPanel(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.generateLayoutParams(layoutParams);
    }

    public VDialogButtonPanel(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f872b = -1;
        this.f873c = 0;
        this.f874d = 0;
        this.f875e = null;
        this.f876f = new Point();
        this.f877g = new Point();
        this.f880j = true;
        this.f881k = false;
        this.f879i = com.originui.core.utils.h.j();
        this.f881k = i.t(context);
        this.f878h = (WindowManager) context.getSystemService("window");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VDialog);
        this.f874d = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogButtonPanelDivider, 0);
        typedArrayObtainStyledAttributes.recycle();
        GradientDrawable gradientDrawable = new GradientDrawable();
        this.f875e = gradientDrawable;
        gradientDrawable.setSize(1, getResources().getDimensionPixelSize(this.f874d));
        TextView textView = new TextView(context);
        this.f883m = textView;
        textView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.f882l = new HashMap();
        f();
    }
}
