package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.k;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.ViewAttrConstant;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogDivider extends View implements VThemeIconUtils.ISystemColorRom14 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f896a;

    public VDialogDivider(Context context) {
        this(context, null);
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (i.j() && this.f896a != 0) {
            setBackgroundColor(getContext().getResources().getColor(this.f896a));
        }
        if (VThemeIconUtils.n() && i.k() && s.c(((View) this).mContext) < 15.0f) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (s.c(((View) this).mContext) >= 15.0f) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            layoutParams.height = r.c(((View) this).mContext, R$dimen.originui_dialog_divider_height_rom15_0);
            setLayoutParams(layoutParams);
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setSystemColorByDayModeRom14(int[] iArr) {
        setBackgroundColor(iArr[12]);
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setSystemColorNightModeRom14(int[] iArr) {
        setBackgroundColor(iArr[6]);
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setSystemColorRom13AndLess(float f2) {
        setViewDefaultColor();
    }

    public VDialogDivider(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VDialogDivider(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VDialogDivider(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VDialog, R$attr.alertDialogStyle, R$style.Vigour_VDialog_Alert);
        this.f896a = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogDividerColor, 0);
        typedArrayObtainStyledAttributes.recycle();
        q.r(this, 0);
        setForceDarkAllowed(false);
        int iD = i.i(context) ? k.d(context, "vigour_linear_view_divider_light", "drawable", "vivo") : 0;
        BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
        if (orCreateViewAttr != null) {
            if (iD != 0) {
                orCreateViewAttr.setGlobalBackground(iD);
            }
            if (!i.j()) {
                orCreateViewAttr.setBackgroundActiveMode(ViewAttrConstant.createActiveMode(false, false, false, false, true));
            } else {
                orCreateViewAttr.setBackgroundActiveMode(ViewAttrConstant.createActiveMode(true, false, true, false, true));
            }
        }
        if (iD != 0) {
            setBackground(getResources().getDrawable(iD));
        }
        if (VThemeIconUtils.n() && i.k() && s.c(((View) this).mContext) < 15.0f) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setViewDefaultColor() {
    }
}
