package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Point;
import android.provider.Settings;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewOverlay;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.b0;
import com.originui.core.utils.k;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.resmap.attr.BaseViewAttr;
import com.originui.resmap.attr.IUpdateBlur;
import com.originui.resmap.attr.ParserUtil;
import com.originui.resmap.attr.ViewAttrConstant;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VCustomRoundRectLayout extends LinearLayout implements VThemeIconUtils.ISystemColorRom14, IUpdateBlur {
    private g A;
    private ViewTreeObserver.OnGlobalLayoutListener B;
    private int C;
    private int D;
    private boolean E;
    private boolean F;
    private boolean G;
    private boolean H;
    private int I;
    private boolean J;
    private boolean K;
    private boolean L;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f820a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f821b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f822c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f823d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f824e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f825f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f826g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f827h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f828i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f829j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f830k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f831l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f832m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f833n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f834o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f835p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private final Point f836q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private final Point f837r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private final WindowManager f838s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private final boolean f839t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private boolean f840u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f841v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f842w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f843x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private boolean f844y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private f f845z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            VCustomRoundRectLayout.this.s();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            boolean zT = i.t(((LinearLayout) VCustomRoundRectLayout.this).mContext);
            if (VCustomRoundRectLayout.this.G != zT) {
                VCustomRoundRectLayout.this.G = zT;
                m.i("VDialog/VCustomRoundRectLayout", "mIsSplitLayout = " + VCustomRoundRectLayout.this.G);
                if (VCustomRoundRectLayout.this.A != null) {
                    VCustomRoundRectLayout.this.A.a(VCustomRoundRectLayout.this.G);
                }
            }
            VCustomRoundRectLayout vCustomRoundRectLayout = VCustomRoundRectLayout.this;
            vCustomRoundRectLayout.p(vCustomRoundRectLayout.getContext().getResources().getConfiguration());
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends ViewOutlineProvider {
        c() {
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            if (com.originui.core.utils.b.m(outline, 0, 0, view.getWidth(), view.getHeight(), VCustomRoundRectLayout.this.f820a, view)) {
                return;
            }
            outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), VCustomRoundRectLayout.this.f820a);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements b.b {
        d() {
        }

        @Override // b.b
        public void a(boolean z2) {
            m.i("VDialog/VCustomRoundRectLayout", "isBlurSuccess:" + z2 + ",mBlurEnabled:" + VCustomRoundRectLayout.this.f844y + ",setNightModeBlur:" + VCustomRoundRectLayout.this.f842w);
            if (z2) {
                return;
            }
            VCustomRoundRectLayout.this.r();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e implements b.b {
        e() {
        }

        @Override // b.b
        public void a(boolean z2) {
            m.i("VDialog/VCustomRoundRectLayout", "isBlurSuccess:" + z2 + ",mBlurEnabled:" + VCustomRoundRectLayout.this.f844y + ",setNightModeBlur:" + VCustomRoundRectLayout.this.f842w);
            if (z2) {
                return;
            }
            VCustomRoundRectLayout.this.r();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface f {
        void a(int i2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static abstract class g {
        g() {
        }

        abstract void a(boolean z2);
    }

    public VCustomRoundRectLayout(Context context) {
        this(context, null);
    }

    private int getAvailableHeightForArd15() {
        WindowInsets windowInsets = this.f838s.getCurrentWindowMetrics().getWindowInsets();
        return (this.f838s.getCurrentWindowMetrics().getBounds().height() - windowInsets.getSystemWindowInsetTop()) - windowInsets.getSystemWindowInsetBottom();
    }

    private int getAvailableWidthForArd15() {
        WindowInsets windowInsets = this.f838s.getCurrentWindowMetrics().getWindowInsets();
        return (this.f838s.getCurrentWindowMetrics().getBounds().width() - windowInsets.getSystemWindowInsetLeft()) - windowInsets.getSystemWindowInsetRight();
    }

    private void i() {
        if (this.f828i) {
            return;
        }
        this.f828i = true;
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) getLayoutParams();
        if (this.f839t || this.f831l) {
            layoutParams.gravity = 17;
        } else {
            layoutParams.gravity = 81;
        }
        setLayoutParams(layoutParams);
    }

    private void j() {
        setOutlineProvider(new c());
        com.originui.core.utils.f.t(this, this.f820a);
        setClipToOutline(true);
    }

    private boolean k() {
        int intForUser;
        int intForUser2;
        if (b0.c(((LinearLayout) this).mContext)) {
            try {
                intForUser = Settings.System.getIntForUser(getContext().getContentResolver(), "input_method_state", b0.f507a);
                try {
                    intForUser2 = Settings.System.getIntForUser(getContext().getContentResolver(), "secure_input_method_state", b0.f507a);
                } catch (Settings.SettingNotFoundException unused) {
                    m.b("VDialog/VCustomRoundRectLayout", "get input state in privacy system is error");
                    intForUser2 = 0;
                }
            } catch (Settings.SettingNotFoundException unused2) {
                intForUser = 0;
            }
        } else {
            intForUser = Settings.System.getInt(getContext().getContentResolver(), "input_method_state", 0);
            intForUser2 = Settings.System.getInt(getContext().getContentResolver(), "secure_input_method_state", 0);
        }
        return intForUser == 1 || intForUser2 == 1;
    }

    private boolean l(String str) {
        return str.contains("multi-window");
    }

    private void m() {
        boolean zP = com.originui.core.utils.f.p(getContext());
        if (zP != this.f844y) {
            this.f844y = zP;
            updateBlur();
        }
    }

    private void n() {
        int iC = i.c(getContext(), this.f825f);
        if (this.f820a != iC) {
            this.f820a = iC;
            j();
            f fVar = this.f845z;
            if (fVar != null) {
                fVar.a(this.f820a);
            }
        }
    }

    private void o() {
        com.originui.core.utils.f.J(this, com.originui.core.utils.b.k(getWidth(), getHeight(), this.f820a));
    }

    private void q() {
        boolean z2 = this.H;
        Float fValueOf = Float.valueOf(0.0f);
        if (!z2) {
            setElevation(0.0f);
            return;
        }
        try {
            if (s.b() < 14.0f) {
                setElevation(p.a(12.0f));
                setOutlineSpotShadowColor(Color.parseColor("#80000000"));
                return;
            }
            Class<?> cls = Class.forName("android.view.View");
            Class<?> cls2 = Float.TYPE;
            Method method = cls.getMethod("setLightSourceGeometry", cls2, cls2, cls2, cls2);
            Method method2 = cls.getMethod("setLightSourceAlpha", cls2, cls2);
            setElevation(208.0f);
            method.setAccessible(true);
            method.invoke(this, fValueOf, fValueOf, Float.valueOf(10000.0f), Float.valueOf(2650.0f));
            method2.setAccessible(true);
            method2.invoke(this, fValueOf, Float.valueOf(0.13f));
            invalidate();
        } catch (Exception e2) {
            setElevation(p.a(12.0f));
            setOutlineSpotShadowColor(Color.parseColor("#80000000"));
            m.e("VDialog/VCustomRoundRectLayout", "setLightSourceGeometry error = " + e2.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void s() {
        if (this.E || !this.f843x) {
            getViewTreeObserver().removeOnGlobalLayoutListener(this.B);
            return;
        }
        Configuration configuration = getContext().getResources().getConfiguration();
        String string = configuration.toString();
        boolean z2 = configuration.orientation == 2;
        boolean zL = l(string);
        if (!zL || z2) {
            boolean zK = k();
            this.K = zK;
            if (!zK && this.J && !this.L) {
                this.J = false;
                requestLayout();
                return;
            }
            this.L = false;
            this.J = zK;
            int iC = com.originui.core.utils.h.c(getContext());
            int iD = com.originui.core.utils.h.d(getContext());
            float availableHeightForArd15 = getAvailableHeightForArd15();
            if (availableHeightForArd15 != 0.0f) {
                iC = (int) availableHeightForArd15;
            }
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) getLayoutParams();
            int imeHeight = this.f822c;
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "realMaxHeight:" + imeHeight + ",screenHeight:" + iC + ",screenWidth:" + iD + ",topMargin:" + layoutParams.topMargin + ",bottomMargin:" + layoutParams.bottomMargin + ",mMaxHeight:" + this.f822c + ",isSoftInputShow:" + k() + "imeHeight:" + getImeHeight() + ",isLandscape:" + z2 + ",isSplit:" + zL);
            }
            if (i.p(getContext())) {
                imeHeight = this.f822c;
            } else if (zL) {
                imeHeight = Math.min((iD - layoutParams.topMargin) - layoutParams.bottomMargin, this.f822c);
            } else if (this.K) {
                imeHeight = (!z2 || i.n(getContext())) ? ((iC - getImeHeight()) - layoutParams.topMargin) - layoutParams.bottomMargin : (iD - layoutParams.topMargin) - layoutParams.bottomMargin;
            }
            if (this.D != imeHeight) {
                this.D = imeHeight;
                requestLayout();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00e6 A[PHI: r2 r3
      0x00e6: PHI (r2v8 float) = (r2v5 float), (r2v13 float) binds: [B:33:0x00e4, B:16:0x007e] A[DONT_GENERATE, DONT_INLINE]
      0x00e6: PHI (r3v13 int) = (r3v8 int), (r3v28 int) binds: [B:33:0x00e4, B:16:0x007e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:35:0x00e9 A[PHI: r0 r2 r3
      0x00e9: PHI (r0v13 float) = (r0v6 float), (r0v18 float) binds: [B:33:0x00e4, B:16:0x007e] A[DONT_GENERATE, DONT_INLINE]
      0x00e9: PHI (r2v11 float) = (r2v5 float), (r2v13 float) binds: [B:33:0x00e4, B:16:0x007e] A[DONT_GENERATE, DONT_INLINE]
      0x00e9: PHI (r3v18 int) = (r3v8 int), (r3v28 int) binds: [B:33:0x00e4, B:16:0x007e] A[DONT_GENERATE, DONT_INLINE]] */
    private float t() {
        int i2;
        float f2;
        int i3;
        float f3;
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) getLayoutParams();
        Resources resources = getResources();
        float fApplyDimension = TypedValue.applyDimension(1, resources.getConfiguration().screenWidthDp, resources.getDisplayMetrics());
        if (this.F && this.G) {
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "updateAvailableWidth availableWidth = " + fApplyDimension);
            }
            int i4 = this.f836q.x;
            if (i4 > 0) {
                fApplyDimension = i4;
            }
            i2 = layoutParams.leftMargin + layoutParams.rightMargin;
            int dimensionPixelSize = getResources().getDimensionPixelSize(this.f830k) + i2;
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "updateAvailableWidth availableWidth = " + fApplyDimension + ", margin = " + i2 + ", maxWidth = " + dimensionPixelSize);
            }
            f2 = dimensionPixelSize;
            if (fApplyDimension > f2) {
                f3 = fApplyDimension - i2;
            } else {
                f3 = fApplyDimension - (((i2 * fApplyDimension) / f2) * 0.5f);
            }
        } else {
            float availableWidthForArd15 = getAvailableWidthForArd15();
            if (availableWidthForArd15 != 0.0f) {
                fApplyDimension = availableWidthForArd15;
            }
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "updateAvailableWidth availableWidth = " + fApplyDimension);
            }
            if (fApplyDimension < 200.0f && (i3 = this.f836q.x) > 0) {
                fApplyDimension = i3;
            }
            i2 = layoutParams.leftMargin + layoutParams.rightMargin;
            int dimensionPixelSize2 = getResources().getDimensionPixelSize(this.f830k) + i2;
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "updateAvailableWidth availableWidth = " + fApplyDimension + ", margin = " + i2 + ", maxWidth = " + dimensionPixelSize2);
            }
            f2 = dimensionPixelSize2;
            if (fApplyDimension > f2) {
                f3 = fApplyDimension - i2;
            } else {
                f3 = fApplyDimension - (((i2 * fApplyDimension) / f2) * 0.5f);
            }
        }
        if (m.f583b) {
            m.b("VDialog/VCustomRoundRectLayout", "widthPixels = " + resources.getDisplayMetrics().widthPixels + ", availableWidth = " + f3);
        }
        return Math.min(Math.max(resources.getDisplayMetrics().widthPixels, this.f836q.x), f3);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return super.generateDefaultLayoutParams();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    public int getImeHeight() {
        InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
        int iIntValue = 0;
        try {
            Class[] clsArr = new Class[0];
            Method method = inputMethodManager.getClass().getMethod("getInputMethodWindowVisibleHeight", null);
            method.setAccessible(true);
            iIntValue = ((Integer) method.invoke(inputMethodManager, null)).intValue();
            m.b("VDialog/VCustomRoundRectLayout", "getInputMethodWindowVisibleHeight:" + iIntValue);
            return iIntValue;
        } catch (Exception unused) {
            m.b("VDialog/VCustomRoundRectLayout", "getInputMethodWindowVisibleHeight error");
            return iIntValue;
        }
    }

    public int getMaxHeight() {
        return this.f822c;
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.G = i.t(((LinearLayout) this).mContext);
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m.i("VDialog/VCustomRoundRectLayout", "onConfigurationChanged newConfig = " + configuration);
        this.f833n = configuration.uiMode;
        if (VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
            setBlurEnable(this.f840u);
        }
        n();
        m();
        postDelayed(new b(), 100L);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalLayoutListener(this.B);
        this.f834o = 0;
        this.f835p = 0;
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        int i6 = i5 - i3;
        if (this.f835p == i6 && this.f834o == i4 - i2) {
            return;
        }
        this.f835p = i6;
        this.f834o = i4 - i2;
        if (i.l(((LinearLayout) this).mContext)) {
            q();
        }
        j();
        o();
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        int iC;
        i();
        try {
            this.f838s.getDefaultDisplay().getRealSize(this.f836q);
            this.f838s.getDefaultDisplay().getSize(this.f837r);
            int i4 = this.f823d;
            if (i4 != -1) {
                this.f821b = i4;
            } else {
                this.f821b = (int) t();
            }
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "onMeasure screenSizePoint height = " + this.f836q.y + ", width = " + this.f836q.x + ", mMaxWidth = " + this.f821b);
                StringBuilder sb = new StringBuilder();
                sb.append("onMeasure windowSizePoint height = ");
                sb.append(this.f837r.y);
                sb.append(", width = ");
                sb.append(this.f837r.x);
                m.b("VDialog/VCustomRoundRectLayout", sb.toString());
                m.b("VDialog/VCustomRoundRectLayout", "onMeasure mIsSplitLayout = " + this.G);
            }
            if (getLayoutParams() instanceof FrameLayout.LayoutParams) {
                int mode = View.MeasureSpec.getMode(i2);
                if (i.l(((LinearLayout) this).mContext)) {
                    iC = i.z(((LinearLayout) this).mContext) ? r.c(((LinearLayout) this).mContext, R$dimen.originui_dialog_width_vos) : r.c(((LinearLayout) this).mContext, R$dimen.originui_dialog_width);
                } else {
                    iC = r.c(((LinearLayout) this).mContext, R$dimen.originui_dialog_width_fos);
                }
                if (!this.f839t && ((i.k() && s.c(((LinearLayout) this).mContext) >= 15.0f) || i.z(((LinearLayout) this).mContext))) {
                    int i5 = this.f837r.x;
                    Context context = ((LinearLayout) this).mContext;
                    int i6 = R$dimen.originui_dialog_500dp;
                    if (i5 > r.c(context, i6) || (this.F && this.G && this.f836q.x > r.c(((LinearLayout) this).mContext, i6))) {
                        iC = r.c(((LinearLayout) this).mContext, i.r() ? R$dimen.originui_dialog_width_m_vos : R$dimen.originui_dialog_width_m);
                    }
                }
                if (m.f583b) {
                    m.b("VDialog/VCustomRoundRectLayout", "onMeasure widthMode = " + mode + ", widthSize = " + iC);
                }
                if (mode == 1073741824) {
                    int i7 = this.f821b;
                    i2 = iC > i7 ? View.MeasureSpec.makeMeasureSpec(i7, 1073741824) : View.MeasureSpec.makeMeasureSpec(iC, 1073741824);
                }
            }
            this.C = i2;
            super.onMeasure(i2, i3);
            if (this.f827h != -1) {
                int measuredHeight = getMeasuredHeight();
                int i8 = this.f827h;
                if (measuredHeight > i8) {
                    super.onMeasure(i2, View.MeasureSpec.makeMeasureSpec(i8, 1073741824));
                    return;
                }
                return;
            }
            if (this.f826g) {
                int i9 = this.f824e;
                if (i9 != -1) {
                    this.f822c = i9;
                    return;
                }
                int measuredHeight2 = getMeasuredHeight();
                Point point = this.f836q;
                int iMax = point.y;
                int i10 = point.x;
                if (iMax < 500 && !this.f831l) {
                    iMax = Math.max(p.a(getResources().getConfiguration().screenHeightDp), iMax);
                }
                if (this.f839t) {
                    this.f822c = (int) (Math.min(i10, iMax) * 0.6666667f);
                } else {
                    this.f822c = (int) (iMax * (this.f831l ? 0.75f : 0.6666667f));
                }
                if (this.K && this.f843x && !this.E) {
                    this.f822c = Math.min(this.D, this.f822c);
                }
                int i11 = this.f822c;
                if (measuredHeight2 > i11) {
                    super.onMeasure(i2, View.MeasureSpec.makeMeasureSpec(i11, 1073741824));
                    return;
                }
                return;
            }
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) getLayoutParams();
            if (this.F && this.G) {
                this.f822c = (Math.max(p.a(getResources().getConfiguration().screenHeightDp), this.f836q.y) - layoutParams.topMargin) - layoutParams.bottomMargin;
                int measuredHeight3 = getMeasuredHeight();
                int i12 = this.f822c;
                if (measuredHeight3 > i12) {
                    super.onMeasure(i2, View.MeasureSpec.makeMeasureSpec(i12, 1073741824));
                    return;
                }
                return;
            }
            Resources resources = getResources();
            float fApplyDimension = TypedValue.applyDimension(1, resources.getConfiguration().screenHeightDp, resources.getDisplayMetrics());
            float availableHeightForArd15 = getAvailableHeightForArd15();
            if (availableHeightForArd15 != 0.0f) {
                fApplyDimension = availableHeightForArd15;
            }
            int iMax2 = this.f836q.y;
            if (iMax2 < 500 && !this.f831l) {
                iMax2 = Math.max(p.a(getResources().getConfiguration().screenHeightDp), iMax2);
            }
            if (i.p(((LinearLayout) this).mContext)) {
                this.f822c = (((int) fApplyDimension) - layoutParams.topMargin) - layoutParams.bottomMargin;
            } else {
                this.f822c = Math.min((int) ((fApplyDimension - layoutParams.topMargin) - layoutParams.bottomMargin), iMax2);
            }
            int measuredHeight4 = getMeasuredHeight();
            int i13 = this.f822c;
            if (measuredHeight4 > i13) {
                super.onMeasure(i2, View.MeasureSpec.makeMeasureSpec(i13, 1073741824));
            }
        } catch (Exception unused) {
            m.e("VDialog/VCustomRoundRectLayout", "exception in measure");
            super.onMeasure(i2, i3);
        }
    }

    public void p(Configuration configuration) {
        boolean z2 = false;
        if (i.A(getContext())) {
            this.f826g = false;
        } else if (this.f839t) {
            this.f826g = true;
        } else {
            this.f831l = i.m(getContext());
            if (configuration == null) {
                configuration = getContext().getResources().getConfiguration();
            }
            int iE = i.e(getContext());
            boolean z3 = configuration.orientation == 2;
            boolean zL = l(configuration.toString());
            if (m.f583b) {
                m.b("VDialog/VCustomRoundRectLayout", "refreshHeightLimit() dockSide=" + iE + ", isLandscape=" + z3 + ", isSplit=" + zL + ", isInFreeFormMode=" + i.p(getContext()));
            }
            if (this.G) {
                if ((!z3 || i.n(getContext())) && !i.p(getContext())) {
                    z2 = true;
                }
                this.f826g = z2;
            } else if (i.n(getContext()) && zL) {
                if (iE != 2 && iE != 4) {
                    z2 = true;
                }
                this.f826g = z2;
            } else {
                if ((!z3 || i.n(getContext())) && !zL && !i.p(getContext())) {
                    z2 = true;
                }
                this.f826g = z2;
            }
        }
        if (m.f583b) {
            m.b("VDialog/VCustomRoundRectLayout", "refreshHeightLimit() isHeightLimit=" + this.f826g + "mIsSplitLayout:" + this.G);
        }
        requestLayout();
    }

    public void r() {
        setBackground(getContext().getDrawable(this.f829j));
        if (VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    public void setBlurEnable(boolean z2) {
        this.f840u = z2;
        b.a aVar = new b.a(this.f820a);
        b.e eVar = new b.e();
        eVar.I(aVar);
        eVar.J(0);
        int color = this.I;
        if (color == -1) {
            color = getResources().getColor(R$color.originui_dialog_background);
        }
        eVar.H(color);
        if (this.f842w) {
            com.originui.core.utils.f.x(this, 6, eVar, true, this.f840u, i.i(getContext()), this.f841v, false, 1, new d());
        } else {
            com.originui.core.utils.f.w(this, 6, eVar, true, this.f840u, i.i(getContext()), false, 0, 1, new e());
        }
    }

    public void setBlurMarkerColor(int i2) {
        this.I = i2;
    }

    public void setCustomHeightLimit(int i2) {
        m.i("VDialog/VCustomRoundRectLayout", "setCustomHeightLimit heightLimit = " + i2);
        this.f824e = i2;
        requestLayout();
    }

    public void setCustomMaxHeight(int i2) {
        this.f827h = i2;
    }

    public void setCustomMaxWidth(int i2) {
        m.i("VDialog/VCustomRoundRectLayout", "setCustomMaxWidth width = " + i2);
        this.f823d = i2;
        requestLayout();
    }

    public void setDisableEditDialogCalculation(boolean z2) {
        this.E = z2;
    }

    public void setFullScreenStyle(boolean z2) {
        this.F = z2;
    }

    public void setHasInputView(boolean z2) {
        this.f843x = z2;
    }

    public void setMaxFilletLevel(int i2) {
        if (this.f825f != i2) {
            this.f825f = i2;
            n();
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColor() {
        this.f832m = this.f833n;
        if (VThemeIconUtils.A(getContext())) {
            setViewDefaultColor();
        } else {
            setBackgroundColor(VThemeIconUtils.p(getContext(), VThemeIconUtils.f476z, VThemeIconUtils.M));
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColorNightMode() {
        setViewDefaultColor();
    }

    public void setOnFilletChangeListener(f fVar) {
        this.f845z = fVar;
    }

    public void setShadowEffectEnable(boolean z2) {
        this.H = z2;
    }

    public void setSplitChangedCallback(g gVar) {
        this.A = gVar;
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setSystemColorByDayModeRom14(int[] iArr) {
        setViewDefaultColor();
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setSystemColorNightModeRom14(int[] iArr) {
        if (!VThemeIconUtils.C(iArr)) {
            setViewDefaultColor();
        } else {
            this.f832m = this.f833n;
            setBackgroundColor(iArr[5]);
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setSystemColorRom13AndLess(float f2) {
        setViewDefaultColor();
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setViewDefaultColor() {
        m.b("VDialog/VCustomRoundRectLayout", "setViewDefaultColor uiMode = " + this.f832m + ", newUiMode = " + this.f833n);
        if (i.j()) {
            int i2 = this.f832m;
            int i3 = this.f833n;
            if (i2 != i3) {
                this.f832m = i3;
                setBackground(getContext().getDrawable(this.f829j));
            }
        }
    }

    @Override // com.originui.resmap.attr.IUpdateBlur
    public void updateBlur() {
        setBlurEnable(this.f840u);
    }

    public VCustomRoundRectLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    protected /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.generateLayoutParams(layoutParams);
    }

    public VCustomRoundRectLayout(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VCustomRoundRectLayout(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f823d = -1;
        this.f824e = -1;
        this.f825f = 3;
        this.f826g = false;
        this.f827h = -1;
        this.f828i = false;
        this.f829j = 0;
        this.f830k = 0;
        this.f831l = false;
        this.f834o = 0;
        this.f835p = 0;
        this.f836q = new Point();
        this.f837r = new Point();
        this.f840u = true;
        this.f841v = false;
        this.f842w = false;
        this.f843x = false;
        this.f844y = false;
        this.D = 10000;
        this.E = false;
        this.F = true;
        this.G = false;
        this.H = true;
        this.I = -1;
        this.J = false;
        this.K = false;
        this.L = true;
        this.f839t = com.originui.core.utils.h.j();
        this.G = i.t(context);
        this.f844y = com.originui.core.utils.f.p(getContext());
        if (i.r()) {
            this.E = true;
        }
        this.f838s = (WindowManager) context.getSystemService("window");
        this.f833n = context.getResources().getConfiguration().uiMode;
        if (i.d() != -1) {
            q.r(this, i.d());
        }
        m.i("VDialog/VCustomRoundRectLayout", "nightMode: " + VThemeIconUtils.A(context));
        if (i.o()) {
            setForceDarkAllowed(i.f());
        }
        BaseViewAttr orCreateViewAttr = ParserUtil.getOrCreateViewAttr(this);
        if (orCreateViewAttr != null) {
            orCreateViewAttr.setSizeActiveMode(ViewAttrConstant.createActiveMode(false));
            if (i.j()) {
                orCreateViewAttr.setBackgroundActiveMode(ViewAttrConstant.createActiveMode(true, false));
            } else {
                orCreateViewAttr.setBackgroundActiveMode(ViewAttrConstant.createActiveMode(false, false, false, false, true));
            }
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.VDialog, R$attr.alertDialogStyle, R$style.Vigour_VDialog_Alert);
        this.f830k = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogWidth, 0);
        this.f829j = typedArrayObtainStyledAttributes.getResourceId(R$styleable.VDialog_dialogBackground, 0);
        typedArrayObtainStyledAttributes.recycle();
        m.i("VDialog/VCustomRoundRectLayout", "isApplyGlobalTheme: " + i.i(context));
        if (i.i(context)) {
            this.f829j = k.d(context, "vigour_dialog_full_light", "drawable", "vivo");
            m.i("VDialog/VCustomRoundRectLayout", "backgroundResourceId: " + this.f829j);
            if (this.f829j != 0) {
                setBackground(getContext().getDrawable(this.f829j));
            }
            if (orCreateViewAttr != null) {
                orCreateViewAttr.setGlobalBackground(this.f829j);
            }
        }
        if (VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
        n();
        p(null);
        com.originui.core.utils.d.i(this, "6.0.1.8");
        com.originui.core.utils.d.j(this, true, "GridView");
        this.B = new a();
        getRootView().getViewTreeObserver().addOnGlobalLayoutListener(this.B);
    }
}
