package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.View;
import com.originui.core.utils.VThemeIconUtils;
import com.originui.core.utils.m;
import com.originui.core.utils.q;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VDialogButtonDivider extends View implements VThemeIconUtils.ISystemColorRom14 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f869a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f870b;

    public VDialogButtonDivider(Context context) {
        this(context, null);
    }

    private int a(int i2, int i3) {
        if (i3 < 0 || i3 > 255) {
            throw new IllegalArgumentException("alpha must be between 0 and 255.");
        }
        return (16777215 & i2) | (i3 << 24);
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m.b("VDialogButtonDivider", "onConfigurationChanged newConfig = " + configuration);
        this.f870b = configuration.uiMode;
        if (VThemeIconUtils.n()) {
            VThemeIconUtils.E(getContext(), VThemeIconUtils.n(), this);
        }
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColor() {
        this.f869a = this.f870b;
        setBackgroundColor(VThemeIconUtils.p(getContext(), VThemeIconUtils.f476z, VThemeIconUtils.L));
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setMyDynamicColorNightMode() {
        this.f869a = this.f870b;
        setBackgroundColor(a(VThemeIconUtils.p(getContext(), VThemeIconUtils.f476z, VThemeIconUtils.K), 51));
    }

    @Override // com.originui.core.utils.VThemeIconUtils.ISystemColorRom14
    public void setViewDefaultColor() {
        m.b("VDialogButtonDivider", "setViewDefaultColor uiMode = " + this.f869a + ", newUiMode = " + this.f870b);
        if (i.j()) {
            int i2 = this.f869a;
            int i3 = this.f870b;
            if (i2 != i3) {
                this.f869a = i3;
                setBackgroundColor(getResources().getColor(R$color.originui_dialog_button_divider));
            }
        }
    }

    public VDialogButtonDivider(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VDialogButtonDivider(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public VDialogButtonDivider(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        q.r(this, 0);
        setForceDarkAllowed(false);
    }
}
