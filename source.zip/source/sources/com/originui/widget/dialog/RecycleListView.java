package com.originui.widget.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOverlay;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.originui.resmap.attr.ParserUtil;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class RecycleListView extends ListView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final int f813a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final int f814b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f815c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f816d;

    public RecycleListView(Context context) {
        this(context, null);
    }

    public void a(boolean z2, boolean z3) {
        if (z3 && z2) {
            return;
        }
        ParserUtil.setViewPadding(this, 0, z2 ? 0 : this.f813a, 0, z3 ? 0 : this.f814b);
    }

    @Override // android.widget.AbsListView, android.view.ViewGroup
    public /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return super.generateLayoutParams(attributeSet);
    }

    @Override // android.widget.ListView, android.widget.AdapterView
    public /* bridge */ /* synthetic */ Adapter getAdapter() {
        return super.getAdapter();
    }

    @Override // android.view.ViewGroup, android.view.View
    public /* bridge */ /* synthetic */ ViewOverlay getOverlay() {
        return super.getOverlay();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        int i2;
        super.onConfigurationChanged(configuration);
        if (!i.j() || this.f815c == (i2 = configuration.uiMode)) {
            return;
        }
        this.f815c = i2;
        ListAdapter adapter = getAdapter();
        if (adapter instanceof BaseAdapter) {
            ((BaseAdapter) adapter).notifyDataSetChanged();
        }
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View
    protected void onMeasure(int i2, int i3) {
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(536870911, Integer.MIN_VALUE);
        if (this.f816d) {
            int childCount = getChildCount();
            int measuredHeight = 0;
            for (int i4 = 0; i4 < childCount; i4++) {
                measuredHeight += getChildAt(i4).getMeasuredHeight();
            }
            if (measuredHeight != 0) {
                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
            }
        }
        super.onMeasure(i2, iMakeMeasureSpec);
    }

    @Override // android.widget.AdapterView
    public /* bridge */ /* synthetic */ void setAdapter(Adapter adapter) {
        super.setAdapter((ListAdapter) adapter);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(com.originui.core.utils.d.e(drawable, "6.0.1.8"));
    }

    public void setNeedSpecialMeasure(boolean z2) {
        this.f816d = z2;
    }

    public RecycleListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f815c = 0;
        this.f816d = false;
        this.f815c = context.getResources().getConfiguration().uiMode;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.RecycleListView);
        this.f814b = typedArrayObtainStyledAttributes.getResourceId(R$styleable.RecycleListView_paddingBottomNoButtons, -1);
        this.f813a = typedArrayObtainStyledAttributes.getResourceId(R$styleable.RecycleListView_paddingTopNoTitle, -1);
        typedArrayObtainStyledAttributes.recycle();
        setSelector(new ColorDrawable(0));
        setBackgroundColor(0);
        i.C(this, false);
        setVerticalScrollBarEnabled(false);
        setScrollContainer(true);
        i.D(this, false);
    }
}
