package com.originui.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.TextView;
import com.originui.core.utils.s;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private BaseDialogBuilder f1102a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f1103b;

    public j(Context context, int i2) {
        this.f1102a = null;
        this.f1103b = -1.0f;
        this.f1103b = s.c(context);
        if (i.r()) {
            this.f1102a = new g(context, i2);
        } else if (this.f1103b >= 13.0f) {
            this.f1102a = new g(context, i2);
        } else {
            this.f1102a = new c(context, i2);
        }
    }

    public Dialog a() {
        Dialog dialogC = this.f1102a.c();
        l(dialogC);
        return dialogC;
    }

    public Context b() {
        return this.f1102a.d();
    }

    public TextView c() {
        return this.f1102a.e();
    }

    public j d(int i2, DialogInterface.OnClickListener onClickListener) {
        this.f1102a.l(i2, onClickListener);
        return this;
    }

    public j e(int i2, DialogInterface.OnClickListener onClickListener) {
        this.f1102a.m(i2, onClickListener);
        return this;
    }

    public j f(int i2) {
        this.f1102a.n(i2);
        return this;
    }

    public j g(CharSequence charSequence) {
        this.f1102a.o(charSequence);
        return this;
    }

    public j h(int i2) {
        return i(b().getText(i2));
    }

    public j i(CharSequence charSequence) {
        this.f1102a.q(charSequence);
        return this;
    }

    public j j(int i2) {
        return k(b().getText(i2));
    }

    public j k(CharSequence charSequence) {
        this.f1102a.r(charSequence);
        return this;
    }

    public void l(Dialog dialog) {
    }
}
