package com.android.common.contacts;

import android.accounts.Account;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.text.util.Rfc822Token;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import com.android.common.widget.CompositeCursorAdapter;
import java.util.ArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class BaseEmailAddressAdapter extends CompositeCursorAdapter implements Filterable {
    private static final int ALLOWANCE_FOR_DUPLICATES = 5;
    private static final int DEFAULT_PREFERRED_MAX_RESULT_COUNT = 10;
    private static final long DIRECTORY_LOCAL_INVISIBLE = 1;
    private static final String DIRECTORY_PARAM_KEY = "directory";
    private static final String LIMIT_PARAM_KEY = "limit";
    private static final int MESSAGE_SEARCH_PENDING = 1;
    private static final int MESSAGE_SEARCH_PENDING_DELAY = 1000;
    private static final String PRIMARY_ACCOUNT_NAME = "name_for_primary_account";
    private static final String PRIMARY_ACCOUNT_TYPE = "type_for_primary_account";
    private static final String SEARCHING_CURSOR_MARKER = "searching";
    private static final String TAG = "BaseEmailAddressAdapter";
    private Account mAccount;
    protected final ContentResolver mContentResolver;
    private boolean mDirectoriesLoaded;
    private Handler mHandler;
    private int mPreferredMaxResultCount;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends Handler {
        a() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            BaseEmailAddressAdapter.this.showSearchPendingIfNotComplete(message.arg1);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class b extends Filter {
        private b() {
        }

        @Override // android.widget.Filter
        public CharSequence convertResultToString(Object obj) {
            return BaseEmailAddressAdapter.this.makeDisplayString((Cursor) obj);
        }

        @Override // android.widget.Filter
        protected Filter.FilterResults performFiltering(CharSequence charSequence) {
            Cursor cursorQuery;
            Cursor cursorQuery2 = null;
            if (BaseEmailAddressAdapter.this.mDirectoriesLoaded) {
                cursorQuery = null;
            } else {
                cursorQuery = BaseEmailAddressAdapter.this.mContentResolver.query(c.f358a, c.f359b, null, null, null);
                BaseEmailAddressAdapter.this.mDirectoriesLoaded = true;
            }
            Filter.FilterResults filterResults = new Filter.FilterResults();
            if (!TextUtils.isEmpty(charSequence)) {
                Uri.Builder builderAppendQueryParameter = ContactsContract.CommonDataKinds.Email.CONTENT_FILTER_URI.buildUpon().appendPath(charSequence.toString()).appendQueryParameter(BaseEmailAddressAdapter.LIMIT_PARAM_KEY, String.valueOf(BaseEmailAddressAdapter.this.mPreferredMaxResultCount));
                if (BaseEmailAddressAdapter.this.mAccount != null) {
                    builderAppendQueryParameter.appendQueryParameter(BaseEmailAddressAdapter.PRIMARY_ACCOUNT_NAME, BaseEmailAddressAdapter.this.mAccount.name);
                    builderAppendQueryParameter.appendQueryParameter(BaseEmailAddressAdapter.PRIMARY_ACCOUNT_TYPE, BaseEmailAddressAdapter.this.mAccount.type);
                }
                cursorQuery2 = BaseEmailAddressAdapter.this.mContentResolver.query(builderAppendQueryParameter.build(), f.f372a, null, null, null);
                filterResults.count = cursorQuery2.getCount();
            }
            filterResults.values = new Cursor[]{cursorQuery, cursorQuery2};
            return filterResults;
        }

        @Override // android.widget.Filter
        protected void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
            Object obj = filterResults.values;
            if (obj != null) {
                Cursor[] cursorArr = (Cursor[]) obj;
                BaseEmailAddressAdapter.this.onDirectoryLoadFinished(charSequence, cursorArr[0], cursorArr[1]);
            }
            filterResults.count = BaseEmailAddressAdapter.this.getCount();
        }

        /* synthetic */ b(BaseEmailAddressAdapter baseEmailAddressAdapter, a aVar) {
            this();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final Uri f358a = Uri.withAppendedPath(ContactsContract.AUTHORITY_URI, "directories");

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final String[] f359b = {"_id", "accountName", "accountType", "displayName", "packageName", "typeResourceId"};
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static final class d extends CompositeCursorAdapter.a {

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public long f360f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public String f361g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public String f362h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public String f363i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public String f364j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public boolean f365k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public CharSequence f366l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public e f367m;

        public d() {
            super(false, false);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class e extends Filter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f368a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final long f369b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f370c;

        public e(int i2, long j2) {
            this.f368a = i2;
            this.f369b = j2;
        }

        public synchronized int a() {
            return this.f370c;
        }

        public synchronized void b(int i2) {
            this.f370c = i2;
        }

        @Override // android.widget.Filter
        protected Filter.FilterResults performFiltering(CharSequence charSequence) {
            Filter.FilterResults filterResults = new Filter.FilterResults();
            if (!TextUtils.isEmpty(charSequence)) {
                filterResults.values = BaseEmailAddressAdapter.this.mContentResolver.query(ContactsContract.CommonDataKinds.Email.CONTENT_FILTER_URI.buildUpon().appendPath(charSequence.toString()).appendQueryParameter(BaseEmailAddressAdapter.DIRECTORY_PARAM_KEY, String.valueOf(this.f369b)).appendQueryParameter(BaseEmailAddressAdapter.LIMIT_PARAM_KEY, String.valueOf(a() + 5)).build(), f.f372a, null, null, null);
            }
            return filterResults;
        }

        @Override // android.widget.Filter
        protected void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
            BaseEmailAddressAdapter.this.onPartitionLoadFinished(charSequence, this.f368a, (Cursor) filterResults.values);
            filterResults.count = BaseEmailAddressAdapter.this.getCount();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class f {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final String[] f372a = {"display_name", "data1"};
    }

    public BaseEmailAddressAdapter(Context context) {
        this(context, 10);
    }

    private Cursor createLoadingCursor() {
        MatrixCursor matrixCursor = new MatrixCursor(new String[]{SEARCHING_CURSOR_MARKER});
        matrixCursor.addRow(new Object[]{""});
        return matrixCursor;
    }

    private boolean hasDuplicates(Cursor cursor, int i2) {
        cursor.moveToPosition(-1);
        while (cursor.moveToNext()) {
            if (isDuplicate(cursor.getString(1), i2)) {
                return true;
            }
        }
        return false;
    }

    private boolean isDuplicate(String str, int i2) {
        Cursor cursor;
        int partitionCount = getPartitionCount();
        for (int i3 = 0; i3 < partitionCount; i3++) {
            if (i3 != i2 && !isLoading(i3) && (cursor = getCursor(i3)) != null) {
                cursor.moveToPosition(-1);
                while (cursor.moveToNext()) {
                    if (TextUtils.equals(str, cursor.getString(1))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isLoading(int i2) {
        return ((d) getPartition(i2)).f365k;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String makeDisplayString(Cursor cursor) {
        if (cursor.getColumnName(0).equals(SEARCHING_CURSOR_MARKER)) {
            return "";
        }
        String string = cursor.getString(0);
        String string2 = cursor.getString(1);
        return (TextUtils.isEmpty(string) || TextUtils.equals(string, string2)) ? string2 : new Rfc822Token(string, string2, null).toString();
    }

    private Cursor removeDuplicatesAndTruncate(int i2, Cursor cursor) {
        if (cursor == null) {
            return null;
        }
        if (cursor.getCount() <= 10 && !hasDuplicates(cursor, i2)) {
            return cursor;
        }
        MatrixCursor matrixCursor = new MatrixCursor(f.f372a);
        cursor.moveToPosition(-1);
        int i3 = 0;
        while (cursor.moveToNext() && i3 < 10) {
            String string = cursor.getString(0);
            String string2 = cursor.getString(1);
            if (!isDuplicate(string2, i2)) {
                matrixCursor.addRow(new Object[]{string, string2});
                i3++;
            }
        }
        cursor.close();
        return matrixCursor;
    }

    @Override // com.android.common.widget.CompositeCursorAdapter, android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override // com.android.common.widget.CompositeCursorAdapter
    protected void bindView(View view, int i2, Cursor cursor, int i3) {
        String str;
        String str2;
        d dVar = (d) getPartition(i2);
        String str3 = dVar.f361g;
        String str4 = dVar.f362h;
        if (dVar.f365k) {
            bindViewLoading(view, str3, str4);
            return;
        }
        String string = cursor.getString(0);
        String string2 = cursor.getString(1);
        if (TextUtils.isEmpty(string) || TextUtils.equals(string, string2)) {
            str = null;
            str2 = string2;
        } else {
            str2 = string;
            str = string2;
        }
        bindView(view, str3, str4, str2, str);
    }

    protected abstract void bindView(View view, String str, String str2, String str3, String str4);

    protected abstract void bindViewLoading(View view, String str, String str2);

    @Override // android.widget.Filterable
    public Filter getFilter() {
        return new b(this, null);
    }

    @Override // com.android.common.widget.CompositeCursorAdapter
    protected int getItemViewType(int i2, int i3) {
        return ((d) getPartition(i2)).f365k ? 1 : 0;
    }

    protected abstract View inflateItemView(ViewGroup viewGroup);

    protected abstract View inflateItemViewLoading(ViewGroup viewGroup);

    @Override // com.android.common.widget.CompositeCursorAdapter
    protected boolean isEnabled(int i2, int i3) {
        return !isLoading(i2);
    }

    @Override // com.android.common.widget.CompositeCursorAdapter
    protected View newView(Context context, int i2, Cursor cursor, int i3, ViewGroup viewGroup) {
        return ((d) getPartition(i2)).f365k ? inflateItemViewLoading(viewGroup) : inflateItemView(viewGroup);
    }

    protected void onDirectoryLoadFinished(CharSequence charSequence, Cursor cursor, Cursor cursor2) {
        int i2 = 0;
        if (cursor != null) {
            PackageManager packageManager = getContext().getPackageManager();
            ArrayList arrayList = new ArrayList();
            d dVar = null;
            while (cursor.moveToNext()) {
                long j2 = cursor.getLong(i2);
                if (j2 != DIRECTORY_LOCAL_INVISIBLE) {
                    d dVar2 = new d();
                    dVar2.f360f = j2;
                    dVar2.f362h = cursor.getString(3);
                    dVar2.f363i = cursor.getString(1);
                    dVar2.f364j = cursor.getString(2);
                    String string = cursor.getString(4);
                    int i3 = cursor.getInt(5);
                    if (string != null && i3 != 0) {
                        try {
                            String string2 = packageManager.getResourcesForApplication(string).getString(i3);
                            dVar2.f361g = string2;
                            if (string2 == null) {
                                Log.e(TAG, "Cannot resolve directory name: " + i3 + "@" + string);
                            }
                        } catch (PackageManager.NameNotFoundException e2) {
                            Log.e(TAG, "Cannot resolve directory name: " + i3 + "@" + string, e2);
                        }
                    }
                    Account account = this.mAccount;
                    if (account != null && account.name.equals(dVar2.f363i) && this.mAccount.type.equals(dVar2.f364j)) {
                        dVar = dVar2;
                    } else {
                        arrayList.add(dVar2);
                    }
                    i2 = 0;
                }
            }
            if (dVar != null) {
                arrayList.add(1, dVar);
            }
            int size = arrayList.size();
            int i4 = 0;
            while (i4 < size) {
                Object obj = arrayList.get(i4);
                i4++;
                addPartition((d) obj);
            }
        }
        int partitionCount = getPartitionCount();
        setNotificationsEnabled(false);
        if (cursor2 != null) {
            try {
                if (getPartitionCount() > 0) {
                    changeCursor(0, cursor2);
                }
            } catch (Throwable th) {
                setNotificationsEnabled(true);
                throw th;
            }
        }
        int count = this.mPreferredMaxResultCount - (cursor2 == null ? 0 : cursor2.getCount());
        for (int i5 = 1; i5 < partitionCount; i5++) {
            d dVar3 = (d) getPartition(i5);
            dVar3.f366l = charSequence;
            if (count <= 0) {
                dVar3.f365k = false;
                changeCursor(i5, null);
            } else if (!dVar3.f365k) {
                dVar3.f365k = true;
                changeCursor(i5, null);
            }
        }
        setNotificationsEnabled(true);
        for (int i6 = 1; i6 < partitionCount; i6++) {
            d dVar4 = (d) getPartition(i6);
            if (dVar4.f365k) {
                this.mHandler.removeMessages(1, dVar4);
                this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1, i6, 0, dVar4), 1000L);
                if (dVar4.f367m == null) {
                    dVar4.f367m = new e(i6, dVar4.f360f);
                }
                dVar4.f367m.b(count);
                dVar4.f367m.filter(charSequence);
            } else {
                e eVar = dVar4.f367m;
                if (eVar != null) {
                    eVar.filter(null);
                }
            }
        }
    }

    public void onPartitionLoadFinished(CharSequence charSequence, int i2, Cursor cursor) {
        if (i2 >= getPartitionCount()) {
            if (cursor != null) {
                cursor.close();
                return;
            }
            return;
        }
        d dVar = (d) getPartition(i2);
        if (dVar.f365k && TextUtils.equals(charSequence, dVar.f366l)) {
            dVar.f365k = false;
            this.mHandler.removeMessages(1, dVar);
            changeCursor(i2, removeDuplicatesAndTruncate(i2, cursor));
        } else if (cursor != null) {
            cursor.close();
        }
    }

    public void setAccount(Account account) {
        this.mAccount = account;
    }

    void showSearchPendingIfNotComplete(int i2) {
        if (i2 >= getPartitionCount() || !((d) getPartition(i2)).f365k) {
            return;
        }
        changeCursor(i2, createLoadingCursor());
    }

    public BaseEmailAddressAdapter(Context context, int i2) {
        super(context);
        this.mContentResolver = context.getContentResolver();
        this.mPreferredMaxResultCount = i2;
        this.mHandler = new a();
    }
}
