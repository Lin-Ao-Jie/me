package com.android.common.widget;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class GroupingListAdapter extends BaseAdapter {
    private static final long EXPANDED_GROUP_MASK = Long.MIN_VALUE;
    private static final int GROUP_METADATA_ARRAY_INCREMENT = 128;
    private static final int GROUP_METADATA_ARRAY_INITIAL_SIZE = 16;
    private static final long GROUP_OFFSET_MASK = 4294967295L;
    private static final long GROUP_SIZE_MASK = 9223372032559808512L;
    public static final int ITEM_TYPE_GROUP_HEADER = 1;
    public static final int ITEM_TYPE_IN_GROUP = 2;
    public static final int ITEM_TYPE_STANDALONE = 0;
    private Context mContext;
    private int mCount;
    private Cursor mCursor;
    private int mGroupCount;
    private long[] mGroupMetadata;
    private int mLastCachedCursorPosition;
    private int mLastCachedGroup;
    private int mLastCachedListPosition;
    private int mRowIdColumnIndex;
    private SparseIntArray mPositionCache = new SparseIntArray();
    private c mPositionMetadata = new c();
    protected ContentObserver mChangeObserver = new a(new Handler());
    protected DataSetObserver mDataSetObserver = new b();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends ContentObserver {
        a(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return true;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2) {
            GroupingListAdapter.this.onContentChanged();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends DataSetObserver {
        b() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            GroupingListAdapter.this.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            GroupingListAdapter.this.notifyDataSetInvalidated();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    protected static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f385a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        boolean f386b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f387c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f388d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f389e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private int f390f = -1;

        protected c() {
        }
    }

    public GroupingListAdapter(Context context) {
        this.mContext = context;
        resetCache();
    }

    private void findGroups() {
        this.mGroupCount = 0;
        this.mGroupMetadata = new long[16];
        Cursor cursor = this.mCursor;
        if (cursor == null) {
            return;
        }
        addGroups(cursor);
    }

    private int idealByteArraySize(int i2) {
        for (int i3 = 4; i3 < 32; i3++) {
            int i4 = (1 << i3) - 12;
            if (i2 <= i4) {
                return i4;
            }
        }
        return i2;
    }

    private int idealLongArraySize(int i2) {
        return idealByteArraySize(i2 * 8) / 8;
    }

    private void resetCache() {
        this.mCount = -1;
        this.mLastCachedListPosition = -1;
        this.mLastCachedCursorPosition = -1;
        this.mLastCachedGroup = -1;
        this.mPositionMetadata.f390f = -1;
        this.mPositionCache.clear();
    }

    protected void addGroup(int i2, int i3, boolean z2) {
        int i4 = this.mGroupCount;
        long[] jArr = this.mGroupMetadata;
        if (i4 >= jArr.length) {
            long[] jArr2 = new long[idealLongArraySize(jArr.length + 128)];
            System.arraycopy(this.mGroupMetadata, 0, jArr2, 0, this.mGroupCount);
            this.mGroupMetadata = jArr2;
        }
        long j2 = ((long) i2) | (((long) i3) << 32);
        if (z2) {
            j2 |= EXPANDED_GROUP_MASK;
        }
        long[] jArr3 = this.mGroupMetadata;
        int i5 = this.mGroupCount;
        this.mGroupCount = i5 + 1;
        jArr3[i5] = j2;
    }

    protected abstract void addGroups(Cursor cursor);

    protected abstract void bindChildView(View view, Context context, Cursor cursor);

    protected abstract void bindGroupView(View view, Context context, Cursor cursor, int i2, boolean z2);

    protected abstract void bindStandAloneView(View view, Context context, Cursor cursor);

    public void changeCursor(Cursor cursor) {
        Cursor cursor2 = this.mCursor;
        if (cursor == cursor2) {
            return;
        }
        if (cursor2 != null) {
            cursor2.unregisterContentObserver(this.mChangeObserver);
            this.mCursor.unregisterDataSetObserver(this.mDataSetObserver);
            this.mCursor.close();
        }
        this.mCursor = cursor;
        resetCache();
        findGroups();
        if (cursor == null) {
            notifyDataSetInvalidated();
            return;
        }
        cursor.registerContentObserver(this.mChangeObserver);
        cursor.registerDataSetObserver(this.mDataSetObserver);
        this.mRowIdColumnIndex = cursor.getColumnIndexOrThrow("_id");
        notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.mCursor == null) {
            return 0;
        }
        int i2 = this.mCount;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        int i4 = 0;
        for (int i5 = 0; i5 < this.mGroupCount; i5++) {
            long j2 = this.mGroupMetadata[i5];
            int i6 = (int) (GROUP_OFFSET_MASK & j2);
            boolean z2 = (EXPANDED_GROUP_MASK & j2) != 0;
            int i7 = (int) ((j2 & GROUP_SIZE_MASK) >> 32);
            int i8 = i3 + (i6 - i4);
            i3 = z2 ? i8 + i7 + 1 : i8 + 1;
            i4 = i6 + i7;
        }
        int count = (i3 + this.mCursor.getCount()) - i4;
        this.mCount = count;
        return count;
    }

    public Cursor getCursor() {
        return this.mCursor;
    }

    public int getGroupSize(int i2) {
        obtainPositionMetadata(this.mPositionMetadata, i2);
        return this.mPositionMetadata.f388d;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i2) {
        if (this.mCursor == null) {
            return null;
        }
        obtainPositionMetadata(this.mPositionMetadata, i2);
        if (this.mCursor.moveToPosition(this.mPositionMetadata.f387c)) {
            return this.mCursor;
        }
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        if (getItem(i2) != null) {
            return this.mCursor.getLong(this.mRowIdColumnIndex);
        }
        return -1L;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int i2) {
        obtainPositionMetadata(this.mPositionMetadata, i2);
        return this.mPositionMetadata.f385a;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        obtainPositionMetadata(this.mPositionMetadata, i2);
        if (view == null) {
            int i3 = this.mPositionMetadata.f385a;
            if (i3 == 0) {
                view = newStandAloneView(this.mContext, viewGroup);
            } else if (i3 == 1) {
                view = newGroupView(this.mContext, viewGroup);
            } else if (i3 == 2) {
                view = newChildView(this.mContext, viewGroup);
            }
        }
        View view2 = view;
        this.mCursor.moveToPosition(this.mPositionMetadata.f387c);
        c cVar = this.mPositionMetadata;
        int i4 = cVar.f385a;
        if (i4 == 0) {
            bindStandAloneView(view2, this.mContext, this.mCursor);
            return view2;
        }
        if (i4 == 1) {
            bindGroupView(view2, this.mContext, this.mCursor, cVar.f388d, cVar.f386b);
            return view2;
        }
        if (i4 != 2) {
            return view2;
        }
        bindChildView(view2, this.mContext, this.mCursor);
        return view2;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 3;
    }

    public boolean isGroupHeader(int i2) {
        obtainPositionMetadata(this.mPositionMetadata, i2);
        return this.mPositionMetadata.f385a == 1;
    }

    protected abstract View newChildView(Context context, ViewGroup viewGroup);

    protected abstract View newGroupView(Context context, ViewGroup viewGroup);

    protected abstract View newStandAloneView(Context context, ViewGroup viewGroup);

    /* JADX WARN: Code duplicated, block: B:16:0x0046  */
    public void obtainPositionMetadata(c cVar, int i2) {
        int iValueAt;
        int iKeyAt;
        int i3;
        if (cVar.f390f == i2) {
            return;
        }
        int i4 = this.mLastCachedListPosition;
        if (i4 == -1) {
            iValueAt = 0;
            iKeyAt = 0;
            i3 = 0;
        } else if (i2 <= i4) {
            int iIndexOfKey = this.mPositionCache.indexOfKey(i2);
            if (iIndexOfKey < 0) {
                int i5 = ~iIndexOfKey;
                int i6 = i5 - 1;
                iIndexOfKey = i6 >= this.mPositionCache.size() ? i5 - 2 : i6;
            }
            if (iIndexOfKey >= 0) {
                iKeyAt = this.mPositionCache.keyAt(iIndexOfKey);
                iValueAt = this.mPositionCache.valueAt(iIndexOfKey);
                i3 = (int) (this.mGroupMetadata[iValueAt] & GROUP_OFFSET_MASK);
            } else {
                iValueAt = 0;
                iKeyAt = 0;
                i3 = 0;
            }
        } else {
            int i7 = this.mLastCachedGroup;
            i3 = this.mLastCachedCursorPosition;
            iKeyAt = i4;
            iValueAt = i7;
        }
        while (iValueAt < this.mGroupCount) {
            long j2 = this.mGroupMetadata[iValueAt];
            int i8 = (int) (j2 & GROUP_OFFSET_MASK);
            int i9 = iKeyAt + (i8 - i3);
            if (iValueAt > this.mLastCachedGroup) {
                this.mPositionCache.append(i9, iValueAt);
                this.mLastCachedListPosition = i9;
                this.mLastCachedCursorPosition = i8;
                this.mLastCachedGroup = iValueAt;
            }
            if (i2 < i9) {
                cVar.f385a = 0;
                cVar.f387c = i8 - (i9 - i2);
                return;
            }
            boolean z2 = (EXPANDED_GROUP_MASK & j2) != 0;
            int i10 = (int) ((j2 & GROUP_SIZE_MASK) >> 32);
            if (i2 == i9) {
                cVar.f385a = 1;
                cVar.f389e = iValueAt;
                cVar.f386b = z2;
                cVar.f388d = i10;
                cVar.f387c = i8;
                return;
            }
            if (!z2) {
                iKeyAt = i9 + 1;
            } else {
                if (i2 < i9 + i10 + 1) {
                    cVar.f385a = 2;
                    cVar.f387c = (i8 + (i2 - i9)) - 1;
                    return;
                }
                iKeyAt = i9 + i10 + 1;
            }
            i3 = i8 + i10;
            iValueAt++;
        }
        cVar.f385a = 0;
        cVar.f387c = i3 + (i2 - iKeyAt);
    }

    public void toggleGroup(int i2) {
        obtainPositionMetadata(this.mPositionMetadata, i2);
        c cVar = this.mPositionMetadata;
        if (cVar.f385a != 1) {
            throw new IllegalArgumentException("Not a group at position " + i2);
        }
        if (cVar.f386b) {
            long[] jArr = this.mGroupMetadata;
            int i3 = cVar.f389e;
            jArr[i3] = jArr[i3] & Long.MAX_VALUE;
        } else {
            long[] jArr2 = this.mGroupMetadata;
            int i4 = cVar.f389e;
            jArr2[i4] = jArr2[i4] | EXPANDED_GROUP_MASK;
        }
        resetCache();
        notifyDataSetChanged();
    }

    protected void onContentChanged() {
    }
}
