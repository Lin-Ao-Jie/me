package com.android.common.widget;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class CompositeCursorAdapter extends BaseAdapter {
    private static final int INITIAL_CAPACITY = 2;
    private boolean mCacheValid;
    private final Context mContext;
    private int mCount;
    private boolean mNotificationNeeded;
    private boolean mNotificationsEnabled;
    private ArrayList<a> mPartitions;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        boolean f378a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        boolean f379b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        Cursor f380c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f381d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        int f382e;

        public a(boolean z2, boolean z3) {
            this.f378a = z2;
            this.f379b = z3;
        }
    }

    public CompositeCursorAdapter(Context context) {
        this(context, 2);
    }

    public void addPartition(boolean z2, boolean z3) {
        addPartition(new a(z2, z3));
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean areAllItemsEnabled() {
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            a aVar = arrayList.get(i2);
            i2++;
            if (aVar.f379b) {
                return false;
            }
        }
        return true;
    }

    protected abstract void bindView(View view, int i2, Cursor cursor, int i3);

    public void changeCursor(int i2, Cursor cursor) {
        Cursor cursor2 = this.mPartitions.get(i2).f380c;
        if (cursor2 != cursor) {
            if (cursor2 != null && !cursor2.isClosed()) {
                cursor2.close();
            }
            this.mPartitions.get(i2).f380c = cursor;
            if (cursor != null && !cursor.isClosed()) {
                this.mPartitions.get(i2).f381d = cursor.getColumnIndex("_id");
            }
            invalidate();
            notifyDataSetChanged();
        }
    }

    public void clearPartitions() {
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            a aVar = arrayList.get(i2);
            i2++;
            aVar.f380c = null;
        }
        invalidate();
        notifyDataSetChanged();
    }

    public void close() {
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            a aVar = arrayList.get(i2);
            i2++;
            Cursor cursor = aVar.f380c;
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        this.mPartitions.clear();
        invalidate();
        notifyDataSetChanged();
    }

    protected void ensureCacheValid() {
        if (this.mCacheValid) {
            return;
        }
        this.mCount = 0;
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            a aVar = arrayList.get(i2);
            i2++;
            a aVar2 = aVar;
            Cursor cursor = aVar2.f380c;
            int count = (cursor == null || cursor.isClosed()) ? 0 : cursor.getCount();
            if (aVar2.f379b && (count != 0 || aVar2.f378a)) {
                count++;
            }
            aVar2.f382e = count;
            this.mCount += count;
        }
        this.mCacheValid = true;
    }

    public Context getContext() {
        return this.mContext;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ensureCacheValid();
        return this.mCount;
    }

    public Cursor getCursor(int i2) {
        return this.mPartitions.get(i2).f380c;
    }

    protected View getHeaderView(int i2, Cursor cursor, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = newHeaderView(this.mContext, i2, cursor, viewGroup);
        }
        bindHeaderView(view, i2, cursor);
        return view;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i2) {
        Cursor cursor;
        ensureCacheValid();
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i3 = 0;
        int i4 = 0;
        while (i4 < size) {
            a aVar = arrayList.get(i4);
            i4++;
            a aVar2 = aVar;
            int i5 = aVar2.f382e + i3;
            if (i2 >= i3 && i2 < i5) {
                int i6 = i2 - i3;
                if (aVar2.f379b) {
                    i6--;
                }
                if (i6 == -1 || (cursor = aVar2.f380c) == null || cursor.isClosed() || !cursor.moveToPosition(i6)) {
                    return null;
                }
                return cursor;
            }
            i3 = i5;
        }
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        Cursor cursor;
        ensureCacheValid();
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i3 = 0;
        int i4 = 0;
        while (i4 < size) {
            a aVar = arrayList.get(i4);
            i4++;
            a aVar2 = aVar;
            int i5 = aVar2.f382e + i3;
            if (i2 >= i3 && i2 < i5) {
                int i6 = i2 - i3;
                if (aVar2.f379b) {
                    i6--;
                }
                if (i6 == -1 || aVar2.f381d == -1 || (cursor = aVar2.f380c) == null || cursor.isClosed() || !cursor.moveToPosition(i6)) {
                    return 0L;
                }
                return cursor.getLong(aVar2.f381d);
            }
            i3 = i5;
        }
        return 0L;
    }

    protected int getItemViewType(int i2, int i3) {
        return 1;
    }

    public int getItemViewTypeCount() {
        return 1;
    }

    public int getOffsetInPartition(int i2) {
        ensureCacheValid();
        ArrayList<a> arrayList = this.mPartitions;
        int size = arrayList.size();
        int i3 = 0;
        int i4 = 0;
        while (i4 < size) {
            a aVar = arrayList.get(i4);
            i4++;
            a aVar2 = aVar;
            int i5 = aVar2.f382e + i3;
            if (i2 >= i3 && i2 < i5) {
                int i6 = i2 - i3;
                return aVar2.f379b ? i6 - 1 : i6;
            }
            i3 = i5;
        }
        return -1;
    }

    public a getPartition(int i2) {
        return this.mPartitions.get(i2);
    }

    public int getPartitionCount() {
        return this.mPartitions.size();
    }

    public int getPartitionForPosition(int i2) {
        ensureCacheValid();
        int size = this.mPartitions.size();
        int i3 = 0;
        int i4 = 0;
        while (i3 < size) {
            int i5 = this.mPartitions.get(i3).f382e + i4;
            if (i2 >= i4 && i2 < i5) {
                return i3;
            }
            i3++;
            i4 = i5;
        }
        return -1;
    }

    public int getPositionForPartition(int i2) {
        ensureCacheValid();
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            i3 += this.mPartitions.get(i4).f382e;
        }
        return i3;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        View view2;
        ensureCacheValid();
        int size = this.mPartitions.size();
        int i3 = 0;
        int i4 = 0;
        while (i4 < size) {
            int i5 = this.mPartitions.get(i4).f382e + i3;
            if (i2 >= i3 && i2 < i5) {
                int i6 = i2 - i3;
                if (this.mPartitions.get(i4).f379b) {
                    i6--;
                }
                int i7 = i6;
                if (i7 == -1) {
                    view2 = getHeaderView(i4, this.mPartitions.get(i4).f380c, view, viewGroup);
                } else {
                    if (!this.mPartitions.get(i4).f380c.moveToPosition(i7)) {
                        throw new IllegalStateException("Couldn't move cursor to position " + i7);
                    }
                    view2 = getView(i4, this.mPartitions.get(i4).f380c, i7, view, viewGroup);
                }
                if (view2 != null) {
                    return view2;
                }
                throw new NullPointerException("View should not be null, partition: " + i4 + " position: " + i7);
            }
            i4++;
            i3 = i5;
            view = view;
            viewGroup = viewGroup;
        }
        throw new ArrayIndexOutOfBoundsException(i2);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return getItemViewTypeCount() + 1;
    }

    public boolean hasHeader(int i2) {
        return this.mPartitions.get(i2).f379b;
    }

    protected void invalidate() {
        this.mCacheValid = false;
    }

    protected boolean isEnabled(int i2, int i3) {
        return true;
    }

    public boolean isPartitionEmpty(int i2) {
        Cursor cursor = this.mPartitions.get(i2).f380c;
        return cursor == null || cursor.isClosed() || cursor.getCount() == 0;
    }

    protected View newHeaderView(Context context, int i2, Cursor cursor, ViewGroup viewGroup) {
        return null;
    }

    protected abstract View newView(Context context, int i2, Cursor cursor, int i3, ViewGroup viewGroup);

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        if (!this.mNotificationsEnabled) {
            this.mNotificationNeeded = true;
        } else {
            this.mNotificationNeeded = false;
            super.notifyDataSetChanged();
        }
    }

    public void removePartition(int i2) {
        Cursor cursor = this.mPartitions.get(i2).f380c;
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        this.mPartitions.remove(i2);
        invalidate();
        notifyDataSetChanged();
    }

    public void setHasHeader(int i2, boolean z2) {
        this.mPartitions.get(i2).f379b = z2;
        invalidate();
    }

    public void setNotificationsEnabled(boolean z2) {
        this.mNotificationsEnabled = z2;
        if (z2 && this.mNotificationNeeded) {
            notifyDataSetChanged();
        }
    }

    public void setShowIfEmpty(int i2, boolean z2) {
        this.mPartitions.get(i2).f378a = z2;
        invalidate();
    }

    public CompositeCursorAdapter(Context context, int i2) {
        this.mCount = 0;
        this.mCacheValid = true;
        this.mNotificationsEnabled = true;
        this.mContext = context;
        this.mPartitions = new ArrayList<>();
    }

    public void addPartition(a aVar) {
        this.mPartitions.add(aVar);
        invalidate();
        notifyDataSetChanged();
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int i2) {
        ensureCacheValid();
        int size = this.mPartitions.size();
        int i3 = 0;
        int i4 = 0;
        while (i3 < size) {
            int i5 = this.mPartitions.get(i3).f382e + i4;
            if (i2 >= i4 && i2 < i5) {
                int i6 = i2 - i4;
                if (this.mPartitions.get(i3).f379b) {
                    i6--;
                }
                if (i6 == -1) {
                    return -1;
                }
                return getItemViewType(i3, i6);
            }
            i3++;
            i4 = i5;
        }
        throw new ArrayIndexOutOfBoundsException(i2);
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int i2) {
        ensureCacheValid();
        int size = this.mPartitions.size();
        int i3 = 0;
        int i4 = 0;
        while (i3 < size) {
            int i5 = this.mPartitions.get(i3).f382e + i4;
            if (i2 >= i4 && i2 < i5) {
                int i6 = i2 - i4;
                if (this.mPartitions.get(i3).f379b && i6 == 0) {
                    return false;
                }
                return isEnabled(i3, i6);
            }
            i3++;
            i4 = i5;
        }
        return false;
    }

    public void addPartition(int i2, a aVar) {
        this.mPartitions.add(i2, aVar);
        invalidate();
        notifyDataSetChanged();
    }

    protected View getView(int i2, Cursor cursor, int i3, View view, ViewGroup viewGroup) {
        int i4;
        Cursor cursor2;
        int i5;
        View viewNewView;
        if (view != null) {
            i5 = i2;
            viewNewView = view;
            i4 = i3;
            cursor2 = cursor;
        } else {
            i4 = i3;
            cursor2 = cursor;
            i5 = i2;
            viewNewView = newView(this.mContext, i5, cursor2, i4, viewGroup);
        }
        bindView(viewNewView, i5, cursor2, i4);
        return viewNewView;
    }

    protected void bindHeaderView(View view, int i2, Cursor cursor) {
    }
}
