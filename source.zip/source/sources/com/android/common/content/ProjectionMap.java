package com.android.common.content;

import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ProjectionMap extends HashMap<String, String> {
    private String[] mColumns;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private ProjectionMap f373a = new ProjectionMap();
    }

    public static a builder() {
        return new a();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void putColumn(String str, String str2) {
        super.put(str, str2);
    }

    public String[] getColumnNames() {
        return this.mColumns;
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public void putAll(Map<? extends String, ? extends String> map) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public String put(String str, String str2) {
        throw new UnsupportedOperationException();
    }
}
