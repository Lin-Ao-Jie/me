package com.android.common.content;

import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteTransactionListener;
import android.net.Uri;
import java.util.ArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class SQLiteContentProvider extends ContentProvider implements SQLiteTransactionListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private SQLiteOpenHelper f374a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private volatile boolean f375b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected SQLiteDatabase f376c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final ThreadLocal f377d = new ThreadLocal();

    private boolean a() {
        return this.f377d.get() != null && ((Boolean) this.f377d.get()).booleanValue();
    }

    @Override // android.content.ContentProvider
    public ContentProviderResult[] applyBatch(ArrayList arrayList) {
        SQLiteDatabase writableDatabase = this.f374a.getWritableDatabase();
        this.f376c = writableDatabase;
        writableDatabase.beginTransactionWithListener(this);
        try {
            this.f377d.set(Boolean.TRUE);
            int size = arrayList.size();
            ContentProviderResult[] contentProviderResultArr = new ContentProviderResult[size];
            int i2 = 0;
            int i3 = 0;
            for (int i4 = 0; i4 < size; i4++) {
                i2++;
                if (i2 > e()) {
                    throw new OperationApplicationException("Too many content provider operations between yield points. The maximum number of operations per yield point is 500", i3);
                }
                ContentProviderOperation contentProviderOperation = (ContentProviderOperation) arrayList.get(i4);
                if (i4 > 0 && contentProviderOperation.isYieldAllowed()) {
                    boolean z2 = this.f375b;
                    if (this.f376c.yieldIfContendedSafely(4000L)) {
                        this.f376c = this.f374a.getWritableDatabase();
                        this.f375b = z2;
                        i3++;
                    }
                    i2 = 0;
                }
                contentProviderResultArr[i4] = contentProviderOperation.apply(this, contentProviderResultArr, i4);
            }
            this.f376c.setTransactionSuccessful();
            this.f377d.set(Boolean.FALSE);
            this.f376c.endTransaction();
            i();
            return contentProviderResultArr;
        } catch (Throwable th) {
            this.f377d.set(Boolean.FALSE);
            this.f376c.endTransaction();
            i();
            throw th;
        }
    }

    @Override // android.content.ContentProvider
    public int bulkInsert(Uri uri, ContentValues[] contentValuesArr) {
        int length = contentValuesArr.length;
        SQLiteDatabase writableDatabase = this.f374a.getWritableDatabase();
        this.f376c = writableDatabase;
        writableDatabase.beginTransactionWithListener(this);
        for (ContentValues contentValues : contentValuesArr) {
            try {
                if (f(uri, contentValues) != null) {
                    this.f375b = true;
                }
                boolean z2 = this.f375b;
                SQLiteDatabase sQLiteDatabase = this.f376c;
                sQLiteDatabase.yieldIfContendedSafely();
                this.f376c = sQLiteDatabase;
                this.f375b = z2;
            } catch (Throwable th) {
                this.f376c.endTransaction();
                throw th;
            }
        }
        this.f376c.setTransactionSuccessful();
        this.f376c.endTransaction();
        i();
        return length;
    }

    protected abstract int c(Uri uri, String str, String[] strArr);

    protected abstract SQLiteOpenHelper d(Context context);

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        if (a()) {
            int iC = c(uri, str, strArr);
            if (iC > 0) {
                this.f375b = true;
            }
            return iC;
        }
        SQLiteDatabase writableDatabase = this.f374a.getWritableDatabase();
        this.f376c = writableDatabase;
        writableDatabase.beginTransactionWithListener(this);
        try {
            int iC2 = c(uri, str, strArr);
            if (iC2 > 0) {
                this.f375b = true;
            }
            this.f376c.setTransactionSuccessful();
            this.f376c.endTransaction();
            i();
            return iC2;
        } catch (Throwable th) {
            this.f376c.endTransaction();
            throw th;
        }
    }

    public int e() {
        return 500;
    }

    protected abstract Uri f(Uri uri, ContentValues contentValues);

    protected abstract void g();

    protected void i() {
        if (this.f375b) {
            this.f375b = false;
            g();
        }
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        if (a()) {
            Uri uriF = f(uri, contentValues);
            if (uriF != null) {
                this.f375b = true;
            }
            return uriF;
        }
        SQLiteDatabase writableDatabase = this.f374a.getWritableDatabase();
        this.f376c = writableDatabase;
        writableDatabase.beginTransactionWithListener(this);
        try {
            Uri uriF2 = f(uri, contentValues);
            if (uriF2 != null) {
                this.f375b = true;
            }
            this.f376c.setTransactionSuccessful();
            this.f376c.endTransaction();
            i();
            return uriF2;
        } catch (Throwable th) {
            this.f376c.endTransaction();
            throw th;
        }
    }

    protected abstract int j(Uri uri, ContentValues contentValues, String str, String[] strArr);

    @Override // android.database.sqlite.SQLiteTransactionListener
    public void onBegin() {
        h();
    }

    @Override // android.database.sqlite.SQLiteTransactionListener
    public void onCommit() {
        b();
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        this.f374a = d(getContext());
        return true;
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        if (a()) {
            int iJ = j(uri, contentValues, str, strArr);
            if (iJ > 0) {
                this.f375b = true;
            }
            return iJ;
        }
        SQLiteDatabase writableDatabase = this.f374a.getWritableDatabase();
        this.f376c = writableDatabase;
        writableDatabase.beginTransactionWithListener(this);
        try {
            int iJ2 = j(uri, contentValues, str, strArr);
            if (iJ2 > 0) {
                this.f375b = true;
            }
            this.f376c.setTransactionSuccessful();
            this.f376c.endTransaction();
            i();
            return iJ2;
        } catch (Throwable th) {
            this.f376c.endTransaction();
            throw th;
        }
    }

    protected void b() {
    }

    protected void h() {
    }

    @Override // android.database.sqlite.SQLiteTransactionListener
    public void onRollback() {
    }
}
