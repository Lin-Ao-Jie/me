package com.vivo.springkit;

import com.vivo.vmdri.R;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$styleable {
    public static final int NestedScrollLayout_disallowintercept_enable = 0;
    public static final int NestedScrollLayout_nested_scrolling_enable = 1;
    public static final int NestedScrollLayout_touch_enable = 2;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_disallow_intercept_enable = 0;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_load_more_enabled = 1;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_load_more_footer_index = 2;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_load_more_footer_max_offset = 3;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_nested_scrolling_enable = 4;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_refresh_enabled = 5;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_refresh_header_index = 6;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_refresh_header_max_offset = 7;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_swipe_target_index = 8;
    public static final int NestedScrollRefreshLoadMoreLayout_rl_touch_enable = 9;
    public static final int[] NestedScrollLayout = {R.attr.disallowintercept_enable, R.attr.nested_scrolling_enable, R.attr.touch_enable};
    public static final int[] NestedScrollRefreshLoadMoreLayout = {R.attr.rl_disallow_intercept_enable, R.attr.rl_load_more_enabled, R.attr.rl_load_more_footer_index, R.attr.rl_load_more_footer_max_offset, R.attr.rl_nested_scrolling_enable, R.attr.rl_refresh_enabled, R.attr.rl_refresh_header_index, R.attr.rl_refresh_header_max_offset, R.attr.rl_swipe_target_index, R.attr.rl_touch_enable};
}
