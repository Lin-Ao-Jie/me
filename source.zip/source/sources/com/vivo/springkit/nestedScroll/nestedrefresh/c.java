package com.vivo.springkit.nestedScroll.nestedrefresh;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface c {
    void a(int i2, boolean z2, boolean z3, boolean z4);

    void b();

    void c();

    void e();

    void f();
}
