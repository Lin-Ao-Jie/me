package com.vivo.springkit.nestedScroll.nestedrefresh;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import androidx.annotation.Nullable;
import androidx.core.view.NestedScrollingChildHelper;
import androidx.core.view.NestedScrollingParent;
import androidx.core.view.NestedScrollingParentHelper;
import com.vivo.springkit.R$styleable;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class NestedScrollRefreshLoadMoreLayout extends LinearLayout implements NestedScrollingParent {
    private boolean A;
    private int B;
    private boolean C;
    private boolean D;
    private boolean E;
    private List F;
    private boolean G;
    private boolean H;
    private int I;
    private long J;
    private long K;
    private float L;
    private float M;
    private float N;
    private float O;
    protected View P;
    protected View Q;
    protected View R;
    private float S;
    private float T;
    private boolean U;
    private boolean V;
    private boolean W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1216a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    private boolean f1217a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final NestedScrollingParentHelper f1218b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    private float f1219b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final NestedScrollingChildHelper f1220c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    private ValueAnimator f1221c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private r.b f1222d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    private boolean f1223d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f1224e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    private boolean f1225e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    protected int[] f1226f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    private boolean f1227f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected int[] f1228g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    private boolean f1229g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected float f1230h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    private boolean f1231h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected float f1232i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    private float f1233i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1234j;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    private float f1235j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1236k;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    private float f1237k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1238l;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    private float f1239l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1240m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    private float f1241m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f1242n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    private float f1243n0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f1244o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    private boolean f1245o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f1246p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    private float f1247p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1248q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    private int f1249q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f1250r;
    boolean r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private boolean f1251s;
    private float s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private final List f1252t;
    private float t0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private boolean f1253u;
    private boolean u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f1254v;
    private g v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f1255w;
    private f w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f1256x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f1257y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private float f1258z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends f {
        a() {
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void a(int i2, boolean z2, boolean z3, boolean z4) {
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                KeyEvent.Callback callback = NestedScrollRefreshLoadMoreLayout.this.R;
                if (callback instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) callback).a(i2, z2, z3, z4);
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void b() {
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if ((nestedScrollRefreshLoadMoreLayout.R instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) && h.h(nestedScrollRefreshLoadMoreLayout.I)) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.R).b();
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void c() {
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if ((nestedScrollRefreshLoadMoreLayout.R instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) && h.h(nestedScrollRefreshLoadMoreLayout.I)) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.R).c();
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.a
        public void d() {
            if (NestedScrollRefreshLoadMoreLayout.this.p() && h.c(NestedScrollRefreshLoadMoreLayout.this.I)) {
                KeyEvent.Callback callback = NestedScrollRefreshLoadMoreLayout.this.R;
                if (callback instanceof com.vivo.springkit.nestedScroll.nestedrefresh.a) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.a) callback).d();
                }
                NestedScrollRefreshLoadMoreLayout.this.getClass();
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void e() {
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if (nestedScrollRefreshLoadMoreLayout.R instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) {
                    if (nestedScrollRefreshLoadMoreLayout.f1231h0) {
                        NestedScrollRefreshLoadMoreLayout.this.setStatus(0);
                        NestedScrollRefreshLoadMoreLayout.this.f1231h0 = false;
                    }
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.R).e();
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void f() {
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if ((nestedScrollRefreshLoadMoreLayout.R instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) && h.f(nestedScrollRefreshLoadMoreLayout.I)) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.R).f();
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements ValueAnimator.AnimatorUpdateListener {
        b() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                float fFloatValue = 1.0f - ((Float) valueAnimator.getAnimatedValue()).floatValue();
                if (fFloatValue < 0.0f) {
                    fFloatValue = 0.0f;
                }
                float f2 = fFloatValue <= 1.0f ? fFloatValue : 1.0f;
                if (NestedScrollRefreshLoadMoreLayout.this.f1223d0) {
                    NestedScrollRefreshLoadMoreLayout.this.R.setAlpha(f2);
                }
                if (f2 < 0.2f) {
                    NestedScrollRefreshLoadMoreLayout.this.G();
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends AnimatorListenerAdapter {
        c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            if (NestedScrollRefreshLoadMoreLayout.this.p()) {
                if (NestedScrollRefreshLoadMoreLayout.this.x()) {
                    NestedScrollRefreshLoadMoreLayout.this.R.setTranslationY(0.0f);
                } else {
                    NestedScrollRefreshLoadMoreLayout.this.R.setTranslationX(0.0f);
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements View.OnScrollChangeListener {
        d() {
        }

        @Override // android.view.View.OnScrollChangeListener
        public void onScrollChange(View view, int i2, int i3, int i4, int i5) {
            NestedScrollRefreshLoadMoreLayout.e(NestedScrollRefreshLoadMoreLayout.this);
            if (NestedScrollRefreshLoadMoreLayout.this.F == null || NestedScrollRefreshLoadMoreLayout.this.F.size() <= 0) {
                return;
            }
            b.c.a(NestedScrollRefreshLoadMoreLayout.this.F.get(0));
            throw null;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends g {
        e() {
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void a(int i2, boolean z2, boolean z3, boolean z4) {
            if (NestedScrollRefreshLoadMoreLayout.this.t()) {
                KeyEvent.Callback callback = NestedScrollRefreshLoadMoreLayout.this.P;
                if (callback instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) callback).a(i2, z2, z3, z4);
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void b() {
            if (NestedScrollRefreshLoadMoreLayout.this.t()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if ((nestedScrollRefreshLoadMoreLayout.P instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) && h.h(nestedScrollRefreshLoadMoreLayout.I)) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.P).b();
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void c() {
            if (NestedScrollRefreshLoadMoreLayout.this.t()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if ((nestedScrollRefreshLoadMoreLayout.P instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) && h.h(nestedScrollRefreshLoadMoreLayout.I)) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.P).c();
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.b
        public void d() {
            if (NestedScrollRefreshLoadMoreLayout.this.t() && h.e(NestedScrollRefreshLoadMoreLayout.this.I)) {
                KeyEvent.Callback callback = NestedScrollRefreshLoadMoreLayout.this.P;
                if (callback instanceof com.vivo.springkit.nestedScroll.nestedrefresh.b) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.b) callback).d();
                }
                NestedScrollRefreshLoadMoreLayout.this.getClass();
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void e() {
            if (NestedScrollRefreshLoadMoreLayout.this.t()) {
                KeyEvent.Callback callback = NestedScrollRefreshLoadMoreLayout.this.P;
                if (callback instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) callback).e();
                }
            }
        }

        @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
        public void f() {
            if (NestedScrollRefreshLoadMoreLayout.this.t()) {
                NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout = NestedScrollRefreshLoadMoreLayout.this;
                if ((nestedScrollRefreshLoadMoreLayout.P instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) && h.g(nestedScrollRefreshLoadMoreLayout.I)) {
                    ((com.vivo.springkit.nestedScroll.nestedrefresh.c) NestedScrollRefreshLoadMoreLayout.this.P).f();
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static abstract class f implements com.vivo.springkit.nestedScroll.nestedrefresh.c, com.vivo.springkit.nestedScroll.nestedrefresh.a {
        f() {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static abstract class g implements com.vivo.springkit.nestedScroll.nestedrefresh.c, com.vivo.springkit.nestedScroll.nestedrefresh.b {
        g() {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static final class h {
        public static String a(int i2) {
            switch (i2) {
                case -4:
                    return "status_refresh_returning";
                case -3:
                    return "status_refreshing";
                case -2:
                    return "status_release_to_refresh";
                case -1:
                    return "status_swiping_to_refresh";
                case 0:
                    return "status_default";
                case 1:
                    return "status_swiping_to_load_more";
                case 2:
                    return "status_release_to_load_more";
                case 3:
                    return "status_loading_more";
                case 4:
                    return "status_load_more_returning";
                default:
                    return "status_illegal!";
            }
        }

        public static boolean b(int i2) {
            return i2 > 0;
        }

        public static boolean c(int i2) {
            return i2 == 3;
        }

        public static boolean d(int i2) {
            return i2 < 0;
        }

        public static boolean e(int i2) {
            return i2 == -3;
        }

        public static boolean f(int i2) {
            return i2 == 2;
        }

        public static boolean g(int i2) {
            return i2 == -2;
        }

        public static boolean h(int i2) {
            return i2 == 0;
        }
    }

    public NestedScrollRefreshLoadMoreLayout(Context context) {
        this(context, null);
    }

    private void A(int i2, int i3, int[] iArr) {
        if (x()) {
            if (i3 > 0) {
                float f2 = this.f1230h;
                if (f2 > 0.0f) {
                    float f3 = i3;
                    if (f3 > f2) {
                        iArr[1] = (int) (iArr[1] + f2);
                        if (t()) {
                            R(0.0f);
                            setStatus(0);
                            this.v0.c();
                        }
                        O(0.0f);
                        if (this.f1220c.dispatchNestedPreScroll(i2, (int) (f3 - this.f1230h), this.f1228g, this.f1226f)) {
                            int i4 = iArr[0];
                            int[] iArr2 = this.f1228g;
                            iArr[0] = i4 + iArr2[0];
                            iArr[1] = iArr[1] + iArr2[1];
                            return;
                        }
                        return;
                    }
                    iArr[1] = iArr[1] + i3;
                    if (t()) {
                        float f4 = -i3;
                        R(this.f1230h + f4);
                        float f5 = this.f1230h;
                        if (f4 + f5 > this.N) {
                            setStatus(-2);
                        } else if (f4 + f5 > 0.0f) {
                            setStatus(-1);
                        } else {
                            setStatus(0);
                            this.v0.c();
                        }
                    }
                    O((-i3) + this.f1230h);
                    if (this.f1220c.dispatchNestedPreScroll(i2, 0, this.f1228g, this.f1226f)) {
                        iArr[0] = iArr[0] + this.f1228g[0];
                        return;
                    }
                    return;
                }
            }
            if (i3 < 0) {
                float f6 = this.f1230h;
                if (f6 < 0.0f) {
                    float f7 = i3;
                    if (f7 < f6) {
                        iArr[1] = (int) (iArr[1] + f6);
                        if (p()) {
                            P(0.0f);
                            setStatus(0);
                            if (this.V) {
                                this.w0.c();
                            }
                        }
                        O(0.0f);
                        if (this.f1220c.dispatchNestedPreScroll(i2, (int) (f7 - this.f1230h), this.f1228g, this.f1226f)) {
                            int i5 = iArr[0];
                            int[] iArr3 = this.f1228g;
                            iArr[0] = i5 + iArr3[0];
                            iArr[1] = iArr[1] + iArr3[1];
                            return;
                        }
                        return;
                    }
                    iArr[1] = iArr[1] + i3;
                    if (p()) {
                        float f8 = -i3;
                        P(this.f1230h + f8);
                        if (this.f1217a0 && s()) {
                            t.a.a("NestedScrollRefreshLoadMoreLayout", "onPreScroll mStatus:" + this.I + ", AutoLoadMore not change status");
                        } else {
                            float f9 = this.f1230h;
                            if (f8 + f9 < this.O) {
                                setStatus(2);
                            } else if (f8 + f9 < 0.0f) {
                                setStatus(1);
                            } else {
                                setStatus(0);
                                if (this.V) {
                                    this.w0.c();
                                }
                            }
                        }
                    }
                    O((-i3) + this.f1230h);
                    if (this.f1220c.dispatchNestedPreScroll(i2, 0, this.f1228g, this.f1226f)) {
                        iArr[0] = iArr[0] + this.f1228g[0];
                        return;
                    }
                    return;
                }
            }
            if (this.f1224e && this.E && i3 > 0 && this.f1220c.dispatchNestedPreScroll(i2, i3, this.f1228g, this.f1226f)) {
                int i6 = iArr[0];
                int[] iArr4 = this.f1228g;
                iArr[0] = i6 + iArr4[0];
                iArr[1] = iArr[1] + iArr4[1];
                return;
            }
            return;
        }
        if (i2 > 0) {
            float f10 = this.f1230h;
            if (f10 > 0.0f) {
                float f11 = i2;
                if (f11 > f10) {
                    iArr[0] = (int) (iArr[0] + f10);
                    if (t()) {
                        R(0.0f);
                        setStatus(0);
                        this.v0.c();
                    }
                    O(0.0f);
                    if (this.f1220c.dispatchNestedPreScroll((int) (f11 - this.f1230h), i3, this.f1228g, this.f1226f)) {
                        int i7 = iArr[0];
                        int[] iArr5 = this.f1228g;
                        iArr[0] = i7 + iArr5[0];
                        iArr[1] = iArr[1] + iArr5[1];
                        return;
                    }
                    return;
                }
                iArr[0] = iArr[0] + i2;
                if (t()) {
                    float f12 = -i2;
                    R(this.f1230h + f12);
                    float f13 = this.f1230h;
                    if (f12 + f13 > this.N) {
                        setStatus(-2);
                    } else if (f12 + f13 > 0.0f) {
                        setStatus(-1);
                    } else {
                        setStatus(0);
                        this.v0.c();
                    }
                }
                O((-i2) + this.f1230h);
                if (this.f1220c.dispatchNestedPreScroll(0, i3, this.f1228g, this.f1226f)) {
                    iArr[1] = iArr[1] + this.f1228g[1];
                    return;
                }
                return;
            }
        }
        if (i2 < 0) {
            float f14 = this.f1230h;
            if (f14 < 0.0f) {
                float f15 = i2;
                if (f15 < f14) {
                    iArr[0] = (int) (iArr[0] + f14);
                    if (p()) {
                        P(0.0f);
                        setStatus(0);
                        if (this.V) {
                            this.w0.c();
                        }
                    }
                    O(0.0f);
                    if (this.f1220c.dispatchNestedPreScroll((int) (f15 - this.f1230h), i3, iArr, (int[]) null)) {
                        int i8 = iArr[0];
                        int[] iArr6 = this.f1228g;
                        iArr[0] = i8 + iArr6[0];
                        iArr[1] = iArr[1] + iArr6[1];
                        return;
                    }
                    return;
                }
                iArr[0] = iArr[0] + i2;
                if (p()) {
                    float f16 = -i2;
                    P(this.f1230h + f16);
                    if (this.f1217a0 && s()) {
                        t.a.a("NestedScrollRefreshLoadMoreLayout", "onPreScroll mStatus:" + this.I + ", AutoLoadMore not change status");
                    } else {
                        float f17 = this.f1230h;
                        if (f16 + f17 < this.O) {
                            setStatus(2);
                        } else if (f16 + f17 < 0.0f) {
                            setStatus(1);
                        } else {
                            setStatus(0);
                            if (this.V) {
                                this.w0.c();
                            }
                        }
                    }
                }
                O((-i2) + this.f1230h);
                if (this.f1220c.dispatchNestedPreScroll(0, i3, iArr, (int[]) null)) {
                    iArr[1] = iArr[1] + this.f1228g[1];
                    return;
                }
                return;
            }
        }
        if (this.f1224e && this.E && i2 > 0 && this.f1220c.dispatchNestedPreScroll(i2, i3, iArr, (int[]) null)) {
            int i9 = iArr[0];
            int[] iArr7 = this.f1228g;
            iArr[0] = i9 + iArr7[0];
            iArr[1] = iArr[1] + iArr7[1];
        }
    }

    private void B(float f2) {
        if (f2 == 0.0f) {
            return;
        }
        if (this.f1229g0 && t() && f2 < 0.0f && w()) {
            t.a.a("NestedScrollRefreshLoadMoreLayout", "onScroll: return");
            return;
        }
        float fH = this.f1230h + (h(f2) * this.f1233i0);
        if (h.h(this.I)) {
            if (t() && fH > 0.0f) {
                t.a.a("NestedScrollRefreshLoadMoreLayout", "distance > 0 onScroll mStatus:" + this.I + ", case of isStatusDefault will call mRefreshCallback.onPrepare()");
                this.v0.b();
                setStatus(-1);
            } else if (p() && fH < 0.0f) {
                t.a.a("NestedScrollRefreshLoadMoreLayout", "distance < 0 onScroll mStatus:" + this.I + ", case of isStatusDefault will call mLoadMoreCallback.onPrepare()");
                if (this.V) {
                    this.w0.b();
                }
                setStatus(1);
            }
        }
        if (t() && h.d(this.I)) {
            if (!h.g(this.I)) {
                if (fH >= this.N) {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onScroll mStatus:" + this.I + "--> STATUS.STATUS_RELEASE_TO_REFRESH");
                    setStatus(-2);
                } else {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onScroll mStatus:" + this.I + "--> STATUS.STATUS_SWIPING_TO_REFRESH");
                    setStatus(-1);
                }
            }
            R(fH);
        } else if (p() && h.b(this.I)) {
            if (!h.f(this.I)) {
                if (this.f1217a0 && s()) {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onScroll mStatus:" + this.I + ", AutoLoadMore not change status");
                } else if (fH <= this.O) {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onScroll mStatus:" + this.I + "--> STATUS.STATUS_RELEASE_TO_LOAD_MORE");
                    setStatus(2);
                } else {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onScroll mStatus:" + this.I + "--> STATUS.STATUS_SWIPING_TO_LOAD_MORE");
                    setStatus(1);
                }
            }
            P(fH);
        }
        k(fH);
        O(fH);
    }

    private void C(float f2) {
        int i2 = this.f1216a;
        if (i2 == 0 || i2 == 2) {
            S(f2);
        } else if (i2 == 1 || i2 == 3) {
            Q(f2);
        }
        O(f2);
    }

    private void E(int i2, int i3) {
        this.f1248q = true;
        this.f1216a = i3;
        j(i3, i2);
    }

    private void F(boolean z2) {
        for (ViewParent viewParent : this.f1252t) {
            if (viewParent != null) {
                viewParent.requestDisallowInterceptTouchEvent(z2);
            }
        }
    }

    private boolean L(float f2, float f3) {
        t.a.a("NestedScrollRefreshLoadMoreLayout", "onNestedPreFling, velocityX = " + f2 + ", velocityY = " + f3 + ", moveDistance = " + this.f1230h);
        if (this.f1230h == 0.0f) {
            if (x()) {
                if (!this.f1253u && f3 < 0.0f) {
                    return false;
                }
                if (!this.f1254v && f3 > 0.0f) {
                    return false;
                }
            } else {
                if (!this.f1256x && f2 < 0.0f) {
                    return false;
                }
                if (!this.f1255w && f2 > 0.0f) {
                    return false;
                }
            }
        }
        if (this.f1229g0 && t() && f3 < 0.0f && w()) {
            return true;
        }
        if (this.f1248q) {
            t.a.a("NestedScrollRefreshLoadMoreLayout", "PreFling forbidden, Is over scrolling!");
            return true;
        }
        if (x()) {
            if ((f3 > 0.0f && this.f1230h > 0.0f) || (f3 < 0.0f && this.f1230h < 0.0f)) {
                if (this.u0) {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "PreFling forbidden!");
                    return true;
                }
                a();
            }
        } else if ((f2 > 0.0f && this.f1230h > 0.0f) || (f2 < 0.0f && this.f1230h < 0.0f)) {
            if (this.u0) {
                t.a.a("NestedScrollRefreshLoadMoreLayout", "PreFling forbidden!");
                return true;
            }
            a();
        }
        z(f2, f3);
        return false;
    }

    private void M(float f2) {
        if (f2 == 0.0f) {
            if (this.R.getAlpha() != 0.0f) {
                this.R.setAlpha(0.0f);
            }
            t.a.a("NestedScrollRefreshLoadMoreLayout", "footer alpha: 0");
            return;
        }
        if (f2 < 0.0f) {
            float f3 = this.O;
            if (f2 < f3) {
                if (this.R.getAlpha() != 1.0f) {
                    this.R.setAlpha(1.0f);
                    return;
                }
                return;
            }
            float f4 = f2 / f3;
            float f5 = f4 >= 0.0f ? f4 : 0.0f;
            float f6 = f5 <= 1.0f ? f5 : 1.0f;
            this.R.setAlpha(f6);
            t.a.a("NestedScrollRefreshLoadMoreLayout", "footer alpha: " + f6);
        }
    }

    private void N(float f2) {
        if (f2 == 0.0f) {
            if (this.P.getAlpha() != 0.0f) {
                this.P.setAlpha(0.0f);
            }
            t.a.a("NestedScrollRefreshLoadMoreLayout", "header alpha: 0");
            return;
        }
        if (f2 > 0.0f) {
            float f3 = this.N;
            if (f2 > f3) {
                if (this.P.getAlpha() != 1.0f) {
                    this.P.setAlpha(1.0f);
                    return;
                }
                return;
            }
            float f4 = f2 / f3;
            float f5 = f4 >= 0.0f ? f4 : 0.0f;
            float f6 = f5 <= 1.0f ? f5 : 1.0f;
            this.P.setAlpha(f6);
            t.a.a("NestedScrollRefreshLoadMoreLayout", "header alpha: " + f6);
        }
    }

    private void O(float f2) {
        if (!(this.f1255w && this.f1253u) && f2 > 0.0f) {
            return;
        }
        if (!(this.f1256x && this.f1254v) && f2 < 0.0f) {
            return;
        }
        if (x()) {
            if (Math.abs(f2) > Math.max(this.f1234j, this.f1236k)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1238l, this.f1240m)) {
            return;
        }
        t.a.a("NestedScrollRefreshLoadMoreLayout", "transContent:" + f2);
        this.f1232i = this.f1230h;
        this.f1230h = f2;
        if (this.Q != null) {
            if (x()) {
                this.Q.setTranslationY(this.f1230h);
            } else {
                this.Q.setTranslationX(this.f1230h);
            }
            List list = this.F;
            if (list == null || list.size() <= 0) {
                return;
            }
            b.c.a(this.F.get(0));
            throw null;
        }
    }

    private void P(float f2) {
        if (!p() || f2 > 0.0f) {
            return;
        }
        if (x()) {
            if (Math.abs(f2) > Math.max(this.f1234j, this.f1236k)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1238l, this.f1240m)) {
            return;
        }
        if (this.f1223d0) {
            M(f2);
        }
        if (f2 <= this.O) {
            float fI = i(f2);
            if (x()) {
                this.R.setTranslationY(fI);
            } else {
                this.R.setTranslationX(fI);
            }
            if (this.V) {
                if (!this.f1217a0 || s() || o()) {
                    this.w0.a((int) fI, true, false, !this.D);
                    return;
                }
                t.a.a("NestedScrollRefreshLoadMoreLayout", "transFooter onAutoLoadMore MaxOffset");
                setStatus(3);
                this.w0.d();
                return;
            }
            return;
        }
        if (x()) {
            this.R.setTranslationY(f2);
        } else {
            this.R.setTranslationX(f2);
        }
        if (this.V) {
            if (!this.f1217a0 || s() || o()) {
                this.w0.a((int) f2, false, false, !this.D);
                return;
            }
            t.a.a("NestedScrollRefreshLoadMoreLayout", "transFooter onAutoLoadMore distances = " + f2);
            setStatus(3);
            this.w0.d();
        }
    }

    private void Q(float f2) {
        if (!p() || f2 > 0.0f) {
            return;
        }
        if (x()) {
            if (Math.abs(f2) > Math.max(this.f1234j, this.f1236k)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1238l, this.f1240m)) {
            return;
        }
        if (this.f1223d0) {
            M(f2);
        }
        if (f2 > this.O) {
            if (x()) {
                this.R.setTranslationY(f2);
            } else {
                this.R.setTranslationX(f2);
            }
            if (this.V) {
                t.a.a("NestedScrollRefreshLoadMoreLayout", "transFooterByFling(): onMove distance = " + f2);
                this.w0.a((int) f2, false, true, this.D ^ true);
                return;
            }
            return;
        }
        if (h.h(this.I)) {
            float fI = i(f2);
            if (x()) {
                this.R.setTranslationY(fI);
            } else {
                this.R.setTranslationX(fI);
            }
            setStatus(3);
            if (this.V) {
                t.a.a("NestedScrollRefreshLoadMoreLayout", "transFooterByFling(): onLoadMore");
                this.w0.a((int) fI, true, true, !this.D);
                this.w0.d();
            }
        }
    }

    private void R(float f2) {
        if (!t() || f2 < 0.0f) {
            return;
        }
        if (x()) {
            if (Math.abs(f2) > Math.max(this.f1234j, this.f1236k)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1238l, this.f1240m)) {
            return;
        }
        if (this.f1225e0) {
            N(f2);
        }
        if (f2 < this.N) {
            boolean z2 = this.D;
            this.v0.a((int) f2, false, z2, !z2);
        } else {
            f2 = i(f2);
            boolean z3 = this.D;
            this.v0.a((int) f2, true, z3, !z3);
        }
        if (x()) {
            this.P.setTranslationY(f2);
        } else {
            this.P.setTranslationX(f2);
        }
    }

    private void S(float f2) {
        if (!t() || f2 < 0.0f) {
            return;
        }
        if (x()) {
            if (Math.abs(f2) > Math.max(this.f1234j, this.f1236k)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1238l, this.f1240m)) {
            return;
        }
        if (this.f1225e0) {
            N(f2);
        }
        if (f2 < this.N) {
            this.v0.a((int) f2, false, true, !this.D);
        } else {
            f2 = i(f2);
            this.v0.a((int) f2, true, true, !this.D);
        }
        if (x()) {
            this.P.setTranslationY(f2);
        } else {
            this.P.setTranslationX(f2);
        }
    }

    static /* synthetic */ o.c e(NestedScrollRefreshLoadMoreLayout nestedScrollRefreshLoadMoreLayout) {
        nestedScrollRefreshLoadMoreLayout.getClass();
        return null;
    }

    private float h(float f2) {
        int i2;
        if (x()) {
            i2 = f2 > 0.0f ? this.f1236k : this.f1234j;
        } else {
            i2 = f2 > 0.0f ? this.f1238l : this.f1240m;
        }
        float f3 = i2;
        if (f3 == 0.0f) {
            return f2;
        }
        float fAbs = Math.abs(this.f1230h) / f3;
        return (int) (f2 / ((this.f1237k0 * ((float) Math.pow(fAbs, this.f1239l0))) + (this.f1241m0 * ((float) Math.pow(1.0f + fAbs, this.f1243n0)))));
    }

    private float i(float f2) {
        float f3;
        float f4;
        if (f2 == 0.0f) {
            return f2;
        }
        if (f2 > 0.0f) {
            f3 = f2 + this.N;
            f4 = this.f1219b0;
        } else {
            f3 = f2 + this.O;
            f4 = this.f1219b0;
        }
        return f3 / f4;
    }

    private void j(int i2, float f2) {
        if (x()) {
            int iO = (int) (this.f1222d.o() * this.f1235j0);
            t.a.a("NestedScrollRefreshLoadMoreLayout", "overScroll offset= " + f2 + " velocity= " + iO + ", orientation= " + i2);
            if (i2 == 0) {
                this.v0.b();
                this.f1222d.F(0, 0, -iO);
            } else if (i2 == 1) {
                if (p()) {
                    if (this.V) {
                        this.w0.b();
                    }
                    this.f1222d.F(0, (int) this.O, -iO);
                } else {
                    this.f1222d.F(0, 0, -iO);
                }
            }
        } else {
            int iN = (int) (this.f1222d.n() * this.f1235j0);
            t.a.a("NestedScrollRefreshLoadMoreLayout", "overScroll offset= " + f2 + " velocity= " + iN + ", orientation= " + i2);
            if (i2 == 2) {
                this.v0.b();
                this.f1222d.E(0, 0, -iN);
            } else if (i2 == 3) {
                if (p()) {
                    if (this.V) {
                        this.w0.b();
                    }
                    this.f1222d.E(0, (int) this.O, -iN);
                } else {
                    this.f1222d.E(0, 0, -iN);
                }
            }
        }
        postInvalidateOnAnimation();
    }

    private boolean l(int i2, int i3) {
        if (getChildCount() > 0) {
            int scrollY = getScrollY();
            View childAt = getChildAt(0);
            if (i3 >= childAt.getTop() - scrollY && i3 < childAt.getBottom() - scrollY && i2 >= childAt.getLeft() && i2 < childAt.getRight()) {
                return true;
            }
        }
        return false;
    }

    private void m() {
        if (this.f1222d != null) {
            return;
        }
        r.b bVar = new r.b(getContext());
        this.f1222d = bVar;
        bVar.B(false);
    }

    private void n() {
        int childCount = getChildCount();
        if (childCount <= 0) {
            throw new RuntimeException("NestedScrollRefreshLoadMoreLayout至少包含1个子view!");
        }
        if (childCount > 3) {
            throw new RuntimeException("NestedScrollRefreshLoadMoreLayout最多支持3个子View!");
        }
        if (childCount == 1) {
            this.Q = getChildAt(0);
        } else if (childCount == 2) {
            View childAt = getChildAt(0);
            if (childAt instanceof com.vivo.springkit.nestedScroll.nestedrefresh.b) {
                this.P = childAt;
                this.Q = getChildAt(1);
            } else {
                this.Q = childAt;
                View childAt2 = getChildAt(1);
                this.R = childAt2;
                if (!(childAt2 instanceof com.vivo.springkit.nestedScroll.nestedrefresh.a)) {
                    this.R = null;
                }
            }
        } else {
            this.P = getChildAt(0);
            this.Q = getChildAt(1);
            View childAt3 = getChildAt(2);
            this.R = childAt3;
            if (!(this.P instanceof com.vivo.springkit.nestedScroll.nestedrefresh.b)) {
                this.P = null;
            }
            if (!(childAt3 instanceof com.vivo.springkit.nestedScroll.nestedrefresh.a)) {
                this.R = null;
            }
        }
        View view = this.Q;
        if (view == null || (view instanceof com.vivo.springkit.nestedScroll.nestedrefresh.c) || (view instanceof com.vivo.springkit.nestedScroll.nestedrefresh.b) || (view instanceof com.vivo.springkit.nestedScroll.nestedrefresh.a)) {
            throw new RuntimeException("NestedScrollRefreshLoadMoreLayout必须包含一个可滑动view");
        }
        View view2 = this.P;
        if (view2 == null || !(view2 instanceof com.vivo.springkit.nestedScroll.nestedrefresh.b)) {
            t.a.a("NestedScrollRefreshLoadMoreLayout", "refresh header is null, refresh disabled!");
        }
        View view3 = this.R;
        if (view3 == null || !(view3 instanceof com.vivo.springkit.nestedScroll.nestedrefresh.a)) {
            t.a.a("NestedScrollRefreshLoadMoreLayout", "load more header is null, load more disabled!");
        }
        View view4 = this.Q;
        if (view4 != null) {
            view4.setOnScrollChangeListener(new d());
        }
    }

    private boolean q() {
        if (x()) {
            return p() && this.R.getY() == this.T;
        }
        return p() && this.R.getX() == this.T;
    }

    private boolean r() {
        if (x()) {
            return p() && (this.R.getY() != this.T || this.D);
        }
        return p() && (this.R.getX() != this.T || this.D);
    }

    private boolean u() {
        if (x()) {
            return t() && this.P.getY() == this.S;
        }
        return t() && this.P.getX() == this.S;
    }

    private boolean v() {
        if (x()) {
            return t() && (this.P.getY() != this.S || this.D);
        }
        return t() && (this.P.getX() != this.S || this.D);
    }

    private void y() {
        int i2;
        int i3;
        int i4;
        int i5;
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        View view = this.P;
        if (view != null) {
            if (x()) {
                this.L = view.getMeasuredHeight();
            } else {
                this.L = view.getMeasuredWidth();
            }
            t.a.a("NestedScrollRefreshLoadMoreLayout", "mRefreshHeaderLength: " + this.L);
            float f2 = this.N;
            float f3 = this.L;
            if (f2 < f3) {
                this.N = f3;
            }
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            if (x()) {
                i4 = marginLayoutParams.leftMargin + paddingLeft;
                i5 = (int) ((marginLayoutParams.topMargin + paddingTop) - this.L);
            } else {
                i4 = (int) ((marginLayoutParams.leftMargin + paddingLeft) - this.L);
                i5 = marginLayoutParams.topMargin + paddingTop;
            }
            int measuredWidth2 = view.getMeasuredWidth() + i4;
            int measuredHeight2 = view.getMeasuredHeight() + i5;
            this.S = x() ? i5 : i4;
            view.layout(i4, i5, measuredWidth2, measuredHeight2);
        }
        View view2 = this.Q;
        if (view2 != null) {
            if (x()) {
                this.f1242n = view2.getMeasuredHeight();
            } else {
                this.f1242n = view2.getMeasuredWidth();
            }
            t.a.a("NestedScrollRefreshLoadMoreLayout", "mContentViewLength: " + this.f1242n);
            ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
            int i6 = paddingLeft + marginLayoutParams2.leftMargin;
            int i7 = paddingTop + marginLayoutParams2.topMargin;
            view2.layout(i6, i7, view2.getMeasuredWidth() + i6, view2.getMeasuredHeight() + i7);
            this.Q.bringToFront();
        }
        View view3 = this.R;
        if (view3 != null) {
            if (x()) {
                this.M = view3.getMeasuredHeight();
            } else {
                this.M = view3.getMeasuredWidth();
            }
            t.a.a("NestedScrollRefreshLoadMoreLayout", "mLoadMoreFooterLength: " + this.M);
            float f4 = this.O;
            float f5 = this.M;
            if (f4 > (-f5)) {
                this.O = -f5;
            }
            ViewGroup.MarginLayoutParams marginLayoutParams3 = (ViewGroup.MarginLayoutParams) view3.getLayoutParams();
            if (x()) {
                i2 = (int) (((measuredHeight - paddingBottom) - marginLayoutParams3.bottomMargin) + this.M);
                i3 = (measuredWidth - paddingRight) - marginLayoutParams3.rightMargin;
            } else {
                i2 = (measuredHeight - paddingBottom) - marginLayoutParams3.bottomMargin;
                i3 = (int) (((measuredWidth - paddingRight) - marginLayoutParams3.rightMargin) + this.M);
            }
            int measuredWidth3 = i3 - view3.getMeasuredWidth();
            int measuredHeight3 = i2 - view3.getMeasuredHeight();
            this.T = x() ? measuredHeight3 : measuredWidth3;
            view3.layout(measuredWidth3, measuredHeight3, i3, i2);
        }
    }

    private void z(float f2, float f3) {
        if (x()) {
            this.f1246p = 0;
            this.f1222d.j(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        } else {
            this.f1244o = 0;
            this.f1222d.j(0, 0, (int) f2, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
        }
        invalidate();
    }

    protected void D() {
        a();
        this.C = false;
    }

    protected void G() {
        if (x()) {
            this.Q.scrollBy(0, (int) (-this.f1230h));
            this.Q.setTranslationY(0.0f);
        } else {
            this.Q.scrollBy((int) (-this.f1230h), 0);
            this.Q.setTranslationX(0.0f);
        }
        this.f1232i = this.f1230h;
        this.f1230h = 0.0f;
        List list = this.F;
        if (list == null || list.size() <= 0) {
            return;
        }
        b.c.a(this.F.get(0));
        throw null;
    }

    public NestedScrollRefreshLoadMoreLayout H(boolean z2) {
        this.f1251s = z2;
        return this;
    }

    public NestedScrollRefreshLoadMoreLayout I(boolean z2) {
        this.H = z2;
        if (z2) {
            this.U = false;
        }
        return this;
    }

    public NestedScrollRefreshLoadMoreLayout J(boolean z2) {
        this.G = z2;
        return this;
    }

    public NestedScrollRefreshLoadMoreLayout K(boolean z2) {
        this.f1250r = z2;
        return this;
    }

    protected void a() {
        r.b bVar = this.f1222d;
        if (bVar == null || bVar.w()) {
            return;
        }
        this.f1222d.a();
    }

    @Override // android.view.View
    public void computeScroll() {
        r.b bVar = this.f1222d;
        if (bVar == null || bVar.w() || !this.f1222d.i()) {
            t.a.a("NestedScrollRefreshLoadMoreLayout", "computeScroll finish! moveDistance: " + this.f1230h + ", lastMoveDistance: " + this.f1232i);
            if (this.f1248q || this.W) {
                if (u() && this.f1232i > 0.0f) {
                    this.v0.e();
                }
                if (q() && this.V && this.f1232i < 0.0f) {
                    this.w0.e();
                }
            }
            this.D = false;
            this.f1248q = false;
            this.W = false;
            this.f1245o0 = false;
            if (this.U) {
                I(false);
                return;
            }
            return;
        }
        if (x()) {
            int iQ = this.f1222d.q();
            int i2 = iQ - this.f1246p;
            this.f1246p = iQ;
            if (!this.f1248q && i2 < 0 && this.f1230h >= 0.0f && !o.d.a(this.Q)) {
                E(i2, 0);
            } else if (!this.f1248q && i2 > 0 && this.f1230h <= 0.0f && !o.d.d(this.Q)) {
                E(i2, 1);
            } else if (this.W) {
                if (r()) {
                    P(iQ);
                }
            } else if (this.f1248q) {
                if (v()) {
                    R(iQ);
                } else if (r()) {
                    P(iQ);
                }
                C(iQ);
            }
        } else {
            int iP = this.f1222d.p();
            int i3 = iP - this.f1244o;
            this.f1244o = iP;
            if (!this.f1248q && i3 < 0 && this.f1230h >= 0.0f && !o.d.c(this.Q)) {
                E(i3, 2);
            } else if (!this.f1248q && i3 > 0 && this.f1230h <= 0.0f && !o.d.b(this.Q)) {
                E(i3, 3);
            } else if (this.W) {
                if (r()) {
                    P(iP);
                }
            } else if (this.f1248q) {
                if (v()) {
                    R(iP);
                } else if (r()) {
                    P(iP);
                }
                C(iP);
            }
        }
        invalidate();
    }

    /* JADX WARN: Code duplicated, block: B:39:0x0090  */
    /* JADX WARN: Code duplicated, block: B:41:0x0096  */
    /* JADX WARN: Code duplicated, block: B:54:0x00c2  */
    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (!this.f1250r) {
            return true;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.C = true;
            this.B = 0;
            this.A = false;
            this.f1216a = -1;
            this.f1257y = motionEvent.getRawX();
            this.f1258z = motionEvent.getRawY();
            this.s0 = 0.0f;
            this.t0 = 0.0f;
            if (this.f1230h == 0.0f) {
                if (!h.h(this.I)) {
                    setStatus(0);
                }
                this.f1245o0 = false;
            }
        } else if (actionMasked == 1) {
            this.E = false;
            if (this.f1251s) {
                getParent().requestDisallowInterceptTouchEvent(false);
                F(false);
            }
            if (v() && this.V) {
                this.v0.f();
            }
            if (r() && this.V) {
                this.w0.f();
            }
            if (this.r0) {
                onStopNestedScroll(this.Q);
                this.r0 = false;
            }
        } else if (actionMasked == 2) {
            if (this.C) {
                this.E = true;
                this.W = false;
                this.f1248q = false;
                D();
            }
            float rawX = motionEvent.getRawX() - this.f1257y;
            float rawY = motionEvent.getRawY() - this.f1258z;
            if (this.r0) {
                if (x()) {
                    B(this.t0 - rawY);
                } else {
                    B(this.s0 - rawX);
                }
            }
            this.s0 = rawX;
            this.t0 = rawY;
            if (!this.A && this.f1251s) {
                ViewParent parent = getParent();
                if (x()) {
                    z2 = Math.abs(rawX) < Math.abs(rawY);
                    parent.requestDisallowInterceptTouchEvent(z2);
                    F(z2);
                } else {
                    z2 = Math.abs(rawX) >= Math.abs(rawY);
                    parent.requestDisallowInterceptTouchEvent(z2);
                    F(z2);
                }
            }
            int i2 = this.B + 1;
            this.B = i2;
            if (i2 > 2) {
                this.A = true;
            }
        } else if (actionMasked == 3) {
            this.E = false;
            if (this.f1251s) {
                getParent().requestDisallowInterceptTouchEvent(false);
                F(false);
            }
            if (v()) {
                this.v0.f();
            }
            if (r()) {
                this.w0.f();
            }
            if (this.r0) {
                onStopNestedScroll(this.Q);
                this.r0 = false;
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public long getCancelRefreshLoadMoreDuration() {
        return this.J;
    }

    public String getCurrentStatus() {
        return h.a(this.I);
    }

    public float getLoadMoreFooterMaxOffset() {
        return this.O;
    }

    public com.vivo.springkit.nestedScroll.nestedrefresh.d getOnLoadMoreListener() {
        return null;
    }

    public com.vivo.springkit.nestedScroll.nestedrefresh.e getOnRefreshListener() {
        return null;
    }

    public r.b getOverScroller() {
        return this.f1222d;
    }

    public float getRefreshHeaderMaxOffset() {
        return this.N;
    }

    public long getResetContentViewDuration() {
        return this.K;
    }

    public float getScrollFactor() {
        return this.f1233i0;
    }

    public float getVelocityMultiplier() {
        return this.f1235j0;
    }

    public boolean o() {
        return h.h(this.I);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a();
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        n();
        m();
        int iF = o.d.f(getContext());
        int iG = o.d.g(getContext());
        this.f1234j = this.f1253u ? iF : 0;
        if (!this.f1254v) {
            iF = 0;
        }
        this.f1236k = iF;
        this.f1238l = this.f1256x ? iG : 0;
        if (!this.f1255w) {
            iG = 0;
        }
        this.f1240m = iG;
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        y();
        t.a.a("NestedScrollRefreshLoadMoreLayout", "header length: " + this.L + ", header max offset: " + this.N + " --- footer length: " + this.M + ", footer max offset: " + this.O);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        int childCount = getChildCount();
        t.a.a("NestedScrollRefreshLoadMoreLayout", "onMeasure child count: " + childCount);
        for (int i4 = 0; i4 < childCount; i4++) {
            measureChildWithMargins(getChildAt(i4), i2, 0, i3, 0);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        return this.f1220c.dispatchNestedFling(f2, f3, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return L(f2, f3) || this.f1220c.dispatchNestedPreFling(f2, f3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        t.a.a("NestedScrollRefreshLoadMoreLayout", "onNestedPreScroll: " + i2 + ", " + i3 + ", moveDistance: " + this.f1230h);
        A(i2, i3, iArr);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        ViewParent parent;
        t.a.a("NestedScrollRefreshLoadMoreLayout", "onNestedScroll, Consumed = " + i2 + ", " + i3 + ", Unconsumed = " + i4 + ", " + i5 + ", moveDistance: " + this.f1230h);
        boolean zDispatchNestedScroll = this.f1220c.dispatchNestedScroll(i2, i3, i4, i5, this.f1226f);
        StringBuilder sb = new StringBuilder();
        sb.append("scrolled: ");
        sb.append(zDispatchNestedScroll);
        sb.append(", mParentOffsetInWindow: ");
        sb.append(this.f1226f[0]);
        sb.append(", ");
        sb.append(this.f1226f[1]);
        t.a.a("NestedScrollRefreshLoadMoreLayout", sb.toString());
        if (!zDispatchNestedScroll && (parent = getParent()) != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        if (x()) {
            B(i5 + this.f1226f[1]);
        } else {
            B(i4 + this.f1226f[0]);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f1218b.onNestedScrollAccepted(view, view2, i2);
        this.f1220c.startNestedScroll(i2 & 2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if (x()) {
            return (i2 & 2) != 0;
        }
        return (i2 & 1) != 0;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        t.a.a("NestedScrollRefreshLoadMoreLayout", "onStopNestedScroll mMoveDistance: " + this.f1230h + ", Status: " + h.a(this.I));
        this.f1218b.onStopNestedScroll(view);
        if (this.f1230h != 0.0f) {
            this.f1248q = true;
            if (x()) {
                if (t() && h.g(this.I)) {
                    this.f1222d.J((int) this.f1230h, (int) this.N, 0);
                    setStatus(-3);
                    this.v0.d();
                } else if (p() && h.f(this.I)) {
                    this.f1222d.J((int) this.f1230h, (int) this.O, 0);
                    setStatus(3);
                    if (this.V) {
                        this.w0.d();
                    }
                } else if (p() && this.f1217a0 && s()) {
                    if (this.f1230h < this.O) {
                        t.a.a("NestedScrollRefreshLoadMoreLayout", "onStopNestedScroll(): AutoLoadMore spring back !");
                        this.f1222d.J((int) this.f1230h, (int) this.O, 0);
                    } else {
                        t.a.a("NestedScrollRefreshLoadMoreLayout", "onStopNestedScroll(): AutoLoadMore not spring back !");
                        this.f1222d.m(true);
                    }
                } else if ((!h.e(this.I) && !h.c(this.I)) || this.f1227f0) {
                    this.f1222d.J((int) this.f1230h, 0, 0);
                }
            } else if (t() && h.g(this.I)) {
                this.f1222d.I((int) this.f1230h, (int) this.N, 0);
                setStatus(-3);
                this.v0.d();
            } else if (p() && h.f(this.I)) {
                this.f1222d.I((int) this.f1230h, (int) this.O, 0);
                setStatus(3);
                if (this.V) {
                    this.w0.d();
                }
            } else if (p() && this.f1217a0 && s()) {
                if (this.f1230h < this.O) {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onStopNestedScroll(): AutoLoadMore spring back !");
                    this.f1222d.I((int) this.f1230h, (int) this.O, 0);
                } else {
                    t.a.a("NestedScrollRefreshLoadMoreLayout", "onStopNestedScroll(): AutoLoadMore not spring back !");
                    this.f1222d.m(true);
                }
            } else if ((!h.e(this.I) && !h.c(this.I)) || this.f1227f0) {
                this.f1222d.I((int) this.f1230h, 0, 0);
            }
            postInvalidateOnAnimation();
        }
        this.f1220c.stopNestedScroll();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() == 0) {
            if (!l((int) motionEvent.getX(), (int) motionEvent.getY())) {
                t.a.a("NestedScrollRefreshLoadMoreLayout", "touch in parent");
                this.r0 = true;
            }
        }
        return this.r0;
    }

    public boolean p() {
        if (x()) {
            return this.H && this.R != null && this.f1254v;
        }
        return this.H && this.R != null && this.f1256x;
    }

    public boolean s() {
        return h.c(this.I);
    }

    public void setNeedFooterAlphaAnim(boolean z2) {
        this.f1223d0 = z2;
    }

    public void setNeedForbiddenPreFling(boolean z2) {
        this.u0 = z2;
    }

    public void setNeedHeaderAlphaAnim(boolean z2) {
        this.f1225e0 = z2;
    }

    protected void setStatus(int i2) {
        t.a.a("NestedScrollRefreshLoadMoreLayout", "setStatus from:" + h.a(this.I) + " to:" + h.a(i2));
        this.I = i2;
    }

    public boolean t() {
        if (x()) {
            return this.G && this.P != null && this.f1253u;
        }
        return this.G && this.P != null && this.f1255w;
    }

    public boolean w() {
        return h.e(this.I);
    }

    protected boolean x() {
        return getOrientation() == 1;
    }

    public NestedScrollRefreshLoadMoreLayout(Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NestedScrollRefreshLoadMoreLayout(Context context, @Nullable AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1216a = -1;
        this.f1224e = false;
        this.f1226f = new int[2];
        this.f1228g = new int[2];
        this.f1232i = 0.0f;
        this.f1248q = false;
        this.f1250r = true;
        this.f1251s = false;
        this.f1252t = new ArrayList();
        this.f1253u = true;
        this.f1254v = true;
        this.f1255w = true;
        this.f1256x = true;
        this.f1257y = 0.0f;
        this.f1258z = 0.0f;
        this.A = false;
        this.B = 0;
        this.C = false;
        this.D = false;
        this.E = false;
        this.G = false;
        this.H = false;
        this.I = 0;
        this.J = 200L;
        this.K = 100L;
        this.L = 0.0f;
        this.M = 0.0f;
        this.N = 0.0f;
        this.O = 0.0f;
        this.U = false;
        this.V = true;
        this.W = false;
        this.f1217a0 = false;
        this.f1219b0 = 2.0f;
        this.f1223d0 = true;
        this.f1225e0 = true;
        this.f1227f0 = false;
        this.f1229g0 = false;
        this.f1231h0 = false;
        this.f1233i0 = -1.0f;
        this.f1235j0 = 1.0f;
        this.f1237k0 = 2.5f;
        this.f1239l0 = 1.0f;
        this.f1241m0 = 1.0f;
        this.f1243n0 = 1.2f;
        this.f1245o0 = false;
        this.f1247p0 = 600.0f;
        this.f1249q0 = 1;
        this.r0 = false;
        this.u0 = true;
        this.v0 = new e();
        this.w0 = new a();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.NestedScrollRefreshLoadMoreLayout, i2, 0);
        try {
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i3);
                if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_nested_scrolling_enable) {
                    this.f1224e = typedArrayObtainStyledAttributes.getBoolean(index, false);
                } else if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_disallow_intercept_enable) {
                    H(typedArrayObtainStyledAttributes.getBoolean(index, false));
                } else if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_touch_enable) {
                    K(typedArrayObtainStyledAttributes.getBoolean(index, true));
                } else if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_refresh_enabled) {
                    J(typedArrayObtainStyledAttributes.getBoolean(index, false));
                } else if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_refresh_header_max_offset) {
                    float dimension = typedArrayObtainStyledAttributes.getDimension(index, 0.0f);
                    if (dimension < 0.0f) {
                        this.N = -dimension;
                    } else {
                        this.N = dimension;
                    }
                } else if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_load_more_enabled) {
                    I(typedArrayObtainStyledAttributes.getBoolean(index, false));
                } else if (index == R$styleable.NestedScrollRefreshLoadMoreLayout_rl_load_more_footer_max_offset) {
                    float dimension2 = typedArrayObtainStyledAttributes.getDimension(index, 0.0f);
                    if (dimension2 > 0.0f) {
                        this.O = -dimension2;
                    } else {
                        this.O = dimension2;
                    }
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            this.f1218b = new NestedScrollingParentHelper(this);
            NestedScrollingChildHelper nestedScrollingChildHelper = new NestedScrollingChildHelper(this);
            this.f1220c = nestedScrollingChildHelper;
            setNestedScrollingEnabled(true);
            nestedScrollingChildHelper.setNestedScrollingEnabled(this.f1224e);
            ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
            this.f1221c0 = valueAnimatorOfFloat;
            valueAnimatorOfFloat.setInterpolator(new LinearInterpolator());
            this.f1221c0.setDuration(100L);
            this.f1221c0.addUpdateListener(new b());
            this.f1221c0.addListener(new c());
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    private void k(float f2) {
    }
}
