package com.vivo.springkit.nestedScroll.nestedrefresh;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class RefreshHeaderLayoutAdapter extends FrameLayout implements b, c {
    public RefreshHeaderLayoutAdapter(Context context) {
        this(context, null);
    }

    public RefreshHeaderLayoutAdapter(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public RefreshHeaderLayoutAdapter(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
    }

    @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
    public void b() {
    }

    @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
    public void c() {
    }

    @Override // com.vivo.springkit.nestedScroll.nestedrefresh.b
    public void d() {
    }

    @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
    public void e() {
    }

    @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
    public void f() {
    }

    @Override // com.vivo.springkit.nestedScroll.nestedrefresh.c
    public void a(int i2, boolean z2, boolean z3, boolean z4) {
    }
}
