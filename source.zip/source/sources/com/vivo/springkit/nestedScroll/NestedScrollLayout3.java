package com.vivo.springkit.nestedScroll;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.view.NestedScrollingParent2;
import androidx.core.view.NestedScrollingParent3;
import t.a;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class NestedScrollLayout3 extends NestedScrollLayout implements NestedScrollingParent2, NestedScrollingParent3 {
    public NestedScrollLayout3(Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.f1178d.getNestedScrollAxes();
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        return super.onNestedFling(view, f2, f3, z2);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        a.a("NestedScrollLayout", "onNestedPreFling, velocityX = " + f2 + ", velocityY = " + f3 + ", moveDistance = " + this.f1180e);
        if (this.f1180e != 0.0f || this.f1204q) {
            return true;
        }
        if (getOrientation() == 1) {
            if (!this.f1206s && f3 < 0.0f) {
                return false;
            }
            if (!this.f1207t && f3 > 0.0f) {
                return false;
            }
        } else {
            if (!this.f1209v && f2 < 0.0f) {
                return false;
            }
            if (!this.f1208u && f2 > 0.0f) {
                return false;
            }
        }
        j(f2, f3);
        return false;
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        u(view, i2, i3, iArr, 0);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        v(view, i2, i3, i4, i5, 0);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        x(view, view2, i2, 0);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return y(view, view2, i2, 0);
    }

    @Override // com.vivo.springkit.nestedScroll.NestedScrollLayout, android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        z(view, 0);
    }

    public void u(View view, int i2, int i3, int[] iArr, int i4) {
        k(i2, i3, iArr);
    }

    public void v(View view, int i2, int i3, int i4, int i5, int i6) {
        w(view, i2, i3, i4, i5, 0, this.L);
    }

    public void w(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i6 == 0) {
            super.onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    public void x(View view, View view2, int i2, int i3) {
        super.onNestedScrollAccepted(view, view2, i2);
        a.a("NestedScrollLayout", "onNestedScrollAccepted");
        this.f1178d.onNestedScrollAccepted(view, view2, i2, i3);
        this.f1176c = view2;
    }

    public boolean y(View view, View view2, int i2, int i3) {
        a.a("NestedScrollLayout", "onStartNestedScroll2");
        if (getOrientation() == 1) {
            return (i2 & 2) != 0;
        }
        return (i2 & 1) != 0;
    }

    public void z(View view, int i2) {
        a.a("NestedScrollLayout", "onStopNestedScroll, mMoveDistance = " + this.f1180e);
        this.f1178d.onStopNestedScroll(view, i2);
        if (this.f1180e != 0.0f) {
            this.f1204q = true;
            if (getOrientation() == 1) {
                this.f1198n.J((int) this.f1180e, 0, 0);
            } else {
                this.f1198n.I((int) this.f1180e, 0, 0);
            }
            postInvalidateOnAnimation();
        }
        this.f1176c = null;
    }

    public NestedScrollLayout3(Context context, @Nullable AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
    }
}
