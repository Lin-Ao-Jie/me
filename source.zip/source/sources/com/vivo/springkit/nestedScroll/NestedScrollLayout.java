package com.vivo.springkit.nestedScroll;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.NestedScrollingChildHelper;
import androidx.core.view.NestedScrollingParent;
import androidx.core.view.NestedScrollingParentHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.vivo.springkit.R$styleable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import o.d;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class NestedScrollLayout extends LinearLayout implements NestedScrollingParent {
    private boolean A;
    private boolean B;
    protected boolean C;
    private final List D;
    private boolean E;
    private float F;
    private float G;
    private float H;
    private float I;
    private float J;
    private int K;
    protected final int[] L;
    private boolean M;
    private boolean N;
    private float O;
    private float P;
    private float Q;
    private float R;
    private int S;
    private int T;
    private WeakReference U;
    private boolean V;
    private List W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f1172a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    private float f1173a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f1174b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    private boolean f1175b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected View f1176c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    boolean f1177c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected final NestedScrollingParentHelper f1178d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    private final NestedScrollingChildHelper f1179d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected float f1180e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    private boolean f1181e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f1182f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    protected int[] f1183f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1184g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    protected int[] f1185g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1186h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    private boolean f1187h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1188i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    private int f1189i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1190j;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    private int f1191j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1192k;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    private int f1193k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1194l;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    private int f1195l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1196m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    private int f1197m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    protected r.b f1198n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    private int f1199n0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f1200o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    private boolean f1201o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f1202p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    private boolean f1203p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    protected boolean f1204q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    protected boolean f1205r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    protected boolean f1206s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    protected boolean f1207t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected boolean f1208u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    protected boolean f1209v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f1210w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f1211x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private boolean f1212y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private int f1213z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends RecyclerView.OnScrollListener {
        a() {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements View.OnScrollChangeListener {
        b() {
        }

        @Override // android.view.View.OnScrollChangeListener
        public void onScrollChange(View view, int i2, int i3, int i4, int i5) {
            NestedScrollLayout.b(NestedScrollLayout.this);
            if (NestedScrollLayout.this.W == null || NestedScrollLayout.this.W.size() <= 0) {
                return;
            }
            b.c.a(NestedScrollLayout.this.W.get(0));
            throw null;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface c {
    }

    public NestedScrollLayout(Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private void a() {
        r.b bVar = this.f1198n;
        if (bVar == null || bVar.w()) {
            return;
        }
        t.a.a("NestedScrollLayout", "abortAnimation");
        this.f1198n.a();
    }

    static /* synthetic */ o.c b(NestedScrollLayout nestedScrollLayout) {
        nestedScrollLayout.getClass();
        return null;
    }

    private void d(int i2, float f2) {
        t.a.a("NestedScrollLayout", "doSpringBack orientation=" + i2 + " , offset = " + f2);
        if (getOrientation() == 1) {
            int iO = (int) this.f1198n.o();
            if (i()) {
                b.c.a(this.U.get());
                throw null;
            }
            int i3 = (int) (iO * this.F);
            t.a.a("NestedScrollLayout", "doSpringBack velocityY=" + i3);
            if (this.M) {
                this.f1198n.L(0, 0, -i3);
                int i4 = this.S;
                if (i4 > 0) {
                    this.f1198n.C(i4);
                }
                int i5 = this.T;
                if (i5 > 0) {
                    this.f1198n.D(i5);
                }
            } else if (i()) {
                this.f1198n.H(0, 0, -i3);
            } else if (i2 == 0 || i2 == 1) {
                this.f1198n.F((int) (-f2), 0, -i3);
            }
        } else if (getOrientation() == 0) {
            int iN = (int) this.f1198n.n();
            if (i()) {
                b.c.a(this.U.get());
                throw null;
            }
            int i6 = (int) (iN * this.F);
            t.a.a("NestedScrollLayout", "doSpringBack velocityX=" + i6);
            if (this.M) {
                this.f1198n.K(0, 0, -i6);
                int i7 = this.S;
                if (i7 > 0) {
                    this.f1198n.C(i7);
                }
                int i8 = this.T;
                if (i8 > 0) {
                    this.f1198n.D(i8);
                }
            } else if (i()) {
                this.f1198n.G(0, 0, -i6);
            } else if (i2 == 2 || i2 == 3) {
                this.f1198n.E((int) (-f2), 0, -i6);
            }
        }
        postInvalidateOnAnimation();
    }

    private boolean e(int i2, int i3) {
        if (getChildCount() > 0) {
            int scrollY = getScrollY();
            View childAt = getChildAt(0);
            if (i3 >= childAt.getTop() - scrollY && i3 < childAt.getBottom() - scrollY && i2 >= childAt.getLeft() && i2 < childAt.getRight()) {
                return true;
            }
        }
        return false;
    }

    private void f() {
        if (this.K == -1) {
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                View childAt = getChildAt(i2);
                t.a.a("NestedScrollLayout", i2 + " = " + childAt.getClass());
                try {
                    if (Class.forName("androidx.viewpager2.widget.ViewPager2").isInstance(childAt)) {
                        this.M = true;
                        this.K = i2;
                        break;
                    }
                    continue;
                } catch (ClassNotFoundException unused) {
                }
                this.K = 0;
            }
        }
        t.a.a("NestedScrollLayout", "Is ViewPager?= " + this.M);
        View childAt2 = getChildAt(this.K);
        this.f1174b = childAt2;
        if (childAt2 == null) {
            throw new RuntimeException("NestedScrollLayout must have at least one child!");
        }
    }

    private void g() {
        View childAt;
        int i2 = this.K;
        if (i2 < 0 || this.W == null || (childAt = getChildAt(i2)) == null) {
            return;
        }
        if (this.M) {
            childAt = ((ViewGroup) childAt).getChildAt(0);
        }
        childAt.setOnScrollChangeListener(new b());
    }

    private float getCurrentTranslationDistance() {
        if (this.f1174b == null) {
            return 0.0f;
        }
        return getOrientation() == 1 ? this.f1174b.getTranslationY() : this.f1174b.getTranslationX();
    }

    private void h() {
        if (this.f1198n != null) {
            return;
        }
        r.b bVar = new r.b(getContext());
        this.f1198n = bVar;
        bVar.B(false);
    }

    private boolean i() {
        WeakReference weakReference = this.U;
        return (weakReference == null || weakReference.get() == null) ? false : true;
    }

    private void m(float f2) {
        t.a.a("NestedScrollLayout", "onSpringScroll:" + f2);
        t(f2);
    }

    private void n() {
        a();
        this.E = false;
    }

    private void o(int i2, int i3) {
        t.a.a("NestedScrollLayout", "OnFlingOverScrollStart, orientation = " + i2 + ", offset = " + i3);
        List list = this.W;
        if (list != null && list.size() > 0) {
            b.c.a(this.W.get(0));
            throw null;
        }
        if (this.V) {
            t(-i3);
        }
        this.f1204q = true;
        if (i()) {
            b.c.a(this.U.get());
            throw null;
        }
        d(i2, i3);
    }

    private void p(boolean z2) {
        for (ViewParent viewParent : this.D) {
            if (viewParent != null) {
                viewParent.requestDisallowInterceptTouchEvent(z2);
            }
        }
    }

    private void q() {
        r.b bVar;
        if (!this.M || (bVar = this.f1198n) == null) {
            return;
        }
        bVar.v(this.R, this.Q);
    }

    private void r() {
        int iF = d.f(getContext());
        int iG = d.g(getContext());
        int i2 = this.f1190j;
        if (i2 > 0) {
            if (!this.f1206s) {
                i2 = 0;
            }
            this.f1182f = i2;
        } else {
            this.f1182f = this.f1206s ? iF : 0;
        }
        int i3 = this.f1192k;
        if (i3 > 0) {
            if (!this.f1207t) {
                i3 = 0;
            }
            this.f1184g = i3;
        } else {
            if (!this.f1207t) {
                iF = 0;
            }
            this.f1184g = iF;
        }
        int i4 = this.f1194l;
        if (i4 > 0) {
            if (!this.f1209v) {
                i4 = 0;
            }
            this.f1186h = i4;
        } else {
            this.f1186h = this.f1209v ? iG : 0;
        }
        int i5 = this.f1196m;
        if (i5 > 0) {
            this.f1188i = this.f1208u ? i5 : 0;
            return;
        }
        if (!this.f1208u) {
            iG = 0;
        }
        this.f1188i = iG;
    }

    private boolean s(float f2, float f3) {
        t.a.a("NestedScrollLayout", "onNestedPreFling, velocityX = " + f2 + ", velocityY = " + f3 + ", moveDistance = " + this.f1180e);
        if (this.f1180e == 0.0f) {
            if (getOrientation() == 1) {
                if (!this.f1206s && f3 < 0.0f) {
                    return false;
                }
                if (!this.f1207t && f3 > 0.0f) {
                    return false;
                }
            } else {
                if (!this.f1209v && f2 < 0.0f) {
                    return false;
                }
                if (!this.f1208u && f2 > 0.0f) {
                    return false;
                }
            }
        }
        if (this.f1204q) {
            t.a.a("NestedScrollLayout", "PreFling forbidden, Is over scrolling!");
            return true;
        }
        if (getOrientation() == 1) {
            if ((f3 > 0.0f && this.f1180e > 0.0f) || (f3 < 0.0f && this.f1180e < 0.0f)) {
                t.a.a("NestedScrollLayout", "PreFling forbidden!");
                return true;
            }
        } else if ((f2 > 0.0f && this.f1180e > 0.0f) || (f2 < 0.0f && this.f1180e < 0.0f)) {
            t.a.a("NestedScrollLayout", "PreFling forbidden!");
            return true;
        }
        j(f2, f3);
        return false;
    }

    private void t(float f2) {
        t.a.d("NestedScrollLayout", "transContent : distance = " + f2);
        if (!(this.f1208u && this.f1206s) && f2 > 0.0f) {
            return;
        }
        if (!(this.f1209v && this.f1207t) && f2 < 0.0f) {
            return;
        }
        if (getOrientation() == 1) {
            if (Math.abs(f2) > Math.max(this.f1182f, this.f1184g)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1186h, this.f1188i)) {
            return;
        }
        this.f1180e = f2;
        if (this.f1174b != null) {
            if (getOrientation() == 1) {
                this.f1174b.setTranslationY(this.f1180e);
            } else {
                this.f1174b.setTranslationX(this.f1180e);
            }
            List list = this.W;
            if (list == null || list.size() <= 0) {
                return;
            }
            b.c.a(this.W.get(0));
            throw null;
        }
    }

    @Override // android.view.View
    public void computeScroll() {
        List list;
        r.b bVar = this.f1198n;
        boolean z2 = bVar == null || bVar.w() || !this.f1198n.i();
        if (z2) {
            t.a.a("NestedScrollLayout", "isFinish=" + z2);
        }
        if (z2) {
            if (this.f1204q && (list = this.W) != null && list.size() > 0) {
                b.c.a(this.W.get(0));
                throw null;
            }
            this.f1204q = false;
            t.a.a("NestedScrollLayout", "OnFlingOverScrollEnd");
            return;
        }
        if (getOrientation() == 1) {
            int iQ = this.f1198n.q();
            int i2 = iQ - this.f1202p;
            this.f1202p = iQ;
            if (i()) {
                b.c.a(this.U.get());
                throw null;
            }
            if (!this.f1204q && i2 < 0 && this.f1180e >= 0.0f && !d.a(this.f1174b)) {
                t.a.a("NestedScrollLayout", "ORIENTATION_DOWN overScroll");
                o(0, i2 - this.f1199n0);
            } else if (!this.f1204q && i2 > 0 && this.f1180e <= 0.0f && !d.d(this.f1174b)) {
                t.a.a("NestedScrollLayout", "ORIENTATION_UP overScroll");
                o(1, i2 - this.f1199n0);
            } else if (this.f1204q) {
                m(iQ);
            }
        } else {
            int iP = this.f1198n.p();
            int i3 = iP - this.f1200o;
            this.f1200o = iP;
            if (i()) {
                b.c.a(this.U.get());
                throw null;
            }
            if (!this.f1204q && i3 < 0 && this.f1180e >= 0.0f && !d.c(this.f1174b)) {
                t.a.a("NestedScrollLayout", "ORIENTATION_RIGHT overScroll");
                o(2, i3 - this.f1197m0);
            } else if (!this.f1204q && i3 > 0 && this.f1180e <= 0.0f && !d.b(this.f1174b)) {
                t.a.a("NestedScrollLayout", "ORIENTATION_LEFT overScroll");
                o(3, i3 - this.f1197m0);
            } else if (this.f1204q) {
                m(iP);
            }
        }
        if (this.M && this.f1203p0) {
            if (getOrientation() == 0) {
                if (d.c(this.f1174b) && d.b(this.f1174b)) {
                    t.a.a("NestedScrollLayout", "HORIZONTAL - invalidate false");
                    a();
                    return;
                }
            } else if (d.a(this.f1174b) && d.d(this.f1174b)) {
                t.a.a("NestedScrollLayout", "VERTICAL - invalidate false");
                a();
                return;
            }
        }
        postInvalidateOnAnimation();
    }

    /* JADX WARN: Code duplicated, block: B:64:0x00e6  */
    /* JADX WARN: Code duplicated, block: B:66:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:69:0x00ff  */
    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (!this.A) {
            return true;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            t.a.a("NestedScrollLayout", "MotionEvent.ACTION_DOWN");
            this.E = true;
            this.f1213z = 0;
            this.f1212y = false;
            this.f1210w = motionEvent.getRawX();
            this.f1211x = motionEvent.getRawY();
            this.f1197m0 = 0;
            this.f1199n0 = 0;
        } else if (actionMasked == 1) {
            t.a.a("NestedScrollLayout", "MotionEvent.ACTION_UP/ACTION_CANCEL");
            this.f1187h0 = false;
            if (this.B) {
                getParent().requestDisallowInterceptTouchEvent(false);
                p(false);
            }
            if (this.f1177c0) {
                onStopNestedScroll(this.f1174b);
            }
            this.f1177c0 = false;
        } else if (actionMasked == 2) {
            float rawX = motionEvent.getRawX() - this.f1210w;
            float rawY = motionEvent.getRawY() - this.f1211x;
            this.O = rawX;
            this.P = rawY;
            if (this.E) {
                this.f1187h0 = true;
            }
            if (this.f1204q) {
                if (getOrientation() == 1) {
                    if (Math.abs(rawX) < Math.abs(rawY)) {
                        if (this.E) {
                            n();
                        }
                    } else if (this.f1201o0) {
                        t.a.a("NestedScrollLayout", "VERTICAL consume");
                        return true;
                    }
                } else if (getOrientation() == 0) {
                    if (Math.abs(rawX) > Math.abs(rawY)) {
                        if (this.E) {
                            n();
                        }
                    } else if (this.f1201o0) {
                        t.a.a("NestedScrollLayout", "HORIZONTAL consume");
                        return true;
                    }
                }
            }
            if (this.f1177c0) {
                if (getOrientation() == 1) {
                    t(rawY);
                } else {
                    t(rawX);
                }
            }
            if (!this.f1212y && this.B) {
                ViewParent parent = getParent();
                if (getOrientation() == 0) {
                    if (Math.abs(rawX) >= Math.abs(rawY)) {
                        parent.requestDisallowInterceptTouchEvent(true);
                        p(true);
                    } else {
                        parent.requestDisallowInterceptTouchEvent(false);
                        p(false);
                    }
                } else if (Math.abs(rawX) < Math.abs(rawY)) {
                    parent.requestDisallowInterceptTouchEvent(true);
                    p(true);
                } else {
                    t.a.a("NestedScrollLayout", "request X");
                    parent.requestDisallowInterceptTouchEvent(false);
                    p(false);
                }
            }
            int i2 = this.f1213z + 1;
            this.f1213z = i2;
            if (!this.f1212y && i2 > 2) {
                this.f1212y = true;
            }
        } else if (actionMasked == 3) {
            t.a.a("NestedScrollLayout", "MotionEvent.ACTION_UP/ACTION_CANCEL");
            this.f1187h0 = false;
            if (this.B) {
                getParent().requestDisallowInterceptTouchEvent(false);
                p(false);
            }
            if (this.f1177c0) {
                onStopNestedScroll(this.f1174b);
            }
            this.f1177c0 = false;
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public boolean getAllowedListenOutOfChild() {
        return this.f1175b0;
    }

    public int getChildBottomPadding() {
        return this.f1195l0;
    }

    public int getChildLeftPadding() {
        return this.f1189i0;
    }

    public int getChildRightPadding() {
        return this.f1191j0;
    }

    public int getChildTopPadding() {
        return this.f1193k0;
    }

    public View getContentLayout() {
        return this.f1174b;
    }

    public float getEdgeReboundVelocityFactor() {
        return this.f1173a0;
    }

    public r.b getOverScroller() {
        return this.f1198n;
    }

    public float getScrollFactor() {
        return this.f1172a;
    }

    public float getSpringFriction() {
        return this.Q;
    }

    public float getSpringTension() {
        return this.R;
    }

    public int getUserMaxPullDownDistance() {
        return this.f1190j;
    }

    public int getUserMaxPullLeftDistance() {
        return this.f1194l;
    }

    public int getUserMaxPullRightDistance() {
        return this.f1196m;
    }

    public int getUserMaxPullUpDistance() {
        return this.f1192k;
    }

    public float getVelocityMultiplier() {
        return this.F;
    }

    protected void j(float f2, float f3) {
        if (getOrientation() == 1) {
            this.f1202p = 0;
            this.f1198n.j(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        } else {
            this.f1200o = 0;
            this.f1198n.j(0, 0, (int) f2, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
        }
        invalidate();
    }

    protected void k(int i2, int i3, int[] iArr) {
        if (getOrientation() == 1) {
            if (i3 > 0) {
                float f2 = this.f1180e;
                if (f2 > 0.0f) {
                    float f3 = i3;
                    if (f3 <= f2) {
                        iArr[1] = iArr[1] + i3;
                        t((-i3) + f2);
                        if (this.f1179d0.dispatchNestedPreScroll(i2, 0, this.f1185g0, this.f1183f0)) {
                            iArr[0] = iArr[0] + this.f1185g0[0];
                            return;
                        }
                        return;
                    }
                    iArr[1] = (int) (iArr[1] + f2);
                    t(0.0f);
                    if (this.f1179d0.dispatchNestedPreScroll(i2, (int) (f3 - this.f1180e), this.f1185g0, this.f1183f0)) {
                        int i4 = iArr[0];
                        int[] iArr2 = this.f1185g0;
                        iArr[0] = i4 + iArr2[0];
                        iArr[1] = iArr[1] + iArr2[1];
                        return;
                    }
                    return;
                }
            }
            if (i3 < 0) {
                float f4 = this.f1180e;
                if (f4 < 0.0f) {
                    float f5 = i3;
                    if (f5 >= f4) {
                        iArr[1] = iArr[1] + i3;
                        t((-i3) + f4);
                        if (this.f1179d0.dispatchNestedPreScroll(i2, 0, this.f1185g0, this.f1183f0)) {
                            iArr[0] = iArr[0] + this.f1185g0[0];
                            return;
                        }
                        return;
                    }
                    iArr[1] = (int) (iArr[1] + f4);
                    t(0.0f);
                    if (this.f1179d0.dispatchNestedPreScroll(i2, (int) (f5 - this.f1180e), this.f1185g0, this.f1183f0)) {
                        int i5 = iArr[0];
                        int[] iArr3 = this.f1185g0;
                        iArr[0] = i5 + iArr3[0];
                        iArr[1] = iArr[1] + iArr3[1];
                        return;
                    }
                    return;
                }
            }
            if (this.f1181e0 && this.f1187h0 && i3 > 0 && this.f1179d0.dispatchNestedPreScroll(i2, i3, this.f1185g0, this.f1183f0)) {
                int i6 = iArr[0];
                int[] iArr4 = this.f1185g0;
                iArr[0] = i6 + iArr4[0];
                iArr[1] = iArr[1] + iArr4[1];
                return;
            }
            return;
        }
        if (i2 > 0) {
            float f6 = this.f1180e;
            if (f6 > 0.0f) {
                float f7 = i2;
                if (f7 <= f6) {
                    iArr[0] = iArr[0] + i2;
                    t((-i2) + f6);
                    if (this.f1179d0.dispatchNestedPreScroll(0, i3, this.f1185g0, this.f1183f0)) {
                        iArr[1] = iArr[1] + this.f1185g0[1];
                        return;
                    }
                    return;
                }
                iArr[0] = (int) (iArr[0] + f6);
                t(0.0f);
                if (this.f1179d0.dispatchNestedPreScroll((int) (f7 - this.f1180e), i3, this.f1185g0, this.f1183f0)) {
                    int i7 = iArr[0];
                    int[] iArr5 = this.f1185g0;
                    iArr[0] = i7 + iArr5[0];
                    iArr[1] = iArr[1] + iArr5[1];
                    return;
                }
                return;
            }
        }
        if (i2 < 0) {
            float f8 = this.f1180e;
            if (f8 < 0.0f) {
                float f9 = i2;
                if (f9 >= f8) {
                    iArr[0] = iArr[0] + i2;
                    t((-i2) + f8);
                    if (this.f1179d0.dispatchNestedPreScroll(0, i3, iArr, (int[]) null)) {
                        iArr[1] = iArr[1] + this.f1185g0[1];
                        return;
                    }
                    return;
                }
                iArr[0] = (int) (iArr[0] + f8);
                t(0.0f);
                if (this.f1179d0.dispatchNestedPreScroll((int) (f9 - this.f1180e), i3, iArr, (int[]) null)) {
                    int i8 = iArr[0];
                    int[] iArr6 = this.f1185g0;
                    iArr[0] = i8 + iArr6[0];
                    iArr[1] = iArr[1] + iArr6[1];
                    return;
                }
                return;
            }
        }
        if (this.f1181e0 && this.f1187h0 && i2 > 0 && this.f1179d0.dispatchNestedPreScroll(i2, i3, iArr, (int[]) null)) {
            int i9 = iArr[0];
            int[] iArr7 = this.f1185g0;
            iArr[0] = i9 + iArr7[0];
            iArr[1] = iArr[1] + iArr7[1];
        }
    }

    protected void l(float f2) {
        int i2;
        if (f2 == 0.0f) {
            return;
        }
        if (this.C) {
            this.f1205r = true;
            getParent().requestDisallowInterceptTouchEvent(true);
            p(true);
        }
        if (getOrientation() == 1) {
            i2 = f2 > 0.0f ? this.f1184g : this.f1182f;
        } else {
            i2 = f2 > 0.0f ? this.f1186h : this.f1188i;
        }
        float f3 = i2;
        if (f3 == 0.0f) {
            return;
        }
        float fAbs = Math.abs(this.f1180e) / f3;
        t(this.f1180e + (((int) (f2 / ((this.G * ((float) Math.pow(fAbs, this.H))) + (this.I * ((float) Math.pow(1.0f + fAbs, this.J)))))) * this.f1172a));
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a();
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        t.a.a("NestedScrollLayout", "onFinishInflate");
        f();
        h();
        if (this.M) {
            this.f1198n.v(this.R, this.Q);
        }
        r();
        g();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        int left = getLeft();
        int top = getTop();
        int right = getRight();
        int bottom = getBottom();
        t.a.a("NestedScrollLayout", "onLayout parent (" + left + ", " + top + ", " + right + ", " + bottom + ")");
        this.f1189i0 = this.f1174b.getLeft() + this.f1174b.getPaddingLeft();
        this.f1193k0 = this.f1174b.getTop() + this.f1174b.getPaddingTop();
        this.f1191j0 = (right - this.f1174b.getRight()) + this.f1174b.getPaddingRight();
        this.f1195l0 = (bottom - this.f1174b.getBottom()) + this.f1174b.getPaddingBottom();
        t.a.a("NestedScrollLayout", "mChildPadding: (" + this.f1189i0 + ", " + this.f1193k0 + ", " + this.f1191j0 + ", " + this.f1195l0 + ")");
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        for (int i4 = 0; i4 < getChildCount(); i4++) {
            measureChildWithMargins(getChildAt(i4), i2, 0, i3, 0);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        return this.f1179d0.dispatchNestedFling(f2, f3, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return s(f2, f3) || this.f1179d0.dispatchNestedPreFling(f2, f3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        t.a.a("NestedScrollLayout", "onNestedPreScroll, dx = " + i2 + ", dy = " + i3 + ", mMoveDistance = " + this.f1180e);
        k(i2, i3, iArr);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        ViewParent parent;
        boolean zDispatchNestedScroll = this.f1179d0.dispatchNestedScroll(i2, i3, i4, i5, this.f1183f0);
        t.a.a("NestedScrollLayout", "scrolled: " + zDispatchNestedScroll + ", mParentOffsetInWindow: " + this.f1183f0[0] + ", " + this.f1183f0[1]);
        if (!zDispatchNestedScroll && (parent = getParent()) != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
        if (this.N) {
            t.a.a("NestedScrollLayout", "target.getY=" + view.getY() + " , target.getX=" + view.getX() + " , mConsumeMoveEvent=" + this.f1212y);
            if (getOrientation() == 1) {
                t.a.a("NestedScrollLayout", "onNestedScroll, dyConsumed = " + i3 + ", dyUnconsumed = " + i5);
                l((float) (i5 + this.f1183f0[1]));
                return;
            }
            t.a.a("NestedScrollLayout", "onNestedScroll, dxConsumed = " + i2 + ", dxUnconsumed = " + i4);
            l((float) (i4 + this.f1183f0[0]));
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        List list;
        super.onNestedScrollAccepted(view, view2, i2);
        t.a.a("NestedScrollLayout", "onNestedScrollAccepted");
        if (this.f1205r && (list = this.W) != null && list.size() > 0) {
            b.c.a(this.W.get(0));
            throw null;
        }
        this.f1178d.onNestedScrollAccepted(view, view2, i2);
        if (getOrientation() == 1) {
            this.f1179d0.startNestedScroll(i2 & 2);
        } else {
            this.f1179d0.startNestedScroll(i2 & 1);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        t.a.a("NestedScrollLayout", "onStartNestedScroll and reset Displacement+Velocity threshold");
        this.f1198n.x();
        this.f1198n.y();
        if (getOrientation() == 1) {
            return (i2 & 2) != 0;
        }
        return (i2 & 1) != 0;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        t.a.a("NestedScrollLayout", "onStopNestedScroll, mMoveDistance = " + this.f1180e);
        this.f1178d.onStopNestedScroll(view);
        if (this.C) {
            this.f1205r = false;
            getParent().requestDisallowInterceptTouchEvent(false);
            p(false);
        }
        if (this.f1180e != 0.0f) {
            this.f1204q = true;
            if (getOrientation() == 1) {
                this.f1198n.J((int) this.f1180e, 0, 0);
            } else {
                this.f1198n.I((int) this.f1180e, 0, 0);
            }
            postInvalidateOnAnimation();
        }
        this.f1179d0.stopNestedScroll();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f1175b0 && motionEvent.getAction() == 0 && !e((int) motionEvent.getX(), (int) motionEvent.getY())) {
            this.f1177c0 = true;
        }
        return super.onTouchEvent(motionEvent) || this.f1177c0;
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        t.a.a("NestedScrollLayout", "onViewAdded");
        onFinishInflate();
    }

    public void setAllowedListenOutOfChild(boolean z2) {
        this.f1175b0 = z2;
    }

    public void setBottomOverScrollEnable(boolean z2) {
        if (z2 != this.f1207t) {
            int i2 = this.f1192k;
            if (i2 > 0) {
                if (!z2) {
                    i2 = 0;
                }
                this.f1184g = i2;
            } else {
                this.f1184g = z2 ? d.f(getContext()) : 0;
            }
            this.f1207t = z2;
        }
    }

    public void setConsumeMoveEvent(boolean z2) {
        t.a.a("NestedScrollLayout", "setConsumeMoveEvent: " + z2);
        this.f1201o0 = z2;
    }

    public void setDampCoeffFactorPow(float f2) {
        this.J = f2;
    }

    public void setDampCoeffFix(float f2) {
        this.I = f2;
    }

    public void setDampCoeffPow(float f2) {
        this.H = f2;
    }

    public void setDampCoeffZoom(float f2) {
        this.G = f2;
    }

    public void setDisallowIntercept(boolean z2) {
        t.a.a("NestedScrollLayout", "setDisallowIntercept, disallow = " + z2);
        this.B = z2;
    }

    public void setDisallowInterceptEnable(boolean z2) {
        t.a.a("NestedScrollLayout", "setDisalowInterceptEnable, enable = " + z2);
        this.B = z2;
    }

    public void setDisplacementThreshold(int i2) {
        this.S = i2;
    }

    public void setDynamicDisallowInterceptEnable(boolean z2) {
        t.a.a("NestedScrollLayout", "setDynamicDisallowInterceptEnable, enable = " + z2);
        this.C = z2;
    }

    public void setEdgeReboundVelocityFactor(float f2) {
        this.f1173a0 = f2;
    }

    public void setEnableOverDrag(boolean z2) {
        this.N = z2;
    }

    public void setFlingSnapHelper(s.a aVar) {
        this.U = new WeakReference(aVar);
    }

    public void setIsDisplacement(boolean z2) {
        this.V = z2;
    }

    public void setIsViewPager(boolean z2) {
        this.M = z2;
    }

    public void setLeftOverScrollEnable(boolean z2) {
        if (z2 != this.f1208u) {
            int i2 = this.f1196m;
            if (i2 > 0) {
                if (!z2) {
                    i2 = 0;
                }
                this.f1188i = i2;
            } else {
                this.f1188i = z2 ? d.g(getContext()) : 0;
            }
            this.f1208u = z2;
        }
    }

    public void setNestedChildEnable(boolean z2) {
        t.a.a("NestedScrollLayout", "setNestedChildEnable: " + z2);
        this.f1181e0 = z2;
        NestedScrollingChildHelper nestedScrollingChildHelper = this.f1179d0;
        if (nestedScrollingChildHelper != null) {
            nestedScrollingChildHelper.setNestedScrollingEnabled(z2);
        }
    }

    public void setNestedListener(o.c cVar) {
        g();
    }

    public void setNestedScrollStateListener(@NonNull c cVar) {
        g();
    }

    public void setPageScrollStateChangeEnd(boolean z2) {
        this.f1203p0 = z2;
    }

    public void setRightOverScrollEnable(boolean z2) {
        if (z2 != this.f1209v) {
            int i2 = this.f1194l;
            if (i2 > 0) {
                if (!z2) {
                    i2 = 0;
                }
                this.f1186h = i2;
            } else {
                this.f1186h = z2 ? d.g(getContext()) : 0;
            }
            this.f1209v = z2;
        }
    }

    public void setScrollFactor(float f2) {
        this.f1172a = f2;
    }

    public void setSpringDampingRatio(float f2) {
        this.Q = (float) u.a.a(f2, this.R);
        q();
    }

    public void setSpringFriction(float f2) {
        this.Q = f2;
        q();
    }

    public void setSpringStiffness(float f2) {
        this.R = (float) u.a.b(f2);
        q();
    }

    public void setSpringTension(float f2) {
        this.R = f2;
        q();
    }

    public void setTopOverScrollEnable(boolean z2) {
        if (z2 != this.f1206s) {
            int i2 = this.f1190j;
            if (i2 > 0) {
                if (!z2) {
                    i2 = 0;
                }
                this.f1182f = i2;
            } else {
                this.f1182f = z2 ? d.f(getContext()) : 0;
            }
            this.f1206s = z2;
        }
    }

    public void setTouchEnable(boolean z2) {
        this.A = z2;
    }

    public void setUserMaxPullDownDistance(int i2) {
        this.f1190j = i2;
        r();
    }

    public void setUserMaxPullLeftDistance(int i2) {
        this.f1194l = i2;
        r();
    }

    public void setUserMaxPullRightDistance(int i2) {
        this.f1196m = i2;
        r();
    }

    public void setUserMaxPullUpDistance(int i2) {
        this.f1192k = i2;
        r();
    }

    public void setVelocityMultiplier(float f2) {
        this.F = f2;
    }

    public void setVelocityThreshold(int i2) {
        this.T = i2;
    }

    public NestedScrollLayout(Context context, @Nullable AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1172a = -1.0f;
        this.f1204q = false;
        this.f1205r = false;
        this.f1206s = true;
        this.f1207t = true;
        this.f1208u = true;
        this.f1209v = true;
        this.f1210w = 0.0f;
        this.f1211x = 0.0f;
        this.f1212y = false;
        this.f1213z = 0;
        this.A = true;
        this.B = false;
        this.C = true;
        this.D = new ArrayList();
        this.E = false;
        this.F = 1.0f;
        this.G = 2.5f;
        this.H = 1.0f;
        this.I = 1.0f;
        this.J = 1.2f;
        this.K = -1;
        this.L = new int[2];
        this.M = false;
        this.N = true;
        this.O = 0.0f;
        this.P = 0.0f;
        this.Q = 30.0f;
        this.R = 250.0f;
        this.S = -1;
        this.T = -1;
        this.V = true;
        this.f1173a0 = t.b.a("test_scroll_config_edge_rebound_factor", r.a.f2114c);
        this.f1175b0 = false;
        this.f1177c0 = false;
        this.f1181e0 = false;
        this.f1183f0 = new int[2];
        this.f1185g0 = new int[2];
        this.f1187h0 = false;
        this.f1189i0 = 0;
        this.f1191j0 = 0;
        this.f1193k0 = 0;
        this.f1195l0 = 0;
        this.f1197m0 = 0;
        this.f1199n0 = 0;
        this.f1201o0 = true;
        this.f1203p0 = false;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.NestedScrollLayout, i2, 0);
        try {
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i3);
                if (index == R$styleable.NestedScrollLayout_disallowintercept_enable) {
                    setDisallowIntercept(typedArrayObtainStyledAttributes.getBoolean(index, false));
                } else if (index == R$styleable.NestedScrollLayout_touch_enable) {
                    setTouchEnable(typedArrayObtainStyledAttributes.getBoolean(index, true));
                } else if (index == R$styleable.NestedScrollLayout_nested_scrolling_enable) {
                    setNestedChildEnable(typedArrayObtainStyledAttributes.getBoolean(index, false));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            this.f1178d = new NestedScrollingParentHelper(this);
            NestedScrollingChildHelper nestedScrollingChildHelper = new NestedScrollingChildHelper(this);
            this.f1179d0 = nestedScrollingChildHelper;
            setNestedScrollingEnabled(true);
            nestedScrollingChildHelper.setNestedScrollingEnabled(this.f1181e0);
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    public void setVivoHelper(a.a aVar) {
    }

    public void setVivoPagerSnapHelper(a.b bVar) {
    }

    private NestedScrollLayout getSelf() {
        return this;
    }
}
