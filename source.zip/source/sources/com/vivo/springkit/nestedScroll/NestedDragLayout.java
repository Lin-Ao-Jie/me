package com.vivo.springkit.nestedScroll;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.LinearLayout;
import androidx.annotation.Nullable;
import androidx.core.view.NestedScrollingParent;
import androidx.core.view.NestedScrollingParentHelper;
import com.vivo.springkit.R$styleable;
import o.d;
import r.b;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
@Deprecated
public class NestedDragLayout extends LinearLayout implements NestedScrollingParent {
    private float A;
    private float B;
    private float C;
    private float D;
    private int E;
    private int F;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f1146a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f1147b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final NestedScrollingParentHelper f1148c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f1149d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1150e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f1151f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1152g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1153h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1154i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private b f1155j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1156k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1157l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f1158m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f1159n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private boolean f1160o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f1161p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1162q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private float f1163r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1164s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f1165t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f1166u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f1167v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f1168w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f1169x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f1170y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private float f1171z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static final class a {
        private static String c(int i2) {
            switch (i2) {
                case -4:
                    return "status_refresh_returning";
                case -3:
                    return "status_refreshing";
                case -2:
                    return "status_release_to_refresh";
                case -1:
                    return "status_swiping_to_refresh";
                case 0:
                    return "status_default";
                case 1:
                    return "status_swiping_to_load_more";
                case 2:
                    return "status_release_to_load_more";
                case 3:
                    return "status_loading_more";
                case 4:
                    return "status_load_more_returning";
                default:
                    return "status_illegal!";
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static boolean d(int i2) {
            return i2 == 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static void e(int i2) {
            t.a.c("STATUS", "printStatus:" + c(i2));
        }
    }

    public NestedDragLayout(Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private void a() {
        b bVar = this.f1155j;
        if (bVar == null || bVar.w()) {
            return;
        }
        this.f1155j.a();
    }

    private void b(int i2, float f2) {
        t.a.a("NestedDragLayout", "doSpringBack orientation=" + i2 + " , offset = " + f2);
        if (getOrientation() == 1) {
            int iO = (int) this.f1155j.o();
            if (i2 == 0 || i2 == 1) {
                this.f1155j.F(0, 0, -iO);
            }
        } else if (getOrientation() == 0) {
            int iN = (int) this.f1155j.n();
            if (i2 == 2 || i2 == 3) {
                this.f1155j.E(0, 0, -iN);
            }
        }
        postInvalidateOnAnimation();
    }

    private void d() {
        View childAt = getChildAt(0);
        this.f1147b = childAt;
        if (childAt == null) {
            throw new RuntimeException("NestedScrollLayout must have at least one child!");
        }
    }

    private void e() {
        if (this.f1155j != null) {
            return;
        }
        b bVar = new b(getContext());
        this.f1155j = bVar;
        bVar.B(false);
    }

    private void f(float f2, float f3) {
        if (getOrientation() == 1) {
            this.f1157l = 0;
            this.f1155j.j(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        } else {
            this.f1156k = 0;
            this.f1155j.j(0, 0, (int) f2, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
        }
        invalidate();
    }

    private void g(int i2, int i3, int[] iArr) {
        if (getOrientation() == 1) {
            if (i3 > 0) {
                float f2 = this.f1149d;
                if (f2 > 0.0f) {
                    if (i3 > f2) {
                        iArr[1] = (int) (iArr[1] + f2);
                        m(0.0f);
                        return;
                    } else {
                        iArr[1] = iArr[1] + i3;
                        m((-i3) + f2);
                        return;
                    }
                }
            }
            if (i3 < 0) {
                float f3 = this.f1149d;
                if (f3 < 0.0f) {
                    if (i3 < f3) {
                        iArr[1] = (int) (iArr[1] + f3);
                        m(0.0f);
                        return;
                    } else {
                        iArr[1] = iArr[1] + i3;
                        m((-i3) + f3);
                        return;
                    }
                }
                return;
            }
            return;
        }
        if (i2 > 0) {
            float f4 = this.f1149d;
            if (f4 > 0.0f) {
                if (i2 > f4) {
                    iArr[0] = (int) (iArr[0] + f4);
                    m(0.0f);
                    return;
                } else {
                    iArr[0] = iArr[0] + i2;
                    m((-i2) + f4);
                    return;
                }
            }
        }
        if (i2 < 0) {
            float f5 = this.f1149d;
            if (f5 < 0.0f) {
                if (i2 < f5) {
                    iArr[0] = (int) (iArr[0] + f5);
                    m(0.0f);
                } else {
                    iArr[0] = iArr[0] + i2;
                    m((-i2) + f5);
                }
            }
        }
    }

    private void h(float f2) {
        int i2;
        if (f2 == 0.0f) {
            return;
        }
        if (getOrientation() == 1) {
            i2 = f2 > 0.0f ? this.f1151f : this.f1150e;
        } else {
            i2 = f2 > 0.0f ? this.f1152g : this.f1153h;
        }
        float f3 = i2;
        if (f3 == 0.0f) {
            return;
        }
        float fAbs = Math.abs(this.f1149d) / f3;
        float fPow = (int) (f2 / ((this.f1171z * ((float) Math.pow(fAbs, this.A))) + (this.B * ((float) Math.pow(1.0f + fAbs, this.C)))));
        c(this.f1149d + (this.f1146a * fPow));
        m(this.f1149d + (fPow * this.f1146a));
    }

    private void i(float f2) {
        m(f2);
    }

    private void j() {
        a();
        this.f1169x = false;
    }

    private void k(int i2, int i3) {
        t.a.a("NestedDragLayout", "overScroll, orientation = " + i2 + ", offset = " + i3);
        this.f1158m = true;
        b(i2, (float) i3);
    }

    private void l() {
        if (getOrientation() == 1) {
            this.f1154i = Math.max(this.f1150e, this.f1151f);
        } else {
            this.f1154i = Math.max(this.f1152g, this.f1153h);
        }
        t.a.a("NestedDragLayout", "mMaxDistance=" + this.f1154i);
    }

    private void m(float f2) {
        t.a.a("test>>>", "transContent : distance = " + f2);
        if (!(this.f1161p && this.f1159n) && f2 > 0.0f) {
            return;
        }
        if (!(this.f1162q && this.f1160o) && f2 < 0.0f) {
            return;
        }
        if (getOrientation() == 1) {
            if (Math.abs(f2) > Math.max(this.f1150e, this.f1151f)) {
                return;
            }
        } else if (Math.abs(f2) > Math.max(this.f1152g, this.f1153h)) {
            return;
        }
        this.f1149d = f2;
        if (this.f1147b != null) {
            if (getOrientation() == 1) {
                this.f1147b.setTranslationY(this.f1149d);
            } else {
                this.f1147b.setTranslationX(this.f1149d);
            }
        }
    }

    private void setStatus(int i2) {
        t.a.a("NestedDragLayout", "setStatus from:" + this.E + " to:" + i2);
        this.E = i2;
        a.e(i2);
    }

    @Override // android.view.View
    public void computeScroll() {
        b bVar = this.f1155j;
        if (bVar == null || bVar.w() || !this.f1155j.i()) {
            if (!a.d(this.E)) {
                setStatus(0);
            }
            t.a.a("NestedDragLayout", "computeScroll finish!");
            this.f1158m = false;
            return;
        }
        if (getOrientation() == 1) {
            int iQ = this.f1155j.q();
            int i2 = iQ - this.f1157l;
            this.f1157l = iQ;
            if (!this.f1158m && i2 < 0 && this.f1149d >= 0.0f && !d.a(this.f1147b)) {
                t.a.a("NestedDragLayout", "ORIENTATION_DOWN overScroll");
                k(0, i2);
            } else if (!this.f1158m && i2 > 0 && this.f1149d <= 0.0f && !d.d(this.f1147b)) {
                t.a.a("NestedDragLayout", "ORIENTATION_UP overScroll");
                k(1, i2);
            } else if (this.f1158m) {
                t.a.a("test>>>", "currY=" + iQ);
                i((float) iQ);
            }
        } else {
            int iP = this.f1155j.p();
            int i3 = iP - this.f1156k;
            this.f1156k = iP;
            if (!this.f1158m && i3 < 0 && this.f1149d >= 0.0f && !d.c(this.f1147b)) {
                t.a.a("NestedDragLayout", "ORIENTATION_RIGHT overScroll");
                k(2, i3);
            } else if (!this.f1158m && i3 > 0 && this.f1149d <= 0.0f && !d.b(this.f1147b)) {
                t.a.a("NestedDragLayout", "ORIENTATION_LEFT overScroll");
                k(3, i3);
            } else if (this.f1158m) {
                t.a.a("test>>>", "currX=" + iP);
                i((float) iP);
            }
        }
        invalidate();
    }

    /* JADX WARN: Code duplicated, block: B:33:0x006f  */
    /* JADX WARN: Code duplicated, block: B:35:0x0073  */
    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (!this.f1167v) {
            return true;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1169x = true;
            this.f1166u = 0;
            this.f1165t = false;
            this.f1163r = motionEvent.getRawX();
            this.f1164s = motionEvent.getRawY();
            if (this.f1149d == 0.0f && !a.d(this.E)) {
                setStatus(0);
            }
        } else if (actionMasked == 1) {
            if (this.f1168w) {
                getParent().requestDisallowInterceptTouchEvent(false);
            }
        } else if (actionMasked == 2) {
            if (this.f1169x) {
                j();
            }
            float rawX = motionEvent.getRawX() - this.f1163r;
            float rawY = motionEvent.getRawY() - this.f1164s;
            if (!this.f1165t && this.f1168w) {
                ViewParent parent = getParent();
                if (getOrientation() == 0) {
                    if (Math.abs(rawX) >= Math.abs(rawY)) {
                        parent.requestDisallowInterceptTouchEvent(true);
                    } else {
                        parent.requestDisallowInterceptTouchEvent(false);
                    }
                } else if (Math.abs(rawX) < Math.abs(rawY)) {
                    parent.requestDisallowInterceptTouchEvent(true);
                } else {
                    parent.requestDisallowInterceptTouchEvent(false);
                }
            }
            int i2 = this.f1166u + 1;
            this.f1166u = i2;
            if (i2 > 2) {
                this.f1165t = true;
            }
        } else if (actionMasked == 3) {
            if (this.f1168w) {
                getParent().requestDisallowInterceptTouchEvent(false);
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public float getMultiplier() {
        return this.f1170y;
    }

    public float getScrollFactor() {
        return this.f1146a;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a();
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        d();
        e();
        int iF = d.f(getContext());
        int iG = d.g(getContext());
        this.f1150e = this.f1159n ? iF : 0;
        if (!this.f1160o) {
            iF = 0;
        }
        this.f1151f = iF;
        this.f1152g = this.f1162q ? iG : 0;
        if (!this.f1161p) {
            iG = 0;
        }
        this.f1153h = iG;
        l();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1147b.getLayoutParams();
        this.f1147b.layout(getPaddingLeft() + marginLayoutParams.leftMargin, getPaddingTop() + marginLayoutParams.topMargin, getPaddingLeft() + marginLayoutParams.leftMargin + this.f1147b.getMeasuredWidth(), getPaddingTop() + marginLayoutParams.topMargin + this.f1147b.getMeasuredHeight());
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        for (int i4 = 0; i4 < getChildCount(); i4++) {
            measureChildWithMargins(getChildAt(i4), i2, 0, i3, 0);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        return super.onNestedFling(view, f2, f3, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        t.a.a("NestedDragLayout", "onNestedPreFling, velocityX = " + f2 + ", velocityY = " + f3 + ", moveDistance = " + this.f1149d);
        if (this.f1149d == 0.0f) {
            if (getOrientation() == 1) {
                if (!this.f1159n && f3 < 0.0f) {
                    return false;
                }
                if (!this.f1160o && f3 > 0.0f) {
                    return false;
                }
            } else {
                if (!this.f1162q && f2 < 0.0f) {
                    return false;
                }
                if (!this.f1161p && f2 > 0.0f) {
                    return false;
                }
            }
        }
        f(f2, f3);
        if (getOrientation() == 1) {
            if ((f3 > 0.0f && this.f1149d > 0.0f) || (f3 < 0.0f && this.f1149d < 0.0f)) {
                return true;
            }
        } else if ((f2 > 0.0f && this.f1149d > 0.0f) || (f2 < 0.0f && this.f1149d < 0.0f)) {
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        g(i2, i3, iArr);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        t.a.a("test>>>", "onNestedScroll, dyConsumed = " + i3 + ", dyUnconsumed = " + i5);
        if (getOrientation() == 1) {
            h(i5);
        } else {
            h(i4);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f1148c.onNestedScrollAccepted(view, view2, i2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if (getOrientation() == 1) {
            return (i2 & 2) != 0;
        }
        return (i2 & 1) != 0;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        t.a.a("NestedDragLayout", "onStopNestedScroll, mMoveDistance = " + this.f1149d);
        if (this.f1149d != 0.0f) {
            this.f1158m = true;
            if (getOrientation() == 1) {
                this.f1155j.J((int) this.f1149d, 0, 0);
            } else {
                this.f1155j.I((int) this.f1149d, 0, 0);
            }
            postInvalidateOnAnimation();
        }
    }

    public void setBottomOverScrollEnable(boolean z2) {
        this.f1151f = z2 ? d.f(getContext()) : 0;
        this.f1160o = z2;
        l();
    }

    public void setDisallowInterceptEnable(boolean z2) {
        t.a.a("NestedDragLayout", "setDisalowInterceptEnable, enable = " + z2);
        this.f1168w = z2;
    }

    public void setDragCallDistance(float f2) {
        this.D = f2;
    }

    public void setDragCallMode(int i2) {
        if (i2 < 1 || i2 > 4) {
            return;
        }
        this.F = i2;
    }

    public void setLeftOverScrollEnable(boolean z2) {
        this.f1153h = z2 ? d.g(getContext()) : 0;
        this.f1161p = z2;
        l();
    }

    public void setMultiplier(float f2) {
        this.f1170y = f2;
    }

    public void setRightOverScrollEnable(boolean z2) {
        this.f1152g = z2 ? d.g(getContext()) : 0;
        this.f1162q = z2;
        l();
    }

    public void setScrollFactor(Float f2) {
        this.f1146a = f2.floatValue();
    }

    public void setTopOverScrollEnable(boolean z2) {
        this.f1150e = z2 ? d.f(getContext()) : 0;
        this.f1159n = z2;
        l();
    }

    public void setTouchEnable(boolean z2) {
        this.f1167v = z2;
    }

    public void setVelocityMultiplier(float f2) {
        this.f1170y = f2;
    }

    public NestedDragLayout(Context context, @Nullable AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1146a = -1.0f;
        this.f1158m = false;
        this.f1159n = true;
        this.f1160o = true;
        this.f1161p = true;
        this.f1162q = true;
        this.f1163r = 0.0f;
        this.f1164s = 0.0f;
        this.f1165t = false;
        this.f1166u = 0;
        this.f1167v = true;
        this.f1168w = false;
        this.f1169x = false;
        this.f1170y = 1.0f;
        this.f1171z = 2.5f;
        this.A = 1.0f;
        this.B = 1.0f;
        this.C = 1.2f;
        this.D = 600.0f;
        this.E = 0;
        this.F = 1;
        this.f1148c = new NestedScrollingParentHelper(this);
        setNestedScrollingEnabled(true);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.NestedScrollLayout, i2, 0);
        try {
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i3);
                if (index == R$styleable.NestedScrollLayout_disallowintercept_enable) {
                    setDisallowInterceptEnable(typedArrayObtainStyledAttributes.getBoolean(index, false));
                } else if (index == R$styleable.NestedScrollLayout_touch_enable) {
                    setTouchEnable(typedArrayObtainStyledAttributes.getBoolean(index, true));
                }
            }
        } finally {
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    private void c(float f2) {
    }
}
