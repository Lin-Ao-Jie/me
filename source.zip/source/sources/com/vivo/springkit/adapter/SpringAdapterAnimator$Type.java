package com.vivo.springkit.adapter;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public enum SpringAdapterAnimator$Type {
    SPRING_FROM_TOP,
    SPRING_FROM_BOTTOM,
    SPRING_FROM_RIGHT,
    SPRING_FROM_LEFT,
    SPRING_SCALE_X,
    SPRING_SCALE_Y,
    SPRING_SCALE,
    SPRING_ROTATION_X,
    SPRING_ROTATION_Y
}
