package com.vivo.springkit;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static final int disallowintercept_enable = 2130837616;
    public static final int nested_scrolling_enable = 2130837642;
    public static final int rl_disallow_intercept_enable = 2130837646;
    public static final int rl_load_more_enabled = 2130837647;
    public static final int rl_load_more_footer_index = 2130837648;
    public static final int rl_load_more_footer_max_offset = 2130837649;
    public static final int rl_nested_scrolling_enable = 2130837650;
    public static final int rl_refresh_enabled = 2130837651;
    public static final int rl_refresh_header_index = 2130837652;
    public static final int rl_refresh_header_max_offset = 2130837653;
    public static final int rl_swipe_target_index = 2130837654;
    public static final int rl_touch_enable = 2130837655;
    public static final int touch_enable = 2130837688;
}
