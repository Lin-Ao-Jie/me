package com.vivo.commshare;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public @interface CommError {
    public static final int CHANNEL_NOT_CONN = 9;
    public static final int CHANNEL_STOP = 12;
    public static final int DEVICE_NOT_CONN = 3;
    public static final int GENERIC_FAILURE = 1;
    public static final int LOCAL_NOT_READY = 4;
    public static final int NONE = 0;
    public static final int NOT_SUPPORTED = 2;
    public static final int REMOTE_NOT_READY = 5;
    public static final int RESP_NOT_REQ_CACHE = 10;
    public static final int RESP_TIME_OUT = 6;
    public static final int SDK_ERROR = 7;
    public static final int TOO_LARGE_PACKET = 11;
    public static final int TYPE_ERROR = 8;
}
