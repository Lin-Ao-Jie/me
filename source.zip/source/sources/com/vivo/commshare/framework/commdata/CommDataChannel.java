package com.vivo.commshare.framework.commdata;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommDataChannel {
    private CommDataServiceAgent mVmdriServiceAgent;

    CommDataChannel(CommDataServiceAgent commDataServiceAgent) {
        this.mVmdriServiceAgent = commDataServiceAgent;
    }

    void dispose() {
        this.mVmdriServiceAgent = null;
    }

    public int sendData(String str, byte[] bArr) {
        return this.mVmdriServiceAgent.sendData(str, bArr);
    }
}
