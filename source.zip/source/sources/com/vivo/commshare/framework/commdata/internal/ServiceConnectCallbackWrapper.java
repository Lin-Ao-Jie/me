package com.vivo.commshare.framework.commdata.internal;

import android.annotation.NonNull;
import com.vivo.commshare.framework.commdata.CommDataServiceAgent;
import com.vivo.commshare.framework.commdata.callback.ServiceConnectCallback;
import java.util.Objects;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ServiceConnectCallbackWrapper {

    @NonNull
    private final ServiceConnectCallback mCallback;

    @NonNull
    private final Executor mExecutor;

    public ServiceConnectCallbackWrapper(@NonNull ServiceConnectCallback serviceConnectCallback, @NonNull Executor executor) {
        this.mCallback = serviceConnectCallback;
        this.mExecutor = executor;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.mCallback, ((ServiceConnectCallbackWrapper) obj).mCallback);
    }

    public int hashCode() {
        return Objects.hash(this.mCallback);
    }

    public void onConnected(CommDataServiceAgent commDataServiceAgent) {
        this.mCallback.onConnected(commDataServiceAgent);
    }

    public void onConnectedFailed(String str) {
        this.mCallback.onConnectedFailed(str);
    }

    public void onConnectedFailedInExecutor(final String str) {
        this.mExecutor.execute(new Runnable() { // from class: m.i
            @Override // java.lang.Runnable
            public final void run() {
                this.f1829a.mCallback.onConnectedFailed(str);
            }
        });
    }

    public void onConnectedInExecutor(final CommDataServiceAgent commDataServiceAgent) {
        this.mExecutor.execute(new Runnable() { // from class: m.h
            @Override // java.lang.Runnable
            public final void run() {
                this.f1827a.mCallback.onConnected(commDataServiceAgent);
            }
        });
    }

    public void onDisconnect() {
        this.mCallback.onDisconnect();
    }

    public void onDisconnectInExecutor() {
        Executor executor = this.mExecutor;
        final ServiceConnectCallback serviceConnectCallback = this.mCallback;
        serviceConnectCallback.getClass();
        executor.execute(new Runnable() { // from class: m.g
            @Override // java.lang.Runnable
            public final void run() {
                serviceConnectCallback.onDisconnect();
            }
        });
    }
}
