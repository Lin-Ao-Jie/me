package com.vivo.commshare.framework.commdata.internal;

import android.annotation.NonNull;
import com.vivo.commshare.framework.commdata.callback.DataReceiver;
import java.util.Objects;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class DataReceiverWrapper {

    @NonNull
    private final DataReceiver mDataReceiver;

    @NonNull
    private final Executor mExecutor;

    public DataReceiverWrapper(@NonNull DataReceiver dataReceiver, @NonNull Executor executor) {
        this.mDataReceiver = dataReceiver;
        this.mExecutor = executor;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.mDataReceiver, ((DataReceiverWrapper) obj).mDataReceiver);
    }

    public int hashCode() {
        return Objects.hash(this.mDataReceiver);
    }

    public void recvData(final String str, final byte[] bArr) {
        this.mExecutor.execute(new Runnable() { // from class: m.a
            @Override // java.lang.Runnable
            public final void run() {
                this.f1812a.mDataReceiver.recvData(str, bArr);
            }
        });
    }
}
