package com.vivo.commshare.framework.commdata.callback;

import com.vivo.commshare.framework.base.DeviceInfo;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class DeviceListener {
    public abstract void onRemoteDeviceConnected(DeviceInfo deviceInfo);

    public abstract void onRemoteDeviceDisconnected(DeviceInfo deviceInfo);

    public abstract void onRemoteReady(String str, boolean z2);

    public void onLocalDeviceStateChanged(DeviceInfo deviceInfo) {
    }

    public void onRemoteDeviceStateChanged(DeviceInfo deviceInfo) {
    }
}
