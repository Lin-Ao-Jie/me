package com.vivo.commshare.framework.commdata;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import com.vivo.commshare.IVmdriComm;
import com.vivo.commshare.framework.base.CommLog;
import com.vivo.commshare.framework.base.Constants;
import com.vivo.commshare.framework.commdata.callback.ServiceConnectCallback;
import com.vivo.commshare.framework.commdata.internal.ServiceConnectCallbackWrapper;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommDataManager {
    private static final Object mLock = new Object();
    private int mBusinessType;
    private Context mContext;
    private IVmdriComm mIVmdriCommInterface;
    private boolean mIsServiceBound;
    private final String mLogTag;
    private ServiceConnectCallbackWrapper mServiceConnectCallback;
    private CommDataServiceAgent mVmdriSvcAgent;
    private BinderDeathRecipient mDeathRecipient = new BinderDeathRecipient();
    private VmdriServiceConnection mVmdriServiceConnection = new VmdriServiceConnection();
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class BinderDeathRecipient implements IBinder.DeathRecipient {
        private IBinder mBinder;

        BinderDeathRecipient() {
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            CommDataManager.this.logd("binderDied");
            CommDataManager.this.mIsServiceBound = false;
            CommDataManager.this.mIVmdriCommInterface = null;
            unlinkToDeath();
        }

        public void linkToDeath(IBinder iBinder) throws RemoteException {
            if (iBinder != null) {
                this.mBinder = iBinder;
                iBinder.linkToDeath(this, 0);
            }
        }

        public synchronized void unlinkToDeath() {
            IBinder iBinder = this.mBinder;
            if (iBinder != null) {
                iBinder.unlinkToDeath(this, 0);
                this.mBinder = null;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class VmdriServiceConnection implements ServiceConnection {
        private VmdriServiceConnection() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            CommDataManager.this.logd("onServiceConnected name:" + componentName + " binder:" + iBinder);
            CommDataManager.this.mIVmdriCommInterface = IVmdriComm.Stub.asInterface(iBinder);
            if (CommDataManager.this.mIVmdriCommInterface != null) {
                try {
                    CommDataManager commDataManager = CommDataManager.this;
                    commDataManager.mVmdriSvcAgent = CommDataServiceAgent.create(commDataManager.mContext, CommDataManager.this.mIVmdriCommInterface, CommDataManager.this);
                } catch (RemoteException | RuntimeException e2) {
                    e2.printStackTrace();
                    CommDataManager.this.mContext.unbindService(CommDataManager.this.mVmdriServiceConnection);
                    CommDataManager.this.mServiceConnectCallback.onConnectedFailed(e2.toString());
                }
                if (CommDataManager.this.mVmdriSvcAgent != null) {
                    CommDataManager.this.mIsServiceBound = true;
                    CommDataManager.this.mServiceConnectCallback.onConnected(CommDataManager.this.mVmdriSvcAgent);
                }
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            CommDataManager.this.logd("onServiceDisconnected name:" + componentName);
            CommDataManager.this.mIsServiceBound = false;
            CommDataManager.this.mIVmdriCommInterface = null;
            CommDataManager.this.mVmdriSvcAgent = null;
            CommDataManager.this.mContext.unbindService(CommDataManager.this.mVmdriServiceConnection);
            CommDataManager.this.mServiceConnectCallback.onDisconnect();
        }
    }

    private CommDataManager(Context context, int i2) {
        this.mLogTag = "CommDataManager-" + Constants.getBusinessTypeName(i2);
        logd("CommDataManager v1.0 created");
        this.mContext = context;
        this.mBusinessType = i2;
    }

    public static CommDataManager create(Context context, int i2) {
        return new CommDataManager(context, i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void logd(String str) {
        CommLog.d(this.mLogTag, str);
    }

    private void loge(String str) {
        CommLog.e(this.mLogTag, str);
    }

    private void logi(String str) {
        CommLog.i(this.mLogTag, str);
    }

    public synchronized void connectService(@NonNull ServiceConnectCallback serviceConnectCallback, @Nullable Executor executor) {
        try {
            logd("connectService, svcConnCallback:" + serviceConnectCallback + ", executor:" + executor);
            if (serviceConnectCallback == null) {
                throw new IllegalArgumentException("svcConnCallback must be non-null!");
            }
            if (executor == null) {
                Handler handler = this.mMainHandler;
                handler.getClass();
                executor = new a(handler);
            }
            ServiceConnectCallbackWrapper serviceConnectCallbackWrapper = new ServiceConnectCallbackWrapper(serviceConnectCallback, executor);
            this.mServiceConnectCallback = serviceConnectCallbackWrapper;
            CommDataServiceAgent commDataServiceAgent = this.mVmdriSvcAgent;
            if (commDataServiceAgent == null) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName("com.vivo.vmdri", "com.vivo.vmdri.VmdriCommService"));
                boolean zBindService = this.mContext.bindService(intent, 1, executor, this.mVmdriServiceConnection);
                loge("connectService, status:" + zBindService);
                if (!zBindService) {
                    this.mContext.unbindService(this.mVmdriServiceConnection);
                    this.mServiceConnectCallback.onConnectedFailedInExecutor("status is false, conn vmdri svc failed!");
                }
            } else {
                serviceConnectCallbackWrapper.onConnectedInExecutor(commDataServiceAgent);
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public int getBusinessType() {
        return this.mBusinessType;
    }
}
