package com.vivo.commshare.framework.commdata;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.vivo.commshare.CommDevInfo;
import com.vivo.commshare.ICommShareAudioStateListener;
import com.vivo.commshare.IDataChannel;
import com.vivo.commshare.IDataListener;
import com.vivo.commshare.IDeviceListener;
import com.vivo.commshare.IVmdriComm;
import com.vivo.commshare.framework.base.CommLog;
import com.vivo.commshare.framework.base.Constants;
import com.vivo.commshare.framework.base.DeviceInfo;
import com.vivo.commshare.framework.commdata.callback.AudioStateListener;
import com.vivo.commshare.framework.commdata.callback.DataReceiver;
import com.vivo.commshare.framework.commdata.callback.DeviceListener;
import com.vivo.commshare.framework.commdata.internal.DataReceiverWrapper;
import com.vivo.commshare.framework.commdata.internal.DeviceListenerWrapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommDataServiceAgent {
    private CommShareAudioStateListenerImpl mAudioStateListener;
    private final Context mContext;
    private IDataChannel mIDataChannel;
    private final IDataListenerImpl mIDataListener;
    private final IDeviceListenerImpl mIDeviceListener;
    private final IVmdriComm mIVmdriCommService;
    private final String mLogTag;
    private final CommDataManager mVmdriCommManager;
    private boolean ready;
    private final HashMap<String, DeviceInfo> mRemoteDevInfos = new HashMap<>();
    private final HashMap<String, Boolean> mRemoteDevReady = new HashMap<>();
    private final HashMap<DeviceListener, DeviceListenerWrapper> mDeviceListeners = new HashMap<>();
    private final HashMap<DataReceiver, DataReceiverWrapper> mDataReceivers = new HashMap<>();

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class CommShareAudioStateListenerImpl extends ICommShareAudioStateListener.Stub {

        @NonNull
        private final AudioStateListener mAudioStateListener;

        @NonNull
        private final Executor mExecutor;

        public CommShareAudioStateListenerImpl(@NonNull AudioStateListener audioStateListener, Executor executor) {
            this.mAudioStateListener = audioStateListener;
            this.mExecutor = executor;
        }

        @Override // com.vivo.commshare.ICommShareAudioStateListener
        public void onAudioDataRttUpdate(final long j2) throws RemoteException {
            this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commdata.c
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1114a.mAudioStateListener.onAudioDataRttUpdate(j2);
                }
            });
        }

        @Override // com.vivo.commshare.ICommShareAudioStateListener
        public void onAudioStateStateChanged(final Bundle bundle) throws RemoteException {
            this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commdata.b
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1112a.mAudioStateListener.onAudioStateStateChanged(bundle);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class IDataListenerImpl extends IDataListener.Stub {
        private IDataListenerImpl() {
        }

        @Override // com.vivo.commshare.IDataListener
        public void onDataRecv(final String str, final byte[] bArr) throws RemoteException {
            CommDataServiceAgent.this.mDataReceivers.values().forEach(new Consumer() { // from class: com.vivo.commshare.framework.commdata.d
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    ((DataReceiverWrapper) obj).recvData(str, bArr);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class IDeviceListenerImpl extends IDeviceListener.Stub {
        private IDeviceListenerImpl() {
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onLocalDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException {
            final DeviceInfo deviceInfo = new DeviceInfo(commDevInfo);
            CommDataServiceAgent.this.logd("onLocalDeviceStateChanged, deviceInfo:" + deviceInfo);
            synchronized (CommDataServiceAgent.this.mDeviceListeners) {
                CommDataServiceAgent.this.mDeviceListeners.values().forEach(new Consumer() { // from class: com.vivo.commshare.framework.commdata.i
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((DeviceListenerWrapper) obj).onLocalDeviceStateChanged(deviceInfo);
                    }
                });
            }
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteDeviceConnected(CommDevInfo commDevInfo) throws RemoteException {
            final DeviceInfo deviceInfo = new DeviceInfo(commDevInfo);
            CommDataServiceAgent.this.logd("onRemoteDeviceConnected, remote deviceInfo:" + deviceInfo);
            CommDataServiceAgent.this.mRemoteDevInfos.put(deviceInfo.getDeviceId(), deviceInfo);
            synchronized (CommDataServiceAgent.this.mDeviceListeners) {
                CommDataServiceAgent.this.mDeviceListeners.values().forEach(new Consumer() { // from class: com.vivo.commshare.framework.commdata.e
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((DeviceListenerWrapper) obj).onRemoteDeviceConnected(deviceInfo);
                    }
                });
            }
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteDeviceDisconnected(CommDevInfo commDevInfo) throws RemoteException {
            final DeviceInfo deviceInfo = (DeviceInfo) CommDataServiceAgent.this.mRemoteDevInfos.remove(commDevInfo.deviceId);
            CommDataServiceAgent.this.logd("onRemoteDeviceDisconnected, remote deviceInfo:" + deviceInfo);
            if (deviceInfo != null) {
                synchronized (CommDataServiceAgent.this.mDeviceListeners) {
                    CommDataServiceAgent.this.mDeviceListeners.values().forEach(new Consumer() { // from class: com.vivo.commshare.framework.commdata.f
                        @Override // java.util.function.Consumer
                        public final void accept(Object obj) {
                            ((DeviceListenerWrapper) obj).onRemoteDeviceDisconnected(deviceInfo);
                        }
                    });
                }
            }
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException {
            final DeviceInfo deviceInfo = new DeviceInfo(commDevInfo);
            CommDataServiceAgent.this.logd("onRemoteDeviceStateChanged, remoteDevice:" + deviceInfo);
            synchronized (CommDataServiceAgent.this.mDeviceListeners) {
                CommDataServiceAgent.this.mDeviceListeners.values().forEach(new Consumer() { // from class: com.vivo.commshare.framework.commdata.g
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((DeviceListenerWrapper) obj).onRemoteDeviceStateChanged(deviceInfo);
                    }
                });
            }
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteReady(final String str, final boolean z2) throws RemoteException {
            CommDataServiceAgent.this.logd("onRemoteReady, remoteDevId:" + str + ", ready:" + z2);
            CommDataServiceAgent.this.mRemoteDevReady.put(str, Boolean.valueOf(z2));
            synchronized (CommDataServiceAgent.this.mDeviceListeners) {
                CommDataServiceAgent.this.mDeviceListeners.values().forEach(new Consumer() { // from class: com.vivo.commshare.framework.commdata.h
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((DeviceListenerWrapper) obj).onRemoteReady(str, z2);
                    }
                });
            }
        }
    }

    private CommDataServiceAgent(Context context, IVmdriComm iVmdriComm, CommDataManager commDataManager) throws RemoteException {
        this.mLogTag = "CommDataServiceAgent-" + Constants.getBusinessTypeName(commDataManager.getBusinessType());
        this.mContext = context;
        this.mIVmdriCommService = iVmdriComm;
        this.mVmdriCommManager = commDataManager;
        this.mIDeviceListener = new IDeviceListenerImpl();
        this.mIDataListener = new IDataListenerImpl();
        initChannel();
    }

    static CommDataServiceAgent create(Context context, IVmdriComm iVmdriComm, CommDataManager commDataManager) throws RemoteException {
        return new CommDataServiceAgent(context, iVmdriComm, commDataManager);
    }

    private void initChannel() throws RemoteException {
        this.mIDataChannel = this.mIVmdriCommService.initDataChannel(this.mVmdriCommManager.getBusinessType(), this.mIDeviceListener, this.mIDataListener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void logd(String str) {
        CommLog.d(this.mLogTag, str);
    }

    private void loge(String str) {
        CommLog.e(this.mLogTag, str);
    }

    private void logi(String str) {
        CommLog.i(this.mLogTag, str);
    }

    private void logw(String str) {
        CommLog.w(this.mLogTag, str);
    }

    public void bringUpRemoteProcess(String str) {
        try {
            this.mIVmdriCommService.bringUpRemoteProcess(str, this.mContext.getPackageName());
        } catch (RemoteException | RuntimeException e2) {
            loge("bringUpRemoteProcess, error:" + e2);
        }
    }

    @Nullable
    public CommDataChannel createDataChannel(@NonNull DataReceiver dataReceiver, @NonNull Executor executor) {
        if (dataReceiver == null || executor == null) {
            throw new IllegalArgumentException("DataReceiver and executor must not null!");
        }
        logd("createDataChannel");
        try {
            if (!this.ready) {
                this.mIDataChannel.ready();
                this.ready = true;
            }
            this.mDataReceivers.put(dataReceiver, new DataReceiverWrapper(dataReceiver, executor));
            return new CommDataChannel(this);
        } catch (RemoteException | RuntimeException e2) {
            loge("createDataChannel error:" + e2.toString());
            return null;
        }
    }

    public DeviceInfo getLocalDeviceState() {
        try {
            return new DeviceInfo(this.mIVmdriCommService.getLocalDeviceState());
        } catch (RemoteException | RuntimeException e2) {
            loge("getLocalDeviceState, error:" + e2);
            return null;
        }
    }

    public List<DeviceInfo> getRemoteDeviceState() {
        ArrayList arrayList = new ArrayList();
        try {
            Iterator<CommDevInfo> it = this.mIVmdriCommService.getRemoteDeviceState().iterator();
            while (it.hasNext()) {
                arrayList.add(new DeviceInfo(it.next()));
            }
        } catch (RemoteException | RuntimeException e2) {
            loge("getRemoteDeviceState, error:" + e2);
        }
        return arrayList;
    }

    public void registerDeviceListener(@NonNull DeviceListener deviceListener, @NonNull Executor executor) {
        if (executor == null || deviceListener == null) {
            throw new IllegalArgumentException("DeviceListener and executor must be non-null");
        }
        DeviceListenerWrapper deviceListenerWrapper = new DeviceListenerWrapper(deviceListener, executor);
        synchronized (this.mDeviceListeners) {
            try {
                if (this.mDeviceListeners.containsKey(deviceListener)) {
                    loge("registerDeviceListener, this deviceListener is contains.");
                    return;
                }
                this.mDeviceListeners.put(deviceListener, deviceListenerWrapper);
                logd("registerDeviceListener");
                if (this.mRemoteDevInfos.size() > 0) {
                    for (DeviceInfo deviceInfo : this.mRemoteDevInfos.values()) {
                        deviceListenerWrapper.onRemoteDeviceConnected(deviceInfo);
                        Boolean bool = this.mRemoteDevReady.get(deviceInfo.getDeviceId());
                        logd("registerDeviceListener, deviceInfo:" + deviceInfo + ", ready:" + bool);
                        if (bool != null) {
                            deviceListenerWrapper.onRemoteReady(deviceInfo.getDeviceId(), bool.booleanValue());
                        }
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    int sendData(String str, byte[] bArr) {
        if (!this.ready) {
            loge("sendData error: local not ready (not create channel)!");
            return 4;
        }
        if (!this.mRemoteDevInfos.containsKey(str)) {
            loge("sendData error: remote devId: " + str + " not conn!");
            return 3;
        }
        if (!this.mRemoteDevReady.containsKey(str) || !this.mRemoteDevReady.get(str).booleanValue()) {
            loge("sendData error: remote devId: " + str + " not ready!");
            return 5;
        }
        try {
            return this.mIDataChannel.sendData(str, bArr);
        } catch (RemoteException | RuntimeException e2) {
            loge("sendData error:" + e2.toString());
            return 1;
        }
    }

    public void setAudioEventParam(int i2, Bundle bundle) {
        try {
            this.mIVmdriCommService.setAudioEventParam(i2, bundle);
        } catch (RemoteException | RuntimeException e2) {
            loge("setAudioEventParam, event:" + i2 + ", error:" + e2);
        }
    }

    public int startAudioServer(String str, Bundle bundle, AudioStateListener audioStateListener, @NonNull Executor executor) {
        if (executor == null) {
            throw new IllegalArgumentException("Executor must be non-null!");
        }
        if (audioStateListener != null) {
            this.mAudioStateListener = new CommShareAudioStateListenerImpl(audioStateListener, executor);
        }
        try {
            return this.mIVmdriCommService.startAudioServer(str, bundle, this.mAudioStateListener);
        } catch (RemoteException | RuntimeException e2) {
            loge("startAudioServer, remoteDevId:" + str + ", error:" + e2);
            return -1;
        }
    }

    public void stopAudioServer(String str) {
        try {
            this.mAudioStateListener = null;
            this.mIVmdriCommService.stopAudioServer(str);
        } catch (RemoteException | RuntimeException e2) {
            loge("stopAudioServer, remoteDevId:" + str + ", error:" + e2);
        }
    }

    public void unregisterDeviceListener(@NonNull DeviceListener deviceListener) {
        synchronized (this.mDeviceListeners) {
            this.mDeviceListeners.remove(deviceListener);
        }
    }
}
