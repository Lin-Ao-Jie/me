package com.vivo.commshare.framework.commdata.internal;

import android.annotation.NonNull;
import com.vivo.commshare.framework.base.DeviceInfo;
import com.vivo.commshare.framework.commdata.callback.DeviceListener;
import java.util.Objects;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class DeviceListenerWrapper {

    @NonNull
    private final DeviceListener mDeviceListener;

    @NonNull
    private final Executor mExecutor;

    public DeviceListenerWrapper(@NonNull DeviceListener deviceListener, @NonNull Executor executor) {
        this.mDeviceListener = deviceListener;
        this.mExecutor = executor;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.mDeviceListener, ((DeviceListenerWrapper) obj).mDeviceListener);
    }

    public int hashCode() {
        return Objects.hash(this.mDeviceListener);
    }

    public void onLocalDeviceStateChanged(final DeviceInfo deviceInfo) {
        this.mExecutor.execute(new Runnable() { // from class: m.d
            @Override // java.lang.Runnable
            public final void run() {
                this.f1819a.mDeviceListener.onRemoteDeviceStateChanged(deviceInfo);
            }
        });
    }

    public void onRemoteDeviceConnected(final DeviceInfo deviceInfo) {
        this.mExecutor.execute(new Runnable() { // from class: m.c
            @Override // java.lang.Runnable
            public final void run() {
                this.f1817a.mDeviceListener.onRemoteDeviceConnected(deviceInfo);
            }
        });
    }

    public void onRemoteDeviceDisconnected(final DeviceInfo deviceInfo) {
        this.mExecutor.execute(new Runnable() { // from class: m.f
            @Override // java.lang.Runnable
            public final void run() {
                this.f1824a.mDeviceListener.onRemoteDeviceDisconnected(deviceInfo);
            }
        });
    }

    public void onRemoteDeviceStateChanged(final DeviceInfo deviceInfo) {
        this.mExecutor.execute(new Runnable() { // from class: m.b
            @Override // java.lang.Runnable
            public final void run() {
                this.f1815a.mDeviceListener.onRemoteDeviceStateChanged(deviceInfo);
            }
        });
    }

    public void onRemoteReady(final String str, final boolean z2) {
        this.mExecutor.execute(new Runnable() { // from class: m.e
            @Override // java.lang.Runnable
            public final void run() {
                this.f1821a.mDeviceListener.onRemoteReady(str, z2);
            }
        });
    }
}
