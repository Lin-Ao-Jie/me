package com.vivo.commshare.framework.base;

import android.text.TextUtils;
import com.vivo.commshare.framework.base.Constants;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.function.IntFunction;
import java.util.function.IntPredicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class Constants {
    public static final int BUSINESS_TYPE_BITMASK_DIALER_CONTACTS = 64;
    public static final int BUSINESS_TYPE_BITMASK_INCALL_UI = 16;
    public static final int BUSINESS_TYPE_BITMASK_INTERNAL = 2;
    public static final int BUSINESS_TYPE_BITMASK_PHONE = 4;
    public static final int BUSINESS_TYPE_BITMASK_SMS = 32;
    public static final int BUSINESS_TYPE_BITMASK_TELECOM = 8;
    public static final int BUSINESS_TYPE_BITMASK_TEST = 1;
    public static final int BUSINESS_TYPE_BITMASK_UNKNOWN = 0;
    public static final int BUSINESS_TYPE_DIALER_CONTACTS = 7;
    public static final int BUSINESS_TYPE_INCALL_UI = 5;
    public static final int BUSINESS_TYPE_INTERNAL = 2;
    public static final int BUSINESS_TYPE_PHONE = 3;
    public static final int BUSINESS_TYPE_SMS = 6;
    public static final int BUSINESS_TYPE_TELECOM = 4;
    public static final int BUSINESS_TYPE_TEST = 1;
    public static final int BUSINESS_TYPE_UNKNOWN = 0;
    public static final int CONN_TYPE_BITMASK_BR = 1;
    public static final int CONN_TYPE_BITMASK_P2P = 2;
    public static final int CONN_TYPE_BITMASK_UNKNOWN = 0;
    public static final int CONN_TYPE_BR = 1;
    public static final int CONN_TYPE_P2P = 2;
    public static final int CONN_TYPE_UNKNOWN = 0;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    @Retention(RetentionPolicy.SOURCE)
    public @interface BusinessType {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    @Retention(RetentionPolicy.SOURCE)
    public @interface BusinessTypeBitMask {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    @Retention(RetentionPolicy.SOURCE)
    public @interface ConnType {
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    @Retention(RetentionPolicy.SOURCE)
    public @interface ConnTypeBitMask {
    }

    public static /* synthetic */ boolean c(int i2, int i3) {
        return (i2 & getBitMaskForBusinessType(i3)) == getBitMaskForBusinessType(i3);
    }

    public static String convertBusinessTypeBitmaskToString(final int i2) {
        String str = (String) IntStream.rangeClosed(1, 7).filter(new IntPredicate() { // from class: l.a
            @Override // java.util.function.IntPredicate
            public final boolean test(int i3) {
                return Constants.c(i2, i3);
            }
        }).mapToObj(new IntFunction() { // from class: l.b
            @Override // java.util.function.IntFunction
            public final Object apply(int i3) {
                return Constants.getBusinessTypeName(i3);
            }
        }).collect(Collectors.joining("|"));
        return TextUtils.isEmpty(str) ? "UNKNOWN" : str;
    }

    public static String convertConnTypeBitmaskToString(final long j2) {
        String str = (String) IntStream.rangeClosed(1, 2).filter(new IntPredicate() { // from class: l.c
            @Override // java.util.function.IntPredicate
            public final boolean test(int i2) {
                return Constants.d(j2, i2);
            }
        }).mapToObj(new IntFunction() { // from class: l.d
            @Override // java.util.function.IntFunction
            public final Object apply(int i2) {
                return Constants.getConnTypeName(i2);
            }
        }).collect(Collectors.joining("|"));
        return TextUtils.isEmpty(str) ? "UNKNOWN" : str;
    }

    public static /* synthetic */ boolean d(long j2, int i2) {
        return (j2 & ((long) getBitMaskForConnType(i2))) == ((long) getBitMaskForConnType(i2));
    }

    public static int getBitMaskForBusinessType(int i2) {
        switch (i2) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 4;
            case 4:
                return 8;
            case 5:
                return 16;
            case 6:
                return 32;
            case 7:
                return 64;
            default:
                return 0;
        }
    }

    public static int getBitMaskForConnType(int i2) {
        int i3 = 1;
        if (i2 != 1) {
            i3 = 2;
            if (i2 != 2) {
                return 0;
            }
        }
        return i3;
    }

    public static String getBusinessTypeName(int i2) {
        switch (i2) {
            case 1:
                return "TEST";
            case 2:
                return "INTERNAL";
            case 3:
                return "PHONE";
            case 4:
                return "TELECOM";
            case 5:
                return "INCALL_UI";
            case 6:
                return "SMS";
            case 7:
                return "DIALER_CONTACTS";
            default:
                return "UNKNOWN(" + i2 + ")";
        }
    }

    public static String getConnTypeName(int i2) {
        if (i2 == 0) {
            return "UNKNOWN";
        }
        if (i2 == 1) {
            return "BR";
        }
        if (i2 == 2) {
            return "P2P";
        }
        return "UNKNOWN(" + i2 + ")";
    }
}
