package com.vivo.commshare.framework.base;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.util.Log;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommLog {
    public static void d(@Nullable String str, @NonNull String str2) {
        Log.d(str, str2);
    }

    public static void e(@Nullable String str, @NonNull String str2) {
        Log.e(str, str2);
    }

    public static void i(@Nullable String str, @NonNull String str2) {
        Log.i(str, str2);
    }

    public static void w(@Nullable String str, @NonNull String str2) {
        Log.w(str, str2);
    }

    public static void wtf(@Nullable String str, @NonNull String str2) {
        Log.w(str, str2);
    }
}
