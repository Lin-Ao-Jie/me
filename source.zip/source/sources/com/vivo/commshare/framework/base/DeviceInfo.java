package com.vivo.commshare.framework.base;

import com.vivo.commshare.CommDevInfo;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class DeviceInfo {
    private int mConnTypeBitmask;
    private String mDeviceId;
    private String mDeviceName;
    private int mDeviceType;
    private String mOpenId;
    private String mP2pIfName;
    private String mP2pIp;
    private String mVersion;

    public DeviceInfo() {
        this.mVersion = "";
        this.mDeviceType = 0;
        this.mDeviceId = "";
        this.mDeviceName = "";
        this.mOpenId = "";
        this.mConnTypeBitmask = 0;
        this.mP2pIfName = "";
        this.mP2pIp = "";
    }

    public static String convertDeviceTypeToString(int i2) {
        if (i2 == 1) {
            return "PHONE";
        }
        if (i2 == 2) {
            return "PAD";
        }
        return "UNKNOWN(" + i2 + ")";
    }

    public int getConnTypeBitmask() {
        return this.mConnTypeBitmask;
    }

    public String getDeviceId() {
        return this.mDeviceId;
    }

    public String getDeviceName() {
        return this.mDeviceName;
    }

    public int getDeviceType() {
        return this.mDeviceType;
    }

    public String getOpenId() {
        return this.mOpenId;
    }

    public String getP2pIfName() {
        return this.mP2pIfName;
    }

    public String getP2pIp() {
        return this.mP2pIp;
    }

    public String getVersion() {
        return this.mVersion;
    }

    public boolean hasBrConnType() {
        return (this.mConnTypeBitmask & 1) == 1;
    }

    public boolean hasP2pConnType() {
        return (this.mConnTypeBitmask & 2) == 2;
    }

    public String toString() {
        return "DeviceInfo{mVersion=" + this.mVersion + ", mDeviceType=" + convertDeviceTypeToString(this.mDeviceType) + ", mDeviceId='" + this.mDeviceId + "', mDeviceName='" + this.mDeviceName + "', mOpenId='" + this.mOpenId + "', mConnStateBitmask=" + Constants.convertConnTypeBitmaskToString(this.mConnTypeBitmask) + ", mP2pIfName='" + this.mP2pIfName + "', mP2pIp='" + this.mP2pIp + "'}";
    }

    public DeviceInfo(CommDevInfo commDevInfo) {
        this.mVersion = "";
        this.mDeviceType = 0;
        this.mDeviceId = "";
        this.mDeviceName = "";
        this.mOpenId = "";
        this.mConnTypeBitmask = 0;
        this.mP2pIfName = "";
        this.mP2pIp = "";
        this.mVersion = commDevInfo.version;
        this.mDeviceType = commDevInfo.deviceType;
        this.mDeviceId = commDevInfo.deviceId;
        this.mDeviceName = commDevInfo.deviceName;
        this.mConnTypeBitmask = commDevInfo.connTypeBitmask;
        this.mP2pIfName = commDevInfo.p2pIfName;
        this.mP2pIp = commDevInfo.p2pIp;
    }
}
