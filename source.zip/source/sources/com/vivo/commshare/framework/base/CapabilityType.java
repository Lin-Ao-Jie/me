package com.vivo.commshare.framework.base;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface CapabilityType {
    public static final int CALL = 1;
    public static final int DATA = 3;
    public static final int NONE = 0;
    public static final int SMS = 2;
}
