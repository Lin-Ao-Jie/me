package com.vivo.commshare.framework.commonService;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class CommonServiceConnectionCallback {
    public abstract void onConnected(CommonServiceAgent commonServiceAgent);

    public abstract void onConnectedFailed(String str);

    public abstract void onDisconnect();
}
