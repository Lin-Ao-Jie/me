package com.vivo.commshare.framework.commonService;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommonServiceCallback {
    public void onCallCapabilityChanged(String str, boolean z2) {
    }

    public void onCapabilityChanged(String str, int i2) {
    }

    public void onDataCapabilityChanged(String str, boolean z2) {
    }

    public void onSmsCapabilityChanged(String str, boolean z2) {
    }
}
