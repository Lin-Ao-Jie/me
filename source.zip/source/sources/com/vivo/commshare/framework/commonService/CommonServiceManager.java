package com.vivo.commshare.framework.commonService;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import com.vivo.commshare.ICommShare;
import com.vivo.commshare.framework.base.CommLog;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommonServiceManager {
    private static final String LOG_TAG = "CommonServiceManager";
    private static CommonServiceManager sInstance;
    private ICommShare mCommShare;
    private CommonServiceAgent mCommonServiceAgent;
    private CommonServiceConnectionCallback mCommonServiceConnectionCallback;
    private Context mContext;
    private Executor mExecutor;
    private CommonServiceConnection mCommonServiceConnection = new CommonServiceConnection();
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class CommonServiceConnection implements ServiceConnection {
        private CommonServiceConnection() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            CommonServiceManager.logd("onServiceConnected name:" + componentName + " binder:" + iBinder);
            CommonServiceManager.this.mCommShare = ICommShare.Stub.asInterface(iBinder);
            if (CommonServiceManager.this.mCommShare != null) {
                try {
                    CommonServiceManager commonServiceManager = CommonServiceManager.this;
                    commonServiceManager.mCommonServiceAgent = CommonServiceAgent.create(commonServiceManager.mContext, CommonServiceManager.this.mCommShare);
                } catch (Exception e2) {
                    CommonServiceManager.logd("onServiceConnected e = " + e2);
                    CommonServiceManager.this.mContext.unbindService(CommonServiceManager.this.mCommonServiceConnection);
                    CommonServiceManager.this.mCommonServiceConnectionCallback.onConnectedFailed(e2.toString());
                }
                if (CommonServiceManager.this.mCommonServiceAgent == null || CommonServiceManager.this.mCommonServiceConnectionCallback == null) {
                    return;
                }
                CommonServiceManager.this.mCommonServiceConnectionCallback.onConnected(CommonServiceManager.this.mCommonServiceAgent);
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            CommonServiceManager.logd("onServiceDisconnected name:" + componentName);
            CommonServiceManager.this.mCommShare = null;
        }
    }

    private CommonServiceManager(Context context) {
        logd("CommonServiceManager created.");
        this.mContext = context;
    }

    public static CommonServiceManager create(Context context) {
        CommonServiceManager commonServiceManager = new CommonServiceManager(context);
        sInstance = commonServiceManager;
        return commonServiceManager;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void logd(String str) {
        CommLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        CommLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        CommLog.i(LOG_TAG, str);
    }

    public synchronized void connectService(@NonNull CommonServiceConnectionCallback commonServiceConnectionCallback, @Nullable Executor executor) {
        try {
            logd("connectService.");
            if (commonServiceConnectionCallback == null) {
                throw new IllegalArgumentException("CommonServiceConnectionCallback must be non-null!");
            }
            if (executor == null) {
                Handler handler = this.mMainHandler;
                handler.getClass();
                executor = new com.vivo.commshare.framework.commdata.a(handler);
            }
            this.mCommonServiceConnectionCallback = commonServiceConnectionCallback;
            this.mExecutor = executor;
            if (this.mCommonServiceAgent == null) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName("com.android.phone", "com.android.phone.vivo.VivoCommShareCapabilityService"));
                boolean zBindService = this.mContext.bindService(intent, 1, executor, this.mCommonServiceConnection);
                loge("connectService, status:" + zBindService);
                if (!zBindService) {
                    this.mContext.unbindService(this.mCommonServiceConnection);
                    this.mCommonServiceConnectionCallback.onConnectedFailed("status is false, conn vmdri svc failed!");
                }
            } else {
                executor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.h
                    @Override // java.lang.Runnable
                    public final void run() {
                        CommonServiceManager commonServiceManager = this.f1145a;
                        commonServiceManager.mCommonServiceConnectionCallback.onConnected(commonServiceManager.mCommonServiceAgent);
                    }
                });
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public void disconnectService() {
        try {
            this.mContext.unbindService(this.mCommonServiceConnection);
        } catch (Exception e2) {
            loge("disconnectService e = " + e2);
        }
    }
}
