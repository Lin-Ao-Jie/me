package com.vivo.commshare.framework.commonService;

import com.vivo.commshare.framework.base.CommLog;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommonServiceCallbackWrapper {
    private static final String LOG_TAG = "CommonServiceCallbackWrapper";
    private int mCapability = 0;
    private CommonServiceCallback mCommonServiceCallback;
    private Executor mExecutor;

    public CommonServiceCallbackWrapper(CommonServiceCallback commonServiceCallback, Executor executor) {
        this.mCommonServiceCallback = commonServiceCallback;
        this.mExecutor = executor;
    }

    private static void logd(String str) {
        CommLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        CommLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        CommLog.i(LOG_TAG, str);
    }

    public CommonServiceCallback getCapabilityCallbck() {
        return this.mCommonServiceCallback;
    }

    public void onCapabilityChanged(final String str, final int i2) {
        logd("onCapabilityChanged id = " + str + " capability = " + i2 + " mCapability = " + this.mCapability);
        final int i3 = i2 & 1;
        if (i3 != (this.mCapability & 1)) {
            StringBuilder sb = new StringBuilder();
            sb.append("onCallCapabilityChanged value = ");
            sb.append(i3 != 0);
            logd(sb.toString());
            this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.a
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1124a.mCommonServiceCallback.onCallCapabilityChanged(str, i3 != 0);
                }
            });
        }
        final int i4 = i2 & 2;
        if (i4 != (this.mCapability & 2)) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("onSmsCapabilityChanged value = ");
            sb2.append(i4 != 0);
            logd(sb2.toString());
            this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.b
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1127a.mCommonServiceCallback.onSmsCapabilityChanged(str, i4 != 0);
                }
            });
        }
        final int i5 = i2 & 4;
        if (i5 != (this.mCapability & 4)) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("onDataCapabilityChanged value = ");
            sb3.append(i5 != 0);
            logd(sb3.toString());
            this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.c
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1130a.mCommonServiceCallback.onDataCapabilityChanged(str, i5 != 0);
                }
            });
        }
        if (this.mCapability != i2) {
            this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.d
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1133a.mCommonServiceCallback.onCapabilityChanged(str, i2);
                }
            });
        }
        this.mCapability = i2;
    }

    public void setInitCapability(final String str, int i2) {
        this.mCapability = i2;
        final int i3 = i2 & 1;
        this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.e
            @Override // java.lang.Runnable
            public final void run() {
                this.f1136a.mCommonServiceCallback.onCallCapabilityChanged(str, i3 != 0);
            }
        });
        final int i4 = i2 & 2;
        this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.f
            @Override // java.lang.Runnable
            public final void run() {
                this.f1139a.mCommonServiceCallback.onSmsCapabilityChanged(str, i4 != 0);
            }
        });
        final int i5 = i2 & 4;
        this.mExecutor.execute(new Runnable() { // from class: com.vivo.commshare.framework.commonService.g
            @Override // java.lang.Runnable
            public final void run() {
                this.f1142a.mCommonServiceCallback.onDataCapabilityChanged(str, i5 != 0);
            }
        });
    }
}
