package com.vivo.commshare.framework.commonService;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.content.Context;
import android.os.RemoteException;
import com.vivo.commshare.ICapabilityListener;
import com.vivo.commshare.ICommShare;
import com.vivo.commshare.framework.base.CommLog;
import java.util.HashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommonServiceAgent {
    private static final String LOG_TAG = "CommonServiceAgent";
    private ICommShare mCommShare;
    private CommonServiceCallbackWrapper mCommonServiceCallbackWrapper;
    private Context mContext;
    private Executor mExecutor;
    private HashMap<String, Integer> mCapablityMaps = new HashMap<>();
    private Object mMapLock = new Object();
    private CapabilityListenerImpl mCapabilityListenerImpl = new CapabilityListenerImpl();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class CapabilityListenerImpl extends ICapabilityListener.Stub {
        private CapabilityListenerImpl() {
        }

        @Override // com.vivo.commshare.ICapabilityListener
        public void onCapabilityChanged(String str, int i2) {
            CommonServiceAgent.logd("onCapabilityChanged id = " + str + " capability = " + i2);
            synchronized (CommonServiceAgent.this.mMapLock) {
                CommonServiceAgent.this.mCapablityMaps.put(str, Integer.valueOf(i2));
            }
            if (CommonServiceAgent.this.mCommonServiceCallbackWrapper != null) {
                CommonServiceAgent.this.mCommonServiceCallbackWrapper.onCapabilityChanged(str, i2);
            }
        }
    }

    private CommonServiceAgent(Context context, ICommShare iCommShare) {
        this.mContext = context;
        this.mCommShare = iCommShare;
    }

    public static CommonServiceAgent create(Context context, ICommShare iCommShare) throws RemoteException {
        return new CommonServiceAgent(context, iCommShare);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void logd(String str) {
        CommLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        CommLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        CommLog.i(LOG_TAG, str);
    }

    public void registerCapabilityCallback(@NonNull CommonServiceCallback commonServiceCallback, @Nullable Executor executor) throws RemoteException {
        if (commonServiceCallback == null) {
            throw new IllegalArgumentException("callback executor and deviceId must be non-null");
        }
        logd("registerCapabilityCallback.");
        this.mExecutor = executor;
        this.mCommonServiceCallbackWrapper = new CommonServiceCallbackWrapper(commonServiceCallback, executor);
        this.mCommShare.registerCallback(this.mCapabilityListenerImpl);
    }

    public void sendCallEvent(int i2, String str) throws RemoteException {
        this.mCommShare.sendCallEvent(i2, str);
    }

    public void unregisterCapabilityCallback() throws RemoteException {
        logd("unregisterCapabilityCallback.");
        this.mCommShare.unregisterCallback(this.mCapabilityListenerImpl);
        synchronized (this.mMapLock) {
            this.mCapablityMaps.clear();
        }
    }
}
