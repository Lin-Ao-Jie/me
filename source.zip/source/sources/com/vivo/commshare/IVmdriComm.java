package com.vivo.commshare;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface IVmdriComm extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.commshare.IVmdriComm";

    void bringUpRemoteProcess(String str, String str2) throws RemoteException;

    CommDevInfo getLocalDeviceState() throws RemoteException;

    List<CommDevInfo> getRemoteDeviceState() throws RemoteException;

    IDataChannel initDataChannel(int i2, IDeviceListener iDeviceListener, IDataListener iDataListener) throws RemoteException;

    void setAudioEventParam(int i2, Bundle bundle) throws RemoteException;

    int startAudioServer(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) throws RemoteException;

    void stopAudioServer(String str) throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements IVmdriComm {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.commshare.IVmdriComm
        public CommDevInfo getLocalDeviceState() throws RemoteException {
            return null;
        }

        @Override // com.vivo.commshare.IVmdriComm
        public List<CommDevInfo> getRemoteDeviceState() throws RemoteException {
            return null;
        }

        @Override // com.vivo.commshare.IVmdriComm
        public IDataChannel initDataChannel(int i2, IDeviceListener iDeviceListener, IDataListener iDataListener) throws RemoteException {
            return null;
        }

        @Override // com.vivo.commshare.IVmdriComm
        public int startAudioServer(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) throws RemoteException {
            return 0;
        }

        @Override // com.vivo.commshare.IVmdriComm
        public void stopAudioServer(String str) throws RemoteException {
        }

        @Override // com.vivo.commshare.IVmdriComm
        public void bringUpRemoteProcess(String str, String str2) throws RemoteException {
        }

        @Override // com.vivo.commshare.IVmdriComm
        public void setAudioEventParam(int i2, Bundle bundle) throws RemoteException {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements IVmdriComm {
        static final int TRANSACTION_bringUpRemoteProcess = 4;
        static final int TRANSACTION_getLocalDeviceState = 2;
        static final int TRANSACTION_getRemoteDeviceState = 3;
        static final int TRANSACTION_initDataChannel = 1;
        static final int TRANSACTION_setAudioEventParam = 7;
        static final int TRANSACTION_startAudioServer = 5;
        static final int TRANSACTION_stopAudioServer = 6;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements IVmdriComm {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            @Override // com.vivo.commshare.IVmdriComm
            public void bringUpRemoteProcess(String str, String str2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeString(str2);
                    this.mRemote.transact(4, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            public String getInterfaceDescriptor() {
                return IVmdriComm.DESCRIPTOR;
            }

            @Override // com.vivo.commshare.IVmdriComm
            public CommDevInfo getLocalDeviceState() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    this.mRemote.transact(2, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (CommDevInfo) parcelObtain2.readTypedObject(CommDevInfo.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IVmdriComm
            public List<CommDevInfo> getRemoteDeviceState() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    this.mRemote.transact(3, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.createTypedArrayList(CommDevInfo.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IVmdriComm
            public IDataChannel initDataChannel(int i2, IDeviceListener iDeviceListener, IDataListener iDataListener) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeStrongInterface(iDeviceListener);
                    parcelObtain.writeStrongInterface(iDataListener);
                    this.mRemote.transact(1, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return IDataChannel.Stub.asInterface(parcelObtain2.readStrongBinder());
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IVmdriComm
            public void setAudioEventParam(int i2, Bundle bundle) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeTypedObject(bundle, 0);
                    this.mRemote.transact(7, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IVmdriComm
            public int startAudioServer(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeTypedObject(bundle, 0);
                    parcelObtain.writeStrongInterface(iCommShareAudioStateListener);
                    this.mRemote.transact(5, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readInt();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IVmdriComm
            public void stopAudioServer(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriComm.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(6, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IVmdriComm.DESCRIPTOR);
        }

        public static IVmdriComm asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(IVmdriComm.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof IVmdriComm)) ? new Proxy(iBinder) : (IVmdriComm) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(IVmdriComm.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(IVmdriComm.DESCRIPTOR);
                return true;
            }
            switch (i2) {
                case 1:
                    int i4 = parcel.readInt();
                    IDeviceListener iDeviceListenerAsInterface = IDeviceListener.Stub.asInterface(parcel.readStrongBinder());
                    IDataListener iDataListenerAsInterface = IDataListener.Stub.asInterface(parcel.readStrongBinder());
                    parcel.enforceNoDataAvail();
                    IDataChannel iDataChannelInitDataChannel = initDataChannel(i4, iDeviceListenerAsInterface, iDataListenerAsInterface);
                    parcel2.writeNoException();
                    parcel2.writeStrongInterface(iDataChannelInitDataChannel);
                    return true;
                case 2:
                    CommDevInfo localDeviceState = getLocalDeviceState();
                    parcel2.writeNoException();
                    parcel2.writeTypedObject(localDeviceState, 1);
                    return true;
                case 3:
                    List<CommDevInfo> remoteDeviceState = getRemoteDeviceState();
                    parcel2.writeNoException();
                    parcel2.writeTypedList(remoteDeviceState, 1);
                    return true;
                case 4:
                    String string = parcel.readString();
                    String string2 = parcel.readString();
                    parcel.enforceNoDataAvail();
                    bringUpRemoteProcess(string, string2);
                    return true;
                case 5:
                    String string3 = parcel.readString();
                    Bundle bundle = (Bundle) parcel.readTypedObject(Bundle.CREATOR);
                    ICommShareAudioStateListener iCommShareAudioStateListenerAsInterface = ICommShareAudioStateListener.Stub.asInterface(parcel.readStrongBinder());
                    parcel.enforceNoDataAvail();
                    int iStartAudioServer = startAudioServer(string3, bundle, iCommShareAudioStateListenerAsInterface);
                    parcel2.writeNoException();
                    parcel2.writeInt(iStartAudioServer);
                    return true;
                case 6:
                    String string4 = parcel.readString();
                    parcel.enforceNoDataAvail();
                    stopAudioServer(string4);
                    return true;
                case 7:
                    int i5 = parcel.readInt();
                    Bundle bundle2 = (Bundle) parcel.readTypedObject(Bundle.CREATOR);
                    parcel.enforceNoDataAvail();
                    setAudioEventParam(i5, bundle2);
                    return true;
                default:
                    return super.onTransact(i2, parcel, parcel2, i3);
            }
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
