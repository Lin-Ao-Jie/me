package com.vivo.commshare;

import java.lang.reflect.Array;
import java.util.StringJoiner;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface Capality$$ {
    static String arrayToString(Object obj) {
        if (obj == null) {
            return "null";
        }
        Class<?> cls = obj.getClass();
        if (!cls.isArray()) {
            throw new IllegalArgumentException("not an array: " + obj);
        }
        Class<?> componentType = cls.getComponentType();
        StringJoiner stringJoiner = new StringJoiner(", ", "[", "]");
        int i2 = 0;
        if (componentType.isArray()) {
            while (i2 < Array.getLength(obj)) {
                stringJoiner.add(arrayToString(Array.get(obj, i2)));
                i2++;
            }
        } else {
            if (cls != int[].class) {
                throw new IllegalArgumentException("wrong type: " + cls);
            }
            int[] iArr = (int[]) obj;
            int length = iArr.length;
            while (i2 < length) {
                stringJoiner.add(toString(iArr[i2]));
                i2++;
            }
        }
        return stringJoiner.toString();
    }

    static String toString(int i2) {
        if (i2 == 0) {
            return "NONE";
        }
        if (i2 == 1) {
            return "CALL";
        }
        if (i2 == 2) {
            return "SMS";
        }
        return i2 == 4 ? "DATA" : Integer.toString(i2);
    }
}
