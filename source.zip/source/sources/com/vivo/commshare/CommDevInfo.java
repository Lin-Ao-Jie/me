package com.vivo.commshare;

import android.os.BadParcelableException;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Objects;
import java.util.StringJoiner;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CommDevInfo implements Parcelable {
    public static final Parcelable.Creator<CommDevInfo> CREATOR = new Parcelable.Creator<CommDevInfo>() { // from class: com.vivo.commshare.CommDevInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CommDevInfo createFromParcel(Parcel parcel) {
            CommDevInfo commDevInfo = new CommDevInfo();
            commDevInfo.readFromParcel(parcel);
            return commDevInfo;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public CommDevInfo[] newArray(int i2) {
            return new CommDevInfo[i2];
        }
    };
    public String deviceId;
    public String deviceName;
    public String openId;
    public String p2pIfName;
    public String p2pIp;
    public String version;
    public int deviceType = 0;
    public int connTypeBitmask = 0;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final void readFromParcel(Parcel parcel) {
        int iDataPosition = parcel.dataPosition();
        int i2 = parcel.readInt();
        try {
            if (i2 < 4) {
                throw new BadParcelableException("Parcelable too small");
            }
            if (parcel.dataPosition() - iDataPosition < i2) {
                this.version = parcel.readString();
                if (parcel.dataPosition() - iDataPosition < i2) {
                    this.deviceType = parcel.readInt();
                    if (parcel.dataPosition() - iDataPosition < i2) {
                        this.deviceId = parcel.readString();
                        if (parcel.dataPosition() - iDataPosition < i2) {
                            this.deviceName = parcel.readString();
                            if (parcel.dataPosition() - iDataPosition < i2) {
                                this.openId = parcel.readString();
                                if (parcel.dataPosition() - iDataPosition < i2) {
                                    this.connTypeBitmask = parcel.readInt();
                                    if (parcel.dataPosition() - iDataPosition < i2) {
                                        this.p2pIfName = parcel.readString();
                                        if (parcel.dataPosition() - iDataPosition < i2) {
                                            this.p2pIp = parcel.readString();
                                            if (iDataPosition > Integer.MAX_VALUE - i2) {
                                                throw new BadParcelableException("Overflow in the size of parcelable");
                                            }
                                        } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                                            throw new BadParcelableException("Overflow in the size of parcelable");
                                        }
                                    } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                                        throw new BadParcelableException("Overflow in the size of parcelable");
                                    }
                                } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                                    throw new BadParcelableException("Overflow in the size of parcelable");
                                }
                            } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                                throw new BadParcelableException("Overflow in the size of parcelable");
                            }
                        } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                            throw new BadParcelableException("Overflow in the size of parcelable");
                        }
                    } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                        throw new BadParcelableException("Overflow in the size of parcelable");
                    }
                } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                    throw new BadParcelableException("Overflow in the size of parcelable");
                }
            } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                throw new BadParcelableException("Overflow in the size of parcelable");
            }
            parcel.setDataPosition(iDataPosition + i2);
        } catch (Throwable th) {
            if (iDataPosition > Integer.MAX_VALUE - i2) {
                throw new BadParcelableException("Overflow in the size of parcelable");
            }
            parcel.setDataPosition(iDataPosition + i2);
            throw th;
        }
    }

    public String toString() {
        StringJoiner stringJoiner = new StringJoiner(", ", "{", "}");
        stringJoiner.add("version: " + Objects.toString(this.version));
        stringJoiner.add("deviceType: " + this.deviceType);
        stringJoiner.add("deviceId: " + Objects.toString(this.deviceId));
        stringJoiner.add("deviceName: " + Objects.toString(this.deviceName));
        stringJoiner.add("openId: " + Objects.toString(this.openId));
        stringJoiner.add("connTypeBitmask: " + this.connTypeBitmask);
        stringJoiner.add("p2pIfName: " + Objects.toString(this.p2pIfName));
        stringJoiner.add("p2pIp: " + Objects.toString(this.p2pIp));
        return "CommDevInfo" + stringJoiner.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        int iDataPosition = parcel.dataPosition();
        parcel.writeInt(0);
        parcel.writeString(this.version);
        parcel.writeInt(this.deviceType);
        parcel.writeString(this.deviceId);
        parcel.writeString(this.deviceName);
        parcel.writeString(this.openId);
        parcel.writeInt(this.connTypeBitmask);
        parcel.writeString(this.p2pIfName);
        parcel.writeString(this.p2pIp);
        int iDataPosition2 = parcel.dataPosition();
        parcel.setDataPosition(iDataPosition);
        parcel.writeInt(iDataPosition2 - iDataPosition);
        parcel.setDataPosition(iDataPosition2);
    }
}
