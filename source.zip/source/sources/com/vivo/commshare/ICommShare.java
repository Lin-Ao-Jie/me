package com.vivo.commshare;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface ICommShare extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.commshare.ICommShare";

    void registerCallback(ICapabilityListener iCapabilityListener) throws RemoteException;

    void sendCallEvent(int i2, String str) throws RemoteException;

    void unregisterCallback(ICapabilityListener iCapabilityListener) throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements ICommShare {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.commshare.ICommShare
        public void registerCallback(ICapabilityListener iCapabilityListener) throws RemoteException {
        }

        @Override // com.vivo.commshare.ICommShare
        public void unregisterCallback(ICapabilityListener iCapabilityListener) throws RemoteException {
        }

        @Override // com.vivo.commshare.ICommShare
        public void sendCallEvent(int i2, String str) throws RemoteException {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements ICommShare {
        static final int TRANSACTION_registerCallback = 1;
        static final int TRANSACTION_sendCallEvent = 3;
        static final int TRANSACTION_unregisterCallback = 2;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements ICommShare {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return ICommShare.DESCRIPTOR;
            }

            @Override // com.vivo.commshare.ICommShare
            public void registerCallback(ICapabilityListener iCapabilityListener) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(ICommShare.DESCRIPTOR);
                    parcelObtain.writeStrongInterface(iCapabilityListener);
                    this.mRemote.transact(1, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.ICommShare
            public void sendCallEvent(int i2, String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(ICommShare.DESCRIPTOR);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(3, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.ICommShare
            public void unregisterCallback(ICapabilityListener iCapabilityListener) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(ICommShare.DESCRIPTOR);
                    parcelObtain.writeStrongInterface(iCapabilityListener);
                    this.mRemote.transact(2, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, ICommShare.DESCRIPTOR);
        }

        public static ICommShare asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(ICommShare.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof ICommShare)) ? new Proxy(iBinder) : (ICommShare) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(ICommShare.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(ICommShare.DESCRIPTOR);
                return true;
            }
            if (i2 == 1) {
                ICapabilityListener iCapabilityListenerAsInterface = ICapabilityListener.Stub.asInterface(parcel.readStrongBinder());
                parcel.enforceNoDataAvail();
                registerCallback(iCapabilityListenerAsInterface);
                parcel2.writeNoException();
            } else if (i2 == 2) {
                ICapabilityListener iCapabilityListenerAsInterface2 = ICapabilityListener.Stub.asInterface(parcel.readStrongBinder());
                parcel.enforceNoDataAvail();
                unregisterCallback(iCapabilityListenerAsInterface2);
                parcel2.writeNoException();
            } else {
                if (i2 != 3) {
                    return super.onTransact(i2, parcel, parcel2, i3);
                }
                int i4 = parcel.readInt();
                String string = parcel.readString();
                parcel.enforceNoDataAvail();
                sendCallEvent(i4, string);
                parcel2.writeNoException();
            }
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
