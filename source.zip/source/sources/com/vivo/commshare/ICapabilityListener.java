package com.vivo.commshare;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface ICapabilityListener extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.commshare.ICapabilityListener";

    void onCapabilityChanged(String str, int i2) throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements ICapabilityListener {
        static final int TRANSACTION_onCapabilityChanged = 1;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements ICapabilityListener {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return ICapabilityListener.DESCRIPTOR;
            }

            @Override // com.vivo.commshare.ICapabilityListener
            public void onCapabilityChanged(String str, int i2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(ICapabilityListener.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(i2);
                    this.mRemote.transact(1, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, ICapabilityListener.DESCRIPTOR);
        }

        public static ICapabilityListener asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(ICapabilityListener.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof ICapabilityListener)) ? new Proxy(iBinder) : (ICapabilityListener) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(ICapabilityListener.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(ICapabilityListener.DESCRIPTOR);
                return true;
            }
            if (i2 != 1) {
                return super.onTransact(i2, parcel, parcel2, i3);
            }
            String string = parcel.readString();
            int i4 = parcel.readInt();
            parcel.enforceNoDataAvail();
            onCapabilityChanged(string, i4);
            parcel2.writeNoException();
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements ICapabilityListener {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.commshare.ICapabilityListener
        public void onCapabilityChanged(String str, int i2) throws RemoteException {
        }
    }
}
