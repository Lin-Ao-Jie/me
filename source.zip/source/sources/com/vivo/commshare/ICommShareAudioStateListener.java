package com.vivo.commshare;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface ICommShareAudioStateListener extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.commshare.ICommShareAudioStateListener";

    void onAudioDataRttUpdate(long j2) throws RemoteException;

    void onAudioStateStateChanged(Bundle bundle) throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements ICommShareAudioStateListener {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.commshare.ICommShareAudioStateListener
        public void onAudioDataRttUpdate(long j2) throws RemoteException {
        }

        @Override // com.vivo.commshare.ICommShareAudioStateListener
        public void onAudioStateStateChanged(Bundle bundle) throws RemoteException {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements ICommShareAudioStateListener {
        static final int TRANSACTION_onAudioDataRttUpdate = 2;
        static final int TRANSACTION_onAudioStateStateChanged = 1;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements ICommShareAudioStateListener {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return ICommShareAudioStateListener.DESCRIPTOR;
            }

            @Override // com.vivo.commshare.ICommShareAudioStateListener
            public void onAudioDataRttUpdate(long j2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(ICommShareAudioStateListener.DESCRIPTOR);
                    parcelObtain.writeLong(j2);
                    this.mRemote.transact(2, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.ICommShareAudioStateListener
            public void onAudioStateStateChanged(Bundle bundle) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(ICommShareAudioStateListener.DESCRIPTOR);
                    parcelObtain.writeTypedObject(bundle, 0);
                    this.mRemote.transact(1, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, ICommShareAudioStateListener.DESCRIPTOR);
        }

        public static ICommShareAudioStateListener asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(ICommShareAudioStateListener.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof ICommShareAudioStateListener)) ? new Proxy(iBinder) : (ICommShareAudioStateListener) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(ICommShareAudioStateListener.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(ICommShareAudioStateListener.DESCRIPTOR);
                return true;
            }
            if (i2 == 1) {
                Bundle bundle = (Bundle) parcel.readTypedObject(Bundle.CREATOR);
                parcel.enforceNoDataAvail();
                onAudioStateStateChanged(bundle);
            } else {
                if (i2 != 2) {
                    return super.onTransact(i2, parcel, parcel2, i3);
                }
                long j2 = parcel.readLong();
                parcel.enforceNoDataAvail();
                onAudioDataRttUpdate(j2);
            }
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
