package com.vivo.commshare;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface IDeviceListener extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.commshare.IDeviceListener";

    void onLocalDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException;

    void onRemoteDeviceConnected(CommDevInfo commDevInfo) throws RemoteException;

    void onRemoteDeviceDisconnected(CommDevInfo commDevInfo) throws RemoteException;

    void onRemoteDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException;

    void onRemoteReady(String str, boolean z2) throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements IDeviceListener {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onLocalDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException {
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteDeviceConnected(CommDevInfo commDevInfo) throws RemoteException {
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteDeviceDisconnected(CommDevInfo commDevInfo) throws RemoteException {
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException {
        }

        @Override // com.vivo.commshare.IDeviceListener
        public void onRemoteReady(String str, boolean z2) throws RemoteException {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements IDeviceListener {
        static final int TRANSACTION_onLocalDeviceStateChanged = 5;
        static final int TRANSACTION_onRemoteDeviceConnected = 1;
        static final int TRANSACTION_onRemoteDeviceDisconnected = 2;
        static final int TRANSACTION_onRemoteDeviceStateChanged = 3;
        static final int TRANSACTION_onRemoteReady = 4;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements IDeviceListener {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IDeviceListener.DESCRIPTOR;
            }

            @Override // com.vivo.commshare.IDeviceListener
            public void onLocalDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IDeviceListener.DESCRIPTOR);
                    parcelObtain.writeTypedObject(commDevInfo, 0);
                    this.mRemote.transact(5, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IDeviceListener
            public void onRemoteDeviceConnected(CommDevInfo commDevInfo) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IDeviceListener.DESCRIPTOR);
                    parcelObtain.writeTypedObject(commDevInfo, 0);
                    this.mRemote.transact(1, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IDeviceListener
            public void onRemoteDeviceDisconnected(CommDevInfo commDevInfo) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IDeviceListener.DESCRIPTOR);
                    parcelObtain.writeTypedObject(commDevInfo, 0);
                    this.mRemote.transact(2, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IDeviceListener
            public void onRemoteDeviceStateChanged(CommDevInfo commDevInfo) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IDeviceListener.DESCRIPTOR);
                    parcelObtain.writeTypedObject(commDevInfo, 0);
                    this.mRemote.transact(3, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.commshare.IDeviceListener
            public void onRemoteReady(String str, boolean z2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IDeviceListener.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeBoolean(z2);
                    this.mRemote.transact(4, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IDeviceListener.DESCRIPTOR);
        }

        public static IDeviceListener asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(IDeviceListener.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof IDeviceListener)) ? new Proxy(iBinder) : (IDeviceListener) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(IDeviceListener.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(IDeviceListener.DESCRIPTOR);
                return true;
            }
            if (i2 == 1) {
                CommDevInfo commDevInfo = (CommDevInfo) parcel.readTypedObject(CommDevInfo.CREATOR);
                parcel.enforceNoDataAvail();
                onRemoteDeviceConnected(commDevInfo);
            } else if (i2 == 2) {
                CommDevInfo commDevInfo2 = (CommDevInfo) parcel.readTypedObject(CommDevInfo.CREATOR);
                parcel.enforceNoDataAvail();
                onRemoteDeviceDisconnected(commDevInfo2);
            } else if (i2 == 3) {
                CommDevInfo commDevInfo3 = (CommDevInfo) parcel.readTypedObject(CommDevInfo.CREATOR);
                parcel.enforceNoDataAvail();
                onRemoteDeviceStateChanged(commDevInfo3);
            } else if (i2 == 4) {
                String string = parcel.readString();
                boolean z2 = parcel.readBoolean();
                parcel.enforceNoDataAvail();
                onRemoteReady(string, z2);
            } else {
                if (i2 != 5) {
                    return super.onTransact(i2, parcel, parcel2, i3);
                }
                CommDevInfo commDevInfo4 = (CommDevInfo) parcel.readTypedObject(CommDevInfo.CREATOR);
                parcel.enforceNoDataAvail();
                onLocalDeviceStateChanged(commDevInfo4);
            }
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
