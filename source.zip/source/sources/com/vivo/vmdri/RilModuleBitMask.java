package com.vivo.vmdri;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public @interface RilModuleBitMask {
    public static final int CONFIG = 2;
    public static final int DATA = 4;
    public static final int DEVICE_CONFIG = 1024;
    public static final int IMS = 256;
    public static final int MESSAGING = 8;
    public static final int MODEM = 16;
    public static final int NETWORK = 32;
    public static final int OEM = 512;
    public static final int SIM = 64;
    public static final int UNKNOWN = 1;
    public static final int VOICE = 128;
}
