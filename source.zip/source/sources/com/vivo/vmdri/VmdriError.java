package com.vivo.vmdri;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public @interface VmdriError {
    public static final int DEVICE_NOT_CONN = 3;
    public static final int GENERIC_FAILURE = 1;
    public static final int LOCAL_NOT_READY = 4;
    public static final int NONE = 0;
    public static final int NOT_SUPPORTED = 2;
    public static final int REMOTE_NOT_READY = 5;
    public static final int RESP_TIME_OUT = 6;
    public static final int RIL_INTERNAL_ERROR_START = 5000;
    public static final int SDK_ERROR = 7;
}
