package com.vivo.vmdri;

import android.annotation.NonNull;
import android.os.FtBuild;
import android.text.TextUtils;
import com.vivo.vmdri.ctrl.t;
import d0.l;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.Locale;
import w.d;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriUtils {
    public static boolean AT_LEAST_ROM_15_0 = false;
    public static final String LOG_TAG = "VmdriUtils";
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    static {
        AT_LEAST_ROM_15_0 = FtBuild.getRomVersion() >= 15.0f;
    }

    public static String convertByteToHexString(byte[] bArr) {
        return (bArr == null || bArr.length == 0) ? "null" : HexFormat.of().formatHex(bArr);
    }

    public static String convertCommShareDataCallList(String str, String str2) {
        if (str2 == null) {
            return null;
        }
        String str3 = "###CommShareDataCallList###\n[" + str + "]" + str2;
        logd("convertCommShareDataCallList:" + str3);
        return str3;
    }

    public static String convertDevInfoToLocalLogMessage(String str, d dVar, d dVar2, t tVar, String str2) {
        String string;
        if (dVar == null) {
            return null;
        }
        if (tVar == null) {
            string = dVar2 == null ? "null" : dVar2.toString();
        } else {
            string = tVar.toString();
        }
        String str3 = "###CommShareDevInfo###" + str + "###\nlocalDev=" + dVar.toString() + "\nremoteDev=" + string + "\nextraInfo=" + str2;
        logd("convertDevInfoToLocalLogMessage:" + str3);
        return str3;
    }

    public static String convertIpAddress(String str) {
        StringBuilder sb = new StringBuilder();
        String[] strArrSplit = str.split("\\.");
        if (strArrSplit.length == 4) {
            sb.append("*");
            sb.append(".");
            sb.append("*");
            sb.append(".");
            sb.append(strArrSplit[2]);
            sb.append(".");
            sb.append(strArrSplit[3]);
        }
        return sb.toString();
    }

    public static String getIfNameByAddr(String str) {
        l lVarY;
        String strX = "";
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces != null && networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterfaceNextElement = networkInterfaces.nextElement();
                if (networkInterfaceNextElement.isUp()) {
                    Iterator<InterfaceAddress> it = networkInterfaceNextElement.getInterfaceAddresses().iterator();
                    while (it.hasNext()) {
                        if (str.equals(it.next().getAddress().getHostAddress())) {
                            strX = networkInterfaceNextElement.getName();
                            break;
                        }
                    }
                    if (!TextUtils.isEmpty(strX)) {
                        logd("getIfNameByAddr if:" + strX + ", ip:" + convertIpAddress(str));
                        break;
                    }
                }
            }
        } catch (SocketException e2) {
            e2.printStackTrace();
        }
        if (TextUtils.isEmpty(strX) && (lVarY = l.Y()) != null) {
            strX = lVarY.X(str);
        }
        logd("getIfNameByAddr if:" + strX + ", ip:" + convertIpAddress(str));
        return strX;
    }

    public static boolean isSameDay(Calendar calendar, Calendar calendar2) {
        if (calendar == null && calendar2 == null) {
            return true;
        }
        if (calendar != null && calendar2 != null) {
            int i2 = calendar.get(1);
            int i3 = calendar.get(6);
            int i4 = calendar2.get(1);
            int i5 = calendar2.get(6);
            if (i2 == i4 && i3 == i5) {
                return true;
            }
        }
        return false;
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    @NonNull
    public static String systemTimeToString(long j2) {
        return j2 != 0 ? TIME_FORMAT.format(Long.valueOf(j2)) : "never";
    }
}
