package com.vivo.vmdri;

import android.annotation.NonNull;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.ArraySet;
import c0.u0;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import w.i;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class DependentServiceController extends Handler {
    public static final int EVENT_WAIT_ALL_SERVICE_BOUND = 1;
    public static final String LOG_TAG = "DependentServiceController";
    static final int WAIT_BOUND_MAX_RETRY = 10;
    static final int WAIT_BOUND_RETRY_MILLIS = 100;
    private static final Object mLock = new Object();
    private static DependentServiceController sInstance;
    private boolean mCapabilityServiceBound;
    private final Context mContext;

    @NonNull
    private final Set<DependentServiceCallback> mDependentServiceCallbacks;
    private boolean mNeedBind;
    private final HashMap<String, i> mRemoteDevInfos;
    private boolean mRilBound;

    private DependentServiceController(Context context, Looper looper) {
        super(looper);
        this.mNeedBind = false;
        this.mRilBound = false;
        this.mCapabilityServiceBound = false;
        this.mRemoteDevInfos = new HashMap<>();
        this.mDependentServiceCallbacks = new ArraySet();
        this.mContext = context;
        u0.r().O(new u0.d() { // from class: com.vivo.vmdri.DependentServiceController.1
            @Override // c0.u0.d
            public void onSdkStateChanged(int i2) {
                DependentServiceController.this.handleSdkStateChanged(i2);
            }

            @Override // c0.u0.d
            public void onRemoteDeviceConnStatusChanged(@NonNull i iVar, int i2, int i3) {
            }
        });
    }

    public static /* synthetic */ void a(DependentServiceCallback dependentServiceCallback) {
        dependentServiceCallback.getClass();
        dependentServiceCallback.invokeFromExecutor(new a(dependentServiceCallback));
    }

    public static DependentServiceController create(Context context, Looper looper) {
        DependentServiceController dependentServiceController;
        synchronized (mLock) {
            try {
                if (sInstance != null) {
                    throw new RuntimeException("DependentServiceController already created!");
                }
                dependentServiceController = new DependentServiceController(context, looper);
                sInstance = dependentServiceController;
            } catch (Throwable th) {
                throw th;
            }
        }
        return dependentServiceController;
    }

    public static DependentServiceController getInstance() {
        DependentServiceController dependentServiceController = sInstance;
        if (dependentServiceController != null) {
            return dependentServiceController;
        }
        throw new RuntimeException("DependentServiceController.getInstance can't be called before create()");
    }

    private void handleRemoteDeviceConnStatusChanged(@NonNull i iVar, int i2, int i3) {
        String strD = iVar.d();
        synchronized (this) {
            try {
                if (iVar.k()) {
                    if (!this.mRemoteDevInfos.containsKey(strD)) {
                        this.mNeedBind = true;
                        notifyStartBindDependentServiceIfNeed();
                    }
                    this.mRemoteDevInfos.put(strD, iVar);
                } else {
                    this.mRemoteDevInfos.remove(strD);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleSdkStateChanged(int i2) {
        synchronized (this) {
            if (i2 == 2) {
                try {
                    this.mNeedBind = true;
                    notifyStartBindDependentServiceIfNeed();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    private boolean isRunningOnVmdriMainThread() {
        return ThreadManager.getVmdriMainLooper().getThread() == Thread.currentThread();
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    private static void logw(String str) {
        VmdriLog.w(LOG_TAG, str);
    }

    private void notifyStartBindDependentServiceIfNeed() {
        synchronized (this) {
            try {
                if (isAllServiceBound()) {
                    return;
                }
                sendMessageAtFrontOfQueue(obtainMessage(1, 1, -1));
                logd("notifyStartBindDependentServiceIfNeed");
                this.mDependentServiceCallbacks.forEach(new Consumer() { // from class: com.vivo.vmdri.b
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        DependentServiceController.a((DependentServiceController.DependentServiceCallback) obj);
                    }
                });
                sendMessage(obtainMessage(1, 2, -1));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private void waitServiceBound(int i2) {
        boolean zIsAllServiceBound;
        if (!isRunningOnVmdriMainThread()) {
            logw("waitServiceBound, is run on thread:" + Thread.currentThread().toString() + ", my thread:" + getLooper().getThread().toString());
        }
        int i3 = 0;
        do {
            zIsAllServiceBound = isAllServiceBound();
            if (!zIsAllServiceBound) {
                i3++;
                logd("waitServiceBound retry(" + i3 + ")");
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException unused) {
                }
            }
            if (zIsAllServiceBound) {
                break;
            }
        } while (i3 < 10);
        if (zIsAllServiceBound) {
            logd("waitServiceBound(" + i2 + ") all service bound on " + (i3 * 100) + "ms");
            return;
        }
        logw("waitServiceBound(" + i2 + ")service bound failed on " + (i3 * 100) + "ms");
    }

    @Override // android.os.Handler
    public void handleMessage(@NonNull Message message) {
        super.handleMessage(message);
        if (message.what == 1) {
            waitServiceBound(message.arg1);
            return;
        }
        loge("unsupported message:" + message.what);
    }

    public boolean isAllServiceBound() {
        boolean z2;
        synchronized (this) {
            try {
                z2 = this.mRilBound && this.mCapabilityServiceBound;
            } catch (Throwable th) {
                throw th;
            }
        }
        return z2;
    }

    public boolean isCapabilityServiceBound() {
        boolean z2;
        synchronized (this) {
            z2 = this.mCapabilityServiceBound;
        }
        return z2;
    }

    public boolean isNeedBind() {
        boolean z2;
        synchronized (this) {
            z2 = this.mNeedBind;
        }
        return z2;
    }

    public boolean isRilBound() {
        boolean z2;
        synchronized (this) {
            z2 = this.mRilBound;
        }
        return z2;
    }

    public void registerDependentServiceCallback(@NonNull DependentServiceCallback dependentServiceCallback) {
        synchronized (this) {
            try {
                this.mDependentServiceCallbacks.add(dependentServiceCallback);
                if (this.mNeedBind) {
                    dependentServiceCallback.getClass();
                    dependentServiceCallback.invokeFromExecutor(new a(dependentServiceCallback));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void setCapabilityServiceBound(boolean z2) {
        logd("setCapabilityServiceBound:" + z2);
        synchronized (this) {
            this.mCapabilityServiceBound = z2;
        }
    }

    public void setRilBound(boolean z2) {
        logd("setRilBound:" + z2);
        synchronized (this) {
            this.mRilBound = z2;
        }
    }

    public void unregisterDependentServiceCallback(@NonNull DependentServiceCallback dependentServiceCallback) {
        synchronized (this) {
            this.mDependentServiceCallbacks.remove(dependentServiceCallback);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class DependentServiceCallback extends w.a {
        public DependentServiceCallback(@NonNull Executor executor) {
            super(executor);
        }

        public void tryStartBindDependentService() {
        }
    }
}
