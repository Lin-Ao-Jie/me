package com.vivo.vmdri;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface IVmdriServerHandle extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.vmdri.IVmdriServerHandle";

    DeviceParcel getLocalDeviceInfo() throws RemoteException;

    P2pInfoParcel getLocalP2pInfo() throws RemoteException;

    List<DeviceParcel> getRemoteDeviceInfo() throws RemoteException;

    P2pInfoParcel getRemoteP2pInfo(String str) throws RemoteException;

    boolean getRemoteScreenState(String str) throws RemoteException;

    int getSwitchState(String str) throws RemoteException;

    void sendIndRilMsg(String str, int i2, int i3, int i4, byte[] bArr) throws RemoteException;

    void sendIndRilMsgToAll(int i2, int i3, int i4, byte[] bArr) throws RemoteException;

    void sendRespRilMsg(String str, int i2, int i3, int i4, byte[] bArr, int i5) throws RemoteException;

    void serverRilReady() throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements IVmdriServerHandle {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public DeviceParcel getLocalDeviceInfo() throws RemoteException {
            return null;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public P2pInfoParcel getLocalP2pInfo() throws RemoteException {
            return null;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public List<DeviceParcel> getRemoteDeviceInfo() throws RemoteException {
            return null;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public P2pInfoParcel getRemoteP2pInfo(String str) throws RemoteException {
            return null;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public boolean getRemoteScreenState(String str) throws RemoteException {
            return false;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public int getSwitchState(String str) throws RemoteException {
            return 0;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void serverRilReady() throws RemoteException {
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void sendRespRilMsg(String str, int i2, int i3, int i4, byte[] bArr, int i5) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void sendIndRilMsg(String str, int i2, int i3, int i4, byte[] bArr) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void sendIndRilMsgToAll(int i2, int i3, int i4, byte[] bArr) throws RemoteException {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements IVmdriServerHandle {
        static final int TRANSACTION_getLocalDeviceInfo = 5;
        static final int TRANSACTION_getLocalP2pInfo = 6;
        static final int TRANSACTION_getRemoteDeviceInfo = 7;
        static final int TRANSACTION_getRemoteP2pInfo = 8;
        static final int TRANSACTION_getRemoteScreenState = 9;
        static final int TRANSACTION_getSwitchState = 10;
        static final int TRANSACTION_sendIndRilMsg = 3;
        static final int TRANSACTION_sendIndRilMsgToAll = 4;
        static final int TRANSACTION_sendRespRilMsg = 2;
        static final int TRANSACTION_serverRilReady = 1;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements IVmdriServerHandle {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IVmdriServerHandle.DESCRIPTOR;
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public DeviceParcel getLocalDeviceInfo() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    this.mRemote.transact(5, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (DeviceParcel) parcelObtain2.readTypedObject(DeviceParcel.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public P2pInfoParcel getLocalP2pInfo() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    this.mRemote.transact(6, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (P2pInfoParcel) parcelObtain2.readTypedObject(P2pInfoParcel.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public List<DeviceParcel> getRemoteDeviceInfo() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    this.mRemote.transact(7, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.createTypedArrayList(DeviceParcel.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public P2pInfoParcel getRemoteP2pInfo(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(8, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return (P2pInfoParcel) parcelObtain2.readTypedObject(P2pInfoParcel.CREATOR);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public boolean getRemoteScreenState(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(9, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readBoolean();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public int getSwitchState(String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(10, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    return parcelObtain2.readInt();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public void sendIndRilMsg(String str, int i2, int i3, int i4, byte[] bArr) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeInt(i3);
                    parcelObtain.writeInt(i4);
                    parcelObtain.writeByteArray(bArr);
                    this.mRemote.transact(3, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public void sendIndRilMsgToAll(int i2, int i3, int i4, byte[] bArr) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeInt(i3);
                    parcelObtain.writeInt(i4);
                    parcelObtain.writeByteArray(bArr);
                    this.mRemote.transact(4, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public void sendRespRilMsg(String str, int i2, int i3, int i4, byte[] bArr, int i5) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeInt(i3);
                    parcelObtain.writeInt(i4);
                    parcelObtain.writeByteArray(bArr);
                    parcelObtain.writeInt(i5);
                    this.mRemote.transact(2, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IVmdriServerHandle
            public void serverRilReady() throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IVmdriServerHandle.DESCRIPTOR);
                    this.mRemote.transact(1, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IVmdriServerHandle.DESCRIPTOR);
        }

        public static IVmdriServerHandle asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(IVmdriServerHandle.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof IVmdriServerHandle)) ? new Proxy(iBinder) : (IVmdriServerHandle) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(IVmdriServerHandle.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(IVmdriServerHandle.DESCRIPTOR);
                return true;
            }
            switch (i2) {
                case 1:
                    serverRilReady();
                    return true;
                case 2:
                    String string = parcel.readString();
                    int i4 = parcel.readInt();
                    int i5 = parcel.readInt();
                    int i6 = parcel.readInt();
                    byte[] bArrCreateByteArray = parcel.createByteArray();
                    int i7 = parcel.readInt();
                    parcel.enforceNoDataAvail();
                    sendRespRilMsg(string, i4, i5, i6, bArrCreateByteArray, i7);
                    return true;
                case 3:
                    String string2 = parcel.readString();
                    int i8 = parcel.readInt();
                    int i9 = parcel.readInt();
                    int i10 = parcel.readInt();
                    byte[] bArrCreateByteArray2 = parcel.createByteArray();
                    parcel.enforceNoDataAvail();
                    sendIndRilMsg(string2, i8, i9, i10, bArrCreateByteArray2);
                    return true;
                case 4:
                    int i11 = parcel.readInt();
                    int i12 = parcel.readInt();
                    int i13 = parcel.readInt();
                    byte[] bArrCreateByteArray3 = parcel.createByteArray();
                    parcel.enforceNoDataAvail();
                    sendIndRilMsgToAll(i11, i12, i13, bArrCreateByteArray3);
                    return true;
                case 5:
                    DeviceParcel localDeviceInfo = getLocalDeviceInfo();
                    parcel2.writeNoException();
                    parcel2.writeTypedObject(localDeviceInfo, 1);
                    return true;
                case 6:
                    P2pInfoParcel localP2pInfo = getLocalP2pInfo();
                    parcel2.writeNoException();
                    parcel2.writeTypedObject(localP2pInfo, 1);
                    return true;
                case 7:
                    List<DeviceParcel> remoteDeviceInfo = getRemoteDeviceInfo();
                    parcel2.writeNoException();
                    parcel2.writeTypedList(remoteDeviceInfo, 1);
                    return true;
                case 8:
                    String string3 = parcel.readString();
                    parcel.enforceNoDataAvail();
                    P2pInfoParcel remoteP2pInfo = getRemoteP2pInfo(string3);
                    parcel2.writeNoException();
                    parcel2.writeTypedObject(remoteP2pInfo, 1);
                    return true;
                case 9:
                    String string4 = parcel.readString();
                    parcel.enforceNoDataAvail();
                    boolean remoteScreenState = getRemoteScreenState(string4);
                    parcel2.writeNoException();
                    parcel2.writeBoolean(remoteScreenState);
                    return true;
                case 10:
                    String string5 = parcel.readString();
                    parcel.enforceNoDataAvail();
                    int switchState = getSwitchState(string5);
                    parcel2.writeNoException();
                    parcel2.writeInt(switchState);
                    return true;
                default:
                    return super.onTransact(i2, parcel, parcel2, i3);
            }
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
