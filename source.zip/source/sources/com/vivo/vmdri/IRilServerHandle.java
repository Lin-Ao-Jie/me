package com.vivo.vmdri;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface IRilServerHandle extends IInterface {
    public static final String DESCRIPTOR = "com.vivo.vmdri.IRilServerHandle";

    void onLocalP2pInfoChanged(P2pInfoParcel p2pInfoParcel) throws RemoteException;

    void onRecvRilRequest(String str, int i2, int i3, int i4, int i5, byte[] bArr) throws RemoteException;

    void onRemoteClientRilReady(String str, boolean z2) throws RemoteException;

    void onRemoteDeviceConnected(DeviceParcel deviceParcel, String str) throws RemoteException;

    void onRemoteDeviceDisconnected(DeviceParcel deviceParcel) throws RemoteException;

    void onRemoteP2pInfoChanged(String str, P2pInfoParcel p2pInfoParcel) throws RemoteException;

    void onRemoteScreenStateChanged(String str, boolean z2) throws RemoteException;

    void onSwitchStateChanged(String str, int i2) throws RemoteException;

    void registerVmdriServerHandle(IVmdriServerHandle iVmdriServerHandle) throws RemoteException;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class Default implements IRilServerHandle {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onLocalP2pInfoChanged(P2pInfoParcel p2pInfoParcel) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onRemoteDeviceDisconnected(DeviceParcel deviceParcel) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void registerVmdriServerHandle(IVmdriServerHandle iVmdriServerHandle) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onRemoteClientRilReady(String str, boolean z2) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onRemoteDeviceConnected(DeviceParcel deviceParcel, String str) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onRemoteP2pInfoChanged(String str, P2pInfoParcel p2pInfoParcel) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onRemoteScreenStateChanged(String str, boolean z2) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onSwitchStateChanged(String str, int i2) throws RemoteException {
        }

        @Override // com.vivo.vmdri.IRilServerHandle
        public void onRecvRilRequest(String str, int i2, int i3, int i4, int i5, byte[] bArr) throws RemoteException {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class Stub extends Binder implements IRilServerHandle {
        static final int TRANSACTION_onLocalP2pInfoChanged = 8;
        static final int TRANSACTION_onRecvRilRequest = 9;
        static final int TRANSACTION_onRemoteClientRilReady = 4;
        static final int TRANSACTION_onRemoteDeviceConnected = 2;
        static final int TRANSACTION_onRemoteDeviceDisconnected = 3;
        static final int TRANSACTION_onRemoteP2pInfoChanged = 5;
        static final int TRANSACTION_onRemoteScreenStateChanged = 6;
        static final int TRANSACTION_onSwitchStateChanged = 7;
        static final int TRANSACTION_registerVmdriServerHandle = 1;

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        private static class Proxy implements IRilServerHandle {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IRilServerHandle.DESCRIPTOR;
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onLocalP2pInfoChanged(P2pInfoParcel p2pInfoParcel) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeTypedObject(p2pInfoParcel, 0);
                    this.mRemote.transact(8, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onRecvRilRequest(String str, int i2, int i3, int i4, int i5, byte[] bArr) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(i2);
                    parcelObtain.writeInt(i3);
                    parcelObtain.writeInt(i4);
                    parcelObtain.writeInt(i5);
                    parcelObtain.writeByteArray(bArr);
                    this.mRemote.transact(9, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onRemoteClientRilReady(String str, boolean z2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeBoolean(z2);
                    this.mRemote.transact(4, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onRemoteDeviceConnected(DeviceParcel deviceParcel, String str) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeTypedObject(deviceParcel, 0);
                    parcelObtain.writeString(str);
                    this.mRemote.transact(2, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onRemoteDeviceDisconnected(DeviceParcel deviceParcel) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeTypedObject(deviceParcel, 0);
                    this.mRemote.transact(3, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onRemoteP2pInfoChanged(String str, P2pInfoParcel p2pInfoParcel) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeTypedObject(p2pInfoParcel, 0);
                    this.mRemote.transact(5, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onRemoteScreenStateChanged(String str, boolean z2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeBoolean(z2);
                    this.mRemote.transact(6, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void onSwitchStateChanged(String str, int i2) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(i2);
                    this.mRemote.transact(7, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }

            @Override // com.vivo.vmdri.IRilServerHandle
            public void registerVmdriServerHandle(IVmdriServerHandle iVmdriServerHandle) throws RemoteException {
                Parcel parcelObtain = Parcel.obtain(asBinder());
                try {
                    parcelObtain.writeInterfaceToken(IRilServerHandle.DESCRIPTOR);
                    parcelObtain.writeStrongInterface(iVmdriServerHandle);
                    this.mRemote.transact(1, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, IRilServerHandle.DESCRIPTOR);
        }

        public static IRilServerHandle asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(IRilServerHandle.DESCRIPTOR);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof IRilServerHandle)) ? new Proxy(iBinder) : (IRilServerHandle) iInterfaceQueryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) throws RemoteException {
            if (i2 >= 1 && i2 <= 16777215) {
                parcel.enforceInterface(IRilServerHandle.DESCRIPTOR);
            }
            if (i2 == 1598968902) {
                parcel2.writeString(IRilServerHandle.DESCRIPTOR);
                return true;
            }
            switch (i2) {
                case 1:
                    IVmdriServerHandle iVmdriServerHandleAsInterface = IVmdriServerHandle.Stub.asInterface(parcel.readStrongBinder());
                    parcel.enforceNoDataAvail();
                    registerVmdriServerHandle(iVmdriServerHandleAsInterface);
                    return true;
                case 2:
                    DeviceParcel deviceParcel = (DeviceParcel) parcel.readTypedObject(DeviceParcel.CREATOR);
                    String string = parcel.readString();
                    parcel.enforceNoDataAvail();
                    onRemoteDeviceConnected(deviceParcel, string);
                    return true;
                case 3:
                    DeviceParcel deviceParcel2 = (DeviceParcel) parcel.readTypedObject(DeviceParcel.CREATOR);
                    parcel.enforceNoDataAvail();
                    onRemoteDeviceDisconnected(deviceParcel2);
                    return true;
                case 4:
                    String string2 = parcel.readString();
                    boolean z2 = parcel.readBoolean();
                    parcel.enforceNoDataAvail();
                    onRemoteClientRilReady(string2, z2);
                    return true;
                case 5:
                    String string3 = parcel.readString();
                    P2pInfoParcel p2pInfoParcel = (P2pInfoParcel) parcel.readTypedObject(P2pInfoParcel.CREATOR);
                    parcel.enforceNoDataAvail();
                    onRemoteP2pInfoChanged(string3, p2pInfoParcel);
                    return true;
                case 6:
                    String string4 = parcel.readString();
                    boolean z3 = parcel.readBoolean();
                    parcel.enforceNoDataAvail();
                    onRemoteScreenStateChanged(string4, z3);
                    return true;
                case 7:
                    String string5 = parcel.readString();
                    int i4 = parcel.readInt();
                    parcel.enforceNoDataAvail();
                    onSwitchStateChanged(string5, i4);
                    return true;
                case 8:
                    P2pInfoParcel p2pInfoParcel2 = (P2pInfoParcel) parcel.readTypedObject(P2pInfoParcel.CREATOR);
                    parcel.enforceNoDataAvail();
                    onLocalP2pInfoChanged(p2pInfoParcel2);
                    return true;
                case 9:
                    String string6 = parcel.readString();
                    int i5 = parcel.readInt();
                    int i6 = parcel.readInt();
                    int i7 = parcel.readInt();
                    int i8 = parcel.readInt();
                    byte[] bArrCreateByteArray = parcel.createByteArray();
                    parcel.enforceNoDataAvail();
                    onRecvRilRequest(string6, i5, i6, i7, i8, bArrCreateByteArray);
                    return true;
                default:
                    return super.onTransact(i2, parcel, parcel2, i3);
            }
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
