package com.vivo.vmdri;

import android.annotation.NonNull;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.IndentingPrintWriter;
import c0.e0;
import c0.r;
import c0.u0;
import c0.z0;
import com.vivo.vmdri.ctrl.u;
import d0.l;
import d0.p;
import d0.x;
import d0.z;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriGlobals extends ContextWrapper {
    public static final String LOG_TAG = "VmdriGlobals";
    private static VmdriGlobals sMe;
    private r mDataPlaneInterface;
    private DependentServiceController mDependentServiceController;
    private l mDeviceStateTracker;
    private e0 mDistributedDeviceManager;
    private u0 mDistributedSdk;
    Handler mHandler;
    private p mHsManager;
    private x mLinkManager;
    private p0.a mNotificationChannelMgr;
    private p0.b mNotificationMgr;
    public final long mStartElapsedTimeMs;
    public final long mStartSystemTimeMs;
    private z0 mSwitchSettingsManager;
    private u mTopController;
    private VmdriContext mVmdriContext;
    private z mWifiP2pStateTracker;

    public VmdriGlobals(Context context) {
        super(context);
        this.mHandler = new Handler(this, ThreadManager.getVmdriMainLooper()) { // from class: com.vivo.vmdri.VmdriGlobals.1
            @Override // android.os.Handler
            public void handleMessage(@NonNull Message message) {
                super.handleMessage(message);
            }
        };
        sMe = this;
        this.mStartSystemTimeMs = System.currentTimeMillis();
        this.mStartElapsedTimeMs = SystemClock.elapsedRealtime();
    }

    public static VmdriGlobals getInstance() {
        VmdriGlobals vmdriGlobals = sMe;
        if (vmdriGlobals != null) {
            return vmdriGlobals;
        }
        throw new IllegalStateException("No VmdriGlobals here!");
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    public void dump(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        IndentingPrintWriter indentingPrintWriter = new IndentingPrintWriter(printWriter, "  ");
        indentingPrintWriter.println("VmdriGlobal:");
        VmdriConfig.dump(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getDeviceStateTracker().V(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getTopController().b(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getVmdriContext().dump(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getLinkManager().l(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getHsManager().r(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getDistributedSdk().q(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getDistributedDeviceManager().z(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        getDataPlaneInterface().s(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        indentingPrintWriter.println("++++++++++++++++++++++++++++++++");
        indentingPrintWriter.println("SharedPreferences:");
        indentingPrintWriter.increaseIndent();
        try {
            Map<String, ?> all = PreferenceManager.getDefaultSharedPreferences(this).getAll();
            for (String str : all.keySet()) {
                indentingPrintWriter.println(((Object) str) + " : " + all.get(str));
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        indentingPrintWriter.decreaseIndent();
        indentingPrintWriter.flush();
    }

    public r getDataPlaneInterface() {
        return this.mDataPlaneInterface;
    }

    public l getDeviceStateTracker() {
        return this.mDeviceStateTracker;
    }

    public e0 getDistributedDeviceManager() {
        return this.mDistributedDeviceManager;
    }

    public u0 getDistributedSdk() {
        return this.mDistributedSdk;
    }

    public p getHsManager() {
        return this.mHsManager;
    }

    public x getLinkManager() {
        return this.mLinkManager;
    }

    public p0.a getNotificationChannelMgr() {
        return this.mNotificationChannelMgr;
    }

    public p0.b getNotificationMgr() {
        return this.mNotificationMgr;
    }

    public z0 getSwitchSettingsManager() {
        return this.mSwitchSettingsManager;
    }

    public u getTopController() {
        return this.mTopController;
    }

    public VmdriContext getVmdriContext() {
        return this.mVmdriContext;
    }

    public void onCreate() {
        logd("onCreate, myPkgName:" + getPackageName() + ", myProcName:" + Process.myProcessName() + ", localVersion:" + VmdriConfig.sLocalVersion);
        Looper vmdriMainLooper = ThreadManager.getVmdriMainLooper();
        VmdriComponentFactory vmdriComponentFactory = VmdriComponentFactory.getInstance();
        this.mNotificationChannelMgr = new p0.a(this);
        this.mNotificationMgr = p0.b.A(this);
        this.mVmdriContext = vmdriComponentFactory.makeVmdriContext(this);
        this.mDistributedSdk = vmdriComponentFactory.makeDistributedSdk(this, vmdriMainLooper);
        this.mDependentServiceController = vmdriComponentFactory.makeDependentServiceController(this, vmdriMainLooper);
        e0 e0VarMakeDistributedDeviceManager = vmdriComponentFactory.makeDistributedDeviceManager(this, this.mDistributedSdk);
        this.mDistributedDeviceManager = e0VarMakeDistributedDeviceManager;
        this.mDataPlaneInterface = vmdriComponentFactory.makeDataPlaneInterface(this, this.mDistributedSdk, e0VarMakeDistributedDeviceManager);
        this.mSwitchSettingsManager = vmdriComponentFactory.makeSwitchSettingsManager(this, vmdriMainLooper);
        x xVarMakeLinkManager = vmdriComponentFactory.makeLinkManager(this, vmdriMainLooper);
        this.mLinkManager = xVarMakeLinkManager;
        this.mHsManager = vmdriComponentFactory.makeHsManager(this, xVarMakeLinkManager);
        this.mWifiP2pStateTracker = vmdriComponentFactory.makeWifiP2pStateTracker(this, vmdriMainLooper);
        l lVarMakeDeviceStateTracker = vmdriComponentFactory.makeDeviceStateTracker(this, this.mHsManager);
        this.mDeviceStateTracker = lVarMakeDeviceStateTracker;
        this.mTopController = vmdriComponentFactory.makeTopController(this, vmdriMainLooper, lVarMakeDeviceStateTracker);
        this.mDistributedSdk.c0();
    }
}
