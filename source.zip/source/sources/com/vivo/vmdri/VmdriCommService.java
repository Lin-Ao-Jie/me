package com.vivo.vmdri;

import android.annotation.Nullable;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.UserHandle;
import com.vivo.vmdri.ctrl.u;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriCommService extends Service {
    public static final String LOG_TAG = "VmdriCommService";

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    @Override // android.app.Service
    protected void dump(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(fileDescriptor, printWriter, strArr);
    }

    @Override // android.app.Service
    @Nullable
    public IBinder onBind(Intent intent) {
        logd("onBind : " + intent);
        int iMyUserId = UserHandle.myUserId();
        if (iMyUserId == 0) {
            return u.d().e();
        }
        loge("onBind : " + intent + ", return null on myUserId:" + iMyUserId);
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        logd("onCreate");
        super.onCreate();
    }

    @Override // android.app.Service
    public void onDestroy() {
        logd("onDestroy");
        super.onDestroy();
    }

    @Override // android.app.Service
    public void onRebind(Intent intent) {
        logd("onRebind");
        super.onRebind(intent);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i2, int i3) {
        logd("onStartCommand");
        return super.onStartCommand(intent, i2, i3);
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        logd("onUnbind");
        return super.onUnbind(intent);
    }
}
