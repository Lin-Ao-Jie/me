package com.vivo.vmdri;

import android.app.Application;
import android.os.UserHandle;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriApp extends Application {
    public static final String LOG_TAG = "VmdriApp";
    VmdriGlobals mVmdriGlobals;

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    @Override // android.app.Application
    public void onCreate() {
        if (UserHandle.myUserId() == 0) {
            VmdriGlobals vmdriGlobals = new VmdriGlobals(this);
            this.mVmdriGlobals = vmdriGlobals;
            vmdriGlobals.onCreate();
        }
    }
}
