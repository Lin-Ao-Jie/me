package com.vivo.vmdri;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.SystemProperties;
import android.text.TextUtils;
import android.util.IndentingPrintWriter;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriContext {
    public static final String COMM_SHARE_DEVS = "ril.vmdri.comm_share_dev";
    public static final String LOG_TAG = "VmdriContext";
    public static final String START_COUNT_PROP = "ril.vmdri.start_count";
    public static final String TOTAL_BOOT_NUM_PROP = "persist.radio.vmdri.total_boot_num";
    private static VmdriContext sInstance;
    private final Context mContext;
    private boolean mIsFirstBoot;
    private boolean mIsRecoverFromCrash;
    private final PackageManager mPackageManager;
    private final int mStartCount;
    private final int mTotalBootNum;
    public static final String DEVICE_TYPE_STR = SystemProperties.get("ro.vivo.device.type", "phone");
    public static final int MAX_SUPPORTED_DEV_NUM = SystemProperties.getInt("ro.radio.vmdri.max_support_dev_num", 1);
    private static final Object mLock = new Object();
    private int mCommShareDevSize = 0;
    private final String[] mCommShareDevs = new String[MAX_SUPPORTED_DEV_NUM];
    private String mSystemBuildVersion = "";
    private String mVmdriBuildVersionName = "";
    private int mVmdriBuildVersionCode = -1;
    private int mVmdriBuildVersionCodeMajor = -1;
    private long mVmdriBuildLongVersionCode = -1;

    private VmdriContext(Context context) {
        this.mIsFirstBoot = false;
        this.mContext = context;
        this.mPackageManager = context.getPackageManager();
        int i2 = SystemProperties.getInt(START_COUNT_PROP, 0) + 1;
        this.mStartCount = i2;
        SystemProperties.set(START_COUNT_PROP, String.valueOf(i2));
        if (i2 != 1) {
            this.mIsRecoverFromCrash = true;
        }
        int i3 = SystemProperties.getInt(TOTAL_BOOT_NUM_PROP, 0) + 1;
        this.mTotalBootNum = i3;
        SystemProperties.set(TOTAL_BOOT_NUM_PROP, String.valueOf(i3));
        if (i3 == 1) {
            this.mIsFirstBoot = true;
        }
        logd("VmdriContext create, bootNum:" + i3 + ", isFirstBoot:" + this.mIsFirstBoot + ", startCount:" + i2 + ", isRecoverFromCrash:" + this.mIsRecoverFromCrash);
        initCommShareDevs();
        initSystemBuildVersion();
        initVmdriBuildVersion();
    }

    public static VmdriContext create(Context context) {
        VmdriContext vmdriContext;
        synchronized (mLock) {
            try {
                if (sInstance != null) {
                    throw new RuntimeException("VmdriContext already created!");
                }
                vmdriContext = new VmdriContext(context);
                sInstance = vmdriContext;
            } catch (Throwable th) {
                throw th;
            }
        }
        return vmdriContext;
    }

    public static VmdriContext getInstance() {
        VmdriContext vmdriContext = sInstance;
        if (vmdriContext != null) {
            return vmdriContext;
        }
        throw new RuntimeException("VmdriContext.getInstance can't be called before create()");
    }

    public static int getLocalDevType() {
        return getLocalDeviceType();
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public static int getLocalDeviceType() {
        String str = DEVICE_TYPE_STR;
        str.hashCode();
        byte b2 = -1;
        switch (str.hashCode()) {
            case -881377690:
                if (str.equals("tablet")) {
                    b2 = 0;
                }
                break;
            case 3145837:
                if (str.equals("flip")) {
                    b2 = 1;
                }
                break;
            case 106642798:
                if (str.equals("phone")) {
                    b2 = 2;
                }
                break;
            case 293976283:
                if (str.equals("foldable")) {
                    b2 = 3;
                }
                break;
        }
        switch (b2) {
            case 0:
                return 2;
            default:
                loge("getLocalDeviceType unknown device type config:" + str);
            case 1:
            case 2:
            case 3:
                return 1;
        }
    }

    public static int getMaxSupportedDevNum() {
        return MAX_SUPPORTED_DEV_NUM;
    }

    private void initSystemBuildVersion() {
        String str = SystemProperties.get("ro.build.version.bbk", "");
        this.mSystemBuildVersion = str;
        if (TextUtils.isEmpty(str)) {
            this.mSystemBuildVersion = SystemProperties.get("ro.build.software.version", "");
        }
        if (TextUtils.isEmpty(this.mSystemBuildVersion)) {
            this.mSystemBuildVersion = SystemProperties.get("ro.vivo.build.version", "");
        }
        logd("initSystemBuildVersion, mSystemBuildVersion:" + this.mSystemBuildVersion);
    }

    private void initVmdriBuildVersion() {
        PackageManager packageManager = this.mPackageManager;
        if (packageManager == null) {
            return;
        }
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(this.mContext.getPackageName(), 0);
            this.mVmdriBuildVersionName = packageInfo.versionName;
            this.mVmdriBuildVersionCode = packageInfo.versionCode;
            this.mVmdriBuildVersionCodeMajor = packageInfo.versionCodeMajor;
            this.mVmdriBuildLongVersionCode = packageInfo.getLongVersionCode();
            logd("initVmdriBuildVersion, mVmdriBuildVersionName:" + this.mVmdriBuildVersionName + ", mVmdriBuildVersionCode:" + this.mVmdriBuildVersionCode + ", mVmdriBuildVersionCodeMajor:" + this.mVmdriBuildVersionCodeMajor + ", mVmdriBuildLongVersionCode:" + this.mVmdriBuildLongVersionCode);
        } catch (Exception e2) {
            loge("initVmdriBuildVersion error:" + e2);
        }
    }

    public static boolean isPad() {
        return getLocalDeviceType() == 2;
    }

    public static boolean isPhone() {
        return getLocalDeviceType() == 1;
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    private static void logw(String str) {
        VmdriLog.w(LOG_TAG, str);
    }

    public void addCommShareDev(String str) {
        synchronized (mLock) {
            try {
                if (this.mCommShareDevSize < MAX_SUPPORTED_DEV_NUM && !TextUtils.isEmpty(str)) {
                    String[] strArr = this.mCommShareDevs;
                    int i2 = this.mCommShareDevSize;
                    strArr[i2] = str;
                    this.mCommShareDevSize = i2 + 1;
                    StringBuilder sb = new StringBuilder();
                    sb.append(COMM_SHARE_DEVS);
                    sb.append(this.mCommShareDevSize - 1);
                    SystemProperties.set(sb.toString(), str);
                    return;
                }
                loge("addCommShareDev, mCommShareDevSize:" + this.mCommShareDevSize + ", remoteDevId:" + str);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void clearAllCommShareDevs() {
        synchronized (mLock) {
            try {
                if (this.mCommShareDevSize <= 0) {
                    loge("clearAllCommShareDevs, mCommShareDevSize:" + this.mCommShareDevSize);
                    return;
                }
                int i2 = 0;
                while (true) {
                    int i3 = this.mCommShareDevSize;
                    if (i2 >= i3) {
                        return;
                    }
                    this.mCommShareDevs[i2] = "";
                    this.mCommShareDevSize = i3 - 1;
                    SystemProperties.set(COMM_SHARE_DEVS + i2, "");
                    i2++;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean containCommShareDev(String str) {
        synchronized (mLock) {
            try {
                if (this.mCommShareDevSize > 0 && !TextUtils.isEmpty(str)) {
                    for (int i2 = 0; i2 < this.mCommShareDevSize; i2++) {
                        if (this.mCommShareDevs[i2].equals(str)) {
                            return true;
                        }
                    }
                    return false;
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void dump(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("VmdriContext:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mTotalBootNum=" + this.mTotalBootNum);
        indentingPrintWriter.println("mIsFirstBoot=" + this.mIsFirstBoot);
        indentingPrintWriter.println("mStartCount=" + this.mStartCount);
        indentingPrintWriter.println("mIsRecoverFromCrash=" + this.mIsRecoverFromCrash);
        indentingPrintWriter.println("mDeviceType=" + DEVICE_TYPE_STR + "(" + getLocalDeviceType() + ")");
        StringBuilder sb = new StringBuilder();
        sb.append("mCommShareDevSize=");
        sb.append(this.mCommShareDevSize);
        indentingPrintWriter.println(sb.toString());
        for (String str : this.mCommShareDevs) {
            indentingPrintWriter.println("CommShareDev=" + str);
        }
        indentingPrintWriter.decreaseIndent();
    }

    public Context getApplicationContext() {
        return this.mContext;
    }

    public int getCommShareDevSize() {
        return this.mCommShareDevSize;
    }

    public List<String> getCommShareDevs() {
        ArrayList arrayList;
        synchronized (mLock) {
            arrayList = new ArrayList(Arrays.asList(this.mCommShareDevs).subList(0, this.mCommShareDevSize));
        }
        return arrayList;
    }

    public int getStartCount() {
        return this.mStartCount;
    }

    public String getSystemBuildVersion() {
        return this.mSystemBuildVersion;
    }

    public int getTotalBootNum() {
        return this.mTotalBootNum;
    }

    public long getVmdriBuildLongVersionCode() {
        return this.mVmdriBuildLongVersionCode;
    }

    public int getVmdriBuildVersionCode() {
        return this.mVmdriBuildVersionCode;
    }

    public int getVmdriBuildVersionCodeMajor() {
        return this.mVmdriBuildVersionCodeMajor;
    }

    public String getVmdriBuildVersionName() {
        return this.mVmdriBuildVersionName;
    }

    public void initCommShareDevs() {
        synchronized (mLock) {
            try {
                this.mCommShareDevSize = 0;
                for (int i2 = 0; i2 < MAX_SUPPORTED_DEV_NUM; i2++) {
                    String str = SystemProperties.get(COMM_SHARE_DEVS + i2, "");
                    if (!TextUtils.isEmpty(str)) {
                        logd("initCommShareDevs, remoteDevId:" + str);
                        this.mCommShareDevs[i2] = str;
                        this.mCommShareDevSize = this.mCommShareDevSize + 1;
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean isFirstBoot() {
        return this.mIsFirstBoot;
    }

    public boolean isRecoverFromCrash() {
        return this.mIsRecoverFromCrash;
    }

    public void removeCommShareDev(String str) {
        synchronized (mLock) {
            try {
                if (this.mCommShareDevSize > 0 && !TextUtils.isEmpty(str)) {
                    for (int i2 = 0; i2 < this.mCommShareDevSize; i2++) {
                        if (this.mCommShareDevs[i2].equals(str)) {
                            this.mCommShareDevs[i2] = "";
                            this.mCommShareDevSize--;
                            SystemProperties.set(COMM_SHARE_DEVS + i2, "");
                            return;
                        }
                    }
                    return;
                }
                loge("removeCommShareDev, mCommShareDevSize:" + this.mCommShareDevSize + ", remoteDevId:" + str);
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
