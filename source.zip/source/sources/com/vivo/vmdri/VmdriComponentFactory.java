package com.vivo.vmdri;

import android.content.Context;
import android.os.Looper;
import c0.e0;
import c0.r;
import c0.u0;
import c0.z0;
import com.vivo.vmdri.ctrl.u;
import d0.l;
import d0.p;
import d0.x;
import d0.z;
import z.f;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriComponentFactory {
    public static final String LOG_TAG = "VmdriComponentFactory";
    private static VmdriComponentFactory sInstance;

    public static VmdriComponentFactory getInstance() {
        if (sInstance == null) {
            sInstance = new VmdriComponentFactory();
        }
        return sInstance;
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    private static void logw(String str) {
        VmdriLog.w(LOG_TAG, str);
    }

    public r makeDataPlaneInterface(Context context, u0 u0Var, e0 e0Var) {
        return r.o(context, u0Var, e0Var);
    }

    public DependentServiceController makeDependentServiceController(Context context, Looper looper) {
        return DependentServiceController.create(context, looper);
    }

    public l makeDeviceStateTracker(Context context, p pVar) {
        return l.U(context, pVar);
    }

    public e0 makeDistributedDeviceManager(Context context, u0 u0Var) {
        return e0.y(context, u0Var);
    }

    public u0 makeDistributedSdk(Context context, Looper looper) {
        return f.J0(context, looper);
    }

    public p makeHsManager(Context context, x xVar) {
        return p.q(context, xVar);
    }

    public x makeLinkManager(Context context, Looper looper) {
        return x.k(context, looper);
    }

    public z0 makeSwitchSettingsManager(Context context, Looper looper) {
        return z0.e(context, looper);
    }

    public u makeTopController(Context context, Looper looper, l lVar) {
        return u.a(context, looper, lVar);
    }

    public VmdriContext makeVmdriContext(Context context) {
        return VmdriContext.create(context);
    }

    public z makeWifiP2pStateTracker(Context context, Looper looper) {
        return z.l(context, looper);
    }
}
