package com.vivo.vmdri.ctrl;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class RemoteDevConnEvaluation {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final EvaluationReason f1265a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f1266b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Set f1267c = new HashSet();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private AllowedReason f1268d = AllowedReason.NONE;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private long f1269e = 0;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public enum AllowedReason {
        NONE,
        NORMAL
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public enum DisallowedReason {
        LOCAL_MAX_PREFER_DEV_REACHED(true),
        LOCAL_NOT_SIM(true),
        LOCAL_ON_AIRPLANE_MODE(true),
        LOCAL_WIFI_DISABLE(true),
        LOCAL_BLUETOOTH_DISABLE(true),
        LOCAL_SCREEN_OFF(true),
        LOCAL_AUTO_CONN_DISABLE(true),
        USER_DISLIKE_THIS_DEV(true),
        LOCAL_SWITCH_ALL_DISABLE(true),
        REMOTE_DEV_NOT_CONN(true),
        REMOTE_MAX_PREFER_DEV_REACHED(true),
        BR_NOT_CONN(false),
        DEV_STATE_NOT_SYN_NOW(false),
        REPEAT_EVALUATE_PREFERRED_DEV(true),
        REMOTE_NOT_SIM(true),
        REMOTE_ON_AIRPLANE_MODE(true),
        REMOTE_WIFI_DISABLE(true),
        REMOTE_BLUETOOTH_DISABLE(true),
        CURRENT_IN_TARGETING(true),
        COMBINE_SWITCH_DISABLE(true),
        RIL_SERVICE_NOT_BOUND(true),
        CAPABILITY_SERVICE_NOT_BOUND(true);

        private final boolean mIsHardReason;

        DisallowedReason(boolean z2) {
            this.mIsHardReason = z2;
        }

        public boolean isHardReason() {
            return this.mIsHardReason;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public enum EvaluationReason {
        NEW_REMOTE_DEV_CONN_FROM_SDK(true),
        RECOVER_COMM_SHARE_FROM_CRASH(true),
        REMOTE_DEV_STATE_CHANGED(true),
        REMOTE_COMM_SHARE_STATE_CHANGED(true),
        REQUEST_FROM_REMOTE_DEV(true),
        LOCAL_DEV_STATE_CHANGED(true),
        LOCAL_USER_TARGET_SOFT(true),
        LOCAL_USER_TARGET_HARD(true);

        private final boolean mIsConditionBased;

        EvaluationReason(boolean z2) {
            this.mIsConditionBased = z2;
        }

        public boolean isConditionBased() {
            return this.mIsConditionBased;
        }
    }

    public RemoteDevConnEvaluation(EvaluationReason evaluationReason) {
        this.f1265a = evaluationReason;
    }

    public void a(AllowedReason allowedReason) {
        this.f1267c.clear();
        if (allowedReason.ordinal() > this.f1268d.ordinal()) {
            this.f1268d = allowedReason;
        }
        this.f1269e = System.currentTimeMillis();
    }

    public void b(DisallowedReason disallowedReason) {
        this.f1268d = AllowedReason.NONE;
        this.f1267c.add(disallowedReason);
        this.f1269e = System.currentTimeMillis();
    }

    public boolean c(DisallowedReason disallowedReason) {
        return this.f1267c.contains(disallowedReason);
    }

    public boolean d() {
        return this.f1267c.size() != 0;
    }

    public boolean e(DisallowedReason disallowedReason) {
        return this.f1267c.size() == 1 && c(disallowedReason);
    }

    public List f() {
        return new ArrayList(this.f1267c);
    }

    public String g() {
        StringBuilder sb = new StringBuilder();
        sb.append("disallowed reasons:");
        for (DisallowedReason disallowedReason : this.f1267c) {
            sb.append(" ");
            sb.append(disallowedReason);
        }
        return sb.toString();
    }

    public EvaluationReason h() {
        return this.f1265a;
    }

    public boolean i() {
        return this.f1265a == EvaluationReason.RECOVER_COMM_SHARE_FROM_CRASH;
    }

    public boolean j() {
        int iOrdinal = this.f1265a.ordinal();
        return iOrdinal == 6 || iOrdinal == 7;
    }

    public void k(DisallowedReason disallowedReason) {
        this.f1267c.remove(disallowedReason);
        this.f1269e = System.currentTimeMillis();
    }

    public void l(String str) {
        this.f1266b = str;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CommShare evaluation: evaluation reason:" + this.f1265a + ",");
        if (!TextUtils.isEmpty(this.f1266b)) {
            sb.append(" remoteDevId:" + this.f1266b);
        }
        if (this.f1267c.size() > 0) {
            sb.append(" disallowed reasons:");
            for (DisallowedReason disallowedReason : this.f1267c) {
                sb.append(" ");
                sb.append(disallowedReason);
            }
        } else {
            sb.append(" allowed reason:");
            sb.append(" ");
            sb.append(this.f1268d);
        }
        sb.append(", time=" + VmdriUtils.systemTimeToString(this.f1269e));
        return sb.toString();
    }
}
