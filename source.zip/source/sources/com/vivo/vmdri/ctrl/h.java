package com.vivo.vmdri.ctrl;

import a0.g0;
import a0.n0;
import a0.w;
import a0.y0;
import a0.z0;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncResult;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings;
import android.text.Annotation;
import android.text.SpannableString;
import android.text.SpannedString;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.ArraySet;
import android.util.IndentingPrintWriter;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;
import c0.u0;
import com.originui.core.utils.VThemeIconUtils;
import com.vivo.commshare.framework.base.Constants;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.R;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class h extends com.vivo.vmdri.ctrl.a {
    private static h K;
    private static final Object L = new Object();
    protected final HashMap A;
    private final HashMap B;
    private final HashMap C;
    private final HashMap D;
    protected w.d E;
    List F;
    List G;
    private final DependentServiceController H;
    protected l.c I;
    protected l.b J;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected Context f1288b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected d0.l f1289c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected d0.l.h f1290d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected u0.c f1291e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private y.f f1292f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private x.d f1293g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private com.vivo.vmdri.ctrl.i f1294h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Dialog f1295i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private Dialog f1296j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private Dialog f1297k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Dialog f1298l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private Dialog f1299m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private Dialog f1300n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    protected final Set f1301o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private t f1302p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private w.f f1303q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private long f1304r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private long f1305s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private long f1306t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private HashMap f1307u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private HashMap f1308v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private w.d f1309w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private y0 f1310x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private z0 f1311y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    protected final HashMap f1312z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1313a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f1314b;

        a(w.d dVar, String str) {
            this.f1313a = dVar;
            this.f1314b = str;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            h.t("showCommShareInConflictDialog target start commShare, remoteDevId:" + this.f1313a.i() + ", willPreemptedDevId:" + this.f1314b);
            h.this.p1(this.f1313a.i(), null, this.f1314b);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1316a;

        b(h hVar, w.d dVar) {
            this.f1316a = dVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            h.t("showCommShareInConflictDialog target start commShare, Cancel preemption, remoteDeviceState:" + this.f1316a);
            dialogInterface.dismiss();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends l.c {
        c() {
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void a(final String str, final int i2) {
            h.t("businessStateIndication:" + str + ", businessStateBitmask:" + Constants.convertBusinessTypeBitmaskToString(i2));
            h.this.f1301o.forEach(new Consumer() { // from class: com.vivo.vmdri.ctrl.c
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    g0 g0Var = (g0) obj;
                    g0Var.invokeFromExecutor(new Runnable() { // from class: com.vivo.vmdri.ctrl.f
                        @Override // java.lang.Runnable
                        public final void run() {
                            g0Var.b(str, i);
                        }
                    });
                }
            });
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void b(final String str, final long j2, final long j3) {
            h.t("commShareStateIndication, remoteDevId:" + str + ", dataUsageOfThisConn:" + j2 + ", dataUsageOfThisMonth:" + j3);
            h.this.f1301o.forEach(new Consumer() { // from class: com.vivo.vmdri.ctrl.b
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    g0 g0Var = (g0) obj;
                    g0Var.invokeFromExecutor(new Runnable() { // from class: com.vivo.vmdri.ctrl.e
                        @Override // java.lang.Runnable
                        public final void run() {
                            g0Var.a(str, j, j);
                        }
                    });
                }
            });
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void c(String str, int i2, boolean z2, HashMap map) {
            h.t("commShareStateIndication, remoteDevId:" + str + ", maxSupportedDevs:" + i2 + ", commShareState:" + z2 + ", preferredDevs:" + map);
            h.this.C.put(str, new n0(str, i2, z2, map));
            if (i2 > map.size()) {
                h.this.m1(str, RemoteDevConnEvaluation.EvaluationReason.REMOTE_COMM_SHARE_STATE_CHANGED, false);
            }
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void d(final String str, final int i2) {
            h.t("rilStateIndication:" + str + ", rilState:" + i2);
            h.this.f1301o.forEach(new Consumer() { // from class: com.vivo.vmdri.ctrl.d
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    g0 g0Var = (g0) obj;
                    g0Var.invokeFromExecutor(new Runnable() { // from class: com.vivo.vmdri.ctrl.g
                        @Override // java.lang.Runnable
                        public final void run() {
                            g0Var.c(str, i);
                        }
                    });
                }
            });
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends l.b {
        d() {
        }

        @Override // com.vivo.vmdri.ctrl.l.b
        public void a(String str, String str2) {
            h.t("bringUpProcessFromRemote, remoteDevId:" + str + ", pkgName:" + str2);
            Intent intent = new Intent("com.vivo.vmdri.intent.action.COMM_SHARE_BRING_UP_PROCESS");
            intent.setPackage(str2);
            h.this.f1288b.sendBroadcast(intent);
        }

        @Override // com.vivo.vmdri.ctrl.l.b
        public i0.a b(String str, h0.b bVar) {
            h.t("starConnFromRemote, curReqRemoteDevId:" + str + ", requestMsg:" + bVar + ", PreferredRemoteDev:" + h.this.f1309w + ", RemoteDevStates:" + h.this.A);
            i0.a aVarB0 = h.this.B0(str, bVar);
            h hVar = h.this;
            String strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("remote", hVar.E, (w.d) hVar.A.get(str), h.this.f1302p, aVarB0.toString());
            if (strConvertDevInfoToLocalLogMessage != null) {
                VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
            }
            return aVarB0;
        }

        @Override // com.vivo.vmdri.ctrl.l.b
        public i0.b c(String str, h0.c cVar) {
            h.t("stopConnFromRemote, remoteDevId:" + str + ", requestMsg:" + cVar);
            return h.this.C0(str, cVar);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends u0.c {
        e(Executor executor) {
            super(executor);
        }

        @Override // c0.u0.c
        public void c(int i2) {
            h.t("onSdkStateChanged, state:" + i2);
            if (i2 == 2) {
                Iterator it = h.this.F.iterator();
                while (it.hasNext()) {
                    h.this.z((String) it.next());
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w f1320a;

        f(w wVar) {
            this.f1320a = wVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            h.this.f1270a.add(this.f1320a);
            if (h.this.f1309w == null || h.this.f1310x == null) {
                return;
            }
            h hVar = h.this;
            hVar.w(hVar.f1309w, h.this.f1310x.d());
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1322a;

        g(w.d dVar) {
            this.f1322a = dVar;
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0090  */
        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            String str;
            if (h.this.f1309w != null) {
                String strI = h.this.f1309w.i();
                h hVar = h.this;
                hVar.f1312z.put(strI, hVar.f1309w);
                l lVar = (l) h.this.B.get(strI);
                if (lVar != null) {
                    lVar.q(true, 1, "Preempted by:" + this.f1322a, h.this.obtainMessage(505, new Pair(strI, null)));
                }
                h.this.S0(strI, false, true, true, null, null, null, "preempted");
            }
            n0 n0Var = (n0) h.this.C.get(this.f1322a.i());
            if (n0Var != null) {
                Iterator it = n0Var.b().entrySet().iterator();
                if (it.hasNext()) {
                    str = (String) ((Map.Entry) it.next()).getKey();
                } else {
                    str = "";
                }
            } else {
                str = "";
            }
            h.t("showCommShareConflictDialog target start commShare, remoteDevId:" + this.f1322a.i() + ", willPreemptedDevId:" + str);
            h.this.p1(this.f1322a.i(), null, str);
        }
    }

    /* JADX INFO: renamed from: com.vivo.vmdri.ctrl.h$h, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class DialogInterfaceOnClickListenerC0008h implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1324a;

        DialogInterfaceOnClickListenerC0008h(h hVar, w.d dVar) {
            this.f1324a = dVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            h.t("showCommShareConflictDialog target start commShare, Cancel preemption, remoteDeviceState:" + this.f1324a);
            dialogInterface.dismiss();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class i extends ClickableSpan {
        i() {
        }

        @Override // android.text.style.ClickableSpan
        public void onClick(View view) {
            h.this.d1(false);
        }

        @Override // android.text.style.ClickableSpan, android.text.style.CharacterStyle
        public void updateDrawState(TextPaint textPaint) {
            int color;
            super.updateDrawState(textPaint);
            if (VThemeIconUtils.B()) {
                color = h.this.f1288b.getResources().getColor(R.color.phone_vivo_color_primary);
            } else {
                color = VmdriUtils.AT_LEAST_ROM_15_0 ? h.this.f1288b.getResources().getColor(R.color.os50_vigour_alert_dialog_btn_ok) : h.this.f1288b.getResources().getColor(R.color.vigour_alert_dialog_btn_ok);
            }
            textPaint.setColor(color);
            textPaint.setUnderlineText(false);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class k extends d0.l.h {
        public k(Executor executor) {
            super(executor);
        }

        @Override // d0.l.h
        public void b(w.c cVar) {
            h.t("onConnectFailure");
            h.this.u(cVar);
        }

        @Override // d0.l.h
        public void c(w.d dVar) {
            super.c(dVar);
            h hVar = h.this;
            w.d dVar2 = hVar.E;
            hVar.E = dVar;
            h.t("onLocalDeviceStateChangedInternal: oldDev=" + dVar2);
            h.t("onLocalDeviceStateChangedInternal: newDev=" + dVar);
            if (h.this.f1312z.size() > 0) {
                if (dVar2.y() != dVar.y()) {
                    h.L0("local auto conn switch changed, clear mUserStopRemoteDevs!");
                    h.this.f1312z.clear();
                } else if (dVar2.F() != dVar.F()) {
                    h.L0("local wifi enable changed, clear mUserStopRemoteDevs!");
                    h.this.f1312z.clear();
                } else if (dVar2.z() != dVar.z()) {
                    h.L0("local bluetooth enable switch changed, clear mUserStopRemoteDevs!");
                    h.this.f1312z.clear();
                }
            }
            h.this.v(dVar);
            if (h.this.f1309w == null) {
                h.this.l0(RemoteDevConnEvaluation.EvaluationReason.LOCAL_DEV_STATE_CHANGED, false);
            } else {
                h.this.X0(RemoteDevConnEvaluation.EvaluationReason.LOCAL_DEV_STATE_CHANGED);
            }
        }

        @Override // d0.l.h
        public void d(w.d dVar) {
            super.d(dVar);
            h.t("onRemoteDeviceConnected:" + dVar);
            String strI = dVar.i();
            h hVar = h.this;
            Context context = hVar.f1288b;
            Looper looper = hVar.getLooper();
            h hVar2 = h.this;
            l lVar = new l(context, looper, dVar, hVar2.J, hVar2.I);
            lVar.e();
            h.this.A.put(strI, dVar);
            h.this.B.put(strI, lVar);
            h.this.f1289c.A0(strI);
            if (h.this.f1309w == null) {
                h.this.m1(strI, RemoteDevConnEvaluation.EvaluationReason.NEW_REMOTE_DEV_CONN_FROM_SDK, false);
            }
            h.this.O0(strI);
        }

        @Override // d0.l.h
        public void e(w.d dVar) {
            super.e(dVar);
            h.t("onRemoteDeviceDisConnected:" + dVar);
            String strI = dVar.i();
            l lVar = (l) h.this.B.remove(strI);
            h.this.C.remove(strI);
            h.this.G.remove(strI);
            if (lVar != null) {
                lVar.f();
            }
            if (h.this.f1309w != null && Objects.equals(h.this.f1309w.i(), strI)) {
                h.this.S0(strI, false, false, true, null, null, null, "all phy disconnected");
            }
            if (h.this.f1302p == null || !Objects.equals(h.this.f1302p.c(), strI)) {
                return;
            }
            h.M0("targeting remote dev physical disconnected! curConnTargetInfo:" + h.this.f1302p);
            boolean zF = h.this.f1302p.f();
            if (zF) {
                h.this.T0(strI, null, 0, "allPhysicalDisConn");
            }
            h hVar = h.this;
            hVar.r0(strI, zF, 4, hVar.f1302p, null);
            h.this.i0("all physical disconnected");
        }

        @Override // d0.l.h
        public void f(w.d dVar, boolean z2, boolean z3) {
            super.f(dVar, z2, z3);
            String strI = dVar.i();
            if (((w.d) h.this.A.get(strI)) == null) {
                h.K0("onRemoteDeviceStateRefresh: not find RemoteDevState:" + dVar + " in cache");
                return;
            }
            h.t("onRemoteDeviceStateRefresh:, isRemoteDevStateSyn = " + z2 + ", hasChanged = " + z3 + ", newDev = " + dVar);
            if (z3) {
                h.this.A.put(strI, dVar);
            }
            if (h.this.f1309w != null && z3 && Objects.equals(strI, h.this.f1309w.i())) {
                if (!dVar.v()) {
                    h.this.S0(strI, false, false, true, null, null, null, "br disconnect");
                    return;
                } else {
                    h.this.P0(dVar);
                    h.this.X0(RemoteDevConnEvaluation.EvaluationReason.REMOTE_DEV_STATE_CHANGED);
                    return;
                }
            }
            if (z2 && h.this.F.contains(strI) && !h.this.E.y()) {
                h.t("onRemoteDeviceStateChanged, try to recover comm share with:" + dVar);
                h.this.F.remove(strI);
                h.this.sendMessageDelayed(h.this.obtainMessage(509, new Pair(strI, RemoteDevConnEvaluation.EvaluationReason.RECOVER_COMM_SHARE_FROM_CRASH)), 3000L);
                return;
            }
            if (z2 && h.this.f1302p != null && h.this.f1302p.a().e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW) && !h.this.f1302p.f() && Objects.equals(strI, h.this.f1302p.c())) {
                h.t("onRemoteDeviceStateChanged, dev state syn! continue auto trigger start comm share");
                h.this.removeMessages(511);
                h hVar = h.this;
                hVar.m1(strI, hVar.f1302p.b(), true);
                return;
            }
            if (z2 && h.this.f1302p != null && h.this.f1302p.a().e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW) && h.this.f1302p.f() && Objects.equals(strI, h.this.f1302p.c())) {
                h.t("onRemoteDeviceStateChanged, dev state syn! continue user trigger start comm share");
                h.this.removeMessages(511);
                h hVar2 = h.this;
                hVar2.n1(strI, null, hVar2.f1302p.e(), h.this.f1302p.d(), true);
                return;
            }
            if (dVar.v() && h.this.f1302p != null && h.this.f1302p.a().e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN) && !h.this.f1302p.f() && Objects.equals(strI, h.this.f1302p.c())) {
                h.t("onRemoteDeviceStateChanged, br conn! continue auto trigger start comm share");
                h.this.removeMessages(510);
                h hVar3 = h.this;
                hVar3.m1(strI, hVar3.f1302p.b(), true);
                return;
            }
            if (dVar.v() && h.this.f1302p != null && h.this.f1302p.a().e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN) && h.this.f1302p.f() && Objects.equals(strI, h.this.f1302p.c())) {
                h.t("onRemoteDeviceStateChanged, br conn! continue user trigger start comm share");
                h.this.removeMessages(510);
                h hVar4 = h.this;
                hVar4.n1(strI, null, hVar4.f1302p.e(), h.this.f1302p.d(), true);
                return;
            }
            if (h.this.f1309w == null && z3) {
                h.this.m1(strI, RemoteDevConnEvaluation.EvaluationReason.REMOTE_DEV_STATE_CHANGED, false);
            }
        }
    }

    private h(Context context, Looper looper, d0.l lVar) {
        super(looper);
        this.f1301o = new ArraySet();
        this.f1303q = new w.f(15);
        this.f1307u = new HashMap();
        this.f1308v = new HashMap();
        this.f1312z = new HashMap();
        this.A = new HashMap();
        this.B = new HashMap();
        this.C = new HashMap();
        this.D = new HashMap();
        this.E = new w.d(true);
        this.F = new ArrayList();
        this.G = new ArrayList();
        this.I = new c();
        this.J = new d();
        this.f1288b = context;
        k kVar = new k(new Executor() { // from class: a0.q
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f107a.post(runnable);
            }
        });
        this.f1290d = kVar;
        this.f1289c = lVar;
        lVar.y0(kVar);
        this.f1293g = new x.d(this.f1288b, looper, this);
        this.H = DependentServiceController.getInstance();
        this.f1294h = new com.vivo.vmdri.ctrl.i(this.f1288b, looper, this);
        VmdriContext vmdriContext = VmdriContext.getInstance();
        if (vmdriContext.isRecoverFromCrash() && vmdriContext.getCommShareDevSize() > 0) {
            this.F = vmdriContext.getCommShareDevs();
            t("mPendingToRecoverCommShareDevs:" + this.F);
            vmdriContext.clearAllCommShareDevs();
            this.f1291e = new e(new Executor() { // from class: a0.q
                @Override // java.util.concurrent.Executor
                public final void execute(Runnable runnable) {
                    this.f107a.post(runnable);
                }
            });
            u0.r().N(this.f1291e);
            sendEmptyMessageDelayed(502, 60000L);
        }
        this.f1292f = new y.f(this.f1288b, getLooper(), this);
    }

    private void A0(Message message) {
        AsyncResult asyncResult = (AsyncResult) message.obj;
        String str = (String) ((Pair) asyncResult.userObj).first;
        t("handleStopCommShareByUserDone, stopRemoteDevId:" + str + ", responseMsg:" + ((i0.b) asyncResult.result) + ", ctrlException:" + ((CtrlException) asyncResult.exception) + ", mPreferredDev:" + this.f1309w);
        U0(str, null, 0, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public i0.a B0(String str, h0.b bVar) {
        t("handleTargetStartCommShareFromRemote, remoteDevId:" + str + ", requestMsg:" + bVar);
        int i2 = bVar.f1718c;
        boolean z2 = bVar.f1716a;
        i0.a aVar = new i0.a();
        aVar.f1734a = 1;
        aVar.f1735b = "init";
        w.d dVar = this.f1309w;
        if (dVar != null) {
            aVar.f1736c.put(dVar.i(), this.f1309w.h());
        }
        w.d dVar2 = (w.d) this.A.get(str);
        if (dVar2 == null) {
            aVar.f1734a = 5;
            aVar.f1735b = "[" + this.E.r() + " reject! because not find device " + str + "]";
            return aVar;
        }
        if (!this.H.isRilBound()) {
            aVar.f1734a = 7;
            aVar.f1735b = "[" + this.E.r() + " reject! because ril service not bound " + str + "]";
            return aVar;
        }
        if (!this.H.isCapabilityServiceBound()) {
            aVar.f1734a = 8;
            aVar.f1735b = "[" + this.E.r() + " reject! because capability service not bound " + str + "]";
            return aVar;
        }
        w.d dVar3 = this.f1309w;
        if (dVar3 == null || !Objects.equals(dVar3.i(), str)) {
            w.d dVar4 = this.f1309w;
            if (dVar4 != null && !z2) {
                aVar.f1734a = 4;
                aVar.f1735b = "[" + this.E.r() + " reject! because already have a preferred device " + this.f1309w.r() + "]";
            } else if (dVar4 == null || !z2) {
                aVar.f1734a = 0;
                aVar.f1735b = "[normal accept]";
                f0(dVar2, "", bVar);
            } else {
                aVar.f1734a = 0;
                aVar.f1735b = "[ accept! but preempt a device " + this.f1309w.r() + "]";
                if (f0(dVar2, bVar.f1717b, bVar)) {
                    aVar.f1734a = 0;
                    aVar.f1735b = "[ accept! but preempt a device " + this.f1309w.r() + "]";
                } else {
                    aVar.f1734a = 4;
                    aVar.f1735b = "[" + this.E.r() + " reject! willPreemptedDevId is illegal: " + bVar.f1717b + ", have preferred device(s)" + this.f1309w.r() + "]";
                }
            }
        } else {
            aVar.f1734a = 0;
            aVar.f1735b = "[repeatedly connect a device]";
        }
        t("handleTargetStartCommShareFromRemote, startCommShareResponseMsg:" + aVar);
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public i0.b C0(String str, h0.c cVar) {
        String str2;
        int i2 = cVar.f1721b;
        boolean z2 = cVar.f1720a;
        i0.b bVar = new i0.b();
        bVar.f1737a = 0;
        bVar.f1738b = "init";
        w.d dVar = this.f1309w;
        if (dVar == null) {
            str2 = str;
            bVar.f1738b = "preferred dev already disconnected";
        } else if (Objects.equals(dVar.i(), str)) {
            bVar.f1738b = "normal";
            if (i2 == 1 || z2) {
                this.f1312z.put(str, this.f1309w);
            }
            str2 = str;
            S0(str2, true, i2 == 1, z2, null, null, cVar, "remote target stop");
        } else {
            str2 = str;
            bVar.f1738b = "has new preferred dev";
        }
        t("handleTargetStopCommShareFromRemote, remoteDevId:" + str2 + ", responseMsg:" + bVar);
        return bVar;
    }

    private boolean D0() {
        return getLooper().getThread() == Thread.currentThread();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E0(g0 g0Var) {
        this.f1301o.add(g0Var);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void G0(String str, DialogInterface dialogInterface, int i2) {
        d1(false);
        if (this.E.y()) {
            return;
        }
        t("showPadOnAirplaneDialog target start commShare, remoteDevId:" + str);
        sendMessageDelayed(obtainMessage(508, str), 2000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void H0(String str, Message message) {
        n1(str, message, false, "", false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void I0(String str, Message message, String str2) {
        n1(str, message, true, str2, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void K0(String str) {
        VmdriLog.e("ClientController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void L0(String str) {
        VmdriLog.i("ClientController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void M0(String str) {
        VmdriLog.w("ClientController", str);
    }

    private void N0() {
        boolean z2;
        int maxSupportedDevNum = VmdriContext.getMaxSupportedDevNum();
        HashMap map = new HashMap();
        w.d dVar = this.f1309w;
        if (dVar != null) {
            map.put(dVar.i(), this.f1309w.h());
            z2 = true;
        } else {
            z2 = false;
        }
        t("notifyCommStateToRemote, maxSupportedDevs:" + maxSupportedDevNum + ", commShare:" + z2 + ", preferredDevs:" + map);
        Iterator it = this.B.values().iterator();
        while (it.hasNext()) {
            ((l) it.next()).u(maxSupportedDevNum, z2, map);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void O0(String str) {
        boolean z2;
        l lVar = (l) this.B.get(str);
        if (lVar == null) {
            return;
        }
        int maxSupportedDevNum = VmdriContext.getMaxSupportedDevNum();
        HashMap map = new HashMap();
        w.d dVar = this.f1309w;
        if (dVar != null) {
            map.put(dVar.i(), this.f1309w.h());
            z2 = true;
        } else {
            z2 = false;
        }
        lVar.u(maxSupportedDevNum, z2, map);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void P0(w.d dVar) {
        t("notifyPreferDevStateChanged, mPreferredDev:" + this.f1309w + ", newPreferRemoteDevState:" + dVar);
        if (Objects.equals(this.f1309w.i(), dVar.i())) {
            this.f1309w = dVar;
            y(dVar);
        }
    }

    private void Q0(String str, RemoteDevConnEvaluation remoteDevConnEvaluation, Message message) {
        int i2;
        String strG = remoteDevConnEvaluation.g();
        if (message == null) {
            return;
        }
        RemoteDevConnEvaluation.DisallowedReason disallowedReason = RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE;
        if (remoteDevConnEvaluation.c(disallowedReason) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            i2 = 18;
        } else if (remoteDevConnEvaluation.c(disallowedReason)) {
            i2 = 16;
        } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            i2 = 17;
        } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_NOT_SIM)) {
            i2 = 20;
        } else {
            RemoteDevConnEvaluation.DisallowedReason disallowedReason2 = RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED;
            if (remoteDevConnEvaluation.c(disallowedReason2) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
                i2 = 15;
            } else if (remoteDevConnEvaluation.c(disallowedReason2)) {
                i2 = 13;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
                i2 = 14;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REPEAT_EVALUATE_PREFERRED_DEV)) {
                i2 = 21;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_DEV_NOT_CONN)) {
                i2 = 35;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.CURRENT_IN_TARGETING)) {
                i2 = 23;
            } else if (remoteDevConnEvaluation.e(RemoteDevConnEvaluation.DisallowedReason.RIL_SERVICE_NOT_BOUND)) {
                i2 = 33;
            } else {
                i2 = remoteDevConnEvaluation.e(RemoteDevConnEvaluation.DisallowedReason.CAPABILITY_SERVICE_NOT_BOUND) ? 34 : 1;
            }
        }
        w.k.a(message, null, i2, strG);
        message.sendToTarget();
    }

    private void R0(w.d dVar, boolean z2, boolean z3, t tVar, i0.a aVar, h0.b bVar) {
        t("notifyStartPreferDev, oldPreferredDev:" + this.f1309w + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", targetInfo:" + tVar + ", responseMsg:" + aVar + ", requestMsg:" + bVar + ", newPreferDev:" + dVar);
        String strI = dVar.i();
        this.f1309w = dVar;
        this.f1311y = null;
        this.f1310x = new y0(strI, z2, z3, tVar, aVar, bVar);
        w(dVar, z3);
        N0();
        VmdriContext.getInstance().addCommShareDev(strI);
        this.f1312z.remove(strI);
        this.G.clear();
        if (hasMessages(513)) {
            removeMessages(513);
        }
        u0.r().w(strI, 1);
        this.f1289c.B0(strI);
        t0(dVar, z2, z3, tVar, aVar, bVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void S0(String str, boolean z2, boolean z3, boolean z4, i0.b bVar, RemoteDevConnEvaluation remoteDevConnEvaluation, h0.c cVar, String str2) {
        t("notifyStopPreferDev, remoteDevId:" + str + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", isForce:" + z4 + ", stopCommShareResponseMsg:" + bVar + ", evaluation:" + remoteDevConnEvaluation + ", requestMsg:" + cVar + ", reasonStr:" + str2 + ", mPreferredDev:" + this.f1309w);
        w.d dVar = this.f1309w;
        if (dVar != null && Objects.equals(dVar.i(), str)) {
            v0(this.f1309w, z2, z3, z4, bVar, remoteDevConnEvaluation, cVar, str2);
            this.D.remove(str);
            w.d dVar2 = this.f1309w;
            this.f1309w = null;
            this.f1310x = null;
            this.f1311y = new z0(str, z2, z3, z4, bVar, remoteDevConnEvaluation, cVar, str2);
            x(dVar2, z3);
            VmdriContext.getInstance().removeCommShareDev(str);
            N0();
            if (dVar2.w()) {
                q1(str);
            }
            u0.r().R(str, 1);
            this.f1289c.C0(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void T0(String str, Object obj, int i2, String str2) {
        Message message = (Message) this.f1307u.remove(str);
        if (message != null) {
            w.k.a(message, obj, i2, str2);
            message.sendToTarget();
        }
    }

    private void U0(String str, Object obj, int i2, String str2) {
        Message message = (Message) this.f1308v.remove(str);
        if (message != null) {
            w.k.a(message, obj, i2, str2);
            message.sendToTarget();
        }
    }

    private void V0(String str, Message message) {
        if (message != null) {
            this.f1307u.put(str, message);
        }
    }

    private void W0(String str, Message message) {
        if (message != null) {
            this.f1308v.put(str, message);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void X0(RemoteDevConnEvaluation.EvaluationReason evaluationReason) {
        w.d dVar = this.f1309w;
        if (dVar == null) {
            K0("reevaluatePreferredRemoteDev, terrible mistake: there is not preferred dev!!!");
            return;
        }
        String strI = dVar.i();
        l lVar = (l) this.B.get(strI);
        if (!this.D.containsKey(strI)) {
            RemoteDevConnEvaluation remoteDevConnEvaluationM0 = m0(evaluationReason);
            if (remoteDevConnEvaluationM0.d()) {
                lVar.q(false, 2, "Evaluate Disallowed:" + remoteDevConnEvaluationM0.toString(), obtainMessage(504, new Pair(strI, remoteDevConnEvaluationM0)));
                return;
            }
            return;
        }
        t("reevaluatePreferredRemoteDev, reason:" + evaluationReason + ", don't reevaluate this device" + this.f1309w + ", notReevaluateAgainMap:" + this.D);
    }

    private Message Y0(String str) {
        return (Message) this.f1307u.remove(str);
    }

    private void Z0(String str, int i2) {
        u0.r().T(str, i2, i2, i2, i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: b1, reason: merged with bridge method [inline-methods] */
    public void F0(String str, int i2) {
        l lVar = (l) this.B.get(str);
        t("sendBusinessState, remoteDevId:" + str + ", businessStateBitmask:(" + i2 + ")" + Constants.convertBusinessTypeBitmaskToString(i2) + ", ctrlChannel:" + lVar);
        if (lVar == null) {
            return;
        }
        lVar.s(i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d1(boolean z2) {
        Settings.Global.putInt(this.f1288b.getContentResolver(), "airplane_mode_on", z2 ? 1 : 0);
        Intent intent = new Intent("android.intent.action.AIRPLANE_MODE");
        intent.putExtra("state", z2);
        this.f1288b.sendBroadcastAsUser(intent, UserHandle.ALL);
    }

    private void e1(String str, boolean z2) {
        t("setUpBrConn, remoteDevId:" + str + ", isUserTarget:" + z2);
        u0.r().b0(str, z2, 1, false);
    }

    private boolean f0(w.d dVar, String str, h0.b bVar) {
        boolean z2 = bVar.f1718c == 1;
        L0("addNewPreferredRemoteDevFromRemote, isUserTarget:" + z2 + ", requestMsg:" + bVar + ", willPreemptedDevId:" + str + ", " + this.f1309w + "->" + dVar);
        w.d dVar2 = this.f1309w;
        if (dVar2 != null) {
            if (!Objects.equals(dVar2.i(), str)) {
                K0("addNewPreferredRemoteDevFromRemote, unexpected behavior!, willPreemptedDevId is illegal.");
                return false;
            }
            l lVar = (l) this.B.get(str);
            if (lVar != null) {
                lVar.q(true, 1, "Preempted by:" + dVar, obtainMessage(505, new Pair(str, null)));
            }
            S0(str, true, true, true, null, null, null, "addNewPreferredRemoteDevFromRemote by preempted");
        }
        R0(dVar, true, z2, null, null, bVar);
        return true;
    }

    private void f1(String str) {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1288b, -1);
        jVar.f(R.string.vivo_comm_share_unavailable_tip);
        SpannedString spannedString = (SpannedString) this.f1288b.getText(R.string.vivo_comm_share_unavailable_both_content);
        Annotation[] annotationArr = (Annotation[]) spannedString.getSpans(0, spannedString.length(), Annotation.class);
        SpannableString spannableString = new SpannableString(spannedString);
        boolean z2 = false;
        for (Annotation annotation : annotationArr) {
            if (annotation.getKey().equals("click") && annotation.getValue().equals("function_close")) {
                spannableString.setSpan(new i(), spannedString.getSpanStart(annotation), spannedString.getSpanEnd(annotation), 33);
                z2 = true;
            }
        }
        jVar.k(spannableString);
        TextView textViewC = jVar.c();
        if (textViewC != null && z2) {
            textViewC.setMovementMethod(LinkMovementMethod.getInstance());
        }
        jVar.h(R.string.vivo_comm_share_unavailable_phone_des);
        jVar.e(R.string.vivo_comm_share_unavailable_phone_check, new j(this));
        Dialog dialogA = jVar.a();
        this.f1295i = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1295i.show();
    }

    private void g1(w.d dVar, int i2) {
        String strP0;
        t("showCommShareConflictDialog, remoteDeviceState:" + dVar + ", preferredState:" + i2);
        if (i2 == 1) {
            strP0 = p0();
        } else if (i2 != 2) {
            strP0 = i2 != 3 ? "" : o0(dVar);
        } else {
            strP0 = q0(dVar);
        }
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1288b, -2);
        jVar.g(this.f1288b.getString(R.string.vivo_start_comm_share_tip));
        jVar.k(strP0);
        jVar.e(R.string.vivo_start_comm_share_msg_confirm, new g(dVar));
        jVar.d(R.string.vivo_comm_share_unavailable_pad_cancel, new DialogInterfaceOnClickListenerC0008h(this, dVar));
        Dialog dialogA = jVar.a();
        this.f1300n = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1300n.show();
    }

    private void h0(String str) {
        t("checkClearCommShareState, mCurTargetStartCommShareInfo:" + this.f1302p + ", mPreferredDev:" + this.f1309w);
        if (this.f1302p == null && this.f1309w == null) {
            t("clear comm share state, remoteDevId:" + str);
            Z0(str, 0);
        }
    }

    private void h1(w.d dVar, HashMap map) {
        String str;
        String str2;
        t("showCommShareInConflictDialog, remoteDeviceState:" + dVar + ", preferredDevs:" + map);
        Iterator it = map.entrySet().iterator();
        if (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            str = (String) entry.getKey();
            str2 = (String) entry.getValue();
        } else {
            str = "";
            str2 = "";
        }
        String strH = dVar.h();
        String string = TextUtils.isEmpty(str2) ? this.f1288b.getString(R.string.vivo_start_comm_share_unknown_connect_msg, strH) : this.f1288b.getString(R.string.vivo_start_comm_share_msg, strH, str2);
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1288b, -2);
        jVar.g(this.f1288b.getString(R.string.vivo_start_comm_share_tip));
        jVar.k(string);
        jVar.e(R.string.vivo_start_comm_share_msg_confirm, new a(dVar, str));
        jVar.d(R.string.vivo_comm_share_unavailable_pad_cancel, new b(this, dVar));
        Dialog dialogA = jVar.a();
        this.f1299m = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1299m.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public t i0(String str) {
        t("clearCommShareStartTargetRecord, reason:" + str + ", mCurCommShareStartTargetInfo:" + this.f1302p);
        t tVar = this.f1302p;
        this.f1302p = null;
        sendMessageAtFrontOfQueue(obtainMessage(512, tVar.c()));
        return tVar;
    }

    private void i1(RemoteDevConnEvaluation remoteDevConnEvaluation, w.d dVar) {
        if (dVar == null) {
            return;
        }
        String strI = dVar.i();
        RemoteDevConnEvaluation.DisallowedReason disallowedReason = RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE;
        if (remoteDevConnEvaluation.c(disallowedReason) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            f1(strI);
            return;
        }
        if (remoteDevConnEvaluation.c(disallowedReason)) {
            k1(strI);
            return;
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            l1();
            return;
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_NOT_SIM)) {
            j1();
            return;
        }
        RemoteDevConnEvaluation.DisallowedReason disallowedReason2 = RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED;
        if (remoteDevConnEvaluation.c(disallowedReason2) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
            g1(dVar, 3);
        } else if (remoteDevConnEvaluation.c(disallowedReason2)) {
            g1(dVar, 1);
        } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
            g1(dVar, 2);
        }
    }

    public static h j0(Context context, Looper looper, d0.l lVar) {
        h hVar;
        synchronized (L) {
            try {
                if (K != null) {
                    throw new RuntimeException("ClientController already created!");
                }
                hVar = new h(context, looper, lVar);
                K = hVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return hVar;
    }

    private void j1() {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1288b, -1);
        jVar.g(this.f1288b.getString(R.string.vivo_comm_share_unavailable_tip));
        jVar.j(R.string.vivo_comm_share_unavailable_no_card_pad_msg);
        jVar.e(R.string.vivo_comm_share_unavailable_phone_check, new DialogInterface.OnClickListener() { // from class: a0.o
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                com.vivo.vmdri.ctrl.h.B(dialogInterface, i2);
            }
        });
        Dialog dialogA = jVar.a();
        this.f1298l = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1298l.show();
    }

    private t k0(w.d dVar, RemoteDevConnEvaluation remoteDevConnEvaluation, boolean z2, String str, boolean z3) {
        t tVar = new t(dVar, remoteDevConnEvaluation, z2, str, z3);
        if (this.f1302p == null) {
            if (remoteDevConnEvaluation.j()) {
                Z0(dVar.i(), 2);
            } else {
                Z0(dVar.i(), 3);
            }
            this.f1302p = tVar;
            this.f1303q.a(tVar);
            return tVar;
        }
        K0("createCommShareStartTargetRecord, unexpected behavior !!! Current in target start comm share, now targetStartCommShareInfo:" + tVar + ", mCurTargetStartCommShareInfo:" + this.f1302p);
        return null;
    }

    private void k1(final String str) {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1288b, -2);
        jVar.g(this.f1288b.getString(R.string.vivo_comm_share_unavailable_tip));
        jVar.k(this.f1288b.getString(R.string.vivo_comm_share_unavailable_pad_msg));
        jVar.e(R.string.vivo_comm_share_unavailable_pad_colse, new DialogInterface.OnClickListener() { // from class: a0.l
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.f73a.G0(str, dialogInterface, i2);
            }
        });
        jVar.d(R.string.vivo_comm_share_unavailable_pad_cancel, new DialogInterface.OnClickListener() { // from class: a0.m
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.dismiss();
            }
        });
        Dialog dialogA = jVar.a();
        this.f1297k = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1297k.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean l0(RemoteDevConnEvaluation.EvaluationReason evaluationReason, boolean z2) {
        int size = this.A.size();
        if (size <= 0 || this.f1309w != null) {
            return false;
        }
        t("evaluateAllConnDevice, reason:" + evaluationReason + ", remoteSize:" + size + ", isFilter:" + z2);
        StringBuilder sb = new StringBuilder();
        sb.append("evaluateAllConnDevice, forbidden listdevices = ");
        sb.append(this.G.toString());
        t(sb.toString());
        Iterator it = this.A.values().iterator();
        while (it.hasNext()) {
            String strI = ((w.d) it.next()).i();
            if (!z2 || !this.G.contains(strI)) {
                if (m1(strI, evaluationReason, false)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void l1() {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1288b, -1);
        jVar.g(this.f1288b.getString(R.string.vivo_comm_share_unavailable_tip));
        jVar.k(this.f1288b.getString(R.string.vivo_comm_share_unavailable_phone_msg));
        jVar.i(this.f1288b.getString(R.string.vivo_comm_share_unavailable_phone_content));
        jVar.e(R.string.vivo_comm_share_unavailable_phone_check, new DialogInterface.OnClickListener() { // from class: a0.k
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                com.vivo.vmdri.ctrl.h.I(dialogInterface, i2);
            }
        });
        Dialog dialogA = jVar.a();
        this.f1296j = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1296j.show();
    }

    private RemoteDevConnEvaluation m0(RemoteDevConnEvaluation.EvaluationReason evaluationReason) {
        t("evaluatePreferredRemoteDev, reason:" + evaluationReason);
        t("evaluatePreferredRemoteDev, LocalDevState:" + this.E);
        t("evaluatePreferredRemoteDev, PreferredRemoteDev:" + this.f1309w);
        RemoteDevConnEvaluation remoteDevConnEvaluation = new RemoteDevConnEvaluation(evaluationReason);
        w.d dVar = this.f1309w;
        if (dVar == null) {
            K0("evaluatePreferredRemoteDev, not preferred remote dev!");
            return remoteDevConnEvaluation;
        }
        remoteDevConnEvaluation.l(dVar.i());
        if (!this.E.F()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_WIFI_DISABLE);
        }
        if (!this.E.z()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_BLUETOOTH_DISABLE);
        }
        if (this.E.x()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE);
        }
        if (this.f1309w.s() <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_NOT_SIM);
        }
        if (!this.f1309w.F()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_WIFI_DISABLE);
        }
        if (!this.f1309w.z()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_BLUETOOTH_DISABLE);
        }
        if (!this.f1309w.v()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN);
        }
        if (this.f1309w.x()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE);
        }
        if ((this.E.t() & this.f1309w.t()) <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.COMBINE_SWITCH_DISABLE);
        }
        if (!remoteDevConnEvaluation.d()) {
            remoteDevConnEvaluation.a(RemoteDevConnEvaluation.AllowedReason.NORMAL);
        }
        t("evaluatePreferredRemoteDev, end:" + remoteDevConnEvaluation);
        return remoteDevConnEvaluation;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:27:0x00ff A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:28:0x0101 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:30:0x010e  */
    /* JADX WARN: Code duplicated, block: B:32:0x0112 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:34:0x0118 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x011a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:39:0x0134  */
    public boolean m1(String str, RemoteDevConnEvaluation.EvaluationReason evaluationReason, boolean z2) {
        boolean z3;
        String strConvertDevInfoToLocalLogMessage;
        t("startCommShareAutoIfNeed, remoteDevId:" + str + ", reason:" + evaluationReason);
        t tVarI0 = z2 ? i0("continue(auto)") : null;
        RemoteDevConnEvaluation remoteDevConnEvaluationN0 = n0(str, evaluationReason);
        l lVar = (l) this.B.get(str);
        w.d dVar = (w.d) this.A.get(str);
        boolean z4 = true;
        if (remoteDevConnEvaluationN0.d()) {
            z3 = false;
            if (remoteDevConnEvaluationN0.e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW)) {
                t("startCommShareAutoIfNeed, need to wait syn dev state");
                this.f1289c.A0(str);
                k0(dVar, remoteDevConnEvaluationN0, false, "", z2);
                sendMessageDelayed(obtainMessage(511, this.f1302p), 14000L);
            } else if (remoteDevConnEvaluationN0.e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN)) {
                t("startCommShareAutoIfNeed, need to wait br conn");
                k0(dVar, remoteDevConnEvaluationN0, false, "", z2);
                sendMessageDelayed(obtainMessage(510, this.f1302p), 14000L);
                e1(str, false);
            } else {
                M0("startCommShareAutoIfNeed, disallowed remoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluationN0);
                if (this.A.size() > 1) {
                    if (!this.G.contains(str)) {
                        this.G.add(str);
                    }
                    sendMessageDelayed(obtainMessage(513), 2000L);
                }
                z4 = false;
            }
            if (z4 && !z2) {
                s0(str, z3, remoteDevConnEvaluationN0);
            } else if (z4 && z2) {
                r0(str, false, 3, tVarI0, remoteDevConnEvaluationN0);
                remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
            } else if (!z4 && !z2) {
                w0(str, z3, remoteDevConnEvaluationN0);
            } else if (z4 && z2) {
                u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
            }
            strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("local", this.E, dVar, this.f1302p, remoteDevConnEvaluationN0.toString());
            if (strConvertDevInfoToLocalLogMessage != null) {
                VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
            }
            return z4;
        }
        k0(dVar, remoteDevConnEvaluationN0, false, "", z2);
        z3 = false;
        lVar.p(false, "", 3, evaluationReason.toString(), obtainMessage(503, this.f1302p));
        if (z4) {
            if (z4) {
                if (!z4) {
                    if (z4) {
                        u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                        remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
                    }
                } else if (z4) {
                    u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                    remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
                }
            } else if (!z4) {
                if (z4) {
                    u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                    remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
                }
            } else if (z4) {
                u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
            }
        } else if (z4) {
            if (!z4) {
                if (z4) {
                    u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                    remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
                }
            } else if (z4) {
                u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
            }
        } else if (!z4) {
            if (z4) {
                u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
                remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
            }
        } else if (z4) {
            u0(str, false, remoteDevConnEvaluationN0, tVarI0, this.f1302p);
            remoteDevConnEvaluationN0 = remoteDevConnEvaluationN0;
        }
        strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("local", this.E, dVar, this.f1302p, remoteDevConnEvaluationN0.toString());
        if (strConvertDevInfoToLocalLogMessage != null) {
            VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
        }
        return z4;
    }

    private RemoteDevConnEvaluation n0(String str, RemoteDevConnEvaluation.EvaluationReason evaluationReason) {
        t("evaluateRemoteDev, curEvaRemoteDevId:" + str + ", reason:" + evaluationReason);
        RemoteDevConnEvaluation remoteDevConnEvaluation = new RemoteDevConnEvaluation(evaluationReason);
        remoteDevConnEvaluation.l(str);
        l lVar = (l) this.B.get(str);
        w.d dVar = (w.d) this.A.get(str);
        t("evaluateRemoteDev, LocalDevState:" + this.E);
        t("evaluateRemoteDev, CurEvaRemoteDevState:" + dVar);
        t("evaluateRemoteDev, PreferredRemoteDev:" + this.f1309w);
        if (lVar == null || dVar == null) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_DEV_NOT_CONN);
            K0("evaluateRemoteDev, device not conn, curEvaCtrlChannel:" + lVar);
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (this.f1302p != null) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.CURRENT_IN_TARGETING);
            t("evaluateRemoteDev, current in targeting:" + this.f1302p);
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (!this.H.isRilBound()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.RIL_SERVICE_NOT_BOUND);
        }
        if (!this.H.isCapabilityServiceBound()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.CAPABILITY_SERVICE_NOT_BOUND);
        }
        w.d dVar2 = this.f1309w;
        if (dVar2 != null) {
            if (Objects.equals(dVar2.i(), str)) {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REPEAT_EVALUATE_PREFERRED_DEV);
            } else {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED);
            }
        }
        if (!remoteDevConnEvaluation.j() && !remoteDevConnEvaluation.i()) {
            if (this.f1312z.containsKey(str)) {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.USER_DISLIKE_THIS_DEV);
            }
            if (!this.E.D()) {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_SCREEN_OFF);
            }
            if ((this.E.t() & 8) != 8) {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_AUTO_CONN_DISABLE);
            }
        }
        if (!this.E.F()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_WIFI_DISABLE);
        }
        if (!this.E.z()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_BLUETOOTH_DISABLE);
        }
        if (this.E.x()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE);
        }
        if (this.E.t() <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_SWITCH_ALL_DISABLE);
        }
        n0 n0Var = (n0) this.C.get(str);
        if (n0Var != null && n0Var.c()) {
            int iA = n0Var.a();
            HashMap mapB = n0Var.b();
            if (mapB != null && mapB.size() >= iA && !mapB.containsKey(this.E.i())) {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED);
            }
        }
        RemoteDevConnEvaluation.DisallowedReason disallowedReason = RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED;
        if (remoteDevConnEvaluation.c(disallowedReason) && evaluationReason == RemoteDevConnEvaluation.EvaluationReason.LOCAL_USER_TARGET_HARD) {
            t("force to start comm share, remoteCommShareState:" + n0Var);
            remoteDevConnEvaluation.k(disallowedReason);
        }
        if (!this.f1289c.h0(str)) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW);
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW)) {
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (!dVar.v()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN);
        }
        if ((this.E.t() & dVar.t()) <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.COMBINE_SWITCH_DISABLE);
        }
        if (!dVar.F()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_WIFI_DISABLE);
        }
        if (!dVar.z()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_BLUETOOTH_DISABLE);
        }
        if (dVar.x()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE);
        }
        if (dVar.s() <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_NOT_SIM);
        }
        if (!remoteDevConnEvaluation.d()) {
            remoteDevConnEvaluation.a(RemoteDevConnEvaluation.AllowedReason.NORMAL);
        }
        t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
        return remoteDevConnEvaluation;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean n1(String str, Message message, boolean z2, String str2, boolean z3) {
        t tVarI0;
        w.d dVar;
        RemoteDevConnEvaluation remoteDevConnEvaluation;
        boolean z4;
        t("startCommShareByUser, remoteDevId:" + str + ", force:" + z2 + ", willPreemptedDevId:" + str2 + ", isContinue:" + z3);
        this.f1312z.remove(str);
        if (z3) {
            message = Y0(str);
            tVarI0 = i0("continue(user)");
        } else {
            tVarI0 = null;
        }
        t tVar = tVarI0;
        RemoteDevConnEvaluation.EvaluationReason evaluationReason = z2 ? RemoteDevConnEvaluation.EvaluationReason.LOCAL_USER_TARGET_HARD : RemoteDevConnEvaluation.EvaluationReason.LOCAL_USER_TARGET_SOFT;
        RemoteDevConnEvaluation remoteDevConnEvaluationN0 = n0(str, evaluationReason);
        l lVar = (l) this.B.get(str);
        w.d dVar2 = (w.d) this.A.get(str);
        if (remoteDevConnEvaluationN0.d()) {
            dVar = dVar2;
            if (remoteDevConnEvaluationN0.e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW)) {
                t("startCommShareByUser, need to wait syn dev state");
                this.f1289c.A0(str);
                V0(str, message);
                remoteDevConnEvaluation = remoteDevConnEvaluationN0;
                k0(dVar, remoteDevConnEvaluation, z2, str2, z3);
                sendMessageDelayed(obtainMessage(511, this.f1302p), 14000L);
            } else if (remoteDevConnEvaluation.e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN)) {
                remoteDevConnEvaluation = remoteDevConnEvaluationN0;
                t("startCommShareByUser, need to wait br conn");
                V0(str, message);
                k0(dVar, remoteDevConnEvaluation, z2, str2, z3);
                dVar = dVar;
                sendMessageDelayed(obtainMessage(510, this.f1302p), 14000L);
                e1(str, true);
            } else {
                M0("startCommShareByUser, disallowed remoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
                Q0(str, remoteDevConnEvaluation, message);
                sendMessageDelayed(obtainMessage(514, new Pair(remoteDevConnEvaluation, dVar)), 380L);
                this.f1289c.I0(remoteDevConnEvaluation);
                z4 = false;
            }
            z4 = true;
        } else {
            V0(str, message);
            k0(dVar2, remoteDevConnEvaluationN0, z2, str2, z3);
            dVar = dVar2;
            lVar.p(z2, str2, 1, evaluationReason.toString(), obtainMessage(503, this.f1302p));
            z4 = true;
        }
        if (!z4 && !z3) {
            s0(str, true, remoteDevConnEvaluation);
        } else if (!z4 && z3) {
            RemoteDevConnEvaluation remoteDevConnEvaluation2 = remoteDevConnEvaluation;
            r0(str, true, 3, tVar, remoteDevConnEvaluation2);
            remoteDevConnEvaluation = remoteDevConnEvaluation2;
        } else if (z4 && !z3) {
            w0(str, true, remoteDevConnEvaluation);
        } else if (z4 && z3) {
            RemoteDevConnEvaluation remoteDevConnEvaluation3 = remoteDevConnEvaluation;
            u0(str, true, remoteDevConnEvaluation3, tVar, this.f1302p);
            remoteDevConnEvaluation = remoteDevConnEvaluation3;
        }
        String strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("local", this.E, dVar, this.f1302p, remoteDevConnEvaluation.toString());
        if (strConvertDevInfoToLocalLogMessage != null) {
            VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
        }
        return z4;
    }

    private String o0(w.d dVar) {
        String strH = this.E.h();
        String strH2 = dVar.h();
        w.d dVar2 = this.f1309w;
        String strH3 = dVar2 != null ? dVar2.h() : "";
        Iterator it = ((n0) this.C.get(dVar.i())).b().entrySet().iterator();
        String str = it.hasNext() ? (String) ((Map.Entry) it.next()).getValue() : "";
        if (TextUtils.isEmpty(strH3) && TextUtils.isEmpty(str)) {
            return this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg8, strH, strH2);
        }
        if (!TextUtils.isEmpty(strH3) || TextUtils.isEmpty(str)) {
            return (TextUtils.isEmpty(strH3) || !TextUtils.isEmpty(str)) ? this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg5, strH, strH3, strH2, str) : this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg6, strH, strH3, strH2);
        }
        return this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg7, strH, strH2, str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: o1, reason: merged with bridge method [inline-methods] */
    public void J0(String str, Message message) {
        t("stopCommShareByUser, remote dev id:" + str + ", preferred remote dev:" + this.f1309w);
        W0(str, message);
        w.d dVar = this.f1309w;
        if (dVar == null) {
            M0("stopCommShareByUser:" + str + "device has disconnected");
            U0(str, null, 28, "device has disconnected");
            return;
        }
        if (Objects.equals(dVar.i(), str)) {
            this.f1312z.put(str, this.f1309w);
            l lVar = (l) this.B.get(str);
            if (lVar != null) {
                lVar.q(true, 1, "user stop", obtainMessage(505, new Pair(str, null)));
            }
            S0(str, false, true, true, null, null, null, "stopCommShareByUser");
            return;
        }
        M0("stopCommShareByUser:" + str + "this device id is not connected");
        U0(str, null, 28, "this device id is not connected");
    }

    private String p0() {
        String strH = this.E.h();
        w.d dVar = this.f1309w;
        String strH2 = dVar != null ? dVar.h() : "";
        return TextUtils.isEmpty(strH2) ? this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg2, strH) : this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg1, strH, strH2);
    }

    private String q0(w.d dVar) {
        String strH = dVar.h();
        Iterator it = ((n0) this.C.get(dVar.i())).b().entrySet().iterator();
        String str = it.hasNext() ? (String) ((Map.Entry) it.next()).getValue() : "";
        return TextUtils.isEmpty(str) ? this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg4, strH) : this.f1288b.getString(R.string.vivo_start_comm_share_in_conflict_msg3, strH, str);
    }

    private void q1(String str) {
        t("tearDownP2pConn, remoteDevId:" + str);
        u0.r().i0(str, 2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void r0(String str, boolean z2, int i2, t tVar, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        M0("handleCommShareConnectFailOnConnecting, remoteDevId:" + str + ", isUserTarget:" + z2 + ", cause:" + i2 + ", lastStartInfo:" + tVar + ", evaluation:" + remoteDevConnEvaluation);
        q0.f.w().k(str, z2, i2, this.E, (w.d) this.A.get(str), tVar, remoteDevConnEvaluation);
    }

    private void r1(t tVar) {
        K0("waitBrConnTimeout, startInfo:" + tVar + ", mCurCommShareStartTargetInfo:" + this.f1302p);
        t tVar2 = this.f1302p;
        if (tVar2 == null || !Objects.equals(tVar, tVar2)) {
            return;
        }
        boolean zF = this.f1302p.f();
        r0(tVar.c(), zF, 6, this.f1302p, null);
        i0("waitBrConnTimeout");
        if (zF) {
            T0(tVar.c(), null, 26, "waitBrConnTimeout");
        }
    }

    private void s0(String str, boolean z2, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        M0("handleCommShareConnectFailOnLocalFastEvaluate, remoteDevId:" + str + ", isUserTarget:" + z2 + ", evaluation:" + remoteDevConnEvaluation);
        q0.f.w().k(str, z2, 2, this.E, (w.d) this.A.get(str), null, remoteDevConnEvaluation);
    }

    private void s1(t tVar) {
        K0("waitDevStateSynTimeout, startInfo:" + tVar + ", mCurCommShareStartTargetInfo:" + this.f1302p);
        t tVar2 = this.f1302p;
        if (tVar2 == null || !Objects.equals(tVar, tVar2)) {
            return;
        }
        boolean zF = this.f1302p.f();
        r0(tVar.c(), zF, 5, this.f1302p, null);
        i0("waitDevStateSynTimeout");
        if (zF) {
            T0(tVar.c(), null, 25, "waitDevStateSynTimeout");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void t(String str) {
        VmdriLog.d("ClientController", str);
    }

    private void t0(w.d dVar, boolean z2, boolean z3, t tVar, i0.a aVar, h0.b bVar) {
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        this.f1305s = jElapsedRealtime;
        this.f1306t = jElapsedRealtime - this.f1304r;
        t("handleCommShareConnected, newPreferDev:" + dVar + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", timestamp:" + this.f1305s + ", buildTime:" + this.f1306t + ", targetInfo:" + tVar + ", responseMsg:" + aVar + ", requestMsg:" + bVar);
    }

    private void u0(String str, boolean z2, RemoteDevConnEvaluation remoteDevConnEvaluation, t tVar, t tVar2) {
        t("handleCommShareContinueConnecting, remoteDevId:" + str + ", isUserTarget:" + z2 + ", evaluation:" + remoteDevConnEvaluation + ", lastStartInfo:" + tVar + ", curStartInfo:" + tVar2);
    }

    private void v0(w.d dVar, boolean z2, boolean z3, boolean z4, i0.b bVar, RemoteDevConnEvaluation remoteDevConnEvaluation, h0.c cVar, String str) {
        t("handleCommShareDisconnected, deviceState:" + dVar + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", isForce:" + z4 + ", stopCommShareResponseMsg:" + bVar + ", evaluation:" + remoteDevConnEvaluation + ", requestMsg:" + cVar + ", reasonStr:" + str);
    }

    private void w0(String str, boolean z2, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        this.f1304r = SystemClock.elapsedRealtime();
        t("handleCommShareConnecting, remoteDevId:" + str + ", isUserTarget:" + z2 + ", timestamp:" + this.f1304r + ", evaluation:" + remoteDevConnEvaluation);
    }

    /* JADX WARN: Code duplicated, block: B:38:0x0110 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:39:0x0112  */
    /* JADX WARN: Code duplicated, block: B:41:0x011e  */
    /* JADX WARN: Code duplicated, block: B:43:0x012c  */
    /* JADX WARN: Code duplicated, block: B:45:0x014e  */
    /* JADX WARN: Code duplicated, block: B:47:0x0156  */
    /* JADX WARN: Code duplicated, block: B:70:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Instruction removed from duplicated block: B:43:0x012c, please report this as an issue */
    private void x0(Message message) {
        t tVarI0;
        int i2;
        int i3;
        AsyncResult asyncResult = (AsyncResult) message.obj;
        t tVar = (t) asyncResult.userObj;
        i0.a aVar = (i0.a) asyncResult.result;
        CtrlException ctrlException = (CtrlException) asyncResult.exception;
        boolean zF = tVar.f();
        String strC = tVar.c();
        w.d dVar = (w.d) this.A.get(strC);
        t("handleTargetStartCommShareDone, targetInfo:" + tVar + ", curStartRemoteDevState:" + dVar + ", response:" + aVar + ", ctrlException:" + ctrlException + ", curTargetInfo:" + this.f1302p);
        t tVar2 = this.f1302p;
        if (tVar2 != null) {
            if (!Objects.equals(tVar2.c(), tVar.c())) {
                K0("handleTargetStartCommShareDone, unexpected behavior! Trigger start comm share with multiple devices at one time!, mCurCommShareStartTargetInfo:" + this.f1302p + ", targetInfo:" + tVar);
            }
            tVarI0 = i0("handleTargetStartCommShareDone");
        } else {
            tVarI0 = null;
        }
        if (dVar == null) {
            K0("handleTargetStartCommShareDone, device:" + strC + ", has been physically disconnected!");
            if (zF) {
                T0(strC, null, 24, "physically disconnected");
            }
            r0(strC, zF, 4, tVarI0, null);
            return;
        }
        if (ctrlException == null) {
            w.d dVar2 = this.f1309w;
            if (dVar2 == null) {
                if (zF) {
                    T0(strC, null, 0, "");
                }
                R0(dVar, false, zF, tVar, aVar, null);
                return;
            }
            if (Objects.equals(strC, dVar2.i())) {
                M0("handleTargetStartCommShareDone, Emmm... same device? ignore.");
                if (zF) {
                    T0(strC, null, 30, "start same device");
                }
                r0(strC, zF, 10, tVarI0, null);
                return;
            }
            K0("handleTargetStartCommShareDone, unexpected behavior!, another device (now preferred remote dev):" + this.f1309w + ", was connected while dev " + strC + " were connected!");
            l lVar = (l) this.B.get(strC);
            if (lVar != null) {
                lVar.q(true, 0, "Unexpected preemption by:" + this.f1309w, obtainMessage(506, new Pair(strC, null)));
            }
            if (zF) {
                T0(strC, null, 29, "unexpected preempted");
            }
            r0(strC, zF, 9, tVarI0, null);
            return;
        }
        K0("handleTargetStartCommShareDone, request deviceState:" + strC + ", exception:" + ctrlException);
        CtrlException.Error ctrlError = ctrlException.getCtrlError();
        if (zF && ctrlError == CtrlException.Error.REJECT_FOR_PREFER_DEV_REACHED) {
            h1(dVar, aVar.f1736c);
        }
        CtrlException.Error error = CtrlException.Error.REJECT_FOR_PREFER_DEV_REACHED;
        if (ctrlError == error) {
            i3 = 7;
        } else if (ctrlError == CtrlException.Error.REJECT_FOR_DEV_NOT_FOUND) {
            i3 = 8;
        } else {
            if (ctrlError != CtrlException.Error.RIL_SERVICE_NOT_BOUND) {
                if (ctrlError == CtrlException.Error.CAPABILITY_SERVICE_NOT_BOUND) {
                    i3 = 12;
                } else {
                    i2 = 1;
                }
                r0(strC, zF, i2, tVarI0, null);
                if (zF) {
                    if (ctrlError == error) {
                        T0(strC, null, 14, asyncResult.exception.toString());
                        return;
                    } else {
                        T0(strC, null, ctrlException.convertToErrorCode(ctrlError), asyncResult.exception.toString());
                        return;
                    }
                }
                K0("StartCommShareException forbidden listdevices = " + this.G.toString());
                if (this.A.size() > 1) {
                    if (!this.G.contains(strC)) {
                        this.G.add(strC);
                    }
                    sendMessageDelayed(obtainMessage(513), 2000L);
                }
            }
            i3 = 11;
        }
        i2 = i3;
        r0(strC, zF, i2, tVarI0, null);
        if (zF) {
            if (ctrlError == error) {
                T0(strC, null, 14, asyncResult.exception.toString());
                return;
            } else {
                T0(strC, null, ctrlException.convertToErrorCode(ctrlError), asyncResult.exception.toString());
                return;
            }
        }
        K0("StartCommShareException forbidden listdevices = " + this.G.toString());
        if (this.A.size() > 1) {
            if (!this.G.contains(strC)) {
                this.G.add(strC);
            }
            sendMessageDelayed(obtainMessage(513), 2000L);
        }
    }

    private void y0(Message message) {
        AsyncResult asyncResult = (AsyncResult) message.obj;
        Pair pair = (Pair) asyncResult.userObj;
        String str = (String) pair.first;
        Object obj = pair.second;
        RemoteDevConnEvaluation remoteDevConnEvaluation = obj instanceof RemoteDevConnEvaluation ? (RemoteDevConnEvaluation) obj : null;
        i0.b bVar = (i0.b) asyncResult.result;
        t("handleStopCommShareByReevaluateDone, stopRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation + ", responseMsg:" + bVar + ", ctrlException:" + ((CtrlException) asyncResult.exception) + ", mPreferredDev:" + this.f1309w);
        w.d dVar = this.f1309w;
        if (dVar == null || !Objects.equals(dVar.i(), str)) {
            M0("handleStopCommShareByReevaluateDone, this dev is not preferred now!");
            return;
        }
        int i2 = bVar.f1737a;
        if (i2 == 0) {
            S0(str, false, false, false, bVar, remoteDevConnEvaluation, null, "handleStopCommShareByReevaluateDone");
            return;
        }
        if (i2 == 6) {
            M0("handleStopCommShareByReevaluateDone, NOT_REEVALUATE_ME from" + str);
            this.D.put(str, bVar);
        }
    }

    private void z0(Message message) {
        AsyncResult asyncResult = (AsyncResult) message.obj;
        t("handleStopCommShareByUnexpectedDone, stopRemoteDevId:" + ((String) ((Pair) asyncResult.userObj).first) + ", responseMsg:" + ((i0.b) asyncResult.result) + ", ctrlException:" + ((CtrlException) asyncResult.exception) + ", mPreferredDevs:" + this.f1309w);
    }

    @Override // a0.d0
    public void a(final String str, final Message message) {
        if (D0()) {
            J0(str, message);
            return;
        }
        M0("targetStopCommShareByUser, not running on ClientController.getLooper().getThread() thread, remoteDevId:" + str);
        post(new Runnable() { // from class: a0.n
            @Override // java.lang.Runnable
            public final void run() {
                this.f91a.J0(str, message);
            }
        });
    }

    public void a1(final String str, final int i2) {
        t("sendBusinessState");
        if (D0()) {
            F0(str, i2);
        } else {
            post(new Runnable() { // from class: a0.t
                @Override // java.lang.Runnable
                public final void run() {
                    this.f115a.F0(str, i2);
                }
            });
        }
    }

    @Override // a0.d0
    public void b(final g0 g0Var) {
        if (D0()) {
            this.f1301o.add(g0Var);
        } else {
            M0("registerCtrlIndication on other thread");
            post(new Runnable() { // from class: a0.r
                @Override // java.lang.Runnable
                public final void run() {
                    this.f108a.E0(g0Var);
                }
            });
        }
    }

    @Override // a0.d0
    public void c(String str, long j2, long j3) {
        l lVar = (l) this.B.get(str);
        t("sendCommShareDataUsage, remoteDevId:" + str + ", dataUsageOfThisConn:" + j2 + ", dataUsageOfThisMonth:" + j3);
        if (lVar == null) {
            return;
        }
        lVar.t(j2, j3);
    }

    public void c1(String str, int i2) {
        l lVar = (l) this.B.get(str);
        t("sendRilState, remoteDevId:" + str + ", rilState:" + i2 + ", ctrlChannel:" + lVar);
        if (lVar == null) {
            return;
        }
        lVar.x(i2);
    }

    @Override // a0.d0
    public y0 d(String str) {
        y0 y0Var = this.f1310x;
        if (y0Var == null || !Objects.equals(y0Var.a(), str)) {
            return null;
        }
        return this.f1310x;
    }

    @Override // a0.d0
    public z0 e(String str) {
        z0 z0Var = this.f1311y;
        if (z0Var == null || !Objects.equals(z0Var.c(), str)) {
            return null;
        }
        return this.f1311y;
    }

    @Override // a0.d0
    public void f(final String str, final Message message) {
        if (D0()) {
            n1(str, message, false, "", false);
            return;
        }
        M0("targetStartCommShareByUser, not running on ClientController.getLooper().getThread() thread, remoteDevId:" + str);
        post(new Runnable() { // from class: a0.p
            @Override // java.lang.Runnable
            public final void run() {
                this.f101a.H0(str, message);
            }
        });
    }

    @Override // a0.d0
    public void g(w wVar) {
        y0 y0Var;
        if (wVar == null) {
            K0("registerDeviceCallback a null callback!");
            return;
        }
        if (!D0()) {
            M0("registerCommShareDeviceCallback on other thread");
            post(new f(wVar));
            return;
        }
        this.f1270a.add(wVar);
        w.d dVar = this.f1309w;
        if (dVar == null || (y0Var = this.f1310x) == null) {
            return;
        }
        w(dVar, y0Var.d());
    }

    public void g0(String str, String str2) {
        l lVar = (l) this.B.get(str);
        if (lVar != null) {
            lVar.d(str2, obtainMessage(507));
            return;
        }
        K0("bringUpRemoteProcess not channel error, remoteDevId:" + str + ", pkgName:" + str2);
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        switch (message.what) {
            case 502:
                t("EVENT_CLEAR_PENDING_RECOVER_DEV, mPendingToRecoverCommShareDevs:" + this.F);
                this.F.clear();
                if (this.f1291e != null) {
                    u0.r().m0(this.f1291e);
                    this.f1291e = null;
                    t("recovered from crash, remove callback");
                }
                break;
            case 503:
                x0(message);
                break;
            case 504:
                y0(message);
                break;
            case 505:
                A0(message);
                break;
            case 506:
                z0(message);
                break;
            case 507:
                t("EVENT_BRINGUP_DONE ex:" + ((AsyncResult) message.obj).exception);
                break;
            case 508:
                String str = (String) message.obj;
                t("EVENT_USER_START_COMM_SHARE, remoteDevId:" + str);
                n1(str, null, false, "", false);
                break;
            case 509:
                Pair pair = (Pair) message.obj;
                String str2 = (String) pair.first;
                RemoteDevConnEvaluation.EvaluationReason evaluationReason = (RemoteDevConnEvaluation.EvaluationReason) pair.second;
                t("EVENT_AUTO_START_COMM_SHARE, remoteDevId:" + str2 + ", reason:" + evaluationReason);
                m1(str2, evaluationReason, false);
                break;
            case 510:
                r1((t) message.obj);
                break;
            case 511:
                s1((t) message.obj);
                break;
            case 512:
                h0((String) message.obj);
                break;
            case 513:
                l0(RemoteDevConnEvaluation.EvaluationReason.LOCAL_DEV_STATE_CHANGED, true);
                break;
            case 514:
                Pair pair2 = (Pair) message.obj;
                RemoteDevConnEvaluation remoteDevConnEvaluation = (RemoteDevConnEvaluation) pair2.first;
                w.d dVar = (w.d) pair2.second;
                t("evaluation = " + remoteDevConnEvaluation + ", deviceState = " + dVar);
                if (remoteDevConnEvaluation != null && dVar != null) {
                    i1(remoteDevConnEvaluation, dVar);
                    break;
                }
                break;
            default:
                t("ClientController Unknown msg.what: " + message.what + ", give super to handle.");
                super.handleMessage(message);
                break;
        }
    }

    public void p1(final String str, final Message message, final String str2) {
        if (D0()) {
            n1(str, message, true, str2, false);
            return;
        }
        M0("targetStartCommShareForceByUser, not running on ClientController.getLooper().getThread() thread, remoteDevId:" + str);
        post(new Runnable() { // from class: a0.s
            @Override // java.lang.Runnable
            public final void run() {
                this.f111a.I0(str, message, str2);
            }
        });
    }

    @Override // com.vivo.vmdri.ctrl.a
    protected void r(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("ClientController:");
        super.r(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mPreferredDev=" + this.f1309w);
        indentingPrintWriter.println("mTargetStartMessages=" + this.f1307u);
        indentingPrintWriter.println("mTargetStopMessages=" + this.f1308v);
        indentingPrintWriter.println("mCurTargetStartCommShareInfo=" + this.f1302p);
        indentingPrintWriter.println("mStartCommShareDoneRecord=" + this.f1310x);
        indentingPrintWriter.println("mStopCommShareDoneRecord=" + this.f1311y);
        indentingPrintWriter.println("mTargetStartCommShareInfos=" + this.f1303q);
        indentingPrintWriter.println("mUserDislikeRemoteDevs=" + this.f1312z);
        indentingPrintWriter.println("mRemoteDevStates=" + this.A);
        indentingPrintWriter.println("mLocalDevState=" + this.E);
        indentingPrintWriter.println("mRemoteDevCommShareStates=" + this.C);
        indentingPrintWriter.println("mNotReevaluateAgainMap=" + this.D);
        indentingPrintWriter.println("mCtrlChannels=" + this.B);
        indentingPrintWriter.println("mPendingToRecoverCommShareDevs=" + this.F);
        indentingPrintWriter.decreaseIndent();
    }

    @Override // com.vivo.vmdri.ctrl.a
    public IBinder s() {
        return this.f1293g;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class j implements DialogInterface.OnClickListener {
        j(h hVar) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    public static /* synthetic */ void B(DialogInterface dialogInterface, int i2) {
    }

    public static /* synthetic */ void I(DialogInterface dialogInterface, int i2) {
    }
}
