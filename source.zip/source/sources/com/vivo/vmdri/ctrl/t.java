package com.vivo.vmdri.ctrl;

import com.vivo.vmdri.VmdriUtils;
import java.util.Objects;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f1426a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private long f1427b = System.currentTimeMillis();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f1428c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f1429d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private String f1430e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f1431f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private w.d f1432g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private RemoteDevConnEvaluation f1433h;

    public t(w.d dVar, RemoteDevConnEvaluation remoteDevConnEvaluation, boolean z2, String str, boolean z3) {
        this.f1426a = "TargetStartCommShareInfo-" + dVar.i();
        this.f1428c = dVar.i();
        this.f1429d = z2;
        this.f1430e = str;
        this.f1431f = z3;
        this.f1433h = remoteDevConnEvaluation;
        this.f1432g = dVar;
    }

    public RemoteDevConnEvaluation a() {
        return this.f1433h;
    }

    public RemoteDevConnEvaluation.EvaluationReason b() {
        return this.f1433h.h();
    }

    public String c() {
        return this.f1428c;
    }

    public String d() {
        return this.f1430e;
    }

    public boolean e() {
        return this.f1429d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            t tVar = (t) obj;
            if (this.f1427b == tVar.f1427b && Objects.equals(this.f1428c, tVar.f1428c)) {
                return true;
            }
        }
        return false;
    }

    public boolean f() {
        return this.f1433h.j();
    }

    public int hashCode() {
        return Objects.hash(Long.valueOf(this.f1427b), this.f1428c);
    }

    public String toString() {
        return "CommShareStartTargetInfo{mLogTag='" + this.f1426a + "', mTargetUtcTime(" + this.f1427b + "):" + VmdriUtils.systemTimeToString(this.f1427b) + ", mEvaluation=" + this.f1433h + ", mRemoteDevId='" + this.f1428c + "', mIsForce='" + this.f1429d + ", mWillPreemptedDevId='" + this.f1430e + ", mIsContinue='" + this.f1431f + ", mRemoteDevState=" + this.f1432g + '}';
    }
}
