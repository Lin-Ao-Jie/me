package com.vivo.vmdri.ctrl;

import a0.a0;
import a0.w;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.widget.Toast;
import c0.u0;
import com.vivo.vmdri.R;
import com.vivo.vmdri.VmdriGlobals;
import com.vivo.vmdri.VmdriLog;
import d0.z;
import java.util.Objects;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class i extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1327a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1328b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Context f1329c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private ContentResolver f1330d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private h f1331e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private TelephonyManager f1332f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private AlarmManager f1333g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private e f1334h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private PendingIntent f1335i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private w.d f1336j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private String f1337k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private w.d f1338l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1339m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private long f1340n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private long f1341o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private d f1342p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1343q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f1344r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private p0.b f1345s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f1346t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private z.c f1347u;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends z.c {
        a() {
        }

        @Override // d0.z.c
        public void a(String str, String str2) {
            i.this.Q(str, str2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends w {
        b(Executor executor) {
            super(executor);
        }

        @Override // a0.w
        public void b(w.c cVar) {
            int iB = cVar.b();
            if (iB != 0) {
                i.H("onConnectFailure: errorCode=" + iB);
                i.this.f1344r = false;
            }
        }

        @Override // a0.w
        public void c(w.d dVar) {
            long j2;
            i.J("onLocalDeviceStateChanged, curLocalDevState:" + dVar);
            w.d dVar2 = i.this.f1338l;
            i.this.f1338l = dVar;
            if (VmdriLog.isDetailDebugLevel()) {
                StringBuilder sb = new StringBuilder();
                sb.append("onLocalDeviceStateChanged, mCommShareDevState:");
                sb.append(i.this.f1336j == null ? "null" : "not null");
                sb.append(", mIsVmdriCallSetupP2p2p:");
                sb.append(i.this.f1343q);
                sb.append(", mRemoteDevId:");
                sb.append(i.this.f1337k);
                sb.append(", p2pIP:");
                sb.append(TextUtils.isEmpty(dVar.o()) ? "null" : dVar.o());
                i.H(sb.toString());
            }
            if (i.this.f1336j == null) {
                if (!i.this.f1343q || i.this.f1337k == null || TextUtils.isEmpty(dVar.o())) {
                    return;
                }
                i.H("p2p setup after commshare disconnect, it should be teardown");
                u0.r().i0(i.this.f1337k, 2);
                i.this.f1337k = null;
                return;
            }
            if (dVar2.E() && !dVar.E()) {
                i.this.D("local wifi ap disable");
                if (i.this.hasMessages(3)) {
                    i.this.removeMessages(3);
                }
            } else if (!dVar2.E() && dVar.E()) {
                i.H("local wifi ap enable");
                i iVar = i.this;
                iVar.sendMessageDelayed(iVar.obtainMessage(3), 5000L);
            } else if (!dVar2.F() && dVar.F()) {
                i.this.D("local wifi enable");
            }
            if (!dVar.D() || dVar2.D()) {
                if (!dVar.D() && dVar2.D() && i.this.f1336j.w()) {
                    i.H("local screen off delay to tear down p2p");
                    i.this.O(60000L);
                }
                j2 = 2000;
            } else {
                i.this.C();
                j2 = 0;
            }
            i.this.P(j2, "localDevStateChanged");
        }

        @Override // a0.w
        public void d(w.d dVar, boolean z2) {
            i.J("onRemoteDeviceConnected, remoteDevState:" + dVar + ", isUserTarget:" + z2);
            i.this.f1344r = z2;
            i.this.f1346t = false;
            i.this.f1336j = dVar;
            i iVar = i.this;
            iVar.f1337k = iVar.f1336j.i();
            if (i.this.f1336j.w()) {
                u0.r().w(dVar.i(), 2);
            } else {
                i.this.D("commShareConnected");
                i.this.M(false, "commShareConnected");
            }
            if (i.this.f1336j.E() || i.this.f1338l.E()) {
                i iVar2 = i.this;
                iVar2.sendMessageDelayed(iVar2.obtainMessage(5), 10000L);
            }
        }

        @Override // a0.w
        public void e(w.d dVar, boolean z2) {
            i.J("onRemoteDeviceDisconnected, remoteDevState:" + dVar + ", isUserTarget:" + z2);
            if (i.this.f1336j == null || !Objects.equals(dVar.i(), i.this.f1336j.i())) {
                i.I("onRemoteDeviceDisconnected, repeated disconnections, or disconnection a wrong device:" + dVar + ", mCommShareDevState:" + i.this.f1336j);
                return;
            }
            i.this.D("commShareDisconnected");
            i.this.removeMessages(2);
            i.this.removeMessages(1);
            i.this.removeMessages(3);
            i.this.removeMessages(4);
            i.this.removeMessages(5);
            i.this.f1336j = null;
            i.this.f1343q = false;
            i.this.f1344r = false;
            i.this.f1346t = false;
        }

        @Override // a0.w
        public void f(w.d dVar) {
            i.J("onRemoteDeviceStateChanged, curRemoteDevState:" + dVar);
            w.d dVar2 = i.this.f1336j;
            i.this.f1336j = dVar;
            i iVar = i.this;
            iVar.f1337k = iVar.f1336j.i();
            if (!dVar2.w() && dVar.w()) {
                i.H("p2p is connected");
                i.this.D("p2p is connected");
                i.this.f1344r = false;
                i.this.f1346t = false;
                i.this.removeMessages(2);
                i.this.removeMessages(1);
                u0.r().w(dVar.i(), 2);
                if (!i.this.f1338l.D()) {
                    i.H("p2p is connected, but local screen is off must delay to tear down p2p");
                    i.this.O(60000L);
                }
            }
            if (dVar2.w() && !dVar.w()) {
                i.H("p2p is disconnected");
                i.this.f1344r = false;
                i.this.f1346t = false;
                i.this.f1340n = SystemClock.elapsedRealtime();
                i.this.D("p2p is disconnected");
                i.this.f1343q = false;
            }
            if (dVar2.E() && !dVar.E()) {
                i.this.D("remote wifi ap is disable");
                if (i.this.hasMessages(4)) {
                    i.this.removeMessages(4);
                }
            } else if (!dVar2.E() && dVar.E()) {
                i.H("remote wifi ap enable");
                i iVar2 = i.this;
                iVar2.sendMessageDelayed(iVar2.obtainMessage(4), 5000L);
            }
            if (!dVar2.F() && dVar.F()) {
                i.this.D("remote wifi is enable");
            }
            if (dVar.w()) {
                return;
            }
            i.this.P(2000L, "remoteDevStateChanged");
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends p0.b.AbstractC0021b {
        c() {
        }

        @Override // p0.b.AbstractC0021b
        public void a() {
            i.this.f1346t = true;
            i iVar = i.this;
            int iL = iVar.L(false, "preempt p2p", iVar.f1346t);
            a0 a0VarT = a0.T();
            if (a0VarT != null) {
                a0VarT.o0(iL);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class d extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override // android.telephony.TelephonyCallback.CallStateListener
        public void onCallStateChanged(int i2) {
            if (i.this.f1339m != i2) {
                StringBuilder sb = new StringBuilder();
                sb.append("onCallStateChanged:");
                i iVar = i.this;
                sb.append(iVar.E(iVar.f1339m));
                sb.append(" -> ");
                sb.append(i.this.E(i2));
                i.H(sb.toString());
                i.this.f1339m = i2;
                if (i.this.f1336j == null) {
                    i.I("onCallStateChanged and mCommShareDevState is null!");
                } else if (i.this.F()) {
                    i.this.D("inCall");
                    i.this.P(0L, "inCall");
                }
            }
        }

        private d() {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class e extends BroadcastReceiver {
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            action.hashCode();
            if (action.equals("com.vivo.vmdri.action.ACTION_TEARDOWN_P2P_CONN")) {
                i.H("screen off delay time out! try to tear down p2p conn! cur:" + SystemClock.elapsedRealtime());
                i.this.N();
                if (i.this.f1335i != null) {
                    i.this.f1335i = null;
                }
            }
        }

        private e() {
        }
    }

    i(Context context, Looper looper, h hVar) {
        super(looper);
        this.f1327a = 0;
        this.f1328b = 0;
        this.f1336j = null;
        this.f1337k = null;
        this.f1338l = new w.d(true);
        this.f1339m = 0;
        this.f1340n = -1L;
        this.f1341o = -1L;
        this.f1343q = false;
        this.f1344r = false;
        this.f1347u = new a();
        this.f1329c = context;
        this.f1330d = context.getContentResolver();
        this.f1331e = hVar;
        this.f1332f = (TelephonyManager) this.f1329c.getSystemService("phone");
        this.f1333g = (AlarmManager) this.f1329c.getSystemService("alarm");
        this.f1342p = new d();
        this.f1332f.registerTelephonyCallback(new Executor() { // from class: a0.u
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f120a.post(runnable);
            }
        }, this.f1342p);
        hVar.g(new b(new Executor() { // from class: a0.u
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f120a.post(runnable);
            }
        }));
        this.f1334h = new e();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.vivo.vmdri.action.ACTION_TEARDOWN_P2P_CONN");
        this.f1329c.registerReceiver(this.f1334h, intentFilter, null, this, 2);
        z.o().v(this.f1347u);
        p0.b notificationMgr = VmdriGlobals.getInstance().getNotificationMgr();
        this.f1345s = notificationMgr;
        this.f1346t = false;
        notificationMgr.O(new c());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void C() {
        H("clearAllAlarms");
        PendingIntent pendingIntent = this.f1335i;
        if (pendingIntent != null) {
            this.f1333g.cancel(pendingIntent);
        }
        this.f1335i = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void D(String str) {
        if (this.f1327a != 0 || this.f1328b != 0) {
            H("clearRetryCache, reason:" + str + ", mSetupP2pRetryTimes:" + this.f1327a + ", mP2pUseToUnuseTimes:" + this.f1328b);
        }
        this.f1327a = 0;
        this.f1328b = 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String E(int i2) {
        if (i2 == 0) {
            return "CALL_STATE_IDLE";
        }
        if (i2 == 1) {
            return "CALL_STATE_RINGING";
        }
        if (i2 == 2) {
            return "CALL_STATE_OFFHOOK";
        }
        return "CALL_STATE_UNKNOWN(" + i2 + ")";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean F() {
        int i2 = this.f1339m;
        return i2 == 1 || i2 == 2;
    }

    private boolean G(String str) {
        str.hashCode();
        return str.equals("GroupCreating") || str.equals("GroupCreated");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void H(String str) {
        VmdriLog.d("ClientP2pConnController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void I(String str) {
        VmdriLog.e("ClientP2pConnController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void J(String str) {
        VmdriLog.v("ClientP2pConnController", str);
    }

    private static void K(String str) {
        VmdriLog.w("ClientP2pConnController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int L(boolean z2, String str, boolean z3) {
        w.d dVar = this.f1336j;
        if (dVar == null) {
            K("onEvaluateSetUpP2pConn, mCommShareDevState is null");
            return 1;
        }
        if (dVar.w()) {
            K("onEvaluateSetUpP2pConn, has p2p conn now");
            return 1;
        }
        if (!this.f1336j.F() || !this.f1338l.F()) {
            J("onEvaluateSetUpP2pConn, wifi switch disable, CommShareDevState WifiOn: " + this.f1336j.F() + ", LocalDevState WifiOn:" + this.f1338l.F());
            return 1;
        }
        if (this.f1336j.E() || this.f1338l.E()) {
            J("onEvaluateSetUpP2pConn, wifi AP on, CommShareDevState WifiApOn: " + this.f1336j.E() + ", LocalDevState WifiApOn:" + this.f1338l.E());
            return 1;
        }
        boolean zD = this.f1338l.D();
        if (F()) {
            zD = true;
        }
        H("onEvaluateSetUpP2pConn, setUp p2p conn, reason:" + str + ", needSetUpP2p:" + zD + ", isRetry:" + z2 + ", mP2pIsUserTarget:" + this.f1344r + ", needPreempt:" + z3 + ", mNeedPreempt:" + this.f1346t + ", mSetupP2pRetryTimes:" + this.f1327a + ", remoteDevId:" + this.f1336j.i());
        if (!zD) {
            return 0;
        }
        this.f1341o = SystemClock.uptimeMillis();
        int iB0 = u0.r().b0(this.f1336j.i(), this.f1344r, 2, this.f1346t);
        this.f1343q = true;
        removeMessages(2);
        sendEmptyMessageDelayed(2, (1 << this.f1327a) * 4000);
        return iB0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M(boolean z2, String str) {
        L(z2, str, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void N() {
        w.d dVar = this.f1336j;
        if (dVar == null) {
            K("onEvaluateTearDownP2pConn, not need to tear down p2p because not in comm share");
            return;
        }
        if (!dVar.w()) {
            K("onEvaluateTearDownP2pConn, not need to tear down p2p because not p2p conn now");
            return;
        }
        if (F()) {
            K("onEvaluateTearDownP2pConn, not allow tear down p2p because is in call");
            return;
        }
        if (this.f1338l.D()) {
            K("onEvaluateTearDownP2pConn, not allow tear down p2p because screen is on");
            return;
        }
        String strI = this.f1336j.i();
        H("onEvaluateTearDownP2pConn, tear down p2p remoteDevId:" + strI);
        u0.r().i0(strI, 2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void O(long j2) {
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        H("setAlarmForTearDownP2p, cur:" + jElapsedRealtime + ", delayMillis:" + j2);
        PendingIntent broadcast = PendingIntent.getBroadcast(this.f1329c, 0, new Intent("com.vivo.vmdri.action.ACTION_TEARDOWN_P2P_CONN"), 201326592);
        this.f1335i = broadcast;
        this.f1333g.setExactAndAllowWhileIdle(2, jElapsedRealtime + j2, broadcast);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void P(long j2, String str) {
        w.d dVar = this.f1336j;
        if (dVar == null || dVar.w()) {
            return;
        }
        if (hasMessages(2)) {
            removeMessages(2);
        }
        if (SystemClock.uptimeMillis() - this.f1340n < 2000 && j2 < 2000) {
            K("setUpP2pConnDelay, p2p has just been disconnected, must wait 2s to setup again!");
            j2 = 2000;
        }
        H("setUpP2pConnDelay, reason:" + str + ", delayMillis:" + j2);
        sendMessageDelayed(obtainMessage(1, str), j2);
    }

    public void Q(String str, String str2) {
        H("updateLocalP2pState: " + str + "->" + str2 + ", mP2pUseToUnuseTimes:" + this.f1328b + ", CommShareDevState:" + this.f1336j);
        w.d dVar = this.f1336j;
        if (dVar == null || dVar.w() || !G(str) || G(str2) || this.f1328b >= 3) {
            return;
        }
        P(2000L, "p2pStateChanged");
        this.f1328b++;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        int i2 = message.what;
        if (i2 == 1) {
            Object obj = message.obj;
            M(false, (obj == null || !(obj instanceof String)) ? "" : (String) obj);
            return;
        }
        if (i2 == 2) {
            this.f1344r = false;
            int i3 = this.f1327a;
            this.f1327a = i3 + 1;
            if (i3 < 4) {
                M(true, "retry");
                return;
            } else {
                I("setup p2p conn too many retries, stop now!");
                return;
            }
        }
        if (i2 != 3 && i2 != 4 && i2 != 5) {
            I("Unknown msg.what: " + message.what);
            return;
        }
        if (this.f1336j == null) {
            H("not need to tip user because commshare disconnect");
        }
        H("hotspot enabled, eventId = " + message.what + ", remote wifiApOn = " + this.f1336j.E() + ", local wifiApOn = " + this.f1338l.E());
        if (this.f1336j.E() || this.f1338l.E()) {
            if (message.what == 5) {
                Toast.makeText(this.f1329c, R.string.vivo_netshare_unavailable_toast_for_prehotspot, 1).show();
            } else {
                Toast.makeText(this.f1329c, R.string.vivo_netshare_unavailable_toast_for_curhotspot, 1).show();
            }
        }
    }
}
