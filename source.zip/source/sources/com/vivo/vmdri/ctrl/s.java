package com.vivo.vmdri.ctrl;

import a0.g0;
import a0.n0;
import a0.w;
import a0.y0;
import a0.z0;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncResult;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings;
import android.text.Annotation;
import android.text.SpannableString;
import android.text.SpannedString;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.ArraySet;
import android.util.IndentingPrintWriter;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;
import c0.u0;
import com.originui.core.utils.VThemeIconUtils;
import com.vivo.commshare.framework.base.Constants;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.R;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class s extends com.vivo.vmdri.ctrl.a {
    private static s I;
    private static final Object J = new Object();
    private final HashMap A;
    private final HashMap B;
    private final HashMap C;
    protected w.d D;
    List E;
    private final DependentServiceController F;
    protected l.c G;
    protected l.b H;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected Context f1387b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected d0.l f1388c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected d0.l.h f1389d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected u0.c f1390e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private o0.e f1391f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private n0.d f1392g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private Dialog f1393h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Dialog f1394i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private Dialog f1395j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private Dialog f1396k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Dialog f1397l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private Dialog f1398m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    protected final Set f1399n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private t f1400o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private w.f f1401p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private long f1402q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private long f1403r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private long f1404s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private HashMap f1405t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private HashMap f1406u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private final HashMap f1407v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private final ConcurrentHashMap f1408w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private final ConcurrentHashMap f1409x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    protected final HashMap f1410y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    protected final HashMap f1411z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1412a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f1413b;

        a(w.d dVar, String str) {
            this.f1412a = dVar;
            this.f1413b = str;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            s.t("showCommShareInConflictDialog target start commShare, remoteDevId:" + this.f1412a.i() + ", willPreemptedDevId:" + this.f1413b);
            s.this.k1(this.f1412a.i(), null, this.f1413b);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1415a;

        b(s sVar, w.d dVar) {
            this.f1415a = dVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            s.t("showCommShareInConflictDialog target start commShare, Cancel preemption, remoteDeviceState:" + this.f1415a);
            dialogInterface.dismiss();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends l.c {
        c() {
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void a(final String str, final int i2) {
            s.t("businessStateIndication:" + str + ", businessStateBitmask:" + Constants.convertBusinessTypeBitmaskToString(i2));
            s.this.f1399n.forEach(new Consumer() { // from class: com.vivo.vmdri.ctrl.o
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    g0 g0Var = (g0) obj;
                    g0Var.invokeFromExecutor(new Runnable() { // from class: com.vivo.vmdri.ctrl.p
                        @Override // java.lang.Runnable
                        public final void run() {
                            g0Var.b(str, i);
                        }
                    });
                }
            });
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void b(final String str, final long j2, final long j3) {
            s.t("commShareStateIndication, remoteDevId:" + str + ", dataUsageOfThisConn:" + j2 + ", dataUsageOfThisMonth:" + j3);
            s.this.f1399n.forEach(new Consumer() { // from class: com.vivo.vmdri.ctrl.n
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    g0 g0Var = (g0) obj;
                    g0Var.invokeFromExecutor(new Runnable() { // from class: com.vivo.vmdri.ctrl.q
                        @Override // java.lang.Runnable
                        public final void run() {
                            g0Var.a(str, j, j);
                        }
                    });
                }
            });
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void c(String str, int i2, boolean z2, HashMap map) {
            s.t("commShareStateIndication, remoteDevId:" + str + ", maxSupportedDevs:" + i2 + ", commShareState:" + z2 + ", preferredDevs:" + map);
            s.this.B.put(str, new n0(str, i2, z2, map));
        }

        @Override // com.vivo.vmdri.ctrl.l.c
        public void d(final String str, final int i2) {
            s.t("rilStateIndication:" + str + ", rilState:" + i2);
            s.this.f1399n.forEach(new Consumer() { // from class: com.vivo.vmdri.ctrl.m
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    g0 g0Var = (g0) obj;
                    g0Var.invokeFromExecutor(new Runnable() { // from class: com.vivo.vmdri.ctrl.r
                        @Override // java.lang.Runnable
                        public final void run() {
                            g0Var.c(str, i);
                        }
                    });
                }
            });
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends l.b {
        d() {
        }

        @Override // com.vivo.vmdri.ctrl.l.b
        public void a(String str, String str2) {
            s.t("bringUpProcessFromRemote, remoteDevId:" + str + ", pkgName:" + str2);
            Intent intent = new Intent("com.vivo.vmdri.intent.action.COMM_SHARE_BRING_UP_PROCESS");
            intent.setPackage(str2);
            s.this.f1387b.sendBroadcast(intent);
        }

        @Override // com.vivo.vmdri.ctrl.l.b
        public i0.a b(String str, h0.b bVar) {
            s.t("starConnFromRemote, curReqRemoteDevId:" + str + ", requestMsg:" + bVar + ", PreferredRemoteDevs:" + s.this.f1407v + ", RemoteDevStates:" + s.this.f1411z);
            i0.a aVarX0 = s.this.x0(str, bVar);
            s sVar = s.this;
            String strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("remote", sVar.D, (w.d) sVar.f1411z.get(str), s.this.f1400o, aVarX0.toString());
            if (strConvertDevInfoToLocalLogMessage != null) {
                VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
            }
            return aVarX0;
        }

        @Override // com.vivo.vmdri.ctrl.l.b
        public i0.b c(String str, h0.c cVar) {
            s.t("stopConnFromRemote, remoteDevId:" + str + ", requestMsg:" + cVar);
            return s.this.y0(str, cVar);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends u0.c {
        e(Executor executor) {
            super(executor);
        }

        @Override // c0.u0.c
        public void c(int i2) {
            s.t("onSdkStateChanged, state:" + i2);
            if (i2 == 2) {
                Iterator it = s.this.E.iterator();
                while (it.hasNext()) {
                    s.this.z((String) it.next());
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w f1419a;

        f(w wVar) {
            this.f1419a = wVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            s.this.f1270a.add(this.f1419a);
            for (w.d dVar : s.this.f1407v.values()) {
                y0 y0Var = (y0) s.this.f1408w.get(dVar.i());
                if (y0Var != null) {
                    s.this.w(dVar, y0Var.d());
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1421a;

        g(w.d dVar) {
            this.f1421a = dVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            String strI;
            w.d dVar = new w.d(false);
            Iterator it = s.this.f1407v.entrySet().iterator();
            String str = "";
            if (it.hasNext()) {
                dVar = (w.d) ((Map.Entry) it.next()).getValue();
                strI = dVar.i();
            } else {
                strI = "";
            }
            s.this.f1410y.put(strI, dVar);
            l lVar = (l) s.this.A.get(strI);
            if (lVar != null) {
                lVar.q(true, 1, "Preempted by:" + this.f1421a, s.this.obtainMessage(505, new Pair(strI, null)));
            }
            s.this.O0(strI, false, true, true, null, null, null, "preempted");
            n0 n0Var = (n0) s.this.B.get(this.f1421a.i());
            if (n0Var != null) {
                Iterator it2 = n0Var.b().entrySet().iterator();
                if (it2.hasNext()) {
                    str = (String) ((Map.Entry) it2.next()).getKey();
                }
            }
            s.t("showCommShareConflictDialog target start commShare, remoteDevId:" + this.f1421a.i() + ", willPreemptedDevId:" + str);
            s.this.k1(this.f1421a.i(), null, str);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class h implements DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ w.d f1423a;

        h(s sVar, w.d dVar) {
            this.f1423a = dVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            s.t("showCommShareConflictDialog target start commShare, Cancel preemption, remoteDeviceState:" + this.f1423a);
            dialogInterface.dismiss();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class i extends ClickableSpan {
        i() {
        }

        @Override // android.text.style.ClickableSpan
        public void onClick(View view) {
            s.this.Y0(false);
        }

        @Override // android.text.style.ClickableSpan, android.text.style.CharacterStyle
        public void updateDrawState(TextPaint textPaint) {
            int color;
            super.updateDrawState(textPaint);
            if (VThemeIconUtils.B()) {
                color = s.this.f1387b.getResources().getColor(R.color.phone_vivo_color_primary);
            } else {
                color = VmdriUtils.AT_LEAST_ROM_15_0 ? s.this.f1387b.getResources().getColor(R.color.os50_vigour_alert_dialog_btn_ok) : s.this.f1387b.getResources().getColor(R.color.vigour_alert_dialog_btn_ok);
            }
            textPaint.setColor(color);
            textPaint.setUnderlineText(false);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class k extends d0.l.h {
        public k(Executor executor) {
            super(executor);
        }

        @Override // d0.l.h
        public void c(w.d dVar) {
            super.c(dVar);
            s sVar = s.this;
            w.d dVar2 = sVar.D;
            sVar.D = dVar;
            s.t("onLocalDeviceStateChangedInternal: oldDev=" + dVar2);
            s.t("onLocalDeviceStateChangedInternal: newDev=" + dVar);
            if (s.this.f1410y.size() > 0) {
                if (dVar2.y() != dVar.y()) {
                    s.H0("local auto conn switch changed, clear mUserStopRemoteDevs!");
                    s.this.f1410y.clear();
                } else if (dVar2.F() != dVar.F()) {
                    s.H0("local wifi enable changed, clear mUserStopRemoteDevs!");
                    s.this.f1410y.clear();
                } else if (dVar2.z() != dVar.z()) {
                    s.H0("local bluetooth enable switch changed, clear mUserStopRemoteDevs!");
                    s.this.f1410y.clear();
                }
            }
            s.this.v(dVar);
        }

        @Override // d0.l.h
        public void d(w.d dVar) {
            super.d(dVar);
            s.t("onRemoteDeviceConnected:" + dVar);
            String strI = dVar.i();
            s sVar = s.this;
            Context context = sVar.f1387b;
            Looper looper = sVar.getLooper();
            s sVar2 = s.this;
            l lVar = new l(context, looper, dVar, sVar2.H, sVar2.G);
            lVar.e();
            s.this.f1411z.put(strI, dVar);
            s.this.A.put(strI, lVar);
            s.this.f1388c.A0(strI);
            s.this.K0(strI);
        }

        @Override // d0.l.h
        public void e(w.d dVar) {
            super.e(dVar);
            s.t("onRemoteDeviceDisConnected:" + dVar);
            String strI = dVar.i();
            l lVar = (l) s.this.A.remove(strI);
            s.this.B.remove(strI);
            if (lVar != null) {
                lVar.f();
            }
            if (s.this.f1407v.containsKey(strI)) {
                s.this.O0(strI, false, false, true, null, null, null, "all phy disconnected");
            }
            if (s.this.f1400o == null || !Objects.equals(s.this.f1400o.c(), strI)) {
                return;
            }
            s.I0("targeting remote dev physical disconnected! curConnTargetInfo:" + s.this.f1400o);
            boolean zF = s.this.f1400o.f();
            if (zF) {
                s.this.P0(strI, null, 0, "allPhysicalDisConn");
            }
            s sVar = s.this;
            sVar.n0(strI, zF, 4, sVar.f1400o, null);
            s.this.g0("all physical disconnected");
        }

        @Override // d0.l.h
        public void f(w.d dVar, boolean z2, boolean z3) {
            super.f(dVar, z2, z3);
            String strI = dVar.i();
            if (((w.d) s.this.f1411z.get(strI)) == null) {
                s.G0("onRemoteDeviceStateRefresh: not find RemoteDevState:" + dVar + " in cache");
                return;
            }
            s.t("onRemoteDeviceStateRefresh:, isRemoteDevStateSyn" + z2 + ", hasChanged" + z3 + ", newDev=" + dVar);
            if (z3) {
                s.this.f1411z.put(strI, dVar);
            }
            if (s.this.f1407v.containsKey(strI) && z3) {
                if (dVar.v()) {
                    s.this.L0(dVar);
                    return;
                } else {
                    s.this.O0(strI, false, false, true, null, null, null, "br disconnect");
                    return;
                }
            }
            if (z2 && s.this.E.contains(strI) && !dVar.y()) {
                s.t("onRemoteDeviceStateChanged, try to recover comm share with:" + dVar);
                s.this.E.remove(strI);
                s.this.sendMessageDelayed(s.this.obtainMessage(509, new Pair(strI, RemoteDevConnEvaluation.EvaluationReason.RECOVER_COMM_SHARE_FROM_CRASH)), 3000L);
                return;
            }
            if (z2 && s.this.f1400o != null && s.this.f1400o.a().e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW) && !s.this.f1400o.f() && Objects.equals(strI, s.this.f1400o.c())) {
                s.t("onRemoteDeviceStateChanged, dev state syn! continue auto trigger start comm share");
                s.this.removeMessages(511);
                s sVar = s.this;
                sVar.h1(strI, sVar.f1400o.b(), true);
                return;
            }
            if (z2 && s.this.f1400o != null && s.this.f1400o.a().e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW) && s.this.f1400o.f() && Objects.equals(strI, s.this.f1400o.c())) {
                s.t("onRemoteDeviceStateChanged, dev state syn! continue user trigger start comm share");
                s.this.removeMessages(511);
                s sVar2 = s.this;
                sVar2.i1(strI, null, sVar2.f1400o.e(), s.this.f1400o.d(), true);
                return;
            }
            if (dVar.v() && s.this.f1400o != null && s.this.f1400o.a().e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN) && !s.this.f1400o.f() && Objects.equals(strI, s.this.f1400o.c())) {
                s.t("onRemoteDeviceStateChanged, br conn! continue auto trigger start comm share");
                s.this.removeMessages(510);
                s sVar3 = s.this;
                sVar3.h1(strI, sVar3.f1400o.b(), true);
                return;
            }
            if (dVar.v() && s.this.f1400o != null && s.this.f1400o.a().e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN) && s.this.f1400o.f() && Objects.equals(strI, s.this.f1400o.c())) {
                s.t("onRemoteDeviceStateChanged, br conn! continue user trigger start comm share");
                s.this.removeMessages(510);
                s sVar4 = s.this;
                sVar4.i1(strI, null, sVar4.f1400o.e(), s.this.f1400o.d(), true);
            }
        }
    }

    private s(Context context, Looper looper, d0.l lVar) {
        super(looper);
        this.f1399n = new ArraySet();
        this.f1401p = new w.f(15);
        this.f1405t = new HashMap();
        this.f1406u = new HashMap();
        this.f1407v = new HashMap();
        this.f1408w = new ConcurrentHashMap();
        this.f1409x = new ConcurrentHashMap();
        this.f1410y = new HashMap();
        this.f1411z = new HashMap();
        this.A = new HashMap();
        this.B = new HashMap();
        this.C = new HashMap();
        this.D = new w.d(true);
        this.E = new ArrayList();
        this.G = new c();
        this.H = new d();
        this.f1387b = context;
        k kVar = new k(new Executor() { // from class: a0.r0
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f110a.post(runnable);
            }
        });
        this.f1389d = kVar;
        this.f1388c = lVar;
        lVar.y0(kVar);
        this.f1392g = new n0.d(this.f1387b, looper, this);
        this.F = DependentServiceController.getInstance();
        VmdriContext vmdriContext = VmdriContext.getInstance();
        if (vmdriContext.isRecoverFromCrash() && vmdriContext.getCommShareDevSize() > 0) {
            this.E = vmdriContext.getCommShareDevs();
            t("mPendingToRecoverCommShareDevs:" + this.E);
            vmdriContext.clearAllCommShareDevs();
            this.f1390e = new e(new Executor() { // from class: a0.r0
                @Override // java.util.concurrent.Executor
                public final void execute(Runnable runnable) {
                    this.f110a.post(runnable);
                }
            });
            u0.r().N(this.f1390e);
            sendEmptyMessageDelayed(502, 60000L);
        }
        this.f1391f = new o0.e(this.f1387b, getLooper(), this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A0(g0 g0Var) {
        this.f1399n.add(g0Var);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C0(String str, DialogInterface dialogInterface, int i2) {
        Y0(false);
        if (this.D.y()) {
            return;
        }
        t("showPhoneOnAirplaneDialog target start commShare, remoteDevId:" + str);
        sendMessageDelayed(obtainMessage(508, str), 2000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void D0(String str, Message message) {
        i1(str, message, false, "", false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E0(String str, Message message, String str2) {
        i1(str, message, true, str2, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void G0(String str) {
        VmdriLog.e("ServerController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void H0(String str) {
        VmdriLog.i("ServerController", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void I0(String str) {
        VmdriLog.w("ServerController", str);
    }

    private void J0() {
        boolean z2;
        int maxSupportedDevNum = VmdriContext.getMaxSupportedDevNum();
        HashMap map = new HashMap();
        if (this.f1407v.size() > 0) {
            for (w.d dVar : this.f1407v.values()) {
                map.put(dVar.i(), dVar.h());
            }
            z2 = true;
        } else {
            z2 = false;
        }
        t("notifyCommStateToRemote, maxSupportedDevs:" + maxSupportedDevNum + ", commShare:" + z2 + ", preferredDevs:" + map);
        Iterator it = this.A.values().iterator();
        while (it.hasNext()) {
            ((l) it.next()).u(maxSupportedDevNum, z2, map);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K0(String str) {
        boolean z2;
        l lVar = (l) this.A.get(str);
        if (lVar == null) {
            return;
        }
        int maxSupportedDevNum = VmdriContext.getMaxSupportedDevNum();
        HashMap map = new HashMap();
        if (this.f1407v.size() > 0) {
            for (w.d dVar : this.f1407v.values()) {
                map.put(dVar.i(), dVar.h());
            }
            z2 = true;
        } else {
            z2 = false;
        }
        lVar.u(maxSupportedDevNum, z2, map);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L0(w.d dVar) {
        t("notifyPreferDevStateChanged, mPreferredDevs:" + this.f1407v + ", newPreferRemoteDevState:" + dVar);
        if (this.f1407v.containsKey(dVar.i())) {
            this.f1407v.put(dVar.i(), dVar);
            y(dVar);
        }
    }

    private void M0(String str, RemoteDevConnEvaluation remoteDevConnEvaluation, Message message) {
        int i2;
        String strG = remoteDevConnEvaluation.g();
        if (message == null) {
            return;
        }
        RemoteDevConnEvaluation.DisallowedReason disallowedReason = RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE;
        if (remoteDevConnEvaluation.c(disallowedReason) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            i2 = 18;
        } else if (remoteDevConnEvaluation.c(disallowedReason)) {
            i2 = 16;
        } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            i2 = 17;
        } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.LOCAL_NOT_SIM)) {
            i2 = 19;
        } else {
            RemoteDevConnEvaluation.DisallowedReason disallowedReason2 = RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED;
            if (remoteDevConnEvaluation.c(disallowedReason2) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
                i2 = 15;
            } else if (remoteDevConnEvaluation.c(disallowedReason2)) {
                i2 = 13;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
                i2 = 14;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REPEAT_EVALUATE_PREFERRED_DEV)) {
                i2 = 21;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_DEV_NOT_CONN)) {
                i2 = 35;
            } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.CURRENT_IN_TARGETING)) {
                i2 = 23;
            } else if (remoteDevConnEvaluation.e(RemoteDevConnEvaluation.DisallowedReason.RIL_SERVICE_NOT_BOUND)) {
                i2 = 33;
            } else {
                i2 = remoteDevConnEvaluation.e(RemoteDevConnEvaluation.DisallowedReason.CAPABILITY_SERVICE_NOT_BOUND) ? 34 : 1;
            }
        }
        w.k.a(message, null, i2, strG);
        message.sendToTarget();
    }

    private void N0(w.d dVar, boolean z2, boolean z3, t tVar, i0.a aVar, h0.b bVar) {
        t("notifyStartPreferDev, curPreferredDevs:" + this.f1407v + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", targetInfo:" + tVar + ", responseMsg:" + aVar + ", requestMsg:" + bVar + ", newPreferDev:" + dVar);
        String strI = dVar.i();
        this.f1407v.put(strI, dVar);
        this.f1409x.remove(strI);
        this.f1408w.put(strI, new y0(strI, z2, z3, tVar, aVar, bVar));
        w(dVar, z3);
        J0();
        VmdriContext.getInstance().addCommShareDev(strI);
        this.f1410y.remove(strI);
        this.f1388c.B0(strI);
        p0(dVar, z2, z3, tVar, aVar, bVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void O0(String str, boolean z2, boolean z3, boolean z4, i0.b bVar, RemoteDevConnEvaluation remoteDevConnEvaluation, h0.c cVar, String str2) {
        t("notifyStopPreferDev, remoteDevId:" + str + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", isForce:" + z4 + ", stopCommShareResponseMsg:" + bVar + ", evaluation:" + remoteDevConnEvaluation + ", requestMsg:" + cVar + ", reasonStr:" + str2 + ", mPreferredDevs:" + this.f1407v);
        w.d dVar = (w.d) this.f1407v.remove(str);
        this.f1408w.remove(str);
        if (dVar == null) {
            return;
        }
        r0(dVar, z2, z3, z4, bVar, remoteDevConnEvaluation, cVar, str2);
        this.f1409x.put(str, new z0(str, z2, z3, z4, bVar, remoteDevConnEvaluation, cVar, str2));
        x(dVar, z3);
        VmdriContext.getInstance().removeCommShareDev(str);
        J0();
        this.f1388c.C0(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void P0(String str, Object obj, int i2, String str2) {
        Message message = (Message) this.f1405t.remove(str);
        if (message != null) {
            w.k.a(message, obj, i2, str2);
            message.sendToTarget();
        }
    }

    private void Q0(String str, Object obj, int i2, String str2) {
        Message message = (Message) this.f1406u.remove(str);
        if (message != null) {
            w.k.a(message, obj, i2, str2);
            message.sendToTarget();
        }
    }

    private void R0(String str, Message message) {
        if (message != null) {
            this.f1405t.put(str, message);
        }
    }

    private void S0(String str, Message message) {
        if (message != null) {
            this.f1406u.put(str, message);
        }
    }

    private Message T0(String str) {
        return (Message) this.f1405t.remove(str);
    }

    private void U0(String str, int i2) {
        u0.r().T(str, i2, i2, i2, i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: W0, reason: merged with bridge method [inline-methods] */
    public void B0(String str, int i2) {
        l lVar = (l) this.A.get(str);
        t("sendBusinessState, remoteDevId:" + str + ", businessStateBitmask:(" + i2 + ")" + Constants.convertBusinessTypeBitmaskToString(i2) + ", ctrlChannel:" + lVar);
        if (lVar == null) {
            return;
        }
        lVar.s(i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Y0(boolean z2) {
        Settings.Global.putInt(this.f1387b.getContentResolver(), "airplane_mode_on", z2 ? 1 : 0);
        Intent intent = new Intent("android.intent.action.AIRPLANE_MODE");
        intent.putExtra("state", z2);
        this.f1387b.sendBroadcastAsUser(intent, UserHandle.ALL);
    }

    private void Z0(String str, boolean z2) {
        t("setUpBrConn, remoteDevId:" + str + ", isUserTarget:" + z2);
        u0.r().b0(str, z2, 1, false);
    }

    private void a1(String str) {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1387b, -1);
        jVar.f(R.string.vivo_comm_share_unavailable_tip);
        SpannedString spannedString = (SpannedString) this.f1387b.getText(R.string.vivo_comm_share_unavailable_both_content1);
        Annotation[] annotationArr = (Annotation[]) spannedString.getSpans(0, spannedString.length(), Annotation.class);
        SpannableString spannableString = new SpannableString(spannedString);
        boolean z2 = false;
        for (Annotation annotation : annotationArr) {
            if (annotation.getKey().equals("click") && annotation.getValue().equals("function_close")) {
                spannableString.setSpan(new i(), spannedString.getSpanStart(annotation), spannedString.getSpanEnd(annotation), 33);
                z2 = true;
            }
        }
        jVar.k(spannableString);
        TextView textViewC = jVar.c();
        if (textViewC != null && z2) {
            textViewC.setMovementMethod(LinkMovementMethod.getInstance());
        }
        jVar.h(R.string.vivo_comm_share_unavailable_pad_des);
        jVar.e(R.string.vivo_comm_share_unavailable_phone_check, new j(this));
        Dialog dialogA = jVar.a();
        this.f1393h = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1393h.show();
    }

    private void b1(w.d dVar, int i2) {
        String strL0;
        t("showCommShareConflictDialog, remoteDeviceState:" + dVar + ", preferredState:" + i2);
        if (i2 == 1) {
            strL0 = l0();
        } else if (i2 != 2) {
            strL0 = i2 != 3 ? "" : k0(dVar);
        } else {
            strL0 = m0(dVar);
        }
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1387b, -2);
        jVar.g(this.f1387b.getString(R.string.vivo_start_comm_share_tip));
        jVar.k(strL0);
        jVar.e(R.string.vivo_start_comm_share_msg_confirm, new g(dVar));
        jVar.d(R.string.vivo_comm_share_unavailable_pad_cancel, new h(this, dVar));
        Dialog dialogA = jVar.a();
        this.f1398m = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1398m.show();
    }

    private void c1(w.d dVar, HashMap map) {
        String str;
        String str2;
        t("showCommShareInConflictDialog, remoteDeviceState:" + dVar + ", preferredDevs:" + map);
        Iterator it = map.entrySet().iterator();
        if (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            str = (String) entry.getKey();
            str2 = (String) entry.getValue();
        } else {
            str = "";
            str2 = "";
        }
        String strH = dVar.h();
        String string = TextUtils.isEmpty(str2) ? this.f1387b.getString(R.string.vivo_start_comm_share_unknown_connect_msg, strH) : this.f1387b.getString(R.string.vivo_start_comm_share_msg, strH, str2);
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1387b, -2);
        jVar.g(this.f1387b.getString(R.string.vivo_start_comm_share_tip));
        jVar.k(string);
        jVar.e(R.string.vivo_start_comm_share_msg_confirm, new a(dVar, str));
        jVar.d(R.string.vivo_comm_share_unavailable_pad_cancel, new b(this, dVar));
        Dialog dialogA = jVar.a();
        this.f1397l = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1397l.show();
    }

    private boolean d0(w.d dVar, String str, h0.b bVar) {
        w.d dVar2;
        l lVar;
        boolean z2 = bVar.f1718c == 1;
        H0("addNewPreferredRemoteDevFromRemote, isUserTarget:" + z2 + ", requestMsg:" + bVar + ", curPreferRemoteDevState:" + dVar + ", willPreemptedDevId:" + str);
        if (this.f1407v.size() >= VmdriContext.getMaxSupportedDevNum()) {
            I0("addNewPreferredRemoteDevFromRemote, , There is already preferredRemoteDev, disconnect it first");
            if (TextUtils.isEmpty(str)) {
                dVar2 = null;
                lVar = null;
            } else {
                dVar2 = (w.d) this.f1407v.get(str);
                lVar = (l) this.A.get(str);
            }
            if (lVar == null || dVar2 == null) {
                G0("addNewPreferredRemoteDevFromRemote, unexpected behavior!, willPreemptedDevId is illegal.");
                return false;
            }
            t("addNewPreferredRemoteDevFromRemote, stop willPreemptedDev:" + dVar2);
            lVar.q(true, 1, "Preempted by:" + dVar, obtainMessage(505, new Pair(str, null)));
            O0(str, true, true, true, null, null, null, "addNewPreferredRemoteDevFromRemote by preempted");
        }
        N0(dVar, true, z2, null, null, bVar);
        return true;
    }

    private void d1(RemoteDevConnEvaluation remoteDevConnEvaluation, w.d dVar) {
        String strI = dVar.i();
        RemoteDevConnEvaluation.DisallowedReason disallowedReason = RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE;
        if (remoteDevConnEvaluation.c(disallowedReason) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            a1(strI);
            return;
        }
        if (remoteDevConnEvaluation.c(disallowedReason)) {
            g1(strI);
            return;
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE)) {
            f1();
            return;
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.LOCAL_NOT_SIM)) {
            e1();
            return;
        }
        RemoteDevConnEvaluation.DisallowedReason disallowedReason2 = RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED;
        if (remoteDevConnEvaluation.c(disallowedReason2) && remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
            b1(dVar, 3);
        } else if (remoteDevConnEvaluation.c(disallowedReason2)) {
            b1(dVar, 1);
        } else if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED)) {
            b1(dVar, 2);
        }
    }

    private void e1() {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1387b, -1);
        jVar.g(this.f1387b.getString(R.string.vivo_comm_share_unavailable_tip));
        jVar.j(R.string.vivo_comm_share_unavailable_no_card_pad_msg);
        jVar.e(R.string.vivo_comm_share_unavailable_phone_check, new DialogInterface.OnClickListener() { // from class: a0.s0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                com.vivo.vmdri.ctrl.s.D(dialogInterface, i2);
            }
        });
        Dialog dialogA = jVar.a();
        this.f1396k = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1396k.show();
    }

    private void f0(String str) {
        t("checkClearCommShareState, mCurTargetStartCommShareInfo:" + this.f1400o + ", mPreferredDevs:" + this.f1407v);
        if (this.f1400o != null || this.f1407v.containsKey(str)) {
            return;
        }
        t("clear comm share state, remoteDevId:" + str);
        U0(str, 0);
    }

    private void f1() {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1387b, -1);
        jVar.g(this.f1387b.getString(R.string.vivo_comm_share_unavailable_tip));
        jVar.k(this.f1387b.getString(R.string.vivo_comm_share_unavailable_pad_msg_no_action));
        jVar.i(this.f1387b.getString(R.string.vivo_comm_share_unavailable_phone_content));
        jVar.e(R.string.vivo_comm_share_unavailable_phone_check, new DialogInterface.OnClickListener() { // from class: a0.q0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                com.vivo.vmdri.ctrl.s.G(dialogInterface, i2);
            }
        });
        Dialog dialogA = jVar.a();
        this.f1394i = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1394i.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public t g0(String str) {
        t("clearCommShareStartTargetRecord, reason:" + str + ", mCurCommShareStartTargetInfo:" + this.f1400o);
        t tVar = this.f1400o;
        this.f1400o = null;
        sendMessageAtFrontOfQueue(obtainMessage(512, tVar.c()));
        return tVar;
    }

    private void g1(final String str) {
        com.originui.widget.dialog.j jVar = new com.originui.widget.dialog.j(this.f1387b, -2);
        jVar.g(this.f1387b.getString(R.string.vivo_comm_share_unavailable_tip));
        jVar.k(this.f1387b.getString(R.string.vivo_comm_share_unavailable_phone_msg_action));
        jVar.e(R.string.vivo_comm_share_unavailable_pad_colse, new DialogInterface.OnClickListener() { // from class: a0.t0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.f118a.C0(str, dialogInterface, i2);
            }
        });
        jVar.d(R.string.vivo_comm_share_unavailable_pad_cancel, new DialogInterface.OnClickListener() { // from class: a0.u0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.dismiss();
            }
        });
        Dialog dialogA = jVar.a();
        this.f1395j = dialogA;
        dialogA.getWindow().setType(2008);
        this.f1395j.show();
    }

    public static s h0(Context context, Looper looper, d0.l lVar) {
        s sVar;
        synchronized (J) {
            try {
                if (I != null) {
                    throw new RuntimeException("ServerController already created!");
                }
                sVar = new s(context, looper, lVar);
                I = sVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return sVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:21:0x00c2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:22:0x00c4 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:24:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:26:0x00d5 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:28:0x00db A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:29:0x00dd A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:33:0x00f7  */
    public boolean h1(String str, RemoteDevConnEvaluation.EvaluationReason evaluationReason, boolean z2) {
        boolean z3;
        String strConvertDevInfoToLocalLogMessage;
        t("startCommShareAutoIfNeed, remoteDevId:" + str + ", reason:" + evaluationReason);
        t tVarG0 = z2 ? g0("continue(auto)") : null;
        RemoteDevConnEvaluation remoteDevConnEvaluationJ0 = j0(str, evaluationReason);
        l lVar = (l) this.A.get(str);
        w.d dVar = (w.d) this.f1411z.get(str);
        boolean z4 = true;
        if (remoteDevConnEvaluationJ0.d()) {
            z3 = false;
            if (remoteDevConnEvaluationJ0.e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW)) {
                t("startCommShareAutoIfNeed, need to wait syn dev state");
                this.f1388c.A0(str);
                i0(dVar, remoteDevConnEvaluationJ0, false, "", z2);
                sendMessageDelayed(obtainMessage(511, this.f1400o), 14000L);
            } else if (remoteDevConnEvaluationJ0.e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN)) {
                t("startCommShareAutoIfNeed, need to wait br conn");
                i0(dVar, remoteDevConnEvaluationJ0, false, "", z2);
                sendMessageDelayed(obtainMessage(510, this.f1400o), 14000L);
                Z0(str, false);
            } else {
                z4 = false;
            }
            if (z4 && !z2) {
                o0(str, z3, remoteDevConnEvaluationJ0);
            } else if (z4 && z2) {
                n0(str, false, 3, tVarG0, remoteDevConnEvaluationJ0);
                remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
            } else if (!z4 && !z2) {
                s0(str, z3, remoteDevConnEvaluationJ0);
            } else if (z4 && z2) {
                q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
            }
            strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("local", this.D, dVar, this.f1400o, remoteDevConnEvaluationJ0.toString());
            if (strConvertDevInfoToLocalLogMessage != null) {
                VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
            }
            return z4;
        }
        i0(dVar, remoteDevConnEvaluationJ0, false, "", z2);
        z3 = false;
        lVar.p(false, "", 3, evaluationReason.toString(), obtainMessage(503, this.f1400o));
        if (z4) {
            if (z4) {
                if (!z4) {
                    if (z4) {
                        q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                        remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
                    }
                } else if (z4) {
                    q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                    remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
                }
            } else if (!z4) {
                if (z4) {
                    q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                    remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
                }
            } else if (z4) {
                q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
            }
        } else if (z4) {
            if (!z4) {
                if (z4) {
                    q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                    remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
                }
            } else if (z4) {
                q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
            }
        } else if (!z4) {
            if (z4) {
                q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
                remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
            }
        } else if (z4) {
            q0(str, false, remoteDevConnEvaluationJ0, tVarG0, this.f1400o);
            remoteDevConnEvaluationJ0 = remoteDevConnEvaluationJ0;
        }
        strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("local", this.D, dVar, this.f1400o, remoteDevConnEvaluationJ0.toString());
        if (strConvertDevInfoToLocalLogMessage != null) {
            VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
        }
        return z4;
    }

    private t i0(w.d dVar, RemoteDevConnEvaluation remoteDevConnEvaluation, boolean z2, String str, boolean z3) {
        t tVar = new t(dVar, remoteDevConnEvaluation, z2, str, z3);
        if (this.f1400o == null) {
            if (remoteDevConnEvaluation.j()) {
                U0(dVar.i(), 2);
            } else {
                U0(dVar.i(), 3);
            }
            this.f1400o = tVar;
            this.f1401p.a(tVar);
            return tVar;
        }
        G0("createCommShareStartTargetRecord, unexpected behavior !!! Current in target start comm share, now targetStartCommShareInfo:" + tVar + ", mCurTargetStartCommShareInfo:" + this.f1400o);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean i1(String str, Message message, boolean z2, String str2, boolean z3) {
        t tVarG0;
        w.d dVar;
        RemoteDevConnEvaluation remoteDevConnEvaluation;
        boolean z4;
        t("startCommShareByUser, remoteDevId:" + str + ", force:" + z2 + ", willPreemptedDevId:" + str2 + ", isContinue:" + z3);
        this.f1410y.remove(str);
        if (z3) {
            message = T0(str);
            tVarG0 = g0("continue(user)");
        } else {
            tVarG0 = null;
        }
        t tVar = tVarG0;
        RemoteDevConnEvaluation.EvaluationReason evaluationReason = z2 ? RemoteDevConnEvaluation.EvaluationReason.LOCAL_USER_TARGET_HARD : RemoteDevConnEvaluation.EvaluationReason.LOCAL_USER_TARGET_SOFT;
        RemoteDevConnEvaluation remoteDevConnEvaluationJ0 = j0(str, evaluationReason);
        l lVar = (l) this.A.get(str);
        w.d dVar2 = (w.d) this.f1411z.get(str);
        if (remoteDevConnEvaluationJ0.d()) {
            dVar = dVar2;
            if (remoteDevConnEvaluationJ0.e(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW)) {
                t("startCommShareByUser, need to wait syn dev state");
                this.f1388c.A0(str);
                R0(str, message);
                remoteDevConnEvaluation = remoteDevConnEvaluationJ0;
                i0(dVar, remoteDevConnEvaluation, z2, str2, z3);
                sendMessageDelayed(obtainMessage(511, this.f1400o), 14000L);
            } else if (remoteDevConnEvaluation.e(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN)) {
                remoteDevConnEvaluation = remoteDevConnEvaluationJ0;
                t("startCommShareByUser, need to wait br conn");
                R0(str, message);
                i0(dVar, remoteDevConnEvaluation, z2, str2, z3);
                dVar = dVar;
                sendMessageDelayed(obtainMessage(510, this.f1400o), 14000L);
                Z0(str, true);
            } else {
                I0("startCommShareByUser, disallowed remoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
                M0(str, remoteDevConnEvaluation, message);
                sendMessageDelayed(obtainMessage(513, new Pair(remoteDevConnEvaluation, dVar)), 380L);
                this.f1388c.I0(remoteDevConnEvaluation);
                z4 = false;
            }
            z4 = true;
        } else {
            R0(str, message);
            i0(dVar2, remoteDevConnEvaluationJ0, z2, str2, z3);
            dVar = dVar2;
            lVar.p(z2, str2, 1, evaluationReason.toString(), obtainMessage(503, this.f1400o));
            z4 = true;
        }
        if (!z4 && !z3) {
            o0(str, true, remoteDevConnEvaluation);
        } else if (!z4 && z3) {
            RemoteDevConnEvaluation remoteDevConnEvaluation2 = remoteDevConnEvaluation;
            n0(str, true, 3, tVar, remoteDevConnEvaluation2);
            remoteDevConnEvaluation = remoteDevConnEvaluation2;
        } else if (z4 && !z3) {
            s0(str, true, remoteDevConnEvaluation);
        } else if (z4 && z3) {
            RemoteDevConnEvaluation remoteDevConnEvaluation3 = remoteDevConnEvaluation;
            q0(str, true, remoteDevConnEvaluation3, tVar, this.f1400o);
            remoteDevConnEvaluation = remoteDevConnEvaluation3;
        }
        String strConvertDevInfoToLocalLogMessage = VmdriUtils.convertDevInfoToLocalLogMessage("local", this.D, dVar, this.f1400o, remoteDevConnEvaluation.toString());
        if (strConvertDevInfoToLocalLogMessage != null) {
            VmdriLog.localLog(VmdriLog.REASON_DUMP_COMM_SHARE_INFO, strConvertDevInfoToLocalLogMessage);
        }
        return z4;
    }

    private RemoteDevConnEvaluation j0(String str, RemoteDevConnEvaluation.EvaluationReason evaluationReason) {
        t("evaluateRemoteDev, curEvaRemoteDevId:" + str + ", reason:" + evaluationReason);
        RemoteDevConnEvaluation remoteDevConnEvaluation = new RemoteDevConnEvaluation(evaluationReason);
        remoteDevConnEvaluation.l(str);
        l lVar = (l) this.A.get(str);
        w.d dVar = (w.d) this.f1411z.get(str);
        t("evaluateRemoteDev, LocalDevState:" + this.D);
        t("evaluateRemoteDev, CurEvaRemoteDevState:" + dVar);
        t("evaluateRemoteDev, PreferredRemoteDev:" + this.f1407v);
        if (lVar == null || dVar == null) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_DEV_NOT_CONN);
            G0("evaluateRemoteDev, device not conn, curEvaCtrlChannel:" + lVar);
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (this.f1400o != null) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.CURRENT_IN_TARGETING);
            t("evaluateRemoteDev, current in targeting:" + this.f1400o);
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (!this.F.isRilBound()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.RIL_SERVICE_NOT_BOUND);
        }
        if (!this.F.isCapabilityServiceBound()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.CAPABILITY_SERVICE_NOT_BOUND);
        }
        if (!remoteDevConnEvaluation.j() && !remoteDevConnEvaluation.i()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_AUTO_CONN_DISABLE);
            G0("evaluateRemoteDev, only user target or recovery from crash for phone ");
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (this.f1407v.containsKey(str)) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REPEAT_EVALUATE_PREFERRED_DEV);
        } else if (this.f1407v.size() >= VmdriContext.getMaxSupportedDevNum()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED);
        }
        if (!this.D.F()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_WIFI_DISABLE);
        }
        if (!this.D.z()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_BLUETOOTH_DISABLE);
        }
        if (this.D.x()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE);
        }
        if (this.D.t() <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_SWITCH_ALL_DISABLE);
        }
        if (this.D.s() <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.LOCAL_NOT_SIM);
        }
        n0 n0Var = (n0) this.B.get(str);
        if (n0Var != null && n0Var.c()) {
            int iA = n0Var.a();
            HashMap mapB = n0Var.b();
            if (mapB != null && mapB.size() >= iA && !mapB.containsKey(this.D.i())) {
                remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED);
            }
        }
        RemoteDevConnEvaluation.DisallowedReason disallowedReason = RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED;
        if (remoteDevConnEvaluation.c(disallowedReason) && evaluationReason == RemoteDevConnEvaluation.EvaluationReason.LOCAL_USER_TARGET_HARD) {
            t("force to start comm share, remoteCommShareState:" + n0Var);
            remoteDevConnEvaluation.k(disallowedReason);
        }
        if (!this.f1388c.h0(str)) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW);
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW)) {
            t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
            return remoteDevConnEvaluation;
        }
        if (!dVar.v()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN);
        }
        if ((this.D.t() & dVar.t()) <= 0) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.COMBINE_SWITCH_DISABLE);
        }
        if (!dVar.F()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_WIFI_DISABLE);
        }
        if (!dVar.z()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_BLUETOOTH_DISABLE);
        }
        if (dVar.x()) {
            remoteDevConnEvaluation.b(RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE);
        }
        if (!remoteDevConnEvaluation.d()) {
            remoteDevConnEvaluation.a(RemoteDevConnEvaluation.AllowedReason.NORMAL);
        }
        t("evaluateRemoteDev end, curEvaRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation);
        return remoteDevConnEvaluation;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: j1, reason: merged with bridge method [inline-methods] */
    public void F0(String str, Message message) {
        t("stopCommShareByUser, remote dev id:" + str + ", preferred remote devs:" + this.f1407v);
        S0(str, message);
        w.d dVar = (w.d) this.f1407v.get(str);
        if (dVar != null) {
            this.f1410y.put(str, dVar);
            ((l) this.A.get(str)).q(true, 1, "user stop", obtainMessage(505, new Pair(str, null)));
            O0(str, false, true, true, null, null, null, "stopCommShareByUser");
        } else {
            I0("stopCommShareByUser:" + str + "device has disconnected");
            Q0(str, null, 28, "device has disconnected");
        }
    }

    private String k0(w.d dVar) {
        String strH = this.D.h();
        String strH2 = dVar.h();
        Iterator it = this.f1407v.entrySet().iterator();
        String strH3 = it.hasNext() ? ((w.d) ((Map.Entry) it.next()).getValue()).h() : "";
        Iterator it2 = ((n0) this.B.get(dVar.i())).b().entrySet().iterator();
        String str = it2.hasNext() ? (String) ((Map.Entry) it2.next()).getValue() : "";
        if (TextUtils.isEmpty(strH3) && TextUtils.isEmpty(str)) {
            return this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg8, strH, strH2);
        }
        if (!TextUtils.isEmpty(strH3) || TextUtils.isEmpty(str)) {
            return (TextUtils.isEmpty(strH3) || !TextUtils.isEmpty(str)) ? this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg5, strH, strH3, strH2, str) : this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg6, strH, strH3, strH2);
        }
        return this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg7, strH, strH2, str);
    }

    private String l0() {
        String strH = this.D.h();
        Iterator it = this.f1407v.entrySet().iterator();
        String strH2 = it.hasNext() ? ((w.d) ((Map.Entry) it.next()).getValue()).h() : "";
        return TextUtils.isEmpty(strH2) ? this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg2, strH) : this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg1, strH, strH2);
    }

    private void l1(t tVar) {
        G0("waitBrConnTimeout, startInfo:" + tVar + ", mCurCommShareStartTargetInfo:" + this.f1400o);
        t tVar2 = this.f1400o;
        if (tVar2 == null || !Objects.equals(tVar, tVar2)) {
            return;
        }
        boolean zF = this.f1400o.f();
        n0(tVar.c(), zF, 6, this.f1400o, null);
        g0("waitBrConnTimeout");
        if (zF) {
            P0(tVar.c(), null, 26, "waitBrConnTimeout");
        }
    }

    private String m0(w.d dVar) {
        String strH = dVar.h();
        Iterator it = ((n0) this.B.get(dVar.i())).b().entrySet().iterator();
        String str = it.hasNext() ? (String) ((Map.Entry) it.next()).getValue() : "";
        return TextUtils.isEmpty(str) ? this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg4, strH) : this.f1387b.getString(R.string.vivo_start_comm_share_in_conflict_msg3, strH, str);
    }

    private void m1(t tVar) {
        G0("waitDevStateSynTimeout, startInfo:" + tVar + ", mCurCommShareStartTargetInfo:" + this.f1400o);
        t tVar2 = this.f1400o;
        if (tVar2 == null || !Objects.equals(tVar, tVar2)) {
            return;
        }
        boolean zF = this.f1400o.f();
        n0(tVar.c(), zF, 5, this.f1400o, null);
        g0("waitDevStateSynTimeout");
        if (zF) {
            P0(tVar.c(), null, 25, "waitDevStateSynTimeout");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void n0(String str, boolean z2, int i2, t tVar, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        I0("handleCommShareConnectFailOnConnecting, remoteDevId:" + str + ", isUserTarget:" + z2 + ", cause:" + i2 + ", lastStartInfo:" + tVar + ", evaluation:" + remoteDevConnEvaluation);
        q0.f.w().k(str, z2, i2, this.D, (w.d) this.f1411z.get(str), tVar, remoteDevConnEvaluation);
    }

    private void o0(String str, boolean z2, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        I0("handleCommShareConnectFailOnLocalFastEvaluate, remoteDevId:" + str + ", isUserTarget:" + z2 + ", evaluation:" + remoteDevConnEvaluation);
        q0.f.w().k(str, z2, 2, this.D, (w.d) this.f1411z.get(str), null, remoteDevConnEvaluation);
    }

    private void p0(w.d dVar, boolean z2, boolean z3, t tVar, i0.a aVar, h0.b bVar) {
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        this.f1403r = jElapsedRealtime;
        this.f1404s = jElapsedRealtime - this.f1402q;
        t("handleCommShareConnected, newPreferDev:" + dVar + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", timestamp:" + this.f1403r + ", buildTime:" + this.f1404s + ", targetInfo:" + tVar + ", responseMsg:" + aVar + ", requestMsg:" + bVar);
    }

    private void q0(String str, boolean z2, RemoteDevConnEvaluation remoteDevConnEvaluation, t tVar, t tVar2) {
        t("handleCommShareContinueConnecting, remoteDevId:" + str + ", isUserTarget:" + z2 + ", evaluation:" + remoteDevConnEvaluation + ", lastStartInfo:" + tVar + ", curStartInfo:" + tVar2);
    }

    private void r0(w.d dVar, boolean z2, boolean z3, boolean z4, i0.b bVar, RemoteDevConnEvaluation remoteDevConnEvaluation, h0.c cVar, String str) {
        t("handleCommShareDisconnected, deviceState:" + dVar + ", isFromRemote:" + z2 + ", isUserTarget:" + z3 + ", isForce:" + z4 + ", stopCommShareResponseMsg:" + bVar + ", evaluation:" + remoteDevConnEvaluation + ", requestMsg:" + cVar + ", reasonStr:" + str);
    }

    private void s0(String str, boolean z2, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        this.f1402q = SystemClock.elapsedRealtime();
        t("handleCommShareConnecting, remoteDevId:" + str + ", isUserTarget:" + z2 + ", timestamp:" + this.f1402q + ", evaluation:" + remoteDevConnEvaluation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void t(String str) {
        VmdriLog.d("ServerController", str);
    }

    private void t0(Message message) {
        t tVarG0;
        AsyncResult asyncResult = (AsyncResult) message.obj;
        t tVar = (t) asyncResult.userObj;
        i0.a aVar = (i0.a) asyncResult.result;
        CtrlException ctrlException = (CtrlException) asyncResult.exception;
        boolean zF = tVar.f();
        String strC = tVar.c();
        w.d dVar = (w.d) this.f1411z.get(strC);
        t("handleTargetStartCommShareDone, targetInfo:" + tVar + ", curStartRemoteDevState:" + dVar + ", response:" + aVar + ", ctrlException:" + ctrlException + ", curTargetInfo:" + this.f1400o);
        t tVar2 = this.f1400o;
        if (tVar2 != null) {
            if (!Objects.equals(tVar2.c(), tVar.c())) {
                G0("handleTargetStartCommShareDone, unexpected behavior! Trigger start comm share with multiple devices at one time!, mCurCommShareStartTargetInfo:" + this.f1400o + ", targetInfo:" + tVar);
            }
            tVarG0 = g0("handleTargetStartCommShareDone");
        } else {
            tVarG0 = null;
        }
        if (dVar == null) {
            G0("handleTargetStartCommShareDone, device:" + strC + ", has been physically disconnected!");
            if (zF) {
                P0(strC, null, 24, "physically disconnected");
            }
            n0(strC, zF, 4, tVarG0, null);
            return;
        }
        int i2 = 1;
        if (ctrlException != null) {
            G0("handleTargetStartCommShareDone, request deviceState:" + strC + ", exception:" + ctrlException);
            CtrlException.Error ctrlError = ctrlException.getCtrlError();
            if (zF && ctrlError == CtrlException.Error.REJECT_FOR_PREFER_DEV_REACHED) {
                c1(dVar, aVar.f1736c);
            }
            CtrlException.Error error = CtrlException.Error.REJECT_FOR_PREFER_DEV_REACHED;
            if (ctrlError == error) {
                i2 = 7;
            } else if (ctrlError == CtrlException.Error.REJECT_FOR_DEV_NOT_FOUND) {
                i2 = 8;
            } else if (ctrlError == CtrlException.Error.RIL_SERVICE_NOT_BOUND) {
                i2 = 11;
            } else if (ctrlError == CtrlException.Error.CAPABILITY_SERVICE_NOT_BOUND) {
                i2 = 12;
            }
            n0(strC, zF, i2, tVarG0, null);
            if (zF) {
                if (ctrlError == error) {
                    P0(strC, null, 14, asyncResult.exception.toString());
                    return;
                } else {
                    P0(strC, null, ctrlException.convertToErrorCode(ctrlError), asyncResult.exception.toString());
                    return;
                }
            }
            return;
        }
        if (this.f1407v.size() < VmdriContext.getMaxSupportedDevNum()) {
            if (zF) {
                P0(strC, null, 0, "");
            }
            N0(dVar, false, zF, tVar, aVar, null);
            return;
        }
        if (this.f1407v.containsKey(dVar.i())) {
            I0("handleTargetStartCommShareDone, Emmm... start same device? ignore.");
            if (zF) {
                P0(strC, null, 30, "start same device");
            }
            n0(strC, zF, 10, tVarG0, null);
            return;
        }
        G0("handleTargetStartCommShareDone, unexpected behavior!, another device (now preferred remote dev):" + this.f1407v + ", was connected while dev " + strC + " were connected!");
        l lVar = (l) this.A.get(strC);
        if (lVar != null) {
            lVar.q(true, 0, "Unexpected preemption (Unable to serve more devices):" + this.f1407v, obtainMessage(506, new Pair(strC, null)));
        }
        if (zF) {
            P0(strC, null, 29, "unexpected preempted");
        }
        n0(strC, zF, 9, tVarG0, null);
    }

    private void u0(Message message) {
        AsyncResult asyncResult = (AsyncResult) message.obj;
        Pair pair = (Pair) asyncResult.userObj;
        String str = (String) pair.first;
        Object obj = pair.second;
        RemoteDevConnEvaluation remoteDevConnEvaluation = obj instanceof RemoteDevConnEvaluation ? (RemoteDevConnEvaluation) obj : null;
        i0.b bVar = (i0.b) asyncResult.result;
        CtrlException ctrlException = (CtrlException) asyncResult.exception;
        w.d dVar = (w.d) this.f1407v.get(str);
        t("handleStopCommShareByReevaluateDone, stopRemoteDevId:" + str + ", evaluation:" + remoteDevConnEvaluation + ", responseMsg:" + bVar + ", ctrlException:" + ctrlException + ", stopRemoteDevState:" + dVar);
        if (dVar == null) {
            I0("handleStopCommShareByReevaluateDone, this dev is not preferred now!");
            return;
        }
        int i2 = bVar.f1737a;
        if (i2 == 0) {
            O0(str, false, false, false, bVar, remoteDevConnEvaluation, null, "handleStopCommShareByReevaluateDone");
            return;
        }
        if (i2 == 6) {
            I0("handleStopCommShareByReevaluateDone, NOT_REEVALUATE_ME from" + str);
            this.C.put(str, bVar);
        }
    }

    private void v0(Message message) {
        AsyncResult asyncResult = (AsyncResult) message.obj;
        t("handleStopCommShareByUnexpectedDone, stopRemoteDevId:" + ((String) ((Pair) asyncResult.userObj).first) + ", responseMsg:" + ((i0.b) asyncResult.result) + ", ctrlException:" + ((CtrlException) asyncResult.exception) + ", mPreferredDevs:" + this.f1407v);
    }

    private void w0(Message message) {
        AsyncResult asyncResult = (AsyncResult) message.obj;
        String str = (String) ((Pair) asyncResult.userObj).first;
        t("handleStopCommShareByUserDone, stopRemoteDevId:" + str + ", responseMsg:" + ((i0.b) asyncResult.result) + ", ctrlException:" + ((CtrlException) asyncResult.exception) + ", mPreferredDevs:" + this.f1407v);
        Q0(str, null, 0, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public i0.a x0(String str, h0.b bVar) {
        t("handleTargetStartCommShareFromRemote, remoteDevId:" + str + ", maxSupportedDevNum:" + VmdriContext.getMaxSupportedDevNum() + ", requestMsg:" + bVar);
        int i2 = bVar.f1718c;
        boolean z2 = bVar.f1716a;
        i0.a aVar = new i0.a();
        aVar.f1734a = 1;
        aVar.f1735b = "init";
        for (w.d dVar : this.f1407v.values()) {
            aVar.f1736c.put(dVar.i(), dVar.h());
        }
        w.d dVar2 = (w.d) this.f1411z.get(str);
        if (dVar2 == null) {
            aVar.f1734a = 5;
            aVar.f1735b = "[" + this.D.r() + " reject! because not find device " + str + "]";
            return aVar;
        }
        if (!this.F.isRilBound()) {
            aVar.f1734a = 7;
            aVar.f1735b = "[" + this.D.r() + " reject! because ril service not bound " + str + "]";
            return aVar;
        }
        if (!this.F.isCapabilityServiceBound()) {
            aVar.f1734a = 8;
            aVar.f1735b = "[" + this.D.r() + " reject! because capability service not bound " + str + "]";
            return aVar;
        }
        if (this.f1407v.containsKey(str)) {
            aVar.f1734a = 0;
            aVar.f1735b = "[repeatedly connect a device]";
        } else if (this.f1407v.size() >= VmdriContext.getMaxSupportedDevNum()) {
            if (!z2) {
                aVar.f1734a = 4;
                aVar.f1735b = "[" + this.D.r() + " reject! because already have preferred device(s) " + this.f1407v + "]";
            } else if (d0(dVar2, bVar.f1717b, bVar)) {
                aVar.f1734a = 0;
                aVar.f1735b = "[ accept! but preempt a device " + this.f1407v + "]";
            } else {
                aVar.f1734a = 4;
                aVar.f1735b = "[" + this.D.r() + " reject! willPreemptedDevId is illegal: " + bVar.f1717b + ", have preferred device(s)" + this.f1407v + "]";
            }
        } else if (this.f1407v.size() < VmdriContext.getMaxSupportedDevNum()) {
            aVar.f1734a = 0;
            if (this.f1407v.size() > 0) {
                aVar.f1735b = "[" + this.D.r() + " accept! support conn multi other pad " + this.f1407v + "]";
            } else {
                aVar.f1735b = "[normal accept]";
            }
            d0(dVar2, "", bVar);
        }
        t("handleTargetStartCommShareFromRemote, startCommShareResponseMsg:" + aVar);
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public i0.b y0(String str, h0.c cVar) {
        String str2;
        int i2 = cVar.f1721b;
        boolean z2 = cVar.f1720a;
        i0.b bVar = new i0.b();
        bVar.f1737a = 0;
        bVar.f1738b = "init";
        w.d dVar = (w.d) this.f1407v.get(str);
        if (dVar != null) {
            bVar.f1738b = "normal";
            if (i2 == 1 || z2) {
                this.f1410y.put(str, dVar);
            }
            str2 = str;
            O0(str2, true, i2 == 1, z2, null, null, cVar, "remote target stop");
        } else {
            str2 = str;
            bVar.f1738b = "preferred dev already disconnected";
        }
        t("handleTargetStopCommShareFromRemote, remoteDevId:" + str2 + ", responseMsg:" + bVar);
        return bVar;
    }

    private boolean z0() {
        return getLooper().getThread() == Thread.currentThread();
    }

    public void V0(final String str, final int i2) {
        if (z0()) {
            B0(str, i2);
        } else {
            post(new Runnable() { // from class: a0.x0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f128a.B0(str, i2);
                }
            });
        }
    }

    public void X0(String str, int i2) {
        l lVar = (l) this.A.get(str);
        t("sendRilState, remoteDevId:" + str + ", rilState:" + i2 + ", ctrlChannel:" + lVar);
        if (lVar == null) {
            return;
        }
        lVar.x(i2);
    }

    @Override // a0.d0
    public void a(final String str, final Message message) {
        if (z0()) {
            F0(str, message);
            return;
        }
        I0("targetStopCommShareByUser, not running on ClientController.getLooper().getThread() thread, remoteDevId:" + str);
        post(new Runnable() { // from class: a0.o0
            @Override // java.lang.Runnable
            public final void run() {
                this.f98a.F0(str, message);
            }
        });
    }

    @Override // a0.d0
    public void b(final g0 g0Var) {
        if (z0()) {
            this.f1399n.add(g0Var);
        } else {
            I0("registerCtrlIndication on other thread");
            post(new Runnable() { // from class: a0.w0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f125a.A0(g0Var);
                }
            });
        }
    }

    @Override // a0.d0
    public void c(String str, long j2, long j3) {
        l lVar = (l) this.A.get(str);
        t("sendCommShareDataUsage, remoteDevId:" + str + ", dataUsageOfThisConn:" + j2 + ", dataUsageOfThisMonth:" + j3);
        if (lVar == null) {
            return;
        }
        lVar.t(j2, j3);
    }

    @Override // a0.d0
    public y0 d(String str) {
        return (y0) this.f1408w.get(str);
    }

    @Override // a0.d0
    public z0 e(String str) {
        return (z0) this.f1409x.get(str);
    }

    public void e0(String str, String str2) {
        l lVar = (l) this.A.get(str);
        if (lVar != null) {
            lVar.d(str2, obtainMessage(507));
            return;
        }
        G0("bringUpRemoteProcess not channel error, remoteDevId:" + str + ", pkgName:" + str2);
    }

    @Override // a0.d0
    public void f(final String str, final Message message) {
        if (z0()) {
            i1(str, message, false, "", false);
            return;
        }
        I0("targetStartCommShareByUser, not running on ClientController.getLooper().getThread() thread, remoteDevId:" + str);
        post(new Runnable() { // from class: a0.p0
            @Override // java.lang.Runnable
            public final void run() {
                this.f104a.D0(str, message);
            }
        });
    }

    @Override // a0.d0
    public void g(w wVar) {
        if (wVar == null) {
            G0("registerDeviceCallback a null callback!");
            return;
        }
        if (!z0()) {
            I0("registerCommShareDeviceCallback on other thread");
            post(new f(wVar));
            return;
        }
        this.f1270a.add(wVar);
        for (w.d dVar : this.f1407v.values()) {
            y0 y0Var = (y0) this.f1408w.get(dVar.i());
            if (y0Var != null) {
                w(dVar, y0Var.d());
            }
        }
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        switch (message.what) {
            case 502:
                t("EVENT_CLEAR_PENDING_RECOVER_DEV, mPendingToRecoverCommShareDevs:" + this.E);
                this.E.clear();
                if (this.f1390e != null) {
                    u0.r().m0(this.f1390e);
                    this.f1390e = null;
                    t("recovered from crash, remove callback");
                }
                break;
            case 503:
                t0(message);
                break;
            case 504:
                u0(message);
                break;
            case 505:
                w0(message);
                break;
            case 506:
                v0(message);
                break;
            case 507:
                t("EVENT_BRINGUP_DONE ex:" + ((AsyncResult) message.obj).exception);
                break;
            case 508:
                String str = (String) message.obj;
                t("EVENT_USER_START_COMM_SHARE, remoteDevId:" + str);
                i1(str, null, false, "", false);
                break;
            case 509:
                Pair pair = (Pair) message.obj;
                String str2 = (String) pair.first;
                RemoteDevConnEvaluation.EvaluationReason evaluationReason = (RemoteDevConnEvaluation.EvaluationReason) pair.second;
                t("EVENT_AUTO_START_COMM_SHARE, remoteDevId:" + str2 + ", reason:" + evaluationReason);
                h1(str2, evaluationReason, false);
                break;
            case 510:
                l1((t) message.obj);
                break;
            case 511:
                m1((t) message.obj);
                break;
            case 512:
                f0((String) message.obj);
                break;
            case 513:
                Pair pair2 = (Pair) message.obj;
                RemoteDevConnEvaluation remoteDevConnEvaluation = (RemoteDevConnEvaluation) pair2.first;
                w.d dVar = (w.d) pair2.second;
                t("evaluation = " + remoteDevConnEvaluation + ", deviceState = " + dVar);
                if (remoteDevConnEvaluation != null && dVar != null) {
                    d1(remoteDevConnEvaluation, dVar);
                    break;
                }
                break;
            default:
                t("ServerController Unknown msg.what: " + message.what + ", give super to handle.");
                super.handleMessage(message);
                break;
        }
    }

    public void k1(final String str, final Message message, final String str2) {
        if (z0()) {
            i1(str, message, true, str2, false);
            return;
        }
        I0("targetStartCommShareForceByUser, not running on ClientController.getLooper().getThread() thread, remoteDevId:" + str);
        post(new Runnable() { // from class: a0.v0
            @Override // java.lang.Runnable
            public final void run() {
                this.f121a.E0(str, message, str2);
            }
        });
    }

    @Override // com.vivo.vmdri.ctrl.a
    public void r(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("ServerController:");
        super.r(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mPreferredDevs=" + this.f1407v);
        indentingPrintWriter.println("mTargetStartMessages=" + this.f1405t);
        indentingPrintWriter.println("mTargetStopMessages=" + this.f1406u);
        indentingPrintWriter.println("mCurTargetStartCommShareInfo=" + this.f1400o);
        indentingPrintWriter.println("mStartCommShareDoneRecords=" + this.f1408w);
        indentingPrintWriter.println("mStopCommShareDoneRecords=" + this.f1409x);
        indentingPrintWriter.println("mTargetStartCommShareInfos=" + this.f1401p);
        indentingPrintWriter.println("mUserDislikeRemoteDevs=" + this.f1410y);
        indentingPrintWriter.println("mRemoteDevStates=" + this.f1411z);
        indentingPrintWriter.println("mLocalDevState=" + this.D);
        indentingPrintWriter.println("mRemoteDevCommShareStates=" + this.B);
        indentingPrintWriter.println("mNotReevaluateAgainMap=" + this.C);
        indentingPrintWriter.println("mCtrlChannels=" + this.A);
        indentingPrintWriter.println("mPendingToRecoverCommShareDevs=" + this.E);
        indentingPrintWriter.decreaseIndent();
    }

    @Override // com.vivo.vmdri.ctrl.a
    public IBinder s() {
        return this.f1392g;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class j implements DialogInterface.OnClickListener {
        j(s sVar) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    public static /* synthetic */ void D(DialogInterface dialogInterface, int i2) {
    }

    public static /* synthetic */ void G(DialogInterface dialogInterface, int i2) {
    }
}
