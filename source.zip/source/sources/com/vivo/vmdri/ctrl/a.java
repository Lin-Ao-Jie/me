package com.vivo.vmdri.ctrl;

import a0.d0;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.ArraySet;
import android.util.IndentingPrintWriter;
import c0.u0;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.Set;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a extends Handler implements d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected final Set f1270a;

    public a(Looper looper) {
        super(looper);
        this.f1270a = new ArraySet();
    }

    private static void t(String str) {
        VmdriLog.d("BaseController", str);
    }

    protected void r(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("BaseController:");
    }

    protected abstract IBinder s();

    protected void u(final w.c cVar) {
        this.f1270a.forEach(new Consumer() { // from class: a0.f
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                w wVar = (w) obj;
                wVar.invokeFromExecutor(new Runnable() { // from class: a0.h
                    @Override // java.lang.Runnable
                    public final void run() {
                        wVar.b(cVar);
                    }
                });
            }
        });
    }

    protected void v(final w.d dVar) {
        this.f1270a.forEach(new Consumer() { // from class: a0.i
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                w wVar = (w) obj;
                wVar.invokeFromExecutor(new Runnable() { // from class: a0.j
                    @Override // java.lang.Runnable
                    public final void run() {
                        wVar.c(new w.d(dVar));
                    }
                });
            }
        });
    }

    protected void w(final w.d dVar, final boolean z2) {
        this.f1270a.forEach(new Consumer() { // from class: a0.a
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                w wVar = (w) obj;
                wVar.invokeFromExecutor(new Runnable() { // from class: a0.c
                    @Override // java.lang.Runnable
                    public final void run() {
                        wVar.d(new w.d(dVar), z);
                    }
                });
            }
        });
    }

    protected void x(final w.d dVar, final boolean z2) {
        this.f1270a.forEach(new Consumer() { // from class: a0.b
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                w wVar = (w) obj;
                wVar.invokeFromExecutor(new Runnable() { // from class: a0.d
                    @Override // java.lang.Runnable
                    public final void run() {
                        wVar.e(new w.d(dVar), z);
                    }
                });
            }
        });
    }

    protected void y(final w.d dVar) {
        this.f1270a.forEach(new Consumer() { // from class: a0.e
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                w wVar = (w) obj;
                wVar.invokeFromExecutor(new Runnable() { // from class: a0.g
                    @Override // java.lang.Runnable
                    public final void run() {
                        wVar.f(new w.d(dVar));
                    }
                });
            }
        });
    }

    public void z(String str) {
        t("resetUsingState remoteDevId: " + str);
        u0.r().T(str, 0, 0, 0, 0);
    }
}
