package com.vivo.vmdri.ctrl;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.vivo.vmdri.VmdriLog;
import java.util.HashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntUnaryOperator;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class l extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f1359a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f1360b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final b f1361c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final c f1362d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final w.d f1363e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f1364f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private c0.l f1365g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final HashMap f1366h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final AtomicInteger f1367i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private c0.l.b f1368j;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends c0.l.b {
        a(Executor executor) {
            super(executor);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void d(String str, g0.a aVar) {
            l.this.m(str, aVar);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void e(String str, g0.a aVar) {
            l.this.o(str, aVar);
        }

        @Override // c0.l.b
        public void a(final String str, String str2) {
            super.a(str, str2);
            final g0.a aVarD = g0.a.d(str2);
            l.this.g("onRecvCtrlMessage, remoteDevId:" + str + ", ctrlMessage:" + aVarD);
            int i2 = aVarD.f1711b;
            if (i2 == 1) {
                l.this.post(new Runnable() { // from class: com.vivo.vmdri.ctrl.j
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f1353a.d(str, aVarD);
                    }
                });
                return;
            }
            if (i2 == 2) {
                l.this.n(str, aVarD);
                return;
            }
            if (i2 == 3) {
                l.this.post(new Runnable() { // from class: com.vivo.vmdri.ctrl.k
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f1356a.e(str, aVarD);
                    }
                });
                return;
            }
            l.this.h("onRecvCtrlMessage recv a not support ctrl msg:" + aVarD);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class b {
        public abstract void a(String str, String str2);

        public abstract i0.a b(String str, h0.b bVar);

        public abstract i0.b c(String str, h0.c cVar);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class c {
        public abstract void a(String str, int i2);

        public abstract void b(String str, long j2, long j3);

        public abstract void c(String str, int i2, boolean z2, HashMap map);

        public abstract void d(String str, int i2);
    }

    public l(Context context, Looper looper, w.d dVar, b bVar, c cVar) {
        super(looper);
        this.f1364f = false;
        this.f1366h = new HashMap();
        this.f1367i = new AtomicInteger(0);
        this.f1368j = new a(new Executor() { // from class: a0.e0
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f50a.post(runnable);
            }
        });
        this.f1359a = "CtrlChannel-" + dVar.i();
        g("init");
        this.f1363e = dVar;
        this.f1360b = context;
        this.f1361c = bVar;
        this.f1362d = cVar;
    }

    private int A(g0.a aVar) {
        c0.l lVar = this.f1365g;
        if (lVar == null) {
            h("sendUnsolicitedMsg channel not connect error!");
            return 9;
        }
        if (aVar.f1711b != 3) {
            h("sendUnsolicitedMsg, not send a UnsolicitedMsg");
            return 8;
        }
        int iZ = lVar.Z(aVar.c());
        g("sendUnsolicitedMsg to:" + this.f1365g + ", msg:" + aVar + ", result:" + iZ);
        return iZ;
    }

    public static /* synthetic */ int a(int i2) {
        return (i2 + 1) % Integer.MAX_VALUE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g(String str) {
        VmdriLog.d(this.f1359a, str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void h(String str) {
        VmdriLog.e(this.f1359a, str);
    }

    private g0.a i(int i2, int i3) {
        g0.a aVar = new g0.a(i2, i3, 2, null);
        aVar.f1713d = 1;
        return aVar;
    }

    private g0.a j(int i2, String str, Message message) {
        int andUpdate = this.f1367i.getAndUpdate(new IntUnaryOperator() { // from class: a0.f0
            @Override // java.util.function.IntUnaryOperator
            public final int applyAsInt(int i3) {
                return com.vivo.vmdri.ctrl.l.a(i3);
            }
        });
        g0.a aVar = new g0.a(i2, andUpdate, 1, str);
        this.f1366h.put(Integer.valueOf(andUpdate), message);
        return aVar;
    }

    private g0.a k(int i2, int i3, String str) {
        return new g0.a(i2, i3, 2, str);
    }

    private g0.a l(int i2, String str) {
        return new g0.a(i2, 3, str);
    }

    private int v(g0.a aVar) {
        if (this.f1365g == null) {
            h("sendRequest channel not connect error!");
            return 9;
        }
        if (aVar.f1711b != 1) {
            h("sendRequest, not send a RequestMsg");
            return 8;
        }
        g("sendRequest to:" + this.f1365g + ", msg:" + aVar);
        return this.f1365g.Z(aVar.c());
    }

    private int w(g0.a aVar) {
        if (this.f1365g == null) {
            h("sendResponse channel not connect error!");
            return 9;
        }
        if (aVar.f1711b != 2) {
            h("sendResponse, not send a ResponseMsg");
            return 8;
        }
        g("sendResponse to:" + this.f1365g + ", msg:" + aVar);
        return this.f1365g.Z(aVar.c());
    }

    public void d(String str, Message message) {
        g("bringUpRemoteProcess, pkgName:" + str);
        v(j(10, new h0.a(str).c(), message));
    }

    public void e() {
        g("connect");
        this.f1364f = true;
        this.f1365g = c0.r.u().p(this.f1363e.i(), 2, this.f1368j);
    }

    public void f() {
        g("disconnect");
        this.f1364f = false;
        c0.r.u().r(this.f1365g, false);
        this.f1365g = null;
    }

    protected void m(String str, g0.a aVar) {
        int i2 = aVar.f1710a;
        if (i2 == 1) {
            i0.a aVarB = this.f1361c.b(str, h0.b.d(aVar.f1714e));
            y(aVar.f1712c, aVarB != null ? aVarB.f1734a : 1, aVarB);
            return;
        }
        if (i2 == 2) {
            i0.b bVarC = this.f1361c.c(str, h0.c.d(aVar.f1714e));
            z(aVar.f1712c, bVarC != null ? bVarC.f1737a : 1, bVarC);
            return;
        }
        if (i2 == 10) {
            this.f1361c.a(str, h0.a.d(aVar.f1714e).f1715a);
            r(aVar.f1712c);
            return;
        }
        h("not support request remoteDevId:" + str + ", ctrlMsg:" + aVar);
        w(i(aVar.f1710a, aVar.f1712c));
    }

    protected void n(String str, g0.a aVar) {
        Object objD;
        int i2 = aVar.f1713d;
        CtrlException ctrlExceptionFromCtrlErrno = CtrlException.fromCtrlErrno(i2);
        int i3 = aVar.f1710a;
        if (i3 == 1) {
            objD = i0.a.d(aVar.f1714e);
        } else if (i3 != 2) {
            if (i3 != 10) {
                h("onRecvCtrlResponse, remoteDevId:" + str + "ctrlMsg" + aVar + " not support response msg");
            }
            objD = null;
        } else {
            objD = i0.b.d(aVar.f1714e);
        }
        g("onRecvCtrlResponse, remoteDevId:" + str + ", messageId:" + aVar.f1710a + ", errorCode:" + i2 + ", ctrlException:" + ctrlExceptionFromCtrlErrno + ", ret:" + objD);
        Message message = (Message) this.f1366h.remove(Integer.valueOf(aVar.f1712c));
        if (message != null) {
            AsyncResult.forMessage(message, objD, ctrlExceptionFromCtrlErrno);
            message.sendToTarget();
            return;
        }
        h("onRecvCtrlResponse remoteDevId:" + str + "ctrlMsg" + aVar + " not request cache, drop! may be already time out?");
    }

    protected void o(String str, g0.a aVar) {
        String str2 = aVar.f1714e;
        switch (aVar.f1710a) {
            case 4001:
                this.f1362d.d(str, j0.d.d(str2).f1764a);
                break;
            case 4002:
                this.f1362d.a(str, j0.a.d(str2).f1758a);
                break;
            case 4003:
                j0.c cVarD = j0.c.d(str2);
                this.f1362d.c(str, cVarD.f1761a, cVarD.f1762b, cVarD.f1763c);
                break;
            case 4004:
                j0.b bVarD = j0.b.d(str2);
                this.f1362d.b(str, bVarD.f1759a, bVarD.f1760b);
                break;
            default:
                h("onRecvCtrlUnsolicited, not support Unsolicited from, remoteDevId:" + str + ", ctrlMsg:" + aVar);
                break;
        }
    }

    public void p(boolean z2, String str, int i2, String str2, Message message) {
        g("requestStartCommShare, force:" + z2 + ", willPreemptedDevId:" + str + ", targetSource:" + i2 + ", descStr:" + str2);
        v(j(1, new h0.b(z2, str, i2, str2).c(), message));
    }

    public void q(boolean z2, int i2, String str, Message message) {
        g("requestStopCommShare, force:" + z2 + ", targetSource:" + i2 + ", descStr:" + str);
        v(j(2, new h0.c(z2, i2, str).c(), message));
    }

    public void r(int i2) {
        w(k(10, i2, null));
    }

    public void s(int i2) {
        A(l(4002, new j0.a(i2).c()));
    }

    public void t(long j2, long j3) {
        A(l(4004, new j0.b(j2, j3).c()));
    }

    @Override // android.os.Handler
    public String toString() {
        return "CtrlChannel{mIsConnected=" + this.f1364f + ", mDataChannel=" + this.f1365g + ", mNextSendSerial=" + this.f1367i + '}';
    }

    public void u(int i2, boolean z2, HashMap map) {
        A(l(4003, new j0.c(i2, z2, map).c()));
    }

    public void x(int i2) {
        A(l(4001, new j0.d(i2).c()));
    }

    public void y(int i2, int i3, i0.a aVar) {
        g0.a aVarK = k(1, i2, aVar != null ? aVar.c() : null);
        aVarK.f1713d = i3;
        w(aVarK);
    }

    public void z(int i2, int i3, i0.b bVar) {
        g0.a aVarK = k(2, i2, bVar != null ? bVar.c() : null);
        aVarK.f1713d = i3;
        w(aVarK);
    }
}
