package com.vivo.vmdri.ctrl;

import a0.a0;
import a0.d0;
import a0.j0;
import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.IndentingPrintWriter;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class u extends Handler {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static u f1434f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static final Object f1435g = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f1436a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private d0.l f1437b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private a f1438c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected final a0 f1439d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected final j0 f1440e;

    private u(Context context, Looper looper, d0.l lVar) {
        super(looper);
        this.f1436a = context;
        this.f1437b = lVar;
        h();
        this.f1439d = a0.R(this.f1438c);
        this.f1440e = new j0(this.f1438c, lVar);
    }

    public static u a(Context context, Looper looper, d0.l lVar) {
        u uVar;
        synchronized (f1435g) {
            try {
                if (f1434f != null) {
                    throw new RuntimeException("TopController already created!");
                }
                uVar = new u(context, looper, lVar);
                f1434f = uVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return uVar;
    }

    public static u d() {
        u uVar = f1434f;
        if (uVar != null) {
            return uVar;
        }
        throw new RuntimeException("TopController.getInstance can't be called before create()");
    }

    private static void f(String str) {
        VmdriLog.d("TopController", str);
    }

    private static void g(String str) {
        VmdriLog.e("TopController", str);
    }

    private void h() {
        f("makeSubController");
        if (VmdriContext.isPhone()) {
            this.f1438c = s.h0(this.f1436a, getLooper(), this.f1437b);
        } else {
            this.f1438c = h.j0(this.f1436a, getLooper(), this.f1437b);
        }
    }

    public void b(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("TopController:");
        this.f1438c.r(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        this.f1439d.S(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.flush();
        this.f1440e.q(fileDescriptor, indentingPrintWriter, strArr);
    }

    public d0 c() {
        return this.f1438c;
    }

    public IBinder e() {
        IBinder iBinderS;
        a aVar = this.f1438c;
        if (aVar != null) {
            iBinderS = aVar.s();
        } else {
            g("getVmdriCommService: server and client both null now!");
            iBinderS = null;
        }
        f("getVmdriCommService:" + iBinderS);
        return iBinderS;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        int i2 = message.what;
    }
}
