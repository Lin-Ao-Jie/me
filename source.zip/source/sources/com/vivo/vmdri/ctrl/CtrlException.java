package com.vivo.vmdri.ctrl;

import com.vivo.vmdri.VmdriLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class CtrlException extends RuntimeException {
    public static final String LOG_TAG = "CtrlException";
    private int mErrCode;
    private Error mError;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public enum Error {
        INVALID_RESPONSE,
        NOT_SUPPORTED,
        GENERIC_FAILURE,
        REJECT_FOR_PREFER_DEV_REACHED,
        REJECT_FOR_DEV_NOT_FOUND,
        NOT_REEVALUATE_ME,
        RIL_SERVICE_NOT_BOUND,
        CAPABILITY_SERVICE_NOT_BOUND
    }

    public CtrlException(Error error, int i2) {
        super(error.toString() + "_" + i2);
        this.mError = error;
        this.mErrCode = i2;
    }

    public static CtrlException fromCtrlErrno(int i2) {
        switch (i2) {
            case 0:
                return null;
            case 1:
                return new CtrlException(Error.NOT_SUPPORTED, i2);
            case 2:
                return new CtrlException(Error.INVALID_RESPONSE, i2);
            case 3:
                return new CtrlException(Error.GENERIC_FAILURE, i2);
            case 4:
                return new CtrlException(Error.REJECT_FOR_PREFER_DEV_REACHED, i2);
            case 5:
                return new CtrlException(Error.REJECT_FOR_DEV_NOT_FOUND, i2);
            case 6:
                return new CtrlException(Error.NOT_REEVALUATE_ME, i2);
            case 7:
                return new CtrlException(Error.RIL_SERVICE_NOT_BOUND, i2);
            case 8:
                return new CtrlException(Error.CAPABILITY_SERVICE_NOT_BOUND, i2);
            default:
                loge("Unrecognized ctrl errno " + i2);
                return new CtrlException(Error.INVALID_RESPONSE, i2);
        }
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    public int convertToErrorCode(Error error) {
        int iOrdinal = error.ordinal();
        if (iOrdinal == 0) {
            return 36;
        }
        if (iOrdinal == 1) {
            return 38;
        }
        if (iOrdinal == 3) {
            return 14;
        }
        if (iOrdinal == 4) {
            return 39;
        }
        if (iOrdinal == 5) {
            return 40;
        }
        if (iOrdinal != 6) {
            return iOrdinal != 7 ? 37 : 42;
        }
        return 41;
    }

    public Error getCtrlError() {
        return this.mError;
    }

    public CtrlException(Error error, String str) {
        super(str);
        this.mError = error;
    }
}
