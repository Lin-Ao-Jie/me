package com.vivo.vmdri;

import android.util.IndentingPrintWriter;
import java.io.FileDescriptor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriConfig {
    public static final String LOG_TAG = "VmdriConfig";
    public static final boolean SYN_DEV_STATE_ONLY_COMM_SHARE = false;
    public static final VmdriVersion sLocalVersion = new VmdriVersion(2, 0, 0, 0);

    private VmdriConfig() {
    }

    public static void dump(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("VmdriConfig:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("sLocalVersion=" + sLocalVersion);
        indentingPrintWriter.println("isSynDevStateOnlyCommShare=" + isSynDevStateOnlyCommShare());
        indentingPrintWriter.println("logLevel=" + VmdriLog.sDebugLogLevel);
        indentingPrintWriter.decreaseIndent();
    }

    public static boolean isSynDevStateOnlyCommShare() {
        return false;
    }
}
