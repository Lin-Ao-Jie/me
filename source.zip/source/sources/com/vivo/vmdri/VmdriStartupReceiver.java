package com.vivo.vmdri;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriStartupReceiver extends BroadcastReceiver {
    public static final String LOG_TAG = "VmdriStartupReceiver";

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    private static void logw(String str) {
        VmdriLog.w(LOG_TAG, str);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        logd("onReceive, intent:" + intent);
    }
}
