package com.vivo.vmdri;

import android.os.SystemClock;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriMetrics {
    private static final String LOG_TAG = "VmdriMetrics";
    private static VmdriMetrics sInstance;
    private long mStartSystemTimeMs = System.currentTimeMillis();
    private long mStartElapsedTimeMs = SystemClock.elapsedRealtime();

    public static synchronized VmdriMetrics getInstance() {
        try {
            if (sInstance == null) {
                sInstance = new VmdriMetrics();
            }
        } catch (Throwable th) {
            throw th;
        }
        return sInstance;
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }
}
