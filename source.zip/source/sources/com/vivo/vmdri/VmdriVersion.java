package com.vivo.vmdri;

import java.util.Locale;
import java.util.Objects;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriVersion implements Comparable<VmdriVersion> {
    private static VmdriVersion DEFAULT_VERSION = new VmdriVersion(1, 0, 0, 0);
    public static final String LOG_TAG = "VmdriVersion";
    private final int build;
    private final int major;
    private final int minor;
    private final int patch;

    public VmdriVersion(int i2, int i3, int i4, int i5) {
        this.major = i2;
        this.minor = i3;
        this.patch = i4;
        this.build = i5;
    }

    public static VmdriVersion fromString(String str) {
        logd("fromString fullVersion:" + str);
        String[] strArrSplit = str.split("\\.");
        if (strArrSplit == null || strArrSplit.length != 4) {
            return DEFAULT_VERSION;
        }
        try {
            return new VmdriVersion(Integer.parseInt(strArrSplit[0]), Integer.parseInt(strArrSplit[1]), Integer.parseInt(strArrSplit[2]), Integer.parseInt(strArrSplit[3]));
        } catch (NumberFormatException unused) {
            return DEFAULT_VERSION;
        }
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    private static void logw(String str) {
        VmdriLog.w(LOG_TAG, str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            VmdriVersion vmdriVersion = (VmdriVersion) obj;
            if (this.major == vmdriVersion.major && this.minor == vmdriVersion.minor && this.patch == vmdriVersion.patch && this.build == vmdriVersion.build) {
                return true;
            }
        }
        return false;
    }

    public int getBuild() {
        return this.build;
    }

    public int getMajor() {
        return this.major;
    }

    public int getMinor() {
        return this.minor;
    }

    public int getPatch() {
        return this.patch;
    }

    public String getVersionName() {
        return String.format(Locale.US, "%d.%d.%d.%d", Integer.valueOf(this.major), Integer.valueOf(this.minor), Integer.valueOf(this.patch), Integer.valueOf(this.build));
    }

    public boolean greater(VmdriVersion vmdriVersion) {
        return compareTo(vmdriVersion) > 0;
    }

    public boolean greaterOrEqual(VmdriVersion vmdriVersion) {
        return greater(vmdriVersion) || equals(vmdriVersion);
    }

    public int hashCode() {
        return Objects.hash(Integer.valueOf(this.major), Integer.valueOf(this.minor), Integer.valueOf(this.patch), Integer.valueOf(this.build));
    }

    public boolean less(VmdriVersion vmdriVersion) {
        return compareTo(vmdriVersion) < 0;
    }

    public boolean lessOrEqual(VmdriVersion vmdriVersion) {
        return less(vmdriVersion) || equals(vmdriVersion);
    }

    public String toString() {
        return getVersionName();
    }

    @Override // java.lang.Comparable
    public int compareTo(VmdriVersion vmdriVersion) {
        if (vmdriVersion == null) {
            return 1;
        }
        int i2 = this.major;
        int i3 = vmdriVersion.major;
        if (i2 != i3) {
            return Integer.compare(i2, i3);
        }
        int i4 = this.minor;
        int i5 = vmdriVersion.minor;
        if (i4 != i5) {
            return Integer.compare(i4, i5);
        }
        int i6 = this.patch;
        int i7 = vmdriVersion.patch;
        if (i6 != i7) {
            return Integer.compare(i6, i7);
        }
        int i8 = this.build;
        int i9 = vmdriVersion.build;
        if (i8 != i9) {
            return Integer.compare(i8, i9);
        }
        return 0;
    }
}
