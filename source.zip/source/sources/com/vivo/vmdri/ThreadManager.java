package com.vivo.vmdri;

import android.os.HandlerThread;
import android.os.Looper;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class ThreadManager {
    public static final String LOG_TAG = "ThreadManager";
    private static HandlerThread sVmdriComm;
    private static HandlerThread sVmdriDataChannel;
    private static HandlerThread sVmdriMain;

    public static Looper getVmdriMainLooper() {
        Looper looper;
        synchronized (ThreadManager.class) {
            try {
                if (sVmdriMain == null) {
                    HandlerThread handlerThread = new HandlerThread("vmdri-main");
                    sVmdriMain = handlerThread;
                    handlerThread.start();
                }
                looper = sVmdriMain.getLooper();
            } catch (Throwable th) {
                throw th;
            }
        }
        return looper;
    }

    public static Looper getsVmdriCommLooper() {
        Looper looper;
        synchronized (ThreadManager.class) {
            try {
                if (sVmdriComm == null) {
                    HandlerThread handlerThread = new HandlerThread("vmdri-comm");
                    sVmdriComm = handlerThread;
                    handlerThread.start();
                }
                looper = sVmdriComm.getLooper();
            } catch (Throwable th) {
                throw th;
            }
        }
        return looper;
    }

    public static Looper getsVmdriDataChannelLooper() {
        Looper looper;
        synchronized (ThreadManager.class) {
            try {
                if (sVmdriDataChannel == null) {
                    HandlerThread handlerThread = new HandlerThread("vmdri-data-channel");
                    sVmdriDataChannel = handlerThread;
                    handlerThread.start();
                }
                looper = sVmdriDataChannel.getLooper();
            } catch (Throwable th) {
                throw th;
            }
        }
        return looper;
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }
}
