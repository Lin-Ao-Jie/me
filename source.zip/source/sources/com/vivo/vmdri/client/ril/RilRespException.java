package com.vivo.vmdri.client.ril;

import com.vivo.vmdri.VmdriLog;
import w.e;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class RilRespException extends RuntimeException {
    public static final String LOG_TAG = "RilRespException";
    private String mErrString;
    private int mErrorCode;
    private boolean mIsFormRemote;
    private int mRawErrCode;

    public RilRespException(int i2, String str, boolean z2) {
        super(String.format("ErrCode(%d)-ErrStr(%s)-FromRemote(%b)", Integer.valueOf(i2), str, Boolean.valueOf(z2)));
        this.mRawErrCode = i2;
        this.mIsFormRemote = z2;
        this.mErrString = str;
        if (z2) {
            this.mErrorCode = i2 + 5000;
        } else {
            this.mErrorCode = i2;
        }
    }

    public static RilRespException fromLocalVmdriErrno(int i2) {
        if (i2 == 0) {
            return null;
        }
        if (i2 == 1) {
            return new RilRespException(1, "GENERIC_FAILURE");
        }
        if (i2 == 3) {
            return new RilRespException(3, "DEVICE_NOT_CONN");
        }
        if (i2 == 4) {
            return new RilRespException(4, "LOCAL_NOT_READY");
        }
        if (i2 == 5) {
            return new RilRespException(5, "REMOTE_NOT_READY");
        }
        if (i2 == 6) {
            return new RilRespException(6, "RESP_TIME_OUT");
        }
        if (i2 == 7) {
            return new RilRespException(7, "SDK_ERROR");
        }
        loge("Unrecognized vmdri errno " + i2);
        return new RilRespException(i2, e.a(i2));
    }

    public static RilRespException fromRemoteRilErrno(int i2) {
        if (i2 == 0) {
            return null;
        }
        return new RilRespException(i2, "Remote Ril Resp Error", true);
    }

    private static void logd(String str) {
        VmdriLog.d(LOG_TAG, str);
    }

    private static void loge(String str) {
        VmdriLog.e(LOG_TAG, str);
    }

    private static void logi(String str) {
        VmdriLog.i(LOG_TAG, str);
    }

    public int getErrCode() {
        return this.mErrorCode;
    }

    public String getErrString() {
        return this.mErrString;
    }

    public int getRawErrCode() {
        return this.mRawErrCode;
    }

    public boolean isFormRemote() {
        return this.mIsFormRemote;
    }

    @Override // java.lang.Throwable
    public String toString() {
        return "RilRespException{mRawErrCode=" + this.mRawErrCode + ", mErrorCode=" + this.mErrorCode + ", mIsFormRemote=" + this.mIsFormRemote + ", mErrString='" + this.mErrString + "'} " + super.toString();
    }

    public RilRespException(int i2, String str) {
        this(i2, str, false);
    }
}
