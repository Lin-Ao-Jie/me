package com.vivo.vmdri;

import android.annotation.NonNull;
import android.annotation.Nullable;
import android.os.SystemProperties;
import com.android.telephony.Rlog;
import com.vivo.internal.telephony.VivoTelephonyLocalLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriLog {
    public static final int BASIC_DBG_LEVEL = 2;
    public static final int DBG_LOG_LEVEL;
    public static final int DEFAULT_DBG_LEVEL = 0;
    public static final int DETAIL_DBG_LEVEL = 4;
    public static final int FULL_DBG_LEVEL = 5;
    public static final int LIGHT_DBG_LEVEL = 1;
    public static final int NORMAL_DBG_LEVEL = 3;
    public static final String PREV_TAG = "vmdri_";
    public static final String REASON_DUMP_COMM_SHARE_INFO = "dumpCommShareDevInfo";
    public static final String REASON_DUMP_DATA_CALL_LIST = "dumpCommShareDataCallList";
    public static int sDebugLogLevel;

    static {
        int i2 = SystemProperties.getInt("persist.radio.vmdri.debug_log_level", 3);
        DBG_LOG_LEVEL = i2;
        sDebugLogLevel = i2;
    }

    public static void d(@Nullable String str, @NonNull String str2) {
        Rlog.d(PREV_TAG + str, str2);
    }

    public static void e(@Nullable String str, @NonNull String str2) {
        Rlog.e(PREV_TAG + str, str2);
    }

    public static int getDebugLevel() {
        return sDebugLogLevel;
    }

    public static void i(@Nullable String str, @NonNull String str2) {
        Rlog.i(PREV_TAG + str, str2);
    }

    public static boolean isBasicDebugLevel() {
        return sDebugLogLevel >= 2;
    }

    public static boolean isDetailDebugLevel() {
        return sDebugLogLevel >= 4;
    }

    public static boolean isFullDebugLevel() {
        return sDebugLogLevel >= 5;
    }

    public static boolean isLightDebugLevel() {
        return sDebugLogLevel >= 1;
    }

    public static boolean isNormalDebugLevel() {
        return sDebugLogLevel >= 3;
    }

    public static void localLog(@NonNull String str, @NonNull String str2) {
        VivoTelephonyLocalLog.localLog(str, str2);
    }

    public static void setDebugLevel(int i2) {
        sDebugLogLevel = i2;
    }

    public static void v(@Nullable String str, @NonNull String str2) {
        Rlog.v(PREV_TAG + str, str2);
    }

    public static void w(@Nullable String str, @NonNull String str2) {
        Rlog.w(PREV_TAG + str, str2);
    }

    public static void wtf(@Nullable String str, @NonNull String str2) {
        Rlog.w(PREV_TAG + str, str2);
    }
}
