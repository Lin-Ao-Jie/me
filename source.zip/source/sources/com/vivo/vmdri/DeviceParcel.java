package com.vivo.vmdri;

import android.os.BadParcelableException;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Objects;
import java.util.StringJoiner;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class DeviceParcel implements Parcelable {
    public static final Parcelable.Creator<DeviceParcel> CREATOR = new Parcelable.Creator<DeviceParcel>() { // from class: com.vivo.vmdri.DeviceParcel.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public DeviceParcel createFromParcel(Parcel parcel) {
            DeviceParcel deviceParcel = new DeviceParcel();
            deviceParcel.readFromParcel(parcel);
            return deviceParcel;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public DeviceParcel[] newArray(int i2) {
            return new DeviceParcel[i2];
        }
    };
    public String deviceId;
    public int deviceType = 0;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final void readFromParcel(Parcel parcel) {
        int iDataPosition = parcel.dataPosition();
        int i2 = parcel.readInt();
        try {
            if (i2 < 4) {
                throw new BadParcelableException("Parcelable too small");
            }
            if (parcel.dataPosition() - iDataPosition < i2) {
                this.deviceType = parcel.readInt();
                if (parcel.dataPosition() - iDataPosition < i2) {
                    this.deviceId = parcel.readString();
                    if (iDataPosition > Integer.MAX_VALUE - i2) {
                        throw new BadParcelableException("Overflow in the size of parcelable");
                    }
                } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                    throw new BadParcelableException("Overflow in the size of parcelable");
                }
            } else if (iDataPosition > Integer.MAX_VALUE - i2) {
                throw new BadParcelableException("Overflow in the size of parcelable");
            }
            parcel.setDataPosition(iDataPosition + i2);
        } catch (Throwable th) {
            if (iDataPosition > Integer.MAX_VALUE - i2) {
                throw new BadParcelableException("Overflow in the size of parcelable");
            }
            parcel.setDataPosition(iDataPosition + i2);
            throw th;
        }
    }

    public String toString() {
        StringJoiner stringJoiner = new StringJoiner(", ", "{", "}");
        stringJoiner.add("deviceType: " + this.deviceType);
        stringJoiner.add("deviceId: " + Objects.toString(this.deviceId));
        return "DeviceParcel" + stringJoiner.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        int iDataPosition = parcel.dataPosition();
        parcel.writeInt(0);
        parcel.writeInt(this.deviceType);
        parcel.writeString(this.deviceId);
        int iDataPosition2 = parcel.dataPosition();
        parcel.setDataPosition(iDataPosition);
        parcel.writeInt(iDataPosition2 - iDataPosition);
        parcel.setDataPosition(iDataPosition2);
    }
}
