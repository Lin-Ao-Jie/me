package com.vivo.vmdri;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ DependentServiceController.DependentServiceCallback f1264a;

    @Override // java.lang.Runnable
    public final void run() {
        this.f1264a.tryStartBindDependentService();
    }
}
