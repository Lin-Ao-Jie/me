package com.vivo.vmdri.debug;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import b0.a;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class VmdriDebugService extends Service {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private a f1441a = new a();

    public VmdriDebugService() {
        a("VmdriDebugService()");
    }

    private static void a(String str) {
        VmdriLog.d("VmdriDebugService", str);
    }

    @Override // android.app.Service
    protected void dump(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f1441a.a(fileDescriptor, printWriter, strArr);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }
}
