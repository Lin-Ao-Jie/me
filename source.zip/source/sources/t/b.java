package t;

import android.content.Context;
import android.view.WindowManager;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    public static float a(String str, float f2) {
        return Float.parseFloat(b(str, String.valueOf(f2)));
    }

    public static String b(String str, String str2) {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            return (String) cls.getMethod("get", String.class, String.class).invoke(cls, str, str2);
        } catch (Exception unused) {
            return str2;
        }
    }

    public static int c(Context context) {
        float refreshRate = ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getRefreshRate();
        a.a("getRefreshRate", "rate=" + refreshRate);
        if (refreshRate >= 20.0f && refreshRate < 59.0f) {
            return 30;
        }
        if (refreshRate >= 59.0f && refreshRate < 65.0f) {
            return 60;
        }
        if (refreshRate >= 65.0f && refreshRate < 90.0f) {
            return 72;
        }
        if (refreshRate >= 90.0f && refreshRate < 120.0f) {
            return 90;
        }
        if (refreshRate >= 120.0f && refreshRate < 140.0f) {
            return 120;
        }
        if (refreshRate < 140.0f || refreshRate >= 150.0f) {
            return (int) refreshRate;
        }
        return 144;
    }
}
