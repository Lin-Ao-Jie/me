package t;

import android.os.Build;
import android.os.Trace;
import android.util.Log;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final boolean f2189a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final boolean f2190b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static boolean f2191c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static boolean f2192d;

    static {
        boolean zEquals = b.b("persist.debug.springkit", "false").equals("true");
        f2189a = zEquals;
        String str = Build.TYPE;
        boolean z2 = true;
        boolean z3 = str.equals("eng") || str.equals("branddebug");
        f2190b = z3;
        f2191c = false;
        f2192d = false;
        try {
            boolean zEquals2 = b.b("persist.sys.log.ctrl", "no").equals("yes");
            f2191c = zEquals2;
            if (!z3 && (!zEquals2 || !zEquals)) {
                z2 = false;
            }
            f2192d = z2;
        } catch (Exception e2) {
            b("", e2.getMessage());
        }
    }

    public static void a(String str, String str2) {
        if (f2192d) {
            Log.v("SpringKit-" + str, str2);
        }
    }

    public static void b(String str, String str2) {
        Log.e("SpringKit-" + str, str2);
    }

    public static void c(String str, String str2) {
        if (f2192d) {
            Log.i("SpringKit-" + str, str2);
        }
    }

    public static void d(String str, String str2) {
        if (f2192d) {
            Trace.beginSection("SpringKit-" + str + "_" + str2);
            Trace.endSection();
            StringBuilder sb = new StringBuilder();
            sb.append("SpringKit-");
            sb.append(str);
            Log.d(sb.toString(), str2);
        }
    }
}
