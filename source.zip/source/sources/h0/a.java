package h0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f1715a;

    public a(String str) {
        this.f1715a = str;
    }

    private static void a(String str) {
        VmdriLog.e("BringUpProcessRequestMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(this.f1715a)) {
                jSONObject.put("pkg", this.f1715a);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting BringUpProcessRequestMsg to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            a("Error parsing jsonStr to BringUpProcessRequestMsg object:" + e2.toString());
            return aVar;
        }
    }

    private static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1715a = jSONObject.optString("pkg", "");
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to BringUpProcessRequestMsg object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "BringUpProcessRequestMsg{pkg='" + this.f1715a + "'}";
    }

    public a() {
        this.f1715a = "";
    }
}
