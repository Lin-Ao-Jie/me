package h0;

import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1716a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f1717b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1718c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f1719d;

    public b(boolean z2, String str, int i2, String str2) {
        this.f1717b = "";
        this.f1718c = 0;
        this.f1719d = "";
        this.f1716a = z2;
        this.f1717b = str == null ? "" : str;
        this.f1718c = i2;
        this.f1719d = str2;
    }

    private static void a(String str) {
        VmdriLog.e("StartCommShareRequestMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("fSt", this.f1716a ? 1 : 0);
            jSONObject.put("wPptD", this.f1717b);
            jSONObject.put("tarS", this.f1718c);
            jSONObject.put("desc", this.f1719d);
            return jSONObject;
        } catch (JSONException e2) {
            a("Error converting StartCommShareRequestMsg to JSONObject:" + e2.toString());
            return jSONObject;
        }
    }

    public static b d(String str) {
        if (str == null) {
            return new b();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            b bVar = new b();
            a("Error parsing jsonStr to StartCommShareRequestMsg object:" + e2.toString());
            return bVar;
        }
    }

    private static b e(JSONObject jSONObject) {
        try {
            b bVar = new b();
            boolean z2 = true;
            if (jSONObject.optInt("fSt", 0) != 1) {
                z2 = false;
            }
            bVar.f1716a = z2;
            bVar.f1717b = jSONObject.optString("wPptD", "");
            bVar.f1718c = jSONObject.optInt("tarS", 0);
            bVar.f1719d = jSONObject.optString("desc", "");
            return bVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to StartCommShareRequestMsg object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "StartCommShareRequestMsg{force=" + this.f1716a + ", willPreemptedDevId=" + this.f1717b + ", targetSource=" + this.f1718c + ", descStr='" + this.f1719d + "'}";
    }

    private b() {
        this.f1716a = false;
        this.f1717b = "";
        this.f1718c = 0;
        this.f1719d = "";
    }
}
