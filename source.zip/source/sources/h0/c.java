package h0;

import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1720a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1721b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f1722c;

    public c(boolean z2, int i2, String str) {
        this.f1720a = z2;
        this.f1721b = i2;
        this.f1722c = str;
    }

    private static void a(String str) {
        VmdriLog.e("StopCommShareRequestMsg", str);
    }

    public static c d(String str) {
        if (str == null) {
            return new c();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            c cVar = new c();
            a("Error parsing jsonStr to StopCommShareRequestMsg object:" + e2.toString());
            return cVar;
        }
    }

    public static c e(JSONObject jSONObject) {
        try {
            c cVar = new c();
            boolean z2 = true;
            if (jSONObject.optInt("fSp", 0) != 1) {
                z2 = false;
            }
            cVar.f1720a = z2;
            cVar.f1721b = jSONObject.optInt("tarS", 0);
            cVar.f1722c = jSONObject.optString("desc", "");
            return cVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to StopCommShareRequestMsg object:" + e2.toString());
            return null;
        }
    }

    public JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("fSp", this.f1720a ? 1 : 0);
            jSONObject.put("tarS", this.f1721b);
            jSONObject.put("desc", this.f1722c);
            return jSONObject;
        } catch (JSONException e2) {
            a("Error converting StopCommShareRequestMsg to JSONObject:" + e2.toString());
            return jSONObject;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "StopCommShareRequestMsg{force=" + this.f1720a + ", targetSource=" + this.f1721b + ", descStr='" + this.f1722c + "'}";
    }

    public c() {
        this.f1720a = false;
        this.f1721b = 0;
        this.f1722c = "";
    }
}
