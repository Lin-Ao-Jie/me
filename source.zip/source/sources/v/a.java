package v;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final String f2193a;

    public a(String str) {
        this.f2193a = str;
    }

    public abstract float a(Object obj);

    public abstract void b(Object obj, float f2);
}
