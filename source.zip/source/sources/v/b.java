package v;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f2194a = 0.0f;

    public b(float f2) {
        b(f2);
    }

    public float a() {
        return this.f2194a;
    }

    public void b(float f2) {
        this.f2194a = f2;
    }
}
