package p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static c f2019f = new c(176.0d, 26.0d);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public double f2020a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public double f2021b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public double f2022c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public double f2023d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f2024e = 0;

    public c(double d2, double d3) {
        this.f2021b = d2;
        this.f2020a = d3;
    }

    public String toString() {
        return "tension,friction=[" + this.f2021b + "," + this.f2020a + "]stiffness,damping=[" + this.f2022c + "," + this.f2023d + "]";
    }
}
