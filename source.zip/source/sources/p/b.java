package p;

import android.content.Context;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private static int f1995u = 0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private static double f1996v = 0.064d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private c f1997a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f1998b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private double f2001e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final String f2002f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final C0020b f2003g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final C0020b f2004h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final C0020b f2005i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private double f2006j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private double f2007k;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f2013q;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private WeakReference f1999c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private long f2000d = 0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f2008l = true;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private double f2009m = 0.005d;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private double f2010n = 0.005d;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private final CopyOnWriteArraySet f2011o = new CopyOnWriteArraySet();

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private double f2012p = 0.0d;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f2014r = true;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private boolean f2015s = false;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f2016t = false;

    /* JADX INFO: renamed from: p.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static final class C0020b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        double f2017a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        double f2018b;

        private C0020b() {
        }
    }

    public b() {
        this.f2003g = new C0020b();
        this.f2004h = new C0020b();
        this.f2005i = new C0020b();
        StringBuilder sb = new StringBuilder();
        sb.append("spring:");
        int i2 = f1995u;
        f1995u = i2 + 1;
        sb.append(i2);
        this.f2002f = sb.toString();
        this.f2013q = false;
        w(c.f2019f);
    }

    private double e(C0020b c0020b) {
        return Math.abs(this.f2007k - c0020b.f2017a);
    }

    private void h(double d2) {
        C0020b c0020b = this.f2003g;
        double d3 = c0020b.f2017a * d2;
        C0020b c0020b2 = this.f2004h;
        double d4 = 1.0d - d2;
        c0020b.f2017a = d3 + (c0020b2.f2017a * d4);
        c0020b.f2018b = (c0020b.f2018b * d2) + (c0020b2.f2018b * d4);
    }

    private void s() {
        t.a.a("ReboundSpring", "setMaxDeltaTimeSec");
        WeakReference weakReference = this.f1999c;
        if (weakReference == null) {
            t.a.a("ReboundSpring", "null == mContextWeakReference");
            return;
        }
        Context context = (Context) weakReference.get();
        if (context == null) {
            t.a.a("ReboundSpring", "null == context");
            return;
        }
        int iC = t.b.c(context);
        if (iC == 30) {
            f1996v = 0.125d;
        } else if (iC == 60) {
            f1996v = 0.064d;
        } else if (iC == 72) {
            f1996v = 0.052d;
        } else if (iC == 90) {
            f1996v = 0.041d;
        } else if (iC == 120) {
            f1996v = 0.032d;
        } else if (iC == 144) {
            f1996v = 0.026d;
        }
        t.a.a("ReboundSpring", "MAX_DELTA_TIME_SEC=" + f1996v);
    }

    public b a(d dVar) {
        if (dVar == null) {
            throw new IllegalArgumentException("newListener is required");
        }
        this.f2011o.add(dVar);
        return this;
    }

    public void b(double d2) {
        double d3;
        boolean z2;
        boolean zI = i();
        boolean z3 = false;
        if (zI && this.f2008l) {
            if (this.f2015s && j()) {
                t.a.a("ReboundSpring", "EndValue: " + this.f2007k);
                t.a.a("ReboundSpring", "EndPositionError: " + this.f2000d + ", Pos: " + this.f2003g.f2017a);
                long j2 = this.f2000d - 1;
                this.f2000d = j2;
                if (this.f2001e > 0.0d) {
                    this.f2003g.f2017a += 1.0d;
                } else {
                    this.f2003g.f2017a -= 1.0d;
                }
                if (j2 < 0) {
                    this.f2008l = true;
                    this.f2000d = 0L;
                    this.f2001e = 0.0d;
                    this.f2003g.f2017a = this.f2007k;
                    z3 = true;
                }
                for (d dVar : this.f2011o) {
                    dVar.d(this);
                    if (z3) {
                        dVar.a(this);
                    }
                }
                return;
            }
            return;
        }
        this.f2012p += Math.min(d2, f1996v);
        c cVar = this.f1997a;
        double d4 = cVar.f2021b;
        double d5 = cVar.f2020a;
        C0020b c0020b = this.f2003g;
        double d6 = c0020b.f2017a;
        double d7 = c0020b.f2018b;
        C0020b c0020b2 = this.f2005i;
        double d8 = c0020b2.f2017a;
        double d9 = c0020b2.f2018b;
        while (true) {
            d3 = this.f2012p;
            if (d3 < 0.001d) {
                break;
            }
            double d10 = d3 - 0.001d;
            this.f2012p = d10;
            if (d10 < 0.001d) {
                C0020b c0020b3 = this.f2004h;
                c0020b3.f2017a = d6;
                c0020b3.f2018b = d7;
            }
            double d11 = this.f2007k;
            double d12 = (d4 * (d11 - d8)) - (d5 * d7);
            double d13 = d7 + (d12 * 0.001d * 0.5d);
            double d14 = ((d11 - (d6 + ((d7 * 0.001d) * 0.5d))) * d4) - (d5 * d13);
            double d15 = d7 + (d14 * 0.001d * 0.5d);
            double d16 = ((d11 - (d6 + ((d13 * 0.001d) * 0.5d))) * d4) - (d5 * d15);
            double d17 = d6 + (d15 * 0.001d);
            double d18 = d7 + (d16 * 0.001d);
            d6 += (d7 + ((d13 + d15) * 2.0d) + d18) * 0.16666666666666666d * 0.001d;
            d7 += (d12 + ((d14 + d16) * 2.0d) + (((d11 - d17) * d4) - (d5 * d18))) * 0.16666666666666666d * 0.001d;
            d8 = d17;
            d9 = d18;
        }
        C0020b c0020b4 = this.f2005i;
        c0020b4.f2017a = d8;
        c0020b4.f2018b = d9;
        C0020b c0020b5 = this.f2003g;
        c0020b5.f2017a = d6;
        c0020b5.f2018b = d7;
        if (d3 > 0.0d) {
            h(d3 / 0.001d);
        }
        if (i() || (this.f1998b && k())) {
            if (!this.f2014r || d4 <= 0.0d) {
                double d19 = this.f2003g.f2017a;
                this.f2007k = d19;
                this.f2006j = d19;
            } else if (this.f2015s) {
                t.a.a("ReboundSpring", "End pos error: " + Math.abs(Math.round(this.f2007k - this.f2003g.f2017a)));
                if (Math.abs(Math.round(this.f2007k - this.f2003g.f2017a)) > 0) {
                    this.f2000d = Math.abs(Math.round(this.f2007k - this.f2003g.f2017a)) - 1;
                    C0020b c0020b6 = this.f2003g;
                    double d20 = c0020b6.f2018b;
                    this.f2001e = d20;
                    if (d20 > 0.0d) {
                        c0020b6.f2017a += 1.0d;
                    } else {
                        c0020b6.f2017a -= 1.0d;
                    }
                } else {
                    double d21 = this.f2007k;
                    this.f2006j = d21;
                    this.f2003g.f2017a = d21;
                    zI = true;
                }
            } else {
                double d22 = this.f2007k;
                this.f2006j = d22;
                this.f2003g.f2017a = d22;
            }
            x(0.0d);
            if (!this.f2015s) {
                zI = true;
            }
        }
        if (this.f2008l) {
            this.f2008l = false;
            z2 = true;
        } else {
            z2 = false;
        }
        if (zI) {
            this.f2008l = true;
            z3 = true;
        }
        for (d dVar2 : this.f2011o) {
            if (z2) {
                dVar2.c(this);
            }
            dVar2.d(this);
            if (z3) {
                dVar2.a(this);
            }
        }
    }

    public double c() {
        return this.f2003g.f2017a;
    }

    public double d() {
        return this.f2003g.f2018b;
    }

    public String f() {
        return this.f2002f;
    }

    public double g() {
        return this.f2003g.f2018b;
    }

    public boolean i() {
        StringBuilder sb = new StringBuilder();
        sb.append("SpeedThreshold =");
        sb.append(Math.abs(this.f2003g.f2018b) <= this.f2009m);
        sb.append(" , DistanceThreshold =");
        sb.append(e(this.f2003g) <= this.f2010n);
        t.a.a("ReboundSpring", sb.toString());
        t.a.a("ReboundSpring", "mCurrentState.velocity =" + Math.abs(this.f2003g.f2018b) + " , mCurrentDistance =" + e(this.f2003g));
        return Math.abs(this.f2003g.f2018b) <= this.f2009m && (e(this.f2003g) <= this.f2010n || this.f1997a.f2021b == 0.0d);
    }

    public boolean j() {
        return this.f2000d > 0;
    }

    public boolean k() {
        if (this.f1997a.f2021b <= 0.0d) {
            return false;
        }
        if (this.f2006j >= this.f2007k || c() <= this.f2007k) {
            return this.f2006j > this.f2007k && c() < this.f2007k;
        }
        return true;
    }

    public b l() {
        this.f2011o.clear();
        return this;
    }

    public b m() {
        C0020b c0020b = this.f2003g;
        double d2 = c0020b.f2017a;
        this.f2007k = d2;
        this.f2005i.f2017a = d2;
        c0020b.f2018b = 0.0d;
        return this;
    }

    public void n(Context context) {
        t.a.a("ReboundSpring", "setContext");
        this.f1999c = new WeakReference(context);
    }

    public b o(double d2) {
        return p(d2, true);
    }

    public b p(double d2, boolean z2) {
        this.f2006j = d2;
        this.f2003g.f2017a = d2;
        if (this.f2013q) {
            f();
            throw null;
        }
        if (z2) {
            m();
        }
        s();
        return this;
    }

    public b q(double d2) {
        if (this.f2007k != d2 || !i()) {
            this.f2006j = c();
            this.f2007k = d2;
            if (this.f2013q) {
                f();
                throw null;
            }
            Iterator it = this.f2011o.iterator();
            while (it.hasNext()) {
                ((d) it.next()).b(this);
            }
        }
        return this;
    }

    public void r(boolean z2) {
        this.f2016t = z2;
    }

    public void t(boolean z2) {
        this.f2014r = z2;
    }

    public b u(double d2) {
        this.f2010n = d2;
        return this;
    }

    public b v(double d2) {
        this.f2009m = d2;
        return this;
    }

    public b w(c cVar) {
        if (cVar == null) {
            throw new IllegalArgumentException("springConfig is required");
        }
        this.f1997a = cVar;
        return this;
    }

    public b x(double d2) {
        C0020b c0020b = this.f2003g;
        if (d2 != c0020b.f2018b) {
            c0020b.f2018b = d2;
            if (this.f2013q) {
                f();
                throw null;
            }
        }
        return this;
    }
}
