package z;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.UserManager;
import android.provider.Settings;
import android.util.ArraySet;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import java.util.Set;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class o extends Handler {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final Uri f2374k = Uri.parse("content://com.vivo.handoff.settings/handoff_app_setting/90001");

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final Uri f2375l = Uri.parse("content://com.vivo.handoff.settings/handoff_setting/hoffsetting_sms_share");

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final Uri f2376m = Uri.parse("content://com.vivo.handoff.settings/handoff_setting/hoffsetting_wlan_content_syn");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f2377a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final ContentResolver f2378b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final UserManager f2379c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private w.j f2380d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final BroadcastReceiver f2381e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final Set f2382f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f2383g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f2384h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f2385i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f2386j;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends ContentObserver {
        a(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2, Uri uri) {
            o.C("call share switch changed, selfChange:" + z2 + ", uri:" + uri);
            o.this.J();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends ContentObserver {
        b(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2, Uri uri) {
            o.C("sms share switch changed, selfChange:" + z2 + ", uri:" + uri);
            o.this.L();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends ContentObserver {
        c(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2, Uri uri) {
            o.C("data share switch changed, selfChange:" + z2 + ", uri:" + uri);
            o.this.K();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends ContentObserver {
        d(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2, Uri uri) {
            o.C("comm share auto conn switch changed, selfChange:" + z2 + ", uri:" + uri);
            o.this.I();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class f extends BroadcastReceiver {
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            action.hashCode();
            if (action.equals("android.intent.action.BOOT_COMPLETED")) {
                o.C("system unlock");
                o.this.f2377a.unregisterReceiver(this);
                o.this.v();
            } else {
                o.E("receive a not support broadcast:" + intent);
            }
        }

        private f() {
        }
    }

    public o(Looper looper) {
        o oVar;
        super(looper);
        f fVar = new f();
        this.f2381e = fVar;
        this.f2382f = new ArraySet();
        this.f2383g = false;
        this.f2384h = false;
        this.f2385i = false;
        this.f2386j = false;
        Context applicationContext = VmdriContext.getInstance().getApplicationContext();
        this.f2377a = applicationContext;
        this.f2378b = applicationContext.getContentResolver();
        this.f2379c = UserManager.get(applicationContext);
        boolean zX = x();
        boolean zW = w();
        C("HandOffSettingManager created, userUnlocked:" + zX + ", isProvisioned:" + zW);
        if (zX && zW) {
            post(new Runnable() { // from class: z.l
                @Override // java.lang.Runnable
                public final void run() {
                    this.f2371a.v();
                }
            });
            return;
        }
        if (zX) {
            oVar = this;
        } else {
            oVar = this;
            applicationContext.registerReceiver(fVar, new IntentFilter("android.intent.action.BOOT_COMPLETED"), null, oVar, 2);
        }
        if (zW) {
            return;
        }
        w.j jVar = new w.j(applicationContext, oVar);
        oVar.f2380d = jVar;
        jVar.b(Settings.Global.getUriFor("device_provisioned"), 1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A(e eVar) {
        eVar.d(this.f2385i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B(e eVar) {
        eVar.e(this.f2384h);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void C(String str) {
        VmdriLog.d("HandOffSettingManager", str);
    }

    private static void D(String str) {
        VmdriLog.e("HandOffSettingManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void E(String str) {
        VmdriLog.w("HandOffSettingManager", str);
    }

    private void H(String str) {
        J();
        L();
        K();
        I();
        C("updateAllSwitchStatusAndNotify reason:" + str + ", mCallShareEnable:" + this.f2383g + ", mSmsShareEnable:" + this.f2384h + ", mDataShareEnable:" + this.f2385i + ", mAutoConnEnable:" + this.f2386j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I() {
        boolean zO = o();
        if (zO != this.f2386j) {
            C("updateAutoConnSwitchAndNotify:" + this.f2386j + "->" + zO);
            this.f2386j = zO;
            this.f2382f.forEach(new Consumer() { // from class: z.k
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    this.f2370a.y((o.e) obj);
                }
            });
            this.f2382f.forEach(new j());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void J() {
        boolean zQ = q();
        if (zQ != this.f2383g) {
            C("updateCallSwitchAndNotify:" + this.f2383g + "->" + zQ);
            this.f2383g = zQ;
            this.f2382f.forEach(new Consumer() { // from class: z.m
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    this.f2372a.z((o.e) obj);
                }
            });
            this.f2382f.forEach(new j());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K() {
        boolean zS = s();
        if (zS != this.f2385i) {
            C("updateDataSwitchAndNotify:" + this.f2385i + "->" + zS);
            this.f2385i = zS;
            this.f2382f.forEach(new Consumer() { // from class: z.n
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    this.f2373a.A((o.e) obj);
                }
            });
            this.f2382f.forEach(new j());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L() {
        boolean zU = u();
        if (zU != this.f2384h) {
            C("updateSmsSwitchAndNotify:" + this.f2384h + "->" + zU);
            this.f2384h = zU;
            this.f2382f.forEach(new Consumer() { // from class: z.i
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    this.f2369a.B((o.e) obj);
                }
            });
            this.f2382f.forEach(new j());
        }
    }

    private boolean o() {
        return Settings.Global.getInt(this.f2378b, "vdfs_comm_auto_connect", 0) != 0;
    }

    private boolean q() {
        return q.a(this.f2377a, 90001);
    }

    private boolean s() {
        return q.e(this.f2377a);
    }

    private boolean u() {
        return q.d(this.f2377a);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void v() {
        boolean zX = x();
        boolean zW = w();
        if (zX && zW) {
            q.i(this.f2377a, "90001", new a(this));
            q.k(this.f2377a, new b(this));
            q.l(this.f2377a, new c(this));
            this.f2378b.registerContentObserver(Settings.Global.getUriFor("vdfs_comm_auto_connect"), false, new d(this));
            H("init");
            return;
        }
        E("initializeSettings reject, userUnlocked:" + zX + ", isProvisioned:" + zW);
    }

    private boolean w() {
        return Settings.Global.getInt(this.f2378b, "device_provisioned", 1) == 1;
    }

    private boolean x() {
        return this.f2379c.isUserUnlocked();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y(e eVar) {
        eVar.a(this.f2386j);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z(e eVar) {
        eVar.b(this.f2383g);
    }

    public void F(e eVar) {
        if (eVar == null) {
            return;
        }
        this.f2382f.add(eVar);
        eVar.b(this.f2383g);
        eVar.e(this.f2384h);
        eVar.d(this.f2385i);
        eVar.a(this.f2386j);
        eVar.c();
    }

    public void G(boolean z2) {
        Settings.Global.putInt(this.f2378b, "vdfs_comm_auto_connect", z2 ? 1 : 0);
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        if (message.what != 1) {
            D("Unknown msg.what: " + message.what);
            return;
        }
        C("device provision state changed");
        this.f2380d.c();
        this.f2380d = null;
        v();
    }

    public boolean n() {
        return this.f2386j;
    }

    public boolean p() {
        return this.f2383g;
    }

    public boolean r() {
        return this.f2385i;
    }

    public boolean t() {
        return this.f2384h;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class e {
        public abstract void c();

        public void a(boolean z2) {
        }

        public void b(boolean z2) {
        }

        public void d(boolean z2) {
        }

        public void e(boolean z2) {
        }
    }
}
