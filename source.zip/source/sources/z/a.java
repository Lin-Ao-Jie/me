package z;

import com.vivo.cowork.device.DeviceInfo;
import com.vivo.vmdri.VmdriLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static w.i a(DeviceInfo deviceInfo) {
        if (deviceInfo == null) {
            return new w.i();
        }
        w.i.a aVar = new w.i.a();
        aVar.i(deviceInfo.getDeviceName()).h(deviceInfo.getBleDeviceId()).k(deviceInfo.getOpenId()).g(d(deviceInfo.getConnectType()));
        if (deviceInfo.getDeviceType() == 32) {
            aVar.j(1);
        } else if (deviceInfo.getDeviceType() == 256) {
            aVar.j(2);
        } else {
            aVar.j(0);
        }
        return aVar.f();
    }

    public static w.i b(b bVar) {
        if (bVar == null) {
            return new w.i();
        }
        w.i.a aVar = new w.i.a();
        aVar.i(bVar.d()).h(bVar.b()).k(bVar.f());
        if (bVar.e() == 32) {
            aVar.j(1);
        } else if (bVar.e() == 256) {
            aVar.j(2);
        } else {
            aVar.j(0);
        }
        aVar.g(d(bVar.c()));
        return aVar.f();
    }

    public static int c(int i2) {
        if (i2 == 1) {
            return 4;
        }
        if (i2 != 2) {
            return i2 != 3 ? 0 : 256;
        }
        return 1;
    }

    public static int d(int i2) {
        int i3 = (i2 & 4) == 4 ? 1 : 0;
        if ((i2 & 1) == 1) {
            i3 |= 2;
        }
        return (i2 & 256) == 256 ? i3 | 4 : i3;
    }

    public static int e(int i2) {
        if (i2 == -1) {
            return 0;
        }
        switch (i2) {
            case 101:
                return 1;
            case 102:
            case 103:
                return 2;
            default:
                h("convertToVmdriConnType unknown origCowkConnStatus:" + i2);
                return 0;
        }
    }

    public static int f(int i2) {
        if (i2 == 1) {
            return 2;
        }
        if (i2 == 4) {
            return 1;
        }
        if (i2 == 256) {
            return 3;
        }
        h("convertToVmdriConnType unknown origCowkType:" + i2);
        return 0;
    }

    public static int g(int i2) {
        if (i2 == 0 || i2 == 1 || i2 == 2) {
            return 1;
        }
        return i2 != 3 ? 0 : 2;
    }

    private static void h(String str) {
        VmdriLog.w("CoWkConverter", str);
    }
}
