package z;

import com.vivo.cowork.device.DeviceInfo;
import com.vivo.vmdri.VmdriLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f2332a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f2333b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f2334c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f2335d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private String f2336e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private String f2337f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f2338g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f2339h;

    public b() {
        this.f2334c = "";
        this.f2335d = "";
        this.f2336e = "";
        this.f2337f = "";
    }

    private static void g(String str) {
        VmdriLog.d("CoWkDevInfo", str);
    }

    public boolean a(int i2) {
        boolean z2;
        g("addConnectType start " + this.f2335d + ", now:" + h.b(this.f2333b) + ", add:" + h.b(i2));
        int i3 = this.f2333b;
        int i4 = i2 | i3;
        if (i4 != i3) {
            this.f2333b = i4;
            z2 = true;
        } else {
            z2 = false;
        }
        g("addConnectType end " + this.f2335d + ", now:" + h.b(this.f2333b) + ", changed:" + z2);
        return z2;
    }

    public String b() {
        return this.f2335d;
    }

    public int c() {
        return this.f2333b;
    }

    public String d() {
        return this.f2336e;
    }

    public int e() {
        return this.f2332a;
    }

    public String f() {
        return this.f2337f;
    }

    public boolean h(int i2) {
        boolean z2;
        g("removeConnectType start " + this.f2335d + ", now:" + h.b(this.f2333b) + ", remove:" + h.b(i2));
        int i3 = this.f2333b;
        int i4 = (~(i2 & i3)) & i3;
        if (i4 != i3) {
            this.f2333b = i4;
            z2 = true;
        } else {
            z2 = false;
        }
        g("removeConnectType end " + this.f2335d + ", now:" + h.b(this.f2333b) + ", changed:" + z2);
        return z2;
    }

    public String toString() {
        return "Internal CoWkDevInfo{DeviceName='" + this.f2336e + "', BleDeviceId='" + this.f2335d + "', DeviceType=" + h.f(this.f2332a) + ", ConnectType=" + h.b(this.f2333b) + ", OpenId='" + this.f2337f + "', DeviceId='" + this.f2334c + "', ScreenWidth=" + this.f2338g + ", ScreenHeight=" + this.f2339h + '}';
    }

    public b(DeviceInfo deviceInfo) {
        this.f2334c = "";
        this.f2335d = "";
        this.f2336e = "";
        this.f2337f = "";
        if (deviceInfo == null) {
            return;
        }
        this.f2336e = deviceInfo.getDeviceName();
        this.f2334c = deviceInfo.getDeviceId();
        this.f2335d = deviceInfo.getBleDeviceId();
        this.f2337f = deviceInfo.getOpenId();
        this.f2332a = deviceInfo.getDeviceType();
        this.f2338g = deviceInfo.getScreenWidth();
        this.f2339h = deviceInfo.getScreenHeight();
    }
}
