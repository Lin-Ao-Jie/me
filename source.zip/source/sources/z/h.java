package z;

import com.vivo.cowork.device.DeviceInfo;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class h {
    public static String a(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(i2);
        sb.append("):");
        if (i2 != -1) {
            switch (i2) {
                case 101:
                    sb.append("CONNECTED");
                    break;
                case 102:
                    sb.append("TIMEOUT_DISCONNECT");
                    break;
                case 103:
                    sb.append("DISCONNECT");
                    break;
                case 104:
                    sb.append("CONNECT_FAILURE");
                    break;
                default:
                    sb.append("NOT_SUPPORT");
                    break;
            }
        } else {
            sb.append("SDK_UNKNOWN");
        }
        return sb.toString();
    }

    public static String b(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(0X");
        sb.append(Integer.toHexString(i2));
        sb.append("):");
        if ((i2 & 256) == 256) {
            sb.append("|BASECONN_TUNNEL|");
        }
        if ((i2 & 1) == 1) {
            sb.append("|P2P|");
        }
        if ((i2 & 4) == 4) {
            sb.append("|BR|");
        }
        if ((i2 & 2) == 2) {
            sb.append("|WLAN|");
        }
        if ((i2 & 8) == 8) {
            sb.append("|BLE|");
        }
        if ((i2 & 16) == 16) {
            sb.append("|PC|");
        }
        if ((i2 & 32) == 32) {
            sb.append("|SCREEN_MIRROR|");
        }
        if ((i2 & 65536) == 65536) {
            sb.append("|AUTO|");
        }
        if ((i2 & 64) == 64) {
            sb.append("|CLOUD|");
        }
        return sb.toString();
    }

    public static String c(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(0X");
        sb.append(Integer.toHexString(i2));
        sb.append("):");
        if (i2 == 1) {
            sb.append("|P2P|");
        } else if (i2 == 2) {
            sb.append("|WLAN|");
        } else if (i2 == 4) {
            sb.append("|BR|");
        } else if (i2 == 8) {
            sb.append("|BLE|");
        } else if (i2 == 16) {
            sb.append("|PC|");
        } else if (i2 == 32) {
            sb.append("|SCREEN_MIRROR|");
        } else if (i2 == 64) {
            sb.append("|CLOUD|");
        } else if (i2 == 256) {
            sb.append("|BASECONN_TUNNEL|");
        } else if (i2 != 65536) {
            sb.append("|UNKNOWN|");
        } else {
            sb.append("|AUTO|");
        }
        return sb.toString();
    }

    public static String d(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(i2);
        sb.append("):");
        if (i2 == 1) {
            sb.append("DISCOVERY_DEVICE_FOUND");
        } else if (i2 != 2) {
            sb.append("DISCOVERY_DEVICE_UNKNOWN");
        } else {
            sb.append("DISCOVERY_DEVICE_LOST");
        }
        return sb.toString();
    }

    public static String e(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(i2);
        sb.append("):");
        if (i2 == 0) {
            sb.append("PROCESS_STATE_BACKGROUND");
        } else if (i2 == 1) {
            sb.append("PROCESS_STATE_FOREGROUND");
        } else if (i2 == 2) {
            sb.append("PROCESS_STATE_CREATED");
        } else if (i2 != 3) {
            sb.append("PROCESS_STATE_UNKNOWN");
        } else {
            sb.append("PROCESS_STATE_DIED");
        }
        return sb.toString();
    }

    public static String f(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(0X");
        sb.append(Integer.toHexString(i2));
        sb.append("):");
        if (i2 == -1) {
            sb.append("SDK_UNKNOWN");
        } else if (i2 == 2) {
            sb.append("TV");
        } else if (i2 == 4) {
            sb.append("CAMERA");
        } else if (i2 == 8) {
            sb.append("VOICEBOX");
        } else if (i2 == 16) {
            sb.append("WATCH");
        } else if (i2 == 32) {
            sb.append("PHONE");
        } else if (i2 == 64) {
            sb.append("COMPUTER");
        } else if (i2 == 128) {
            sb.append("CAR_MACHINE");
        } else if (i2 != 256) {
            sb.append("NONSUPPORT");
        } else {
            sb.append("PAD");
        }
        return sb.toString();
    }

    public static String g(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(0X");
        sb.append(Integer.toHexString(i2));
        sb.append("):");
        if ((i2 & 1) == 1) {
            sb.append("|WLAN|");
        }
        if ((i2 & 2) == 2) {
            sb.append("|BR|");
        }
        if ((i2 & 4) == 4) {
            sb.append("|BLE|");
        }
        if ((i2 & 8) == 8) {
            sb.append("|NFC|");
        }
        return sb.toString();
    }

    public static String h(int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(i2);
        sb.append("):");
        if (i2 == -1) {
            sb.append("SDK_UNKNOWN");
        } else if (i2 == 1) {
            sb.append("CLOSE_ACROSS_DEVICE");
        } else if (i2 == 2) {
            sb.append("LOGOUT_ACCOUNT");
        } else if (i2 != 3) {
            sb.append("UNKNOWN");
        } else {
            sb.append("NOT_FOUNT_DEVICE_OVER_2_MINUTE");
        }
        return sb.toString();
    }

    public static String i(DeviceInfo deviceInfo) {
        StringBuilder sb = new StringBuilder();
        if (deviceInfo != null) {
            sb.append("{DeviceId:");
            sb.append(deviceInfo.getDeviceId());
            sb.append(",OpenId:");
            sb.append(deviceInfo.getOpenId());
            sb.append(",BleDeviceId:");
            sb.append(deviceInfo.getBleDeviceId());
            sb.append(",DeviceName:");
            sb.append(deviceInfo.getDeviceName());
            sb.append(",DeviceType:");
            sb.append(f(deviceInfo.getDeviceType()));
            sb.append("}");
        } else {
            sb.append("{null}");
        }
        return sb.toString();
    }
}
