package z;

import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class j implements Consumer {
    @Override // java.util.function.Consumer
    public final void accept(Object obj) {
        ((o.e) obj).c();
    }
}
