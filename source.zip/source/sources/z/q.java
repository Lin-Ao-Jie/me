package z;

import android.content.ContentProviderClient;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import com.vivo.vmdri.VmdriLog;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final String f2392a = String.format("content://%s/handoff_app_setting", "com.vivo.handoff.settings");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final String f2393b = String.format("content://%s/handoff_setting", "com.vivo.handoff.settings");

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final List f2394a;

        /* JADX INFO: Access modifiers changed from: private */
        public void b(a aVar) {
            for (ContentObserver contentObserver : aVar.f2394a) {
                if (!this.f2394a.contains(contentObserver)) {
                    this.f2394a.add(contentObserver);
                }
            }
        }

        private a(ContentObserver contentObserver) {
            ArrayList arrayList = new ArrayList();
            this.f2394a = arrayList;
            arrayList.add(contentObserver);
        }
    }

    public static boolean a(Context context, int i2) {
        boolean z2 = false;
        if (context != null) {
            Uri uri = Uri.parse(String.format("%s/%s", f2392a, Integer.valueOf(i2)));
            ContentProviderClient contentProviderClientAcquireUnstableContentProviderClient = context.getApplicationContext().getContentResolver().acquireUnstableContentProviderClient(uri);
            if (contentProviderClientAcquireUnstableContentProviderClient != null) {
                try {
                    try {
                        Cursor cursorQuery = contentProviderClientAcquireUnstableContentProviderClient.query(uri, null, null, null, null);
                        if (cursorQuery != null) {
                            try {
                                if (cursorQuery.moveToNext()) {
                                    boolean z3 = cursorQuery.getExtras().getBoolean("key_connect_base_permission", false);
                                    boolean z4 = cursorQuery.getExtras().containsKey("key_parent_enable") ? cursorQuery.getExtras().getBoolean("key_parent_enable", true) : b(context);
                                    if (cursorQuery.getInt(cursorQuery.getColumnIndex("enable")) == 1 && z3 && z4) {
                                        z2 = true;
                                    }
                                    f(String.format("isAppHandOffEnable handOffId:%s enable:%s connectBaseHasPermission:%s parentEnable:%s", Integer.valueOf(i2), Boolean.valueOf(z2), Boolean.valueOf(z3), Boolean.valueOf(z4)));
                                }
                            } catch (Throwable th) {
                                try {
                                    cursorQuery.close();
                                    throw th;
                                } catch (Throwable th2) {
                                    th.addSuppressed(th2);
                                    throw th;
                                }
                            }
                        }
                        if (cursorQuery != null) {
                            cursorQuery.close();
                        }
                    } catch (Throwable th3) {
                        n(contentProviderClientAcquireUnstableContentProviderClient);
                        throw th3;
                    }
                } catch (Exception e2) {
                    g("isAppHandOffEnable handOffId: " + i2 + " failed; e: " + e2.getMessage());
                }
                n(contentProviderClientAcquireUnstableContentProviderClient);
                return z2;
            }
            g("isAppHandOffEnable handOffId: " + i2 + " failed; providerClient is null");
        }
        return false;
    }

    public static boolean b(Context context) {
        return m(context, "hoffsetting_app");
    }

    public static boolean c(Context context) {
        return m(context, "hoffsetting_content_syn");
    }

    public static boolean d(Context context) {
        return m(context, "hoffsetting_sms_share") && c(context);
    }

    public static boolean e(Context context) {
        return m(context, "hoffsetting_wlan_content_syn") && c(context);
    }

    private static void f(String str) {
        VmdriLog.d("HandOffSettingTools", str);
    }

    private static void g(String str) {
        VmdriLog.e("HandOffSettingTools", str);
    }

    private static a h(Context context, String str, ContentObserver contentObserver) {
        try {
            context.getApplicationContext().getContentResolver().registerContentObserver(Uri.parse(String.format("%s/%s", f2393b, str)), true, contentObserver);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return new a(contentObserver);
    }

    public static a i(Context context, String str, ContentObserver contentObserver) {
        try {
            context.getContentResolver().registerContentObserver(Uri.parse(String.format("%s/%s", f2392a, str)), true, contentObserver);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        a aVar = new a(contentObserver);
        aVar.b(j(context, contentObserver));
        return aVar;
    }

    public static a j(Context context, ContentObserver contentObserver) {
        return h(context, "hoffsetting_app", contentObserver);
    }

    public static a k(Context context, ContentObserver contentObserver) {
        a aVarH = h(context, "hoffsetting_content_syn", contentObserver);
        a aVarH2 = h(context, "hoffsetting_sms_share", contentObserver);
        aVarH2.b(aVarH);
        return aVarH2;
    }

    public static a l(Context context, ContentObserver contentObserver) {
        a aVarH = h(context, "hoffsetting_content_syn", contentObserver);
        a aVarH2 = h(context, "hoffsetting_wlan_content_syn", contentObserver);
        aVarH2.b(aVarH);
        return aVarH2;
    }

    private static boolean m(Context context, String str) {
        Uri uri = Uri.parse(String.format("%s/%s", f2393b, str));
        ContentProviderClient contentProviderClientAcquireUnstableContentProviderClient = context.getApplicationContext().getContentResolver().acquireUnstableContentProviderClient(uri);
        boolean z2 = false;
        if (contentProviderClientAcquireUnstableContentProviderClient == null) {
            g("queryHandOffSettingEnable settingKey: " + str + " failed; providerClient is null");
            return false;
        }
        try {
            try {
                Cursor cursorQuery = contentProviderClientAcquireUnstableContentProviderClient.query(uri, null, null, null, null);
                if (cursorQuery != null) {
                    try {
                        if (cursorQuery.moveToNext()) {
                            boolean z3 = cursorQuery.getExtras().getBoolean("key_connect_base_permission", false);
                            if (cursorQuery.getInt(cursorQuery.getColumnIndex("enable")) == 1 && z3) {
                                z2 = true;
                            }
                        }
                    } catch (Throwable th) {
                        try {
                            cursorQuery.close();
                            throw th;
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                            throw th;
                        }
                    }
                }
                if (cursorQuery != null) {
                    cursorQuery.close();
                }
            } catch (Exception e2) {
                g("queryHandOffSettingEnable settingKey: " + str + " failed; e: " + e2.getMessage());
            }
            n(contentProviderClientAcquireUnstableContentProviderClient);
            return z2;
        } catch (Throwable th3) {
            n(contentProviderClientAcquireUnstableContentProviderClient);
            throw th3;
        }
    }

    private static void n(ContentProviderClient contentProviderClient) {
        if (contentProviderClient != null) {
            contentProviderClient.close();
        }
    }
}
