package z;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class g {
    public static int a(int i2) {
        int i3 = (i2 & 256) != 256 ? 0 : 256;
        if ((i2 & 1) == 1) {
            i3 |= 1;
        }
        return (i2 & 4) == 4 ? i3 | 4 : i3;
    }
}
