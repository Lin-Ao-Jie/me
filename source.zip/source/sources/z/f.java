package z;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.IndentingPrintWriter;
import android.util.Pair;
import c0.u0;
import com.vivo.commshare.ICommShareAudioStateListener;
import com.vivo.cowork.callback.IAudioStateListener;
import com.vivo.cowork.callback.IDeviceStatusListener;
import com.vivo.cowork.callback.IInstantDataListener;
import com.vivo.cowork.callback.IProcessStateListener;
import com.vivo.cowork.callback.IResultCallback;
import com.vivo.cowork.callback.IServiceConnectCallback;
import com.vivo.cowork.callback.IServiceDispatchCallback;
import com.vivo.cowork.callback.IVResultCallback;
import com.vivo.cowork.callback.IVdfsSelfKillListener;
import com.vivo.cowork.device.DeviceInfo;
import com.vivo.cowork.device.DeviceManager;
import com.vivo.cowork.distributed.data.DistributedInsDataManager;
import com.vivo.cowork.mediaserver.audioserver.AudioBusinessInfo;
import com.vivo.cowork.mediaserver.audioserver.VdfsAudioManager;
import com.vivo.cowork.sdk.CoWorkKit;
import com.vivo.cowork.servicemanager.VdfsServiceManager;
import com.vivo.cowork.vdfskill.VdfsSelfKillManager;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import java.io.FileDescriptor;
import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class f extends u0 {
    private static final Object Q = new Object();
    private ConcurrentHashMap A;
    private ConcurrentHashMap B;
    private ConcurrentHashMap C;
    private ConcurrentHashMap D;
    private z.b E;
    private String F;
    private String G;
    private ConcurrentHashMap H;
    private ConcurrentHashMap I;
    private ConcurrentHashMap J;
    private IServiceConnectCallback K;
    private IDeviceStatusListener L;
    private IServiceDispatchCallback M;
    private IProcessStateListener N;
    private IVdfsSelfKillListener O;
    private IInstantDataListener P;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private HashMap f2344m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f2345n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f2346o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private Context f2347p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f2348q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f2349r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private boolean f2350s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private DeviceManager f2351t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private DistributedInsDataManager f2352u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private VdfsServiceManager f2353v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private VdfsAudioManager f2354w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private VdfsSelfKillManager f2355x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private HashMap f2356y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private final Object f2357z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements IServiceConnectCallback {
        a() {
        }

        public void onConnectFailed(int i2) {
            f.C("CoWork onConnectFailed errorCode:" + i2);
        }

        public void onConnected() {
            f.R0("CoWork onConnected");
            f.this.sendEmptyMessage(502);
        }

        public void onDisconnect() {
            f.B("CoWork onDisconnect");
            f.this.sendEmptyMessage(503);
        }

        public void onLinkToDeath() {
            f.B("CoWork onLinkToDeath");
            f.this.sendEmptyMessage(503);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements IServiceDispatchCallback {

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class a implements w.b {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ IVResultCallback f2361a;

            a(c cVar, IVResultCallback iVResultCallback) {
                this.f2361a = iVResultCallback;
            }

            @Override // w.b
            public void onResult(int i2, String str) {
                f.B("dispatchService, onResult key_start_communication, errorCode:" + i2 + ", message:" + str);
                try {
                    this.f2361a.onResult(i2, str);
                } catch (RemoteException e2) {
                    e2.printStackTrace();
                }
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class b implements w.b {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ IVResultCallback f2362a;

            b(c cVar, IVResultCallback iVResultCallback) {
                this.f2362a = iVResultCallback;
            }

            @Override // w.b
            public void onResult(int i2, String str) {
                f.B("dispatchService, onResult key_stop_communication, errorCode:" + i2 + ", message:" + str);
                try {
                    this.f2362a.onResult(i2, str);
                } catch (RemoteException e2) {
                    e2.printStackTrace();
                }
            }
        }

        c() {
        }

        public void dispatchService(String str, IVResultCallback iVResultCallback) {
            f.B("dispatchService jsonStr:" + str + ", resultCallback:" + iVResultCallback);
            String strOptString = "";
            String strOptString2 = "";
            try {
                JSONObject jSONObject = new JSONObject(str);
                strOptString = jSONObject.optString("option", "");
                strOptString2 = jSONObject.optString("deviceId", "");
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
            String bleDeviceIdByConnId = f.this.f2353v.getBleDeviceIdByConnId(strOptString2);
            f.B("dispatchService bleDeviceId:" + bleDeviceIdByConnId);
            if (TextUtils.isEmpty(bleDeviceIdByConnId)) {
                return;
            }
            if (!Objects.equals(strOptString, "key_start_communication")) {
                if (Objects.equals(strOptString, "key_stop_communication")) {
                    f.this.L(bleDeviceIdByConnId, new b(this, iVResultCallback));
                    return;
                }
                f.C("dispatchService error, jsonStr:" + str);
                return;
            }
            synchronized (f.this.f2357z) {
                try {
                    if (((Integer) f.this.A.getOrDefault(bleDeviceIdByConnId, 0)).intValue() == 3) {
                        f.D("dispatchService report fake comm share state on auto comm is targeting");
                        f fVar = f.this;
                        fVar.e1(bleDeviceIdByConnId, fVar.M0());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            f.this.K(bleDeviceIdByConnId, new a(this, iVResultCallback));
        }

        public int getServiceState(String str, String str2) {
            String bleDeviceIdByConnId = f.this.f2353v.getBleDeviceIdByConnId(str);
            str2.hashCode();
            int iIntValue = 0;
            switch (str2) {
                case "vdfs_comm_share":
                    iIntValue = ((Integer) f.this.A.getOrDefault(bleDeviceIdByConnId, 0)).intValue();
                    break;
                case "vdfs_mms_share":
                    iIntValue = ((Integer) f.this.C.getOrDefault(bleDeviceIdByConnId, 0)).intValue();
                    break;
                case "vdfs_tel_share":
                    iIntValue = ((Integer) f.this.B.getOrDefault(bleDeviceIdByConnId, 0)).intValue();
                    break;
                case "vdfs_net_share":
                    iIntValue = ((Integer) f.this.D.getOrDefault(bleDeviceIdByConnId, 0)).intValue();
                    break;
            }
            f.B("getServiceState, connDeviceId:" + str + ", bleDeviceId:" + bleDeviceIdByConnId + ", serviceId:" + str2 + ", state:" + iIntValue);
            return iIntValue;
        }

        public void setSwitch(String str, String str2, boolean z2, IVResultCallback iVResultCallback) {
            f.B("setSwitch deviceId:" + str + ", serviceId:" + str2 + ", callback:" + iVResultCallback);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e implements IVdfsSelfKillListener {
        e() {
        }

        public int onVdfsKill(int i2) {
            int size = f.this.H.size();
            f.C("onVdfsKill code " + z.h.h(i2) + ", conn dev size:" + size);
            return size > 0 ? -1 : 0;
        }

        public void onVdfsKillImmediately() {
            f.D("onVdfsKillImmediately");
            CoWorkKit.getInstance().disConnectService();
        }
    }

    /* JADX INFO: renamed from: z.f$f, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0029f implements IInstantDataListener {
        C0029f() {
        }

        public void onRec(String str, Bundle bundle) {
            int i2 = bundle.getInt("recv");
            byte[] byteArray = bundle.getByteArray("data");
            int i3 = bundle.getInt("vdfs_data_channel");
            if (VmdriLog.isDetailDebugLevel()) {
                StringBuilder sb = new StringBuilder();
                sb.append("onRecv data, remoteDevId:");
                sb.append(str);
                sb.append(", connType:");
                sb.append(z.h.c(i3));
                sb.append(", data len :");
                sb.append(byteArray != null ? byteArray.length : 0);
                sb.append(", recv type: ");
                sb.append(i2);
                f.B(sb.toString());
            }
            if (i2 != 100 || byteArray == null || str == null) {
                return;
            }
            f.this.T0(str, byteArray);
            f.this.H(str, byteArray, z.a.f(i3));
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g extends ContentObserver {
        g(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2) {
            f.this.h1();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class h implements IAudioStateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private String f2367a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private ICommShareAudioStateListener f2368b;

        public h(String str, ICommShareAudioStateListener iCommShareAudioStateListener) {
            this.f2367a = str;
            this.f2368b = iCommShareAudioStateListener;
        }

        public void onAudioDataRttUpdate(long j2) {
            try {
                this.f2368b.onAudioDataRttUpdate(j2);
            } catch (Exception e2) {
                f.C("onAudioDataRttUpdate error:" + e2);
            }
        }

        public void onAudioStateChanged(Bundle bundle) {
            try {
                this.f2368b.onAudioStateStateChanged(bundle);
            } catch (Exception e2) {
                f.C("onAudioStateStateChanged error:" + e2);
            }
        }
    }

    private f(Context context, Looper looper) {
        super(context, looper);
        this.f2344m = new HashMap();
        this.f2345n = 0;
        this.f2346o = 0;
        this.f2348q = false;
        this.f2349r = false;
        this.f2350s = false;
        this.f2356y = new HashMap();
        this.f2357z = new Object();
        this.A = new ConcurrentHashMap();
        this.B = new ConcurrentHashMap();
        this.C = new ConcurrentHashMap();
        this.D = new ConcurrentHashMap();
        this.E = new z.b();
        this.F = "";
        this.G = "";
        this.H = new ConcurrentHashMap();
        this.I = new ConcurrentHashMap();
        this.J = new ConcurrentHashMap();
        this.K = new a();
        this.L = new b();
        this.M = new c();
        this.N = new d();
        this.O = new e();
        this.P = new C0029f();
        B("CoWorkManager init");
        this.f2347p = context;
        c1();
        h1();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void B(String str) {
        VmdriLog.d("CoWorkManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void C(String str) {
        VmdriLog.e("CoWorkManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void D(String str) {
        VmdriLog.w("CoWorkManager", str);
    }

    private int H0(String str, boolean z2) {
        B("buildBrConnTargetFromSdk, remoteDevId:" + str);
        int iIntValue = ((Integer) this.f2344m.getOrDefault(str, 0)).intValue();
        if (!z2) {
            this.f2344m.remove(str);
            removeEqualMessages(509, str);
            iIntValue = 0;
        }
        z.b bVar = (z.b) this.H.get(str);
        if (bVar != null && (bVar.c() & 4) == 4) {
            return 0;
        }
        int iConnectDevice = this.f2351t.connectDevice(7, str, 4);
        B("buildBrConnTargetFromSdk, remoteDevId:" + str + ", isRetry:" + z2 + ", retryCount:" + iIntValue + ", errorCode:" + iConnectDevice);
        if (iIntValue <= 1) {
            sendMessageDelayed(obtainMessage(509, str), 12000L);
            this.f2344m.put(str, Integer.valueOf(iIntValue));
        }
        return iConnectDevice;
    }

    private void I0(boolean z2) {
        B("connSdkServiceInternal, retry:" + z2 + ", tryCount:" + this.f2345n);
        if (!v()) {
            D("connSdkServiceInternal, CommShare Not Supported!");
            return;
        }
        if (this.f2350s) {
            C("connSdkServiceInternal: CoWork already connected!");
            return;
        }
        if (hasMessages(501)) {
            C("connSdkServiceInternal: CoWork has EVENT_COWORK_RETRY_CONN msg!");
            return;
        }
        if (z2) {
            CoWorkKit.getInstance().disConnectService();
        }
        CoWorkKit.getInstance().connectService(this.f2347p, this.K);
        if (this.f2349r) {
            this.f2345n++;
            sendEmptyMessageDelayed(501, 5000L);
        }
    }

    public static u0 J0(Context context, Looper looper) {
        f fVar;
        synchronized (Q) {
            try {
                if (u0.f318l != null) {
                    throw new RuntimeException("CoWorkManager already created!");
                }
                fVar = new f(context, looper);
                u0.f318l = fVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return fVar;
    }

    private String K0(int i2, int i3, int i4, int i5) {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("serviceId", "vdfs_tel_share");
            jSONObject2.put("usingState", i3);
            JSONObject jSONObject3 = new JSONObject();
            jSONObject3.put("serviceId", "vdfs_mms_share");
            jSONObject3.put("usingState", i4);
            JSONObject jSONObject4 = new JSONObject();
            jSONObject4.put("serviceId", "vdfs_net_share");
            jSONObject4.put("usingState", i5);
            JSONArray jSONArray = new JSONArray();
            jSONArray.put(jSONObject2);
            jSONArray.put(jSONObject3);
            jSONArray.put(jSONObject4);
            JSONObject jSONObject5 = new JSONObject();
            jSONObject5.put("serviceId", "vdfs_comm_share");
            jSONObject5.put("state", i2);
            jSONObject5.put("serviceCaps", jSONArray);
            jSONObject.put("usingState", jSONObject5);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return jSONObject.toString();
    }

    private String L0(String str) {
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager == null) {
            return null;
        }
        String connbaseConnectInfo = deviceManager.getConnbaseConnectInfo(str);
        B("getConnbaseConnectInfo: " + connbaseConnectInfo);
        return connbaseConnectInfo;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String M0() {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("serviceId", "vdfs_tel_share");
            jSONObject2.put("usingState", 2);
            JSONObject jSONObject3 = new JSONObject();
            jSONObject3.put("serviceId", "vdfs_mms_share");
            jSONObject3.put("usingState", 2);
            JSONObject jSONObject4 = new JSONObject();
            jSONObject4.put("serviceId", "vdfs_net_share");
            jSONObject4.put("usingState", 2);
            JSONArray jSONArray = new JSONArray();
            jSONArray.put(jSONObject2);
            jSONArray.put(jSONObject3);
            jSONArray.put(jSONObject4);
            JSONObject jSONObject5 = new JSONObject();
            jSONObject5.put("serviceId", "vdfs_comm_share");
            jSONObject5.put("state", 2);
            jSONObject5.put("serviceCaps", jSONArray);
            jSONObject.put("usingState", jSONObject5);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return jSONObject.toString();
    }

    private z.b N0() {
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager == null) {
            return null;
        }
        DeviceInfo localDevice = deviceManager.getLocalDevice();
        z.b bVar = new z.b(localDevice);
        B("getLocalCoWkDevInfo: " + z.h.i(localDevice) + ", coWorkDev:" + bVar);
        return bVar;
    }

    private DeviceInfo O0(String str) {
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager == null) {
            return null;
        }
        DeviceInfo connbaseDevice = deviceManager.getConnbaseDevice(7, str, (Bundle) null);
        B("getRemoteDeviceInfo,  remoteDevId:" + str + " deviceInfo:" + z.h.i(connbaseDevice));
        return connbaseDevice;
    }

    private int P0(String str, int i2) {
        if (i2 <= 0) {
            C("keepCoWkConnType, coWkConnType is illegal, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager == null) {
            C("keepCoWkConnType, mDeviceManager is null, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        int channelUsingState = deviceManager.setChannelUsingState(7, str, i2, 1, new Bundle());
        R0("keepCoWkConnType, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2) + ", errorCode:" + channelUsingState);
        return channelUsingState;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void Q0(w.i iVar, int i2, int i3) {
        I(iVar, i3, i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void R0(String str) {
        VmdriLog.i("CoWorkManager", str);
    }

    private void S0() {
        String localP2pIp;
        DeviceManager deviceManager = this.f2351t;
        String str = "";
        if (deviceManager != null) {
            localP2pIp = deviceManager.getLocalP2pIp();
            if (localP2pIp == null) {
                localP2pIp = "";
            }
            String ifNameByAddr = VmdriUtils.getIfNameByAddr(localP2pIp);
            if (ifNameByAddr != null) {
                str = ifNameByAddr;
            }
        } else {
            localP2pIp = "";
        }
        if (!str.isEmpty() || localP2pIp.isEmpty()) {
            removeMessages(512);
        }
        if (!localP2pIp.isEmpty() && str.isEmpty()) {
            B("ip is valid but ifName is empty, retry get ifname, mRetryCount: " + this.f2346o);
            if (this.f2346o < 2) {
                if (hasMessages(512)) {
                    return;
                }
                sendEmptyMessageDelayed(512, 1000L);
                this.f2346o++;
                return;
            }
        }
        B("notifyLocalP2pInfoIfNeed curLocalP2pIp: " + VmdriUtils.convertIpAddress(localP2pIp) + ", curLocalP2pIfName: " + str + ", mLocalP2pIp: " + VmdriUtils.convertIpAddress(this.F) + ", mLocalP2pIfName: " + this.G);
        if (Objects.equals(this.F, localP2pIp) && Objects.equals(this.G, str)) {
            return;
        }
        this.F = localP2pIp;
        this.G = str;
        F(localP2pIp, str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void T0(String str, byte[] bArr) {
        if (((Integer) this.J.getOrDefault(str, -1)).intValue() == 3) {
            C("recv data from:" + str + ", dataPacket:" + e0.a.m(bArr) + ", but mRemoteProcessState Indicates that the peer process is dead");
        }
    }

    private void U0() {
        if (this.f2350s) {
            D("onCoWorkConnected, cowork is already connected");
        }
        this.f2345n = 0;
        removeMessages(501);
        this.f2350s = true;
        this.f2351t = CoWorkKit.getInstance().getKitService("DeviceManager");
        this.f2352u = CoWorkKit.getInstance().getKitService("DistributedInstantData");
        this.f2353v = CoWorkKit.getInstance().getKitService("VdfsServiceManager");
        this.f2354w = CoWorkKit.getInstance().getKitService("VdfsAudioManager");
        VdfsSelfKillManager kitService = CoWorkKit.getInstance().getKitService("VdfsKillManager");
        this.f2355x = kitService;
        if (this.f2351t != null && this.f2352u != null && this.f2353v != null && this.f2354w != null && kitService != null) {
            J(2);
            sendEmptyMessage(504);
            return;
        }
        C("onCoWorkConnected error, DeviceManager:" + this.f2351t + ", InsDataManager:" + this.f2352u + ", mServiceManager:" + this.f2353v + ", mAudioManager:" + this.f2354w + ", mSelfKillManager:" + this.f2355x);
    }

    private void V0() {
        if (!this.f2350s) {
            C("onCoWorkDisconnected repeat!");
            return;
        }
        this.f2350s = false;
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager != null) {
            deviceManager.stopDiscovery(7, this.L);
            this.f2351t = null;
        }
        this.f2353v = null;
        this.f2354w = null;
        this.f2355x = null;
        this.f2352u = null;
        this.H.clear();
        this.f2356y.clear();
        CoWorkKit.getInstance().disConnectService();
        J(1);
        h1();
    }

    private void W0() {
        B("onCoWorkStartListen start listen CoWork bs:7");
        DistributedInsDataManager distributedInsDataManager = this.f2352u;
        if (distributedInsDataManager != null) {
            B("onCoWorkStartListen registerInstantDataListener error code :" + distributedInsDataManager.registerInstantDataListener(7, this.P));
        }
        if (this.f2351t != null) {
            this.E = N0();
            B("local device :" + this.E);
            this.f2351t.startDiscovery(7, VmdriContext.isPhone() ? 256 : 32, 6, this.L);
            this.f2351t.registerProcessStateListener(7, new String[]{"com.vivo.vmdri"}, this.N);
        }
        VdfsServiceManager vdfsServiceManager = this.f2353v;
        if (vdfsServiceManager != null) {
            vdfsServiceManager.registerServiceDispatchCallback(7, this.M);
        }
        VdfsSelfKillManager vdfsSelfKillManager = this.f2355x;
        if (vdfsSelfKillManager != null) {
            vdfsSelfKillManager.registerVdfsKillListener(this.O);
        }
    }

    private void X0(w.c cVar) {
        B("onConnectFailureInternal: " + cVar);
        E(cVar);
    }

    private void Y0(z.b bVar, int i2, int i3, Bundle bundle) {
        boolean zH;
        B("onRemoteDevConnectChange device:" + bVar + " coWorkConnType:" + z.h.b(i2) + " connectStatus:" + z.h.a(i3));
        if ((i2 & 1) == 1) {
            S0();
        }
        final int iD = z.a.d(i2);
        if (iD == 0) {
            C("onRemoteDevConnectChange unknown conn type");
            return;
        }
        z.b bVar2 = (z.b) this.H.get(bVar.b());
        if (i3 == 101) {
            if ((i2 & 4) == 4) {
                removeEqualMessages(509, bVar.b());
                this.f2344m.remove(bVar.b());
            }
            if (bVar2 == null || bVar2.c() == 0) {
                boolean zA = bVar.a(i2);
                this.H.put(bVar.b(), bVar);
                bVar2 = bVar;
                zH = zA;
            } else {
                zH = bVar2.a(i2);
            }
        } else if (bVar2 != null) {
            zH = bVar2.h(i2);
            if (bVar2.c() == 0) {
                this.H.remove(bVar2.b());
            }
        } else {
            zH = false;
        }
        if (zH) {
            final int iE = z.a.e(i3);
            final w.i iVarB = z.a.b(bVar2);
            IntStream.rangeClosed(1, 3).filter(new IntPredicate() { // from class: z.d
                @Override // java.util.function.IntPredicate
                public final boolean test(int i4) {
                    return f.n0(iD, i4);
                }
            }).forEach(new IntConsumer() { // from class: z.e
                @Override // java.util.function.IntConsumer
                public final void accept(int i4) {
                    this.f2341a.Q0(iVarB, iE, i4);
                }
            });
        }
    }

    private void Z0(z.b bVar, int i2, int i3) {
        B("onRemoteDevDiscoveryChange device:" + bVar + ", discoveryType: " + z.h.g(i2) + ", discoveryStatus:" + z.h.d(i3));
        String strB = bVar.b();
        if (i3 == 1) {
            if (((z.b) this.I.put(strB, bVar)) == null) {
                B("find a new device");
            }
        } else if (((z.b) this.I.remove(strB)) != null) {
            B("lost a device");
        }
    }

    private void a1(z.b bVar, int i2, String str) {
        B("onRemoteDevPrevConnectChange, device:" + bVar + ", connectStatus:" + z.h.a(i2) + ", connections:" + str);
        Y0(bVar, 256, i2, null);
    }

    private void b1(String str, int i2) {
        int iIntValue = ((Integer) this.J.getOrDefault(str, -1)).intValue();
        B("onRemoteDevProcessStateChange remoteBleDevId:" + str + "  old: " + z.h.e(iIntValue) + ", cur: " + z.h.e(i2));
        if (iIntValue == i2) {
            return;
        }
        this.J.put(str, Integer.valueOf(i2));
        G(str, z.a.g(i2));
    }

    private void c1() {
        g gVar = new g(this);
        this.f2347p.getContentResolver().registerContentObserver(Settings.Global.getUriFor("vdfs_ready"), false, gVar);
    }

    private int d1(String str, int i2) {
        if (i2 <= 0) {
            C("releaseCoWkConnType, coWkConnType is illegal, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager == null) {
            C("releaseCoWkConnType, mDeviceManager is null, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        int channelUsingState = deviceManager.setChannelUsingState(7, str, i2, 2, new Bundle());
        R0("releaseCoWkConnType, , remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2) + ", errorCode:" + channelUsingState);
        return channelUsingState;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e1(String str, String str2) {
        VdfsServiceManager vdfsServiceManager = this.f2353v;
        if (vdfsServiceManager == null) {
            C("reportCommShareStateStr serviceManager is null!");
            return;
        }
        String conCenterDeviceId = vdfsServiceManager.getConCenterDeviceId(str);
        B("reportCommShareStateStr bleRemoteDevId:" + str + ", conCenterDeviceId:" + conCenterDeviceId + ", reportStr:" + str2);
        this.f2353v.reportBusinessInfo(conCenterDeviceId, str2, new IResultCallback() { // from class: z.c
            public final void onResult(int i2, String str3) {
                f.o0(i2, str3);
            }
        });
    }

    private int f1(String str, boolean z2, int i2, boolean z3) {
        if (i2 <= 0) {
            C("setUpCoWkConnType, coWkConnType is illegal, remoteDevId:" + str + ", isUserTarget:" + z2 + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        if (this.f2351t == null) {
            C("setUpCoWkConnType, mDeviceManager is null, remoteDevId:" + str + ", isUserTarget:" + z2 + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean("isUserTarget", z2);
        bundle.putBoolean("preempt_conn", z3);
        int iConnectDevice = this.f2351t.connectDevice(7, str, i2, bundle);
        R0("setUpCoWkConnType, remoteDevId:" + str + ", isUserTarget:" + z2 + ", needPreempt:" + z3 + ", coWkConnType:" + z.h.c(i2) + ", errorCode:" + iConnectDevice);
        return iConnectDevice;
    }

    private int g1(String str, int i2) {
        if (i2 <= 0) {
            C("tearDownCoWkConnType, coWkConnType is illegal, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        DeviceManager deviceManager = this.f2351t;
        if (deviceManager == null) {
            C("tearDownCoWkConnType, mDeviceManager is null, remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2));
            return 1;
        }
        int iDisconnectDevice = deviceManager.disconnectDevice(7, str, i2);
        R0("tearDownCoWkConnType, , remoteDevId:" + str + ", coWkConnType:" + z.h.c(i2) + ", errorCode:" + iDisconnectDevice);
        return iDisconnectDevice;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void h1() {
        boolean z2 = Settings.Global.getInt(this.f2347p.getContentResolver(), "vdfs_ready", 0) == 1;
        if (this.f2349r != z2) {
            B("updateVdfsReadyFlagAndConnSdkIfNeed, vdfs ready flag changed:" + this.f2349r + " -> " + z2);
            this.f2349r = z2;
        }
        B("updateVdfsReadyFlagAndConnSdkIfNeed, start:" + this.f2348q + ", vdfsReadyFlag:" + this.f2349r + ", coWorkConnected:" + this.f2350s);
        if (this.f2348q && this.f2349r && !this.f2350s) {
            I0(false);
        }
    }

    public static /* synthetic */ boolean n0(int i2, int i3) {
        return (i2 & w.p.g(i3)) == w.p.g(i3);
    }

    @Override // c0.u0
    protected void S(String str, int i2) {
        if (this.f2351t == null) {
            C("releaseConnTypeInner, device manager is null!");
            return;
        }
        int iC = z.a.c(i2);
        B("releaseConnTypeInner:" + str + ", vmdriConnType:" + w.p.j(i2) + ", coworkConnType:" + z.h.c(iC));
        d1(str, iC);
    }

    @Override // c0.u0
    protected void U(String str, int i2, int i3, int i4, int i5) {
        synchronized (this.f2357z) {
            this.A.put(str, Integer.valueOf(i2));
            this.B.put(str, Integer.valueOf(i3));
            this.C.put(str, Integer.valueOf(i4));
            this.D.put(str, Integer.valueOf(i5));
        }
        if (this.f2353v == null) {
            C("reportCommunicationStateInner serviceManager is null!");
        } else if (i2 == 3) {
            B("reportCommunicationStateInner, auto connecting ignore report.");
        } else {
            e1(str, K0(i2, i3, i4, i5));
        }
    }

    @Override // c0.u0
    protected int X(String str, byte[] bArr, int i2) {
        if (this.f2352u == null) {
            C("sendData InsDataManager null!");
            return 1;
        }
        z.b bVar = (z.b) this.H.get(str);
        if (bVar == null) {
            C("sendData deviceInfo null!");
            return 3;
        }
        int iC = z.a.c(i2);
        if ((bVar.c() & iC) != iC) {
            C("sendData cowork conn type (" + iC + ")" + z.h.c(iC) + " not conn! coWkDevInfo:" + bVar);
            return 1;
        }
        if (VmdriLog.isDetailDebugLevel()) {
            B("sendData(" + z.h.c(iC) + "), remoteDevId:" + str + ", data len:" + bArr.length);
        }
        Bundle bundle = new Bundle();
        bundle.putByteArray("data", bArr);
        bundle.putBoolean("decrypt", true);
        int iSend = 7;
        try {
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            iSend = this.f2352u.send(7, str, iC, bundle);
            long jElapsedRealtime2 = SystemClock.elapsedRealtime() - jElapsedRealtime;
            if (jElapsedRealtime2 > 200) {
                C("sendData, spending too much time in the sendData interface:" + jElapsedRealtime2 + "ms");
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            C("sendData exception error:" + e2);
        }
        if (iSend == 0) {
            return 0;
        }
        C("sendData, cowork error:" + iSend);
        return iSend;
    }

    @Override // c0.u0
    protected void Z(int i2, Bundle bundle) {
        if (this.f2354w != null) {
            B("setEventParamForAudioInner, event:" + i2 + ", bundle:" + bundle);
            this.f2354w.setEventParam(7, i2, bundle);
        }
    }

    @Override // c0.u0
    protected int a0(String str, boolean z2, int i2, boolean z3) {
        z.b bVar;
        if (this.f2351t == null) {
            C("setupConnTypeInner, device manager is null!");
            return 1;
        }
        int iC = z.a.c(i2);
        B("setupConnTypeInner:" + str + ", isUserTarget:" + z2 + ", vmdriConnType:" + w.p.j(i2) + ", coworkConnType:" + z.h.c(iC));
        int iF1 = f1(str, z2, iC, z3);
        if (iC == 1 && w.e.b(iF1) && (bVar = (z.b) this.H.get(str)) != null) {
            w.c cVar = new w.c(z.a.b(bVar), iF1);
            B("setupConnTypeInner: connectFailureInfo:" + cVar);
            E(cVar);
        }
        return iF1;
    }

    @Override // c0.u0
    protected int e0(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) {
        h hVar;
        if (this.f2354w == null) {
            return 204;
        }
        B("startAudioServerInner, remoteDevId:" + str + ", audioStateListener:" + iCommShareAudioStateListener);
        if (iCommShareAudioStateListener != null) {
            hVar = new h(str, iCommShareAudioStateListener);
            this.f2356y.put(str, hVar);
        } else {
            hVar = null;
        }
        return this.f2354w.startAudioServer(7, new AudioBusinessInfo(7, str, 3, false, 5, true), bundle, hVar);
    }

    @Override // c0.u0
    protected void f0() {
        this.f2348q = true;
        h1();
    }

    @Override // c0.u0
    protected void h0(String str) {
        if (this.f2354w != null) {
            B("stopAudioServerInner remoteDevId:" + str);
            this.f2354w.stopAudioServer(7);
        }
    }

    @Override // c0.u0, android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        switch (message.what) {
            case 501:
                I0(true);
                break;
            case 502:
                U0();
                break;
            case 503:
                V0();
                break;
            case 504:
                W0();
                break;
            case 505:
                Pair pair = (Pair) message.obj;
                a1((z.b) pair.first, message.arg1, (String) pair.second);
                break;
            case 506:
                Pair pair2 = (Pair) message.obj;
                Y0((z.b) pair2.first, message.arg1, message.arg2, (Bundle) pair2.second);
                break;
            case 507:
                Z0((z.b) message.obj, message.arg1, message.arg2);
                break;
            case 508:
                b1((String) message.obj, message.arg1);
                break;
            case 509:
                H0((String) message.obj, true);
                break;
            case 510:
                R0("EVENT_CONNECT_FAILURE");
                X0((w.c) message.obj);
                break;
            case 511:
                R0("EVENT_TRY_UPDATE_REMOTE_DEV_ACTIVELY");
                Pair pair3 = (Pair) message.obj;
                a1((z.b) pair3.first, message.arg1, (String) pair3.second);
                break;
            case 512:
                S0();
                break;
        }
    }

    @Override // c0.u0
    protected void j0(String str, int i2) {
        if (this.f2351t == null) {
            C("tearDownConnTypeInner, device manager is null!");
            return;
        }
        int iC = z.a.c(i2);
        B("tearDownConnTypeInner:" + str + ", vmdriConnType:" + w.p.j(i2) + ", coworkConnType:" + z.h.c(iC));
        g1(str, iC);
        z.b bVar = (z.b) this.H.get(str);
        if (bVar != null) {
            D("tearDownConnTypeInner, Immediately notify the disconnection to avoid cowk not notifying the disconnection!");
            Message messageObtain = Message.obtain();
            messageObtain.what = 506;
            messageObtain.arg1 = iC;
            messageObtain.arg2 = 103;
            messageObtain.obj = new Pair(bVar, null);
            sendMessageDelayed(messageObtain, 0L);
        }
    }

    @Override // c0.u0
    protected void l0(String str) {
        B("tryGetRemoteDevInfoFromSdkInner remoteDevId = " + str);
        DeviceInfo deviceInfoO0 = O0(str);
        if (deviceInfoO0 != null) {
            z.b bVar = new z.b(deviceInfoO0);
            z.a.b(bVar);
            B("tryGetRemoteDevInfoFromSdkInner : remoteCoWkDevInfo = " + bVar + " connectState = " + deviceInfoO0.getConnectStatus());
            if (hasMessages(511)) {
                return;
            }
            String strL0 = L0(str);
            Message messageObtain = Message.obtain();
            messageObtain.what = 511;
            messageObtain.arg1 = deviceInfoO0.getConnectStatus();
            messageObtain.obj = new Pair(bVar, strL0);
            sendMessageDelayed(messageObtain, 0L);
        }
    }

    @Override // c0.u0
    public void q(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        super.q(fileDescriptor, indentingPrintWriter, strArr);
        indentingPrintWriter.println("CoWkManager:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mTryConnCount:" + this.f2345n);
        indentingPrintWriter.println("mStart:" + this.f2348q);
        indentingPrintWriter.println("mVdfsReadyFlag:" + this.f2349r);
        indentingPrintWriter.println("mCoWorkConnected:" + this.f2350s);
        synchronized (this.f2357z) {
            indentingPrintWriter.println("mCommShareState:" + this.A);
            indentingPrintWriter.println("mCallShareState:" + this.B);
            indentingPrintWriter.println("mSmsShareState:" + this.C);
            indentingPrintWriter.println("mDataShareState:" + this.D);
        }
        indentingPrintWriter.println("mLocalDevInfo:" + this.E);
        indentingPrintWriter.println("mLocalP2pIp:" + this.F);
        indentingPrintWriter.println("mLocalP2pIfName:" + this.G);
        indentingPrintWriter.println("mRemoteCoWkDevInfoMap:" + this.H);
        indentingPrintWriter.println("mRemoteProcessState:" + this.J);
        indentingPrintWriter.decreaseIndent();
    }

    @Override // c0.u0
    protected w.i u() {
        return z.a.b(N0());
    }

    @Override // c0.u0
    protected void x(String str, int i2) {
        if (this.f2351t == null) {
            C("keepConnTypeInner, device manager is null!");
            return;
        }
        int iC = z.a.c(i2);
        B("keepConnTypeInner:" + str + ", vmdriConnType:" + w.p.j(i2) + ", coworkConnType:" + z.h.c(iC));
        P0(str, iC);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements IDeviceStatusListener {
        b() {
        }

        public void onConnbaseConnectChanged(DeviceInfo deviceInfo, int i2, String str) {
            if (deviceInfo == null) {
                f.C("onConnbaseConnectChanged, illegal device: deviceInfo is null, connectStatus:" + z.h.a(i2) + ", connections:" + str);
                return;
            }
            if (deviceInfo.getBleDeviceId() == null || deviceInfo.getBleDeviceId().length() <= 0) {
                f.C("onConnbaseConnectChanged, illegal device: ble id is empty, device:" + z.h.i(deviceInfo) + ", connectStatus:" + z.h.a(i2) + ", connections:" + str);
                return;
            }
            f.B("onConnbaseConnectChanged, device:" + z.h.i(deviceInfo) + ", connectStatus:" + z.h.a(i2) + ", connections:" + str);
            z.b bVar = new z.b(deviceInfo);
            Message messageObtain = Message.obtain();
            messageObtain.what = 505;
            messageObtain.arg1 = i2;
            messageObtain.obj = new Pair(bVar, str);
            f.this.sendMessageDelayed(messageObtain, 0L);
        }

        public void onConnectFailure(DeviceInfo deviceInfo, int i2) {
            if (deviceInfo.getBleDeviceId() == null || deviceInfo.getBleDeviceId().isEmpty()) {
                return;
            }
            w.c cVar = new w.c(z.a.a(deviceInfo), i2);
            f.B("onConnectFailure, errorCode:" + w.e.a(i2));
            cVar.d("");
            Message messageObtain = Message.obtain();
            messageObtain.what = 510;
            messageObtain.obj = cVar;
            f.this.sendMessageDelayed(messageObtain, 0L);
        }

        public void onConnectFailureV2(DeviceInfo deviceInfo, int i2, Bundle bundle) {
            if (deviceInfo.getBleDeviceId() == null || deviceInfo.getBleDeviceId().isEmpty()) {
                return;
            }
            w.c cVar = new w.c(z.a.a(deviceInfo), i2);
            String string = bundle.getString("conflict_app_name", "");
            f.B("onConnectFailureV2, conflictAppName:" + string + ", errorCode:" + w.e.a(i2));
            cVar.d(string);
            Message messageObtain = Message.obtain();
            messageObtain.what = 510;
            messageObtain.obj = cVar;
            f.this.sendMessageDelayed(messageObtain, 0L);
        }

        public void onConnectStatusChange(DeviceInfo deviceInfo, int i2, int i3, Bundle bundle) {
            if (deviceInfo == null) {
                f.C("onConnectStatusChange illegal device: deviceInfo is null, connectType: " + z.h.b(i2) + ", connectStatus:" + z.h.a(i3));
                return;
            }
            if (deviceInfo.getBleDeviceId() == null || deviceInfo.getBleDeviceId().length() <= 0) {
                f.C("onConnectStatusChange illegal device: ble id is empty, connectType: " + z.h.b(i2) + ", connectStatus:" + z.h.a(i3) + ", devInfo:" + z.h.i(deviceInfo));
                return;
            }
            if (VmdriContext.isPhone() && deviceInfo.getDeviceType() != 256) {
                f.C("onConnectStatusChange illegal device: local device is phone must discovery pad, connectType: " + z.h.b(i2) + ", connectStatus:" + z.h.a(i3) + ", devInfo:" + z.h.i(deviceInfo));
                return;
            }
            if (VmdriContext.isPad() && deviceInfo.getDeviceType() != 32) {
                f.C("onConnectStatusChange illegal device: local device is pad must discovery phone, connectType: " + z.h.b(i2) + ", connectStatus:" + z.h.a(i3) + ", devInfo:" + z.h.i(deviceInfo));
                return;
            }
            int iA = z.g.a(i2);
            if (iA <= 0) {
                f.C("onConnectStatusChange illegal conn type, connectType: " + z.h.b(i2) + ", connectStatus:" + z.h.a(i3) + ", devInfo:" + z.h.i(deviceInfo));
                return;
            }
            f.B("onConnectStatusChange device:" + z.h.i(deviceInfo) + " connectType: " + z.h.b(i2) + " connectStatus:" + z.h.a(i3));
            z.b bVar = new z.b(deviceInfo);
            Message messageObtain = Message.obtain();
            messageObtain.what = 506;
            messageObtain.arg1 = iA;
            messageObtain.arg2 = i3;
            messageObtain.obj = new Pair(bVar, bundle);
            f.this.sendMessageDelayed(messageObtain, 0L);
        }

        public void onLocalSwitchChange(int i2, int i3) {
        }

        public void onCapabilityChange(DeviceInfo deviceInfo, int i2, int i3) {
        }

        public void onDeviceStatus(DeviceInfo deviceInfo, int i2, int i3) {
        }

        public void onDiscoveryChange(DeviceInfo deviceInfo, int i2, int i3) {
        }

        public void onSwitchChange(DeviceInfo deviceInfo, int i2, int i3) {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements IProcessStateListener {
        d() {
        }

        public void onPeerProcessStateChanged(String str, String str2, int i2) {
            f.B("onPeerProcessStateChanged device:" + str + ", packageName:" + str2 + ", state:" + z.h.e(i2));
            if (Objects.equals(str2, f.this.f2347p.getPackageName()) || Objects.equals(str2, Process.myProcessName())) {
                if (str == null) {
                    f.C("onPeerProcessStateChanged ble id is bull!");
                    return;
                }
                Message messageObtain = Message.obtain();
                messageObtain.what = 508;
                messageObtain.obj = str;
                messageObtain.arg1 = i2;
                f.this.sendMessage(messageObtain);
            }
        }

        public void onLocalProcessStateChanged(String str, int i2) {
        }
    }

    public static /* synthetic */ void o0(int i2, String str) {
    }
}
