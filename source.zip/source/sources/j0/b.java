package j0;

import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f1759a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f1760b;

    public b(long j2, long j3) {
        this.f1759a = j2;
        this.f1760b = j3;
    }

    private static void a(String str) {
        VmdriLog.e("CommShareDataUsage", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            long j2 = this.f1759a;
            if (j2 >= 0) {
                jSONObject.put("conn", j2);
            }
            long j3 = this.f1760b;
            if (j3 >= 0) {
                jSONObject.put("month", j3);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting CommShareDataUsage to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static b d(String str) {
        if (str == null) {
            return new b();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            b bVar = new b();
            a("Error parsing jsonStr to CommShareDataUsage object:" + e2.toString());
            return bVar;
        }
    }

    private static b e(JSONObject jSONObject) {
        try {
            b bVar = new b();
            bVar.f1759a = jSONObject.optLong("conn", -1L);
            bVar.f1760b = jSONObject.optLong("month", -1L);
            return bVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to CommShareDataUsage object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "CommShareDataUsage({dataUsageOfThisConn=" + this.f1759a + "dataUsageOfThisMonth" + this.f1760b + '}';
    }

    public b() {
        this.f1759a = -1L;
        this.f1760b = -1L;
    }
}
