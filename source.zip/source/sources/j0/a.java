package j0;

import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1758a;

    public a(int i2) {
        this.f1758a = i2;
    }

    private static void a(String str) {
        VmdriLog.e("BusinessStateIndicationMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            int i2 = this.f1758a;
            if (i2 >= 0) {
                jSONObject.put("bSta", i2);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting BusinessStateIndicationMsg to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            a("Error parsing jsonStr to BusinessStateIndicationMsg object:" + e2.toString());
            return aVar;
        }
    }

    private static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1758a = jSONObject.optInt("bSta", 0);
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to BusinessStateIndicationMsg object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "BusinessStateIndicationMsg({businessState=" + this.f1758a + '}';
    }

    public a() {
        this.f1758a = 0;
    }
}
