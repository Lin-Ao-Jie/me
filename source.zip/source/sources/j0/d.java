package j0;

import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1764a;

    public d(int i2) {
        this.f1764a = i2;
    }

    private static void a(String str) {
        VmdriLog.e("RilStateIndicationMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            int i2 = this.f1764a;
            if (i2 >= 0) {
                jSONObject.put("rSta", i2);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting RilStateIndicationMsg to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static d d(String str) {
        if (str == null) {
            return new d();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            d dVar = new d();
            a("Error parsing jsonStr to RilStateIndicationMsg object:" + e2.toString());
            return dVar;
        }
    }

    private static d e(JSONObject jSONObject) {
        try {
            d dVar = new d();
            dVar.f1764a = jSONObject.optInt("rSta", 0);
            return dVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to RilStateIndicationMsg object" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "RilStateIndicationMsg{rilState=" + this.f1764a + '}';
    }

    private d() {
        this.f1764a = 0;
    }
}
