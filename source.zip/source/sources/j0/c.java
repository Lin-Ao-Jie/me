package j0;

import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1761a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f1762b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public HashMap f1763c;

    public c(int i2, boolean z2, HashMap map) {
        this.f1761a = VmdriContext.getMaxSupportedDevNum();
        this.f1762b = false;
        this.f1763c = new HashMap();
        this.f1761a = i2;
        this.f1762b = z2;
        if (map != null) {
            this.f1763c = map;
        }
    }

    private static void a(String str) {
        VmdriLog.e("CommShareStateIndicationMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("maxSup", this.f1761a);
            jSONObject.put("cSta", this.f1762b ? 1 : 0);
            if (this.f1763c.size() > 0) {
                JSONArray jSONArray = new JSONArray();
                for (String str : this.f1763c.keySet()) {
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject2.put("id", str);
                    jSONObject2.put("name", this.f1763c.get(str));
                    jSONArray.put(jSONObject2);
                }
                jSONObject.put("pDevs", jSONArray);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting CommShareStateIndicationMsg to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static c d(String str) {
        if (str == null) {
            return new c();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            c cVar = new c();
            a("Error parsing jsonStr to CommShareStateIndicationMsg object:" + e2.toString());
            return cVar;
        }
    }

    private static c e(JSONObject jSONObject) {
        try {
            c cVar = new c();
            boolean z2 = true;
            cVar.f1761a = jSONObject.optInt("maxSup", 1);
            if (jSONObject.optInt("cSta", 0) != 1) {
                z2 = false;
            }
            cVar.f1762b = z2;
            if (!jSONObject.isNull("pDevs")) {
                JSONArray jSONArray = jSONObject.getJSONArray("pDevs");
                int length = jSONArray.length();
                for (int i2 = 0; i2 < length; i2++) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                    cVar.f1763c.put(jSONObject2.optString("id", ""), jSONObject2.optString("name", ""));
                }
            }
            return cVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to CommShareStateIndicationMsg object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "CommShareStateIndicationMsg{commShare=" + this.f1762b + ", maxSupportedDevs=" + this.f1761a + ", preferredDevs=" + this.f1763c + '}';
    }

    public c() {
        this.f1761a = VmdriContext.getMaxSupportedDevNum();
        this.f1762b = false;
        this.f1763c = new HashMap();
    }
}
