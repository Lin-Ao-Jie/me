package q0;

import a0.y0;
import a0.z0;
import com.vivo.vcodetransbase.EventTransfer;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.ctrl.RemoteDevConnEvaluation;
import com.vivo.vmdri.ctrl.t;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static f f2104a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String f2105b = String.valueOf(-1);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final String f2106c = String.valueOf(0);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f2107d = String.valueOf(1);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f2108e = String.valueOf(-1);

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f2109a;

        static {
            int[] iArr = new int[RemoteDevConnEvaluation.DisallowedReason.values().length];
            f2109a = iArr;
            try {
                iArr[RemoteDevConnEvaluation.DisallowedReason.LOCAL_MAX_PREFER_DEV_REACHED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_NOT_SIM.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_WIFI_DISABLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_BLUETOOTH_DISABLE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_SCREEN_OFF.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_AUTO_CONN_DISABLE.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.USER_DISLIKE_THIS_DEV.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.LOCAL_SWITCH_ALL_DISABLE.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REMOTE_DEV_NOT_CONN.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REMOTE_MAX_PREFER_DEV_REACHED.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.BR_NOT_CONN.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.DEV_STATE_NOT_SYN_NOW.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REPEAT_EVALUATE_PREFERRED_DEV.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REMOTE_NOT_SIM.ordinal()] = 15;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REMOTE_ON_AIRPLANE_MODE.ordinal()] = 16;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REMOTE_WIFI_DISABLE.ordinal()] = 17;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.REMOTE_BLUETOOTH_DISABLE.ordinal()] = 18;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.CURRENT_IN_TARGETING.ordinal()] = 19;
            } catch (NoSuchFieldError unused19) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.COMBINE_SWITCH_DISABLE.ordinal()] = 20;
            } catch (NoSuchFieldError unused20) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.RIL_SERVICE_NOT_BOUND.ordinal()] = 21;
            } catch (NoSuchFieldError unused21) {
            }
            try {
                f2109a[RemoteDevConnEvaluation.DisallowedReason.CAPABILITY_SERVICE_NOT_BOUND.ordinal()] = 22;
            } catch (NoSuchFieldError unused22) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A(String str, int i2, w.d dVar, w.d dVar2, z0 z0Var, long j2) {
        try {
            q(str, i2, dVar, dVar2, z0Var, j2);
        } catch (Exception e2) {
            C("addDisconnectedEvent, e:" + e2.getMessage());
        }
    }

    private static void B(String str) {
        VmdriLog.d("VCodeManager", str);
    }

    private static void C(String str) {
        VmdriLog.e("VCodeManager", str);
    }

    public static /* synthetic */ void a(String str, String str2) {
        try {
            HashMap map = new HashMap();
            map.put("type", str);
            map.put("click", str2);
            j("F382|10026", map);
        } catch (Exception e2) {
            C("addRecommendOpenAutoNotifyEvent, ex:" + e2 + ", event:" + str + ", clickType:" + str2);
        }
    }

    public static /* synthetic */ void b(String str, String str2) {
        try {
            HashMap map = new HashMap();
            map.put("type", str);
            map.put("click", str2);
            j("F382|10027", map);
        } catch (Exception e2) {
            C("addCommSharingNotifyEvent, e:" + e2.getMessage());
        }
    }

    private static void j(String str, HashMap map) {
        try {
            B("addCommShareEvent, eventId:" + str + ", data:" + map);
            EventTransfer.getInstance().singleEvent("F382", str, System.currentTimeMillis(), 0L, map);
        } catch (Exception e2) {
            C("addCommShareEvent error, exception:" + e2.getMessage());
        } catch (NoClassDefFoundError e3) {
            C("addCommShareEvent NoClassDefFoundError e = " + e3.getMessage());
        }
    }

    private void l(String str, boolean z2, int i2, w.d dVar, w.d dVar2, t tVar, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        List listF;
        int iT = dVar != null ? dVar.t() : -1;
        int iT2 = dVar2 != null ? dVar2.t() : -1;
        String str2 = z2 ? f2107d : f2106c;
        ArrayList arrayList = new ArrayList();
        if (remoteDevConnEvaluation != null && (listF = remoteDevConnEvaluation.f()) != null) {
            Iterator it = listF.iterator();
            while (it.hasNext()) {
                int iV = v((RemoteDevConnEvaluation.DisallowedReason) it.next());
                if (iV != 0 && !x(iV)) {
                    arrayList.add(Integer.valueOf(iV));
                }
            }
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("ver", "1.0");
        } catch (Exception e2) {
            C("addCommShareFailedEventInternal, error converting to JSONObject:" + e2);
        }
        String string = jSONObject.toString();
        HashMap map = new HashMap();
        map.put("isUserTarget", str2);
        map.put("localSwitch", String.valueOf(iT));
        map.put("remoteSwitch", String.valueOf(iT2));
        map.put("failureCause", String.valueOf(i2));
        map.put("errorList", arrayList.toString());
        map.put("details", string);
        j("F382|10030", map);
    }

    private void m(final String str, final String str2) {
        g.b().a(new Runnable() { // from class: q0.b
            @Override // java.lang.Runnable
            public final void run() {
                f.b(str, str2);
            }
        });
    }

    private void o(String str, int i2, w.d dVar, w.d dVar2, y0 y0Var) {
        String str2;
        int iT = dVar != null ? dVar.t() : -1;
        int iT2 = dVar2 != null ? dVar2.t() : -1;
        String str3 = f2105b;
        if (y0Var != null) {
            str3 = y0Var.d() ? f2107d : f2106c;
            str2 = !y0Var.c() ? f2107d : f2106c;
        } else {
            str2 = str3;
        }
        B("addConnectedData, remoteDevId:" + str + ", details:{}, capability:" + i2 + ", localSwitchBitmask:" + iT + ", remoteSwitchBitmask:" + iT2);
        HashMap map = new HashMap();
        map.put("isUserTarget", str3);
        map.put("isLocalTarget", str2);
        map.put("capability", String.valueOf(i2));
        map.put("localSwitch", String.valueOf(iT));
        map.put("remoteSwitch", String.valueOf(iT2));
        map.put("details", "{}");
        j("F382|10028", map);
    }

    private void q(String str, int i2, w.d dVar, w.d dVar2, z0 z0Var, long j2) {
        String str2;
        String str3;
        int iT = dVar != null ? dVar.t() : -1;
        int iT2 = dVar2 != null ? dVar2.t() : -1;
        if (j2 < 0) {
            j2 = -1;
        }
        String str4 = f2105b;
        if (z0Var != null) {
            str4 = z0Var.f() ? f2107d : f2106c;
            str2 = !z0Var.e() ? f2107d : f2106c;
            str3 = z0Var.d() ? f2107d : f2106c;
        } else {
            str2 = str4;
            str3 = str2;
        }
        JSONObject jSONObject = new JSONObject();
        if (z0Var != null) {
            try {
                jSONObject.put("reasonExact", z0Var.a());
            } catch (Exception e2) {
                C("addDisconnectedEventInternal, error converting stopCommShareDoneRecord to JSONObject:" + e2);
            }
        }
        String string = jSONObject.toString();
        B("addDisconnectedEventInternal, remoteDevId:" + str + ", details:" + string + ", capability:" + i2 + ", connectedDurationTime:" + j2 + ", localSwitchBitmask:" + iT + ", remoteSwitchBitmask:" + iT2);
        HashMap map = new HashMap();
        map.put("isUserTarget", str4);
        map.put("isLocalTarget", str2);
        map.put("isForce", str3);
        map.put("capability", String.valueOf(i2));
        map.put("localSwitch", String.valueOf(iT));
        map.put("remoteSwitch", String.valueOf(iT2));
        map.put("connDuration", String.valueOf(j2));
        map.put("details", string);
        j("F382|10029", map);
    }

    private void s(final String str, final String str2) {
        g.b().a(new Runnable() { // from class: q0.c
            @Override // java.lang.Runnable
            public final void run() {
                f.a(str, str2);
            }
        });
    }

    public static int v(RemoteDevConnEvaluation.DisallowedReason disallowedReason) {
        switch (a.f2109a[disallowedReason.ordinal()]) {
            case 1:
                return 2;
            case 2:
                return 3;
            case 3:
                return 4;
            case 4:
                return 5;
            case 5:
                return 6;
            case 6:
                return 7;
            case 7:
                return 8;
            case 8:
                return 9;
            case 9:
                return 10;
            case 10:
                return 11;
            case 11:
                return 12;
            case 12:
                return 13;
            case 13:
                return 14;
            case 14:
                return 15;
            case 15:
                return 16;
            case 16:
                return 17;
            case 17:
                return 18;
            case 18:
                return 19;
            case 19:
                return 20;
            case 20:
                return 21;
            case 21:
                return 22;
            case 22:
                return 23;
            default:
                return 1;
        }
    }

    public static synchronized f w() {
        try {
            if (f2104a == null) {
                f2104a = new f();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f2104a;
    }

    public static boolean x(int i2) {
        return i2 == 13 || i2 == 14;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y(String str, boolean z2, int i2, w.d dVar, w.d dVar2, t tVar, RemoteDevConnEvaluation remoteDevConnEvaluation) {
        try {
            l(str, z2, i2, dVar, dVar2, tVar, remoteDevConnEvaluation);
        } catch (Exception e2) {
            C("addCommShareFailedEvent, e:" + e2.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z(String str, int i2, w.d dVar, w.d dVar2, y0 y0Var) {
        try {
            o(str, i2, dVar, dVar2, y0Var);
        } catch (Exception e2) {
            C("addConnectedEvent, e:" + e2.getMessage());
        }
    }

    public void f() {
        m("2", "0");
    }

    public void g() {
        s("2", "2");
    }

    public void h() {
        s("2", "0");
    }

    public void i() {
        m("2", "1");
    }

    public void k(final String str, final boolean z2, final int i2, final w.d dVar, final w.d dVar2, final t tVar, final RemoteDevConnEvaluation remoteDevConnEvaluation) {
        if (z2 || i2 != 2) {
            g.b().a(new Runnable() { // from class: q0.a
                @Override // java.lang.Runnable
                public final void run() {
                    this.f2079a.y(str, z2, i2, dVar, dVar2, tVar, remoteDevConnEvaluation);
                }
            });
        }
    }

    public void n(final String str, final int i2, final w.d dVar, final w.d dVar2, final y0 y0Var) {
        g.b().a(new Runnable() { // from class: q0.d
            @Override // java.lang.Runnable
            public final void run() {
                this.f2091a.z(str, i2, dVar, dVar2, y0Var);
            }
        });
    }

    public void p(final String str, final int i2, final w.d dVar, final w.d dVar2, final z0 z0Var, final long j2) {
        g.b().a(new Runnable() { // from class: q0.e
            @Override // java.lang.Runnable
            public final void run() {
                this.f2097a.A(str, i2, dVar, dVar2, z0Var, j2);
            }
        });
    }

    public void r() {
        s("2", "1");
    }

    public void t() {
        m("1", "-1");
    }

    public void u() {
        s("1", "-1");
    }
}
