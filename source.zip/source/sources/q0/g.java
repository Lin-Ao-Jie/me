package q0;

import com.vivo.vmdri.VmdriLog;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ExecutorService f2110a;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static final g f2111a = new g();
    }

    public static g b() {
        return a.f2111a;
    }

    private static void c(String str) {
        VmdriLog.e("VivoThreadPoolUtil", str);
    }

    public void a(Runnable runnable) {
        if (runnable == null) {
            c("execute, runnable obj is null!");
            return;
        }
        try {
            this.f2110a.execute(runnable);
        } catch (Exception e2) {
            c("execute error:" + e2);
        }
    }

    private g() {
        this.f2110a = new ThreadPoolExecutor(2, 12, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue(128), new ThreadPoolExecutor.DiscardOldestPolicy());
    }
}
