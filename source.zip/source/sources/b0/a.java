package b0;

import com.vivo.vmdri.VmdriGlobals;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Objects;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {
    public a() {
        b("DebugService created.");
    }

    private static void b(String str) {
        VmdriLog.d("DebugService", str);
    }

    private static void c(String str) {
        VmdriLog.i("DebugService", str);
    }

    private void d(String[] strArr) {
        if (strArr != null && Objects.equals(strArr[0], "--debug_level") && strArr.length == 2) {
            String str = strArr[1];
            b("setDebugLevel, cmd:" + str);
            str.hashCode();
            switch (str) {
                case "detail":
                    VmdriLog.setDebugLevel(4);
                    break;
                case "normal":
                    VmdriLog.setDebugLevel(3);
                    break;
                case "full":
                    VmdriLog.setDebugLevel(5);
                    break;
                case "basic":
                    VmdriLog.setDebugLevel(2);
                    break;
                case "light":
                    VmdriLog.setDebugLevel(1);
                    break;
                case "default":
                    VmdriLog.setDebugLevel(0);
                    break;
                default:
                    VmdriLog.setDebugLevel(0);
                    break;
            }
        }
    }

    private void e(String[] strArr) {
        if (strArr != null && Objects.equals(strArr[0], "--start_commshare") && strArr.length == 2) {
            String str = strArr[1];
            b("targetCommShare, remoteDevId:" + str);
            VmdriGlobals.getInstance().getTopController().c().f(str, null);
        }
    }

    private void f(String[] strArr) {
        if (strArr != null && Objects.equals(strArr[0], "--stop_commshare") && strArr.length == 2) {
            String str = strArr[1];
            b("targetStopCommShare, remoteDevId:" + str);
            VmdriGlobals.getInstance().getTopController().c().a(str, null);
        }
    }

    public void a(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        if (strArr == null || strArr.length <= 0) {
            b("Dump vmdri.");
            VmdriGlobals.getInstance().dump(fileDescriptor, printWriter, strArr);
            return;
        }
        String str = strArr[0];
        str.hashCode();
        switch (str) {
            case "--stop_commshare":
                f(strArr);
                break;
            case "--debug_level":
                c("set debug log level..");
                d(strArr);
                break;
            case "--start_commshare":
                e(strArr);
                break;
        }
    }
}
