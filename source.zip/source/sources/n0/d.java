package n0;

import a0.g0;
import a0.w;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import c0.l;
import c0.r;
import c0.u0;
import com.vivo.commshare.CommDevInfo;
import com.vivo.commshare.ICommShareAudioStateListener;
import com.vivo.commshare.IDataChannel;
import com.vivo.commshare.IDataListener;
import com.vivo.commshare.IDeviceListener;
import com.vivo.commshare.IVmdriComm;
import com.vivo.commshare.framework.base.Constants;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.ctrl.s;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class d extends IVmdriComm.Stub {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final f f1896a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f1897b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final s f1898c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final c f1899d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final g0 f1900e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final l.b f1901f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1903h;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private w.d f1902g = new w.d(true);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final ConcurrentHashMap f1904i = new ConcurrentHashMap();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final ConcurrentHashMap f1905j = new ConcurrentHashMap();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final ConcurrentHashMap f1906k = new ConcurrentHashMap();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final ConcurrentHashMap f1907l = new ConcurrentHashMap();

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private final ConcurrentHashMap f1908m = new ConcurrentHashMap();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private final ConcurrentHashMap f1909n = new ConcurrentHashMap();

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private final ConcurrentHashMap f1910o = new ConcurrentHashMap();

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends l.b {
        a(Executor executor) {
            super(executor);
        }

        @Override // c0.l.b
        public void a(String str, String str2) {
            super.a(str, str2);
            if (d.this.f1908m.containsKey(str)) {
                d.this.z(str, f0.a.d(str2));
            } else {
                d.C("Received a packet from a wrong device id, remoteDevId:" + str);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class b implements IBinder.DeathRecipient {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f1912a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private IBinder f1913b;

        b(int i2, IBinder iBinder) {
            this.f1912a = i2;
            this.f1913b = iBinder;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            d.this.y(this.f1912a);
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            d.D("binderDied : " + Constants.getBusinessTypeName(this.f1912a));
            d();
            d.this.f1896a.post(new Runnable() { // from class: n0.e
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1919a.b();
                }
            });
        }

        public void c() throws RemoteException {
            this.f1913b.linkToDeath(this, 0);
        }

        public synchronized void d() {
            IBinder iBinder = this.f1913b;
            if (iBinder != null) {
                iBinder.unlinkToDeath(this, 0);
                this.f1913b = null;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class c extends w {
        public c(Executor executor) {
            super(executor);
        }

        @Override // a0.w
        public void c(w.d dVar) {
            super.c(dVar);
            d.B("onLocalDeviceStateChanged, oldLocalDevice:" + d.this.f1902g + ", newLocalDevice:" + dVar);
            w.d dVar2 = d.this.f1902g;
            d.this.f1902g = dVar;
            if (d.this.f1908m.size() <= 0) {
                return;
            }
            if (Objects.equals(dVar2.h(), dVar.h()) && Objects.equals(dVar2.m(), dVar.m()) && Objects.equals(dVar2.o(), dVar.o())) {
                return;
            }
            d.this.E(dVar);
        }

        @Override // a0.w
        public void d(w.d dVar, boolean z2) {
            super.d(dVar, z2);
            d.B("onRemoteDeviceConnected: " + dVar + ", isUserTarget:" + z2);
            if (!d.this.f1908m.containsKey(dVar.i())) {
                d.this.f1908m.put(dVar.i(), dVar);
                d.this.f1910o.put(dVar.i(), r.u().p(dVar.i(), 5, d.this.f1901f));
                d.this.K();
                d.this.G(dVar);
                return;
            }
            d.C("serious error! connect to the same device repeatedly, old:" + d.this.f1908m.get(dVar.i()) + ", new:" + dVar);
        }

        @Override // a0.w
        public void e(w.d dVar, boolean z2) {
            super.e(dVar, z2);
            d.B("onRemoteDeviceDisConnected: " + dVar + ", isUserTarget:" + z2);
            if (((w.d) d.this.f1908m.remove(dVar.i())) == null) {
                d.C("serious error! disconnect a does not exist device, remoteDevice:" + dVar);
                return;
            }
            d.this.H(dVar);
            d.this.M(dVar.i(), 0);
            r.u().r((l) d.this.f1910o.remove(dVar.i()), true);
        }

        @Override // a0.w
        public void f(w.d dVar) {
            super.f(dVar);
            w.d dVar2 = (w.d) d.this.f1908m.get(dVar.i());
            d.B("onRemoteDeviceStateChanged, oldDevice:" + dVar2 + ", newDevice:" + dVar);
            if (dVar2 == null) {
                return;
            }
            d.this.f1908m.put(dVar.i(), dVar);
            if (Objects.equals(dVar2.h(), dVar.h()) && dVar2.f() == dVar.f() && Objects.equals(dVar2.m(), dVar.m()) && Objects.equals(dVar2.o(), dVar.o())) {
                return;
            }
            d.this.I(dVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: n0.d$d, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class BinderC0017d extends IDataChannel.Stub {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f1916a;

        public BinderC0017d(int i2) {
            this.f1916a = i2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            d.this.w(this.f1916a);
        }

        @Override // com.vivo.commshare.IDataChannel
        public int ready() {
            d.B("ready, businessType:(" + this.f1916a + "):" + Constants.getBusinessTypeName(this.f1916a));
            d.this.f1896a.post(new Runnable() { // from class: n0.f
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1920a.b();
                }
            });
            return 0;
        }

        @Override // com.vivo.commshare.IDataChannel
        public int sendData(String str, byte[] bArr) {
            StringBuilder sb = new StringBuilder();
            sb.append("sendData, remoteDevId:");
            sb.append(str);
            sb.append(", businessType:");
            sb.append(Constants.getBusinessTypeName(this.f1916a));
            sb.append(", dataLen:");
            sb.append(bArr != null ? Integer.valueOf(bArr.length) : null);
            d.B(sb.toString());
            return d.this.J(this.f1916a, str, bArr);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class e extends g0 {
        public e(Executor executor) {
            super(executor);
        }

        @Override // a0.g0
        public void b(String str, int i2) {
            super.c(str, i2);
            d.B("onBusinessStateIndication, remoteDevId:" + str + ", newBusinessStateBitmask:" + Constants.convertBusinessTypeBitmaskToString(i2));
            d.this.L(str, i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class f extends Handler {
        public f(d dVar, Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            d.C("unsupported message type:" + message.what);
        }
    }

    public d(Context context, Looper looper, s sVar) {
        this.f1897b = context;
        this.f1898c = sVar;
        final f fVar = new f(this, looper);
        this.f1896a = fVar;
        c cVar = new c(new Executor() { // from class: n0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                fVar.post(runnable);
            }
        });
        this.f1899d = cVar;
        g0 eVar = new e(new Executor() { // from class: n0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                fVar.post(runnable);
            }
        });
        this.f1900e = eVar;
        sVar.g(cVar);
        sVar.b(eVar);
        this.f1901f = new a(new Executor() { // from class: n0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                fVar.post(runnable);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A(String str, int i2, int i3) {
        F(str, i3, (i2 & Constants.getBitMaskForBusinessType(i3)) != 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void B(String str) {
        VmdriLog.d("CommServer", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void C(String str) {
        VmdriLog.e("CommServer", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void D(String str) {
        VmdriLog.i("CommServer", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void E(w.d dVar) {
        B("notifyLocalDeviceStateChanged, localDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        for (Integer num : this.f1904i.keySet()) {
            try {
                ((IDeviceListener) this.f1904i.get(num)).onLocalDeviceStateChanged(commDevInfoA);
            } catch (RemoteException | RuntimeException e2) {
                C("notifyLocalDeviceStateChanged error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    private void F(String str, int i2, boolean z2) {
        B("notifyRemoteBusinessState, remoteDevId:" + str + ", businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2) + ", ready:" + z2);
        IDeviceListener iDeviceListener = (IDeviceListener) this.f1904i.get(Integer.valueOf(i2));
        if (iDeviceListener == null) {
            return;
        }
        try {
            iDeviceListener.onRemoteReady(str, z2);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G(w.d dVar) {
        B("notifyRemoteDeviceConnected, remoteDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        CommDevInfo commDevInfoA2 = this.f1902g.a();
        for (Integer num : this.f1904i.keySet()) {
            IDeviceListener iDeviceListener = (IDeviceListener) this.f1904i.get(num);
            try {
                iDeviceListener.onRemoteDeviceConnected(commDevInfoA);
                iDeviceListener.onLocalDeviceStateChanged(commDevInfoA2);
            } catch (RemoteException | RuntimeException e2) {
                C("notifyRemoteDeviceConnected error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H(w.d dVar) {
        B("notifyRemoteDeviceDisConnected, remoteDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        for (Integer num : this.f1904i.keySet()) {
            try {
                ((IDeviceListener) this.f1904i.get(num)).onRemoteDeviceDisconnected(commDevInfoA);
            } catch (RemoteException | RuntimeException e2) {
                C("notifyRemoteDeviceDisConnected error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I(w.d dVar) {
        B("notifyRemoteDeviceStateChanged, remoteDevice:" + dVar);
        CommDevInfo commDevInfoA = dVar.a();
        for (Integer num : this.f1904i.keySet()) {
            try {
                ((IDeviceListener) this.f1904i.get(num)).onRemoteDeviceStateChanged(commDevInfoA);
            } catch (RemoteException | RuntimeException e2) {
                C("notifyRemoteDeviceStateChanged error:" + e2 + ", businessType:" + Constants.getBusinessTypeName(num.intValue()));
                e2.printStackTrace();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int J(int i2, String str, byte[] bArr) {
        int bitMaskForBusinessType = Constants.getBitMaskForBusinessType(i2);
        if ((this.f1903h & bitMaskForBusinessType) == 0) {
            C("sendDataInternal error, local dev not ready, remoteDevId:" + str + ", businessType:" + i2 + ", businessTypeBitMask:" + bitMaskForBusinessType + ", LocalBusinessTypeBitMask:" + this.f1903h + ", remoteDevId:" + str);
            return 4;
        }
        w.d dVar = (w.d) this.f1908m.get(str);
        if (dVar == null) {
            C("sendDataInternal error, remote dev not conn, remoteDevId:" + str);
            return 3;
        }
        int iIntValue = ((Integer) this.f1909n.getOrDefault(str, 0)).intValue();
        if ((bitMaskForBusinessType & iIntValue) != 0) {
            f0.a aVar = new f0.a();
            aVar.f1622a = i2;
            aVar.f1623b = bArr;
            l lVar = (l) this.f1910o.get(str);
            if (lVar != null) {
                return lVar.Z(aVar.c());
            }
            C("sendDataInternal error, comm data channel not conn, remoteDevId:" + str);
            return 3;
        }
        C("sendDataInternal error, remote dev not ready, remoteDevId:" + str + ", businessType:" + i2 + ", businessTypeBitMask:" + bitMaskForBusinessType + ", RemoteBusinessTypeBitMask:" + iIntValue + ", remoteDevice:" + dVar);
        return 5;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K() {
        Iterator it = this.f1908m.values().iterator();
        while (it.hasNext()) {
            this.f1898c.V0(((w.d) it.next()).i(), this.f1903h);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean L(final String str, final int i2) {
        if (((w.d) this.f1908m.get(str)) == null) {
            C("setRemoteBusinessTypeBitmaskAndNotify a does not exist device Id, remoteDevId:" + str + ", curRemoteBusinessTypeBitMask:" + Constants.convertBusinessTypeBitmaskToString(i2));
            return false;
        }
        final int iIntValue = ((Integer) this.f1909n.getOrDefault(str, 0)).intValue();
        if (iIntValue == i2) {
            return false;
        }
        this.f1909n.put(str, Integer.valueOf(i2));
        B("setRemoteBusinessTypeBitmaskAndNotify remoteDevId:" + str + ", old:" + Constants.convertBusinessTypeBitmaskToString(iIntValue) + ", cur:" + Constants.convertBusinessTypeBitmaskToString(i2));
        IntStream.rangeClosed(1, 7).filter(new IntPredicate() { // from class: n0.b
            @Override // java.util.function.IntPredicate
            public final boolean test(int i3) {
                return d.b(i2, iIntValue, i3);
            }
        }).forEach(new IntConsumer() { // from class: n0.c
            @Override // java.util.function.IntConsumer
            public final void accept(int i3) {
                this.f1893a.A(str, i2, i3);
            }
        });
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean M(String str, int i2) {
        int iIntValue = ((Integer) this.f1909n.getOrDefault(str, 0)).intValue();
        if (iIntValue == i2) {
            return false;
        }
        this.f1909n.put(str, Integer.valueOf(i2));
        B("setRemoteBusinessTypeBitmaskOnly remoteDevId:" + str + ", old:" + Constants.convertBusinessTypeBitmaskToString(iIntValue) + ", cur:" + Constants.convertBusinessTypeBitmaskToString(i2));
        return true;
    }

    public static /* synthetic */ boolean b(int i2, int i3, int i4) {
        return (i2 & Constants.getBitMaskForBusinessType(i4)) != (i3 & Constants.getBitMaskForBusinessType(i4));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean w(int i2) {
        return x(Constants.getBitMaskForBusinessType(i2));
    }

    private boolean x(int i2) {
        boolean z2;
        int i3 = this.f1903h;
        if ((i3 & i2) != i2) {
            this.f1903h = i2 | i3;
            z2 = true;
        } else {
            z2 = false;
        }
        K();
        return z2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void y(int i2) {
        B("clearLocalCache, businessType:" + Constants.getBusinessTypeName(i2));
        this.f1903h = this.f1903h & (~Constants.getBitMaskForBusinessType(i2));
        this.f1905j.remove(Integer.valueOf(i2));
        this.f1904i.remove(Integer.valueOf(i2));
        this.f1907l.remove(Integer.valueOf(i2));
        this.f1906k.remove(Integer.valueOf(i2));
        K();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void z(String str, f0.a aVar) {
        B("onRecvMessage:" + aVar);
        IDataListener iDataListener = (IDataListener) this.f1906k.get(Integer.valueOf(aVar.f1622a));
        if (iDataListener != null) {
            try {
                iDataListener.onDataRecv(str, aVar.f1623b);
                return;
            } catch (RemoteException e2) {
                e2.printStackTrace();
                return;
            }
        }
        C("handleCommMessage, not dataListener for remoteDevId:" + str + ", commMessage:" + aVar);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public void bringUpRemoteProcess(String str, String str2) {
        this.f1898c.e0(str, str2);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public CommDevInfo getLocalDeviceState() {
        return this.f1902g.a();
    }

    @Override // com.vivo.commshare.IVmdriComm
    public List getRemoteDeviceState() {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.f1908m.values().iterator();
        while (it.hasNext()) {
            arrayList.add(((w.d) it.next()).a());
        }
        return arrayList;
    }

    @Override // com.vivo.commshare.IVmdriComm
    public IDataChannel initDataChannel(int i2, IDeviceListener iDeviceListener, IDataListener iDataListener) throws RemoteException {
        B("initDataChannel, businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2) + ", deviceListener:" + iDeviceListener + ", dataListener:" + iDataListener);
        this.f1904i.put(Integer.valueOf(i2), iDeviceListener);
        for (w.d dVar : this.f1908m.values()) {
            String strI = dVar.i();
            Integer num = (Integer) this.f1909n.getOrDefault(strI, 0);
            B("initDataChannel, notify dev conn, device:" + dVar + ", businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2));
            iDeviceListener.onRemoteDeviceConnected(dVar.a());
            if ((num.intValue() & Constants.getBitMaskForBusinessType(i2)) == Constants.getBitMaskForBusinessType(i2)) {
                B("initDataChannel, notify dev ready, device:" + dVar + ", businessType(" + i2 + "):" + Constants.getBusinessTypeName(i2));
                iDeviceListener.onRemoteReady(strI, true);
            }
        }
        b bVar = new b(i2, iDeviceListener.asBinder());
        bVar.c();
        this.f1907l.put(Integer.valueOf(i2), bVar);
        this.f1906k.put(Integer.valueOf(i2), iDataListener);
        BinderC0017d binderC0017d = new BinderC0017d(i2);
        this.f1905j.put(Integer.valueOf(i2), binderC0017d);
        return binderC0017d;
    }

    @Override // com.vivo.commshare.IVmdriComm
    public void setAudioEventParam(int i2, Bundle bundle) {
        u0.r().Y(i2, bundle);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public int startAudioServer(String str, Bundle bundle, ICommShareAudioStateListener iCommShareAudioStateListener) {
        return u0.r().d0(str, bundle, iCommShareAudioStateListener);
    }

    @Override // com.vivo.commshare.IVmdriComm
    public void stopAudioServer(String str) {
        u0.r().g0(str);
    }
}
