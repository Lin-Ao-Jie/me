package g0;

import a0.h0;
import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1710a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1711b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1712c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1713d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f1714e;

    public a(int i2, int i3, int i4, String str) {
        this.f1710a = i2;
        this.f1712c = i3;
        this.f1711b = i4;
        this.f1714e = str;
    }

    private static void a(String str) {
        VmdriLog.e("CtrlMessage", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            int i2 = this.f1710a;
            if (i2 >= 0) {
                jSONObject.put("mId", i2);
            }
            int i3 = this.f1712c;
            if (i3 >= 0) {
                jSONObject.put("sn", i3);
            }
            int i4 = this.f1711b;
            if (i4 >= 0) {
                jSONObject.put("tp", i4);
            }
            int i5 = this.f1713d;
            if (i5 >= 0) {
                jSONObject.put("err", i5);
            }
            if (!TextUtils.isEmpty(this.f1714e)) {
                jSONObject.put("dt", this.f1714e);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting CtrlMessage to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            a("Error parsing jsonStr to CtrlMessage object:" + e2.toString());
            return aVar;
        }
    }

    private static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1710a = jSONObject.optInt("mId", -1);
            aVar.f1712c = jSONObject.optInt("sn", -1);
            aVar.f1711b = jSONObject.optInt("tp", -1);
            aVar.f1713d = jSONObject.optInt("err", 0);
            aVar.f1714e = jSONObject.optString("dt", "");
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to CtrlMessage object" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CtrlMessage{messageId=");
        sb.append(this.f1710a);
        sb.append(", type=");
        sb.append(h0.a(this.f1711b));
        sb.append(", serial=");
        sb.append(this.f1712c);
        sb.append(", error=");
        sb.append(this.f1713d);
        sb.append(", dataLen=");
        String str = this.f1714e;
        sb.append(str == null ? "null" : Integer.valueOf(str.length()));
        sb.append('}');
        return sb.toString();
    }

    public a(int i2, int i3, String str) {
        this.f1710a = i2;
        this.f1711b = i3;
        this.f1714e = str;
    }

    private a() {
    }
}
