package n;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class c extends b {
    private d A;
    private float B;
    private boolean C;

    public c(v.b bVar) {
        super(bVar);
        this.A = null;
        this.B = Float.MAX_VALUE;
        this.C = false;
    }

    private void q() {
        d dVar = this.A;
        if (dVar == null) {
            throw new UnsupportedOperationException("Incomplete SpringAnimation: Either final position or a spring force needs to be set.");
        }
        double dA = dVar.a();
        if (dA > this.f1870g) {
            throw new UnsupportedOperationException("Final position of the spring cannot be greater than the max value.");
        }
        if (dA < this.f1871h) {
            throw new UnsupportedOperationException("Final position of the spring cannot be less than the min value.");
        }
    }

    @Override // n.b
    public void m() {
        q();
        this.A.g(f());
        super.m();
    }

    @Override // n.b
    boolean o(long j2) {
        if (this.C) {
            float f2 = this.B;
            if (f2 != Float.MAX_VALUE) {
                this.A.e(f2);
                this.B = Float.MAX_VALUE;
            }
            this.f1865b = this.A.a();
            this.f1864a = 0.0f;
            this.C = false;
            return true;
        }
        if (this.B != Float.MAX_VALUE) {
            this.A.a();
            long j3 = j2 / 2;
            b.p pVarH = this.A.h(this.f1865b, this.f1864a, j3);
            this.A.e(this.B);
            this.B = Float.MAX_VALUE;
            b.p pVarH2 = this.A.h(pVarH.f1878a, pVarH.f1879b, j3);
            this.f1865b = pVarH2.f1878a;
            this.f1864a = pVarH2.f1879b;
        } else {
            b.p pVarH3 = this.A.h(this.f1865b, this.f1864a, j2);
            this.f1865b = pVarH3.f1878a;
            this.f1864a = pVarH3.f1879b;
        }
        float fMax = Math.max(this.f1865b, this.f1871h);
        this.f1865b = fMax;
        float fMin = Math.min(fMax, this.f1870g);
        this.f1865b = fMin;
        if (!p(fMin, this.f1864a)) {
            return false;
        }
        this.f1865b = this.A.a();
        this.f1864a = 0.0f;
        return true;
    }

    boolean p(float f2, float f3) {
        return this.A.c(f2, f3);
    }

    public c r(d dVar) {
        this.A = dVar;
        return this;
    }
}
