package n;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private double f1883d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private double f1884e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private double f1885f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private double f1886g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private double f1887h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private double f1888i;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    double f1880a = Math.sqrt(1500.0d);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    double f1881b = 0.5d;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f1882c = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final b.p f1889j = new b.p();

    public d(float f2) {
        this.f1888i = Double.MAX_VALUE;
        this.f1888i = f2;
    }

    private void b() {
        if (this.f1882c) {
            return;
        }
        if (this.f1888i == Double.MAX_VALUE) {
            throw new IllegalStateException("Error: Final position of the spring must be set before the animation starts");
        }
        double d2 = this.f1881b;
        if (d2 > 1.0d) {
            double d3 = this.f1880a;
            this.f1885f = ((-d2) * d3) + (d3 * Math.sqrt((d2 * d2) - 1.0d));
            double d4 = this.f1881b;
            double d5 = this.f1880a;
            this.f1886g = ((-d4) * d5) - (d5 * Math.sqrt((d4 * d4) - 1.0d));
        } else if (d2 >= 0.0d && d2 < 1.0d) {
            this.f1887h = this.f1880a * Math.sqrt(1.0d - (d2 * d2));
        }
        this.f1882c = true;
    }

    public float a() {
        return (float) this.f1888i;
    }

    public boolean c(float f2, float f3) {
        return ((double) Math.abs(f3)) < this.f1884e && ((double) Math.abs(f2 - a())) < this.f1883d;
    }

    public d d(float f2) {
        if (f2 < 0.0f) {
            throw new IllegalArgumentException("Damping ratio must be non-negative");
        }
        this.f1881b = f2;
        this.f1882c = false;
        return this;
    }

    public d e(float f2) {
        this.f1888i = f2;
        return this;
    }

    public d f(float f2) {
        if (f2 <= 0.0f) {
            throw new IllegalArgumentException("Spring stiffness constant must be positive.");
        }
        this.f1880a = Math.sqrt(f2);
        this.f1882c = false;
        return this;
    }

    public void g(double d2) {
        double dAbs = Math.abs(d2);
        this.f1883d = dAbs;
        this.f1884e = dAbs * 62.5d;
    }

    public b.p h(double d2, double d3, long j2) {
        double dPow;
        double dCos;
        b();
        double d4 = j2 / 1000.0d;
        double d5 = d2 - this.f1888i;
        double d6 = this.f1881b;
        if (d6 > 1.0d) {
            double d7 = this.f1886g;
            double d8 = this.f1885f;
            double d9 = d5 - (((d7 * d5) - d3) / (d7 - d8));
            double d10 = ((d5 * d7) - d3) / (d7 - d8);
            dPow = (Math.pow(2.718281828459045d, d7 * d4) * d9) + (Math.pow(2.718281828459045d, this.f1885f * d4) * d10);
            double d11 = this.f1886g;
            double dPow2 = d9 * d11 * Math.pow(2.718281828459045d, d11 * d4);
            double d12 = this.f1885f;
            dCos = dPow2 + (d10 * d12 * Math.pow(2.718281828459045d, d12 * d4));
        } else if (d6 == 1.0d) {
            double d13 = this.f1880a;
            double d14 = d3 + (d13 * d5);
            double d15 = d5 + (d14 * d4);
            dPow = Math.pow(2.718281828459045d, (-d13) * d4) * d15;
            double dPow3 = d15 * Math.pow(2.718281828459045d, (-this.f1880a) * d4);
            double d16 = this.f1880a;
            dCos = (d14 * Math.pow(2.718281828459045d, (-d16) * d4)) + (dPow3 * (-d16));
        } else {
            double d17 = 1.0d / this.f1887h;
            double d18 = this.f1880a;
            double d19 = d17 * ((d6 * d18 * d5) + d3);
            dPow = Math.pow(2.718281828459045d, (-d6) * d18 * d4) * ((Math.cos(this.f1887h * d4) * d5) + (Math.sin(this.f1887h * d4) * d19));
            double d20 = this.f1880a;
            double d21 = this.f1881b;
            double dPow4 = Math.pow(2.718281828459045d, (-d21) * d20 * d4);
            double d22 = this.f1887h;
            double dSin = (-d22) * d5 * Math.sin(d22 * d4);
            double d23 = this.f1887h;
            dCos = ((-d20) * dPow * d21) + (dPow4 * (dSin + (d19 * d23 * Math.cos(d23 * d4))));
        }
        b.p pVar = this.f1889j;
        pVar.f1878a = (float) (dPow + this.f1888i);
        pVar.f1879b = (float) dCos;
        return pVar;
    }
}
