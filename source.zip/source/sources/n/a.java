package n;

import android.os.SystemClock;
import android.view.Choreographer;
import androidx.collection.SimpleArrayMap;
import java.util.ArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
class a {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final ThreadLocal f1838g = new ThreadLocal();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private c f1842d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final SimpleArrayMap f1839a = new SimpleArrayMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final ArrayList f1840b = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final C0014a f1841c = new C0014a();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    long f1843e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f1844f = false;

    /* JADX INFO: renamed from: n.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0014a {
        C0014a() {
        }

        void a() {
            a.this.f1843e = SystemClock.uptimeMillis();
            a aVar = a.this;
            aVar.c(aVar.f1843e);
            if (a.this.f1840b.size() > 0) {
                a.this.e().a();
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    interface b {
        boolean a(long j2);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static abstract class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final C0014a f1846a;

        c(C0014a c0014a) {
            this.f1846a = c0014a;
        }

        abstract void a();
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static class d extends c {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Choreographer f1847b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final Choreographer.FrameCallback f1848c;

        /* JADX INFO: renamed from: n.a$d$a, reason: collision with other inner class name */
        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class ChoreographerFrameCallbackC0015a implements Choreographer.FrameCallback {
            ChoreographerFrameCallbackC0015a() {
            }

            @Override // android.view.Choreographer.FrameCallback
            public void doFrame(long j2) {
                d.this.f1846a.a();
            }
        }

        d(C0014a c0014a) {
            super(c0014a);
            this.f1847b = Choreographer.getInstance();
            this.f1848c = new ChoreographerFrameCallbackC0015a();
        }

        @Override // n.a.c
        void a() {
            this.f1847b.postFrameCallback(this.f1848c);
        }
    }

    a() {
    }

    private void b() {
        if (this.f1844f) {
            for (int size = this.f1840b.size() - 1; size >= 0; size--) {
                if (this.f1840b.get(size) == null) {
                    this.f1840b.remove(size);
                }
            }
            this.f1844f = false;
        }
    }

    public static a d() {
        ThreadLocal threadLocal = f1838g;
        if (threadLocal.get() == null) {
            threadLocal.set(new a());
        }
        return (a) threadLocal.get();
    }

    private boolean f(b bVar, long j2) {
        Long l2 = (Long) this.f1839a.get(bVar);
        if (l2 == null) {
            return true;
        }
        if (l2.longValue() >= j2) {
            return false;
        }
        this.f1839a.remove(bVar);
        return true;
    }

    public void a(b bVar, long j2) {
        if (this.f1840b.size() == 0) {
            e().a();
        }
        if (!this.f1840b.contains(bVar)) {
            this.f1840b.add(bVar);
        }
        if (j2 > 0) {
            this.f1839a.put(bVar, Long.valueOf(SystemClock.uptimeMillis() + j2));
        }
    }

    void c(long j2) {
        long jUptimeMillis = SystemClock.uptimeMillis();
        for (int i2 = 0; i2 < this.f1840b.size(); i2++) {
            b bVar = (b) this.f1840b.get(i2);
            if (bVar != null && f(bVar, jUptimeMillis)) {
                bVar.a(j2);
            }
        }
        b();
    }

    c e() {
        if (this.f1842d == null) {
            this.f1842d = new d(this.f1841c);
        }
        return this.f1842d;
    }

    public void g(b bVar) {
        this.f1839a.remove(bVar);
        int iIndexOf = this.f1840b.indexOf(bVar);
        if (iIndexOf >= 0) {
            this.f1840b.set(iIndexOf, null);
            this.f1844f = true;
        }
    }
}
