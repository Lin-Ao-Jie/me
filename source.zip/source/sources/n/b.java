package n;

import android.os.Looper;
import android.util.AndroidRuntimeException;
import android.view.View;
import androidx.core.view.ViewCompat;
import java.util.ArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b implements n.a.b {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final s f1850m = new g("translationX");

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final s f1851n = new h("translationY");

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final s f1852o = new i("translationZ");

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final s f1853p = new j("scaleX");

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final s f1854q = new k("scaleY");

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final s f1855r = new l("rotation");

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final s f1856s = new m("rotationX");

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final s f1857t = new n("rotationY");

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final s f1858u = new o("x");

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final s f1859v = new a("y");

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final s f1860w = new C0016b("z");

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final s f1861x = new c("alpha");

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final s f1862y = new d("scrollX");

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final s f1863z = new e("scrollY");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    final v.a f1868e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    float f1864a = 0.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    float f1865b = Float.MAX_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    boolean f1866c = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f1869f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    float f1870g = Float.MAX_VALUE;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    float f1871h = -Float.MAX_VALUE;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private long f1872i = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final ArrayList f1874k = new ArrayList();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final ArrayList f1875l = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    final Object f1867d = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1873j = 1.0f;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends s {
        a(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getY();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setY(f2);
        }
    }

    /* JADX INFO: renamed from: n.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0016b extends s {
        C0016b(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return ViewCompat.getZ(view);
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            ViewCompat.setZ(view, f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends s {
        c(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getAlpha();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setAlpha(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends s {
        d(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getScrollX();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setScrollX((int) f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends s {
        e(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getScrollY();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setScrollY((int) f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f extends v.a {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ v.b f1876b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        f(String str, v.b bVar) {
            super(str);
            this.f1876b = bVar;
        }

        @Override // v.a
        public float a(Object obj) {
            return this.f1876b.a();
        }

        @Override // v.a
        public void b(Object obj, float f2) {
            this.f1876b.b(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g extends s {
        g(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getTranslationX();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setTranslationX(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class h extends s {
        h(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getTranslationY();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setTranslationY(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class i extends s {
        i(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return ViewCompat.getTranslationZ(view);
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            ViewCompat.setTranslationZ(view, f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class j extends s {
        j(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getScaleX();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setScaleX(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class k extends s {
        k(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getScaleY();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setScaleY(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class l extends s {
        l(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getRotation();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setRotation(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class m extends s {
        m(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getRotationX();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setRotationX(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class n extends s {
        n(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getRotationY();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setRotationY(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class o extends s {
        o(String str) {
            super(str, null);
        }

        @Override // v.a
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(View view) {
            return view.getX();
        }

        @Override // v.a
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(View view, float f2) {
            view.setX(f2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class p {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f1878a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f1879b;
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface q {
        void a(b bVar, boolean z2, float f2, float f3);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public interface r {
        void a(b bVar, float f2, float f3);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class s extends v.a {
        /* synthetic */ s(String str, g gVar) {
            this(str);
        }

        private s(String str) {
            super(str);
        }
    }

    b(v.b bVar) {
        this.f1868e = new f("FloatValueHolder", bVar);
    }

    private void d(boolean z2) {
        this.f1869f = false;
        n.a.d().g(this);
        this.f1872i = 0L;
        this.f1866c = false;
        for (int i2 = 0; i2 < this.f1874k.size(); i2++) {
            if (this.f1874k.get(i2) != null) {
                ((q) this.f1874k.get(i2)).a(this, z2, this.f1865b, this.f1864a);
            }
        }
        i(this.f1874k);
    }

    private float e() {
        return this.f1868e.a(this.f1867d);
    }

    private static void h(ArrayList arrayList, Object obj) {
        int iIndexOf = arrayList.indexOf(obj);
        if (iIndexOf >= 0) {
            arrayList.set(iIndexOf, null);
        }
    }

    private static void i(ArrayList arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (arrayList.get(size) == null) {
                arrayList.remove(size);
            }
        }
    }

    private void n() {
        if (this.f1869f) {
            return;
        }
        this.f1869f = true;
        if (!this.f1866c) {
            this.f1865b = e();
        }
        float f2 = this.f1865b;
        if (f2 > this.f1870g || f2 < this.f1871h) {
            throw new IllegalArgumentException("Starting value need to be in between min value and max value");
        }
        n.a.d().a(this, 0L);
    }

    @Override // n.a.b
    public boolean a(long j2) {
        long j3 = this.f1872i;
        if (j3 == 0) {
            this.f1872i = j2;
            j(this.f1865b);
            return false;
        }
        this.f1872i = j2;
        boolean zO = o(j2 - j3);
        float fMin = Math.min(this.f1865b, this.f1870g);
        this.f1865b = fMin;
        float fMax = Math.max(fMin, this.f1871h);
        this.f1865b = fMax;
        j(fMax);
        if (zO) {
            d(false);
        }
        return zO;
    }

    public b b(q qVar) {
        if (!this.f1874k.contains(qVar)) {
            this.f1874k.add(qVar);
        }
        return this;
    }

    public b c(r rVar) {
        if (g()) {
            throw new UnsupportedOperationException("Error: Update listeners must be added beforethe animation.");
        }
        if (!this.f1875l.contains(rVar)) {
            this.f1875l.add(rVar);
        }
        return this;
    }

    float f() {
        return this.f1873j * 0.75f;
    }

    public boolean g() {
        return this.f1869f;
    }

    void j(float f2) {
        this.f1868e.b(this.f1867d, f2);
        for (int i2 = 0; i2 < this.f1875l.size(); i2++) {
            if (this.f1875l.get(i2) != null) {
                ((r) this.f1875l.get(i2)).a(this, this.f1865b, this.f1864a);
            }
        }
        i(this.f1875l);
    }

    public b k(float f2) {
        this.f1865b = f2;
        this.f1866c = true;
        return this;
    }

    public b l(float f2) {
        this.f1864a = f2;
        return this;
    }

    public void m() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new AndroidRuntimeException("Animations may only be started on the main thread");
        }
        if (this.f1869f) {
            return;
        }
        n();
    }

    abstract boolean o(long j2);

    public void removeEndListener(q qVar) {
        h(this.f1874k, qVar);
    }

    public void removeUpdateListener(r rVar) {
        h(this.f1875l, rVar);
    }
}
