package o0;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import c0.r;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f1940a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private c0.l f1941b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private C0018b f1942c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f1943d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private String f1944e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    ConcurrentHashMap f1945f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private c0.l.b f1946g;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends c0.l.b {
        a(Executor executor) {
            super(executor);
        }

        @Override // c0.l.b
        public void a(String str, String str2) {
            super.a(str, str2);
            b.this.d(str, m0.a.f(str2));
        }
    }

    /* JADX INFO: renamed from: o0.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class C0018b {
        public abstract void a(String str, m0.a aVar);
    }

    public b(Context context, Looper looper, C0018b c0018b) {
        super(looper);
        this.f1943d = false;
        this.f1944e = null;
        this.f1945f = new ConcurrentHashMap();
        this.f1946g = new a(new Executor() { // from class: o0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1939a.post(runnable);
            }
        });
        e("RilChannel init");
        this.f1940a = context;
        this.f1942c = c0018b;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d(String str, m0.a aVar) {
        if (VmdriLog.isFullDebugLevel()) {
            e("handleRilMessage rilMsg:" + aVar + ", from:" + str);
        }
        int i2 = aVar.f1835e;
        if (i2 == 1) {
            w.h hVar = new w.h(aVar.f1834d, aVar.f1831a, aVar.f1832b, aVar.f1833c);
            this.f1945f.put(hVar, hVar);
            this.f1942c.a(str, aVar);
            return;
        }
        if (i2 == 2) {
            f("handleRilMessage, server can't handle RIL response, drop! " + aVar);
            return;
        }
        if (i2 != 3) {
            f("handleRilMessage recv a not support ril msg, drop! " + aVar);
            return;
        }
        f("handleRilMessage, server can't handle RIL indication, drop! " + aVar);
    }

    private static void e(String str) {
        VmdriLog.d("RilServerChannel", str);
    }

    private static void f(String str) {
        VmdriLog.e("RilServerChannel", str);
    }

    public void b(w.d dVar) {
        this.f1943d = true;
        this.f1941b = r.u().p(dVar.i(), 4, this.f1946g);
        this.f1944e = dVar.i();
    }

    public void c() {
        this.f1943d = false;
        r.u().r(this.f1941b, true);
        this.f1945f.clear();
        this.f1941b = null;
    }

    public int g(m0.a aVar) {
        String strConvertCommShareDataCallList;
        if (this.f1941b == null) {
            f("sendIndRilMsg channel not connect error!");
            return 9;
        }
        if (aVar.f1835e != 3) {
            f("sendIndRilMsg, is not a response ril msg:" + aVar);
            return 8;
        }
        if (VmdriLog.isFullDebugLevel()) {
            e("sendIndRilMsg to " + this.f1941b + ", rilIndMsg:" + aVar);
        }
        if (aVar.f1831a == 2 && aVar.f1833c == 500 && (strConvertCommShareDataCallList = VmdriUtils.convertCommShareDataCallList(this.f1944e, aVar.a())) != null) {
            VmdriLog.localLog(VmdriLog.REASON_DUMP_DATA_CALL_LIST, strConvertCommShareDataCallList);
        }
        return this.f1941b.Z(aVar.e());
    }

    public int h(m0.a aVar) {
        if (this.f1941b == null) {
            f("sendRespRilMsg channel not connect error!" + aVar);
            return 9;
        }
        if (aVar.f1835e != 2) {
            f("sendRespRilMsg, is not a response ril msg:" + aVar);
            return 8;
        }
        w.h hVar = (w.h) this.f1945f.remove(new w.h(aVar.f1834d, aVar.f1831a, aVar.f1832b, aVar.f1833c));
        if (hVar == null) {
            f("sendRespRilMsg not req key error!" + aVar);
            return 10;
        }
        aVar.f1833c = hVar.a();
        if (VmdriLog.isFullDebugLevel()) {
            e("sendRespRilMsg to " + this.f1941b + ", rilRequestKey:" + hVar + ", rilRespMsg:" + aVar);
        }
        return this.f1941b.Z(aVar.e());
    }
}
