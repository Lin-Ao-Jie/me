package o0;

import a0.g0;
import a0.w;
import android.content.ComponentName;
import android.content.Context;
import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.os.SystemProperties;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.DeviceParcel;
import com.vivo.vmdri.IRilServerHandle;
import com.vivo.vmdri.IVmdriServerHandle;
import com.vivo.vmdri.P2pInfoParcel;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.ctrl.s;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class e extends Handler {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final boolean f1950p = SystemProperties.getBoolean("persist.vmdri.debug", false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f1951a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final s f1952b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final g0 f1953c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final b f1954d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final DependentServiceController f1955e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private ComponentName f1956f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final m f1957g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private m.b f1958h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private IRilServerHandle f1959i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final Object f1960j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final ConcurrentHashMap f1961k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final ConcurrentHashMap f1962l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private final ConcurrentHashMap f1963m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f1964n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private w.d f1965o;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends DependentServiceController.DependentServiceCallback {
        a(Executor executor) {
            super(executor);
        }

        @Override // com.vivo.vmdri.DependentServiceController.DependentServiceCallback
        public void tryStartBindDependentService() {
            if (e.this.f1957g.r()) {
                return;
            }
            e.E("tryStartBindDependentService connVirMdService");
            e.this.B();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class b extends w {
        public b(Executor executor) {
            super(executor);
        }

        @Override // a0.w
        public void c(w.d dVar) {
            super.c(dVar);
            w.d dVar2 = e.this.f1965o;
            e.this.f1965o = dVar;
            e.E("onLocalDeviceStateChanged, oldLocalDevState:" + dVar2 + ", newLocalDevState:" + dVar);
            if (e.this.f1961k.size() <= 0) {
                return;
            }
            String strM = dVar.m();
            String strO = dVar.o();
            String strM2 = dVar2.m();
            String strO2 = dVar2.o();
            if (!Objects.equals(strM, strM2) || !Objects.equals(strO, strO2)) {
                e eVar = e.this;
                eVar.I(eVar.f1965o.m(), e.this.f1965o.o());
            }
            int iT = dVar.t();
            if (iT != dVar2.t()) {
                for (w.d dVar3 : e.this.f1961k.values()) {
                    e.this.N(dVar3.i(), dVar3.t(), iT);
                }
            }
        }

        @Override // a0.w
        public void d(w.d dVar, boolean z2) {
            super.d(dVar, z2);
            e.E("onRemoteDeviceConnected: " + dVar + ", isUserTarget:" + z2);
            synchronized (e.this.f1960j) {
                try {
                    if (e.this.f1961k.containsKey(dVar.i())) {
                        e.F("serious error! connect to the same device repeatedly, old:" + e.this.f1961k.get(dVar.i()) + ", new:" + dVar);
                        return;
                    }
                    e.this.f1961k.put(dVar.i(), dVar);
                    o0.b bVar = new o0.b(e.this.f1951a, e.this.getLooper(), new d());
                    bVar.b(dVar);
                    e.this.f1962l.put(dVar.i(), bVar);
                    e.this.Q(dVar.i());
                    e.this.G(dVar);
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // a0.w
        public void e(w.d dVar, boolean z2) {
            super.e(dVar, z2);
            e.E("onRemoteDeviceDisConnected: " + dVar + ", isUserTarget:" + z2);
            synchronized (e.this.f1960j) {
                try {
                    if (((w.d) e.this.f1961k.remove(dVar.i())) == null) {
                        e.F("serious error! disconnect a does not exist device, remoteDevice:" + dVar);
                        return;
                    }
                    e.this.H(dVar);
                    o0.b bVar = (o0.b) e.this.f1962l.remove(dVar.i());
                    if (bVar != null) {
                        bVar.c();
                    }
                    e.this.U(dVar.i(), 0);
                    e.this.f1963m.remove(dVar.i());
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // a0.w
        public void f(w.d dVar) {
            super.f(dVar);
            String strI = dVar.i();
            synchronized (e.this.f1960j) {
                try {
                    w.d dVar2 = (w.d) e.this.f1961k.get(strI);
                    e.E("onRemoteDeviceStateChanged, oldRemoteDevState:" + dVar2 + ", newRemoteDevState:" + dVar);
                    if (dVar2 == null) {
                        return;
                    }
                    e.this.f1961k.put(strI, dVar);
                    String strM = dVar.m();
                    String strO = dVar.o();
                    String strM2 = dVar2.m();
                    String strO2 = dVar2.o();
                    if (!Objects.equals(strM, strM2) || !Objects.equals(strO, strO2)) {
                        e.this.K(strI, strM, strO);
                    }
                    int iT = dVar.t();
                    if (iT != dVar2.t()) {
                        e.this.N(strI, iT, e.this.f1965o.t());
                    }
                    if (dVar.D() != dVar2.D()) {
                        e.this.L(strI, dVar.D());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class c extends g0 {
        public c(Executor executor) {
            super(executor);
        }

        @Override // a0.g0
        public void c(String str, int i2) {
            super.c(str, i2);
            e.E("onRilStateIndication, remoteDevId:" + str + ", rilState:" + i2);
            e.this.T(str, i2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class d extends o0.b.C0018b {
        @Override // o0.b.C0018b
        public void a(String str, m0.a aVar) {
            e.this.M(str, aVar);
        }

        private d() {
        }
    }

    /* JADX INFO: renamed from: o0.e$e, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class C0019e extends m.b {
        public C0019e(Executor executor) {
            super(executor);
        }

        @Override // o0.m.b
        public void a(IRilServerHandle iRilServerHandle) {
            e.E("onConnected(VirMd) rilServerHandle:" + iRilServerHandle);
            e.this.f1959i = iRilServerHandle;
            try {
                e.this.f1959i.registerVmdriServerHandle(new f());
            } catch (RemoteException | RuntimeException e2) {
                e.F("onConnected ex:" + e2);
            }
            synchronized (e.this.f1960j) {
                try {
                    if (e.this.f1961k.size() > 0) {
                        for (w.d dVar : e.this.f1961k.values()) {
                            e.this.G(dVar);
                            e.this.Q(dVar.i());
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // o0.m.b
        public void b(String str) {
            e.F("onConnectedFailed(VirMd) reason:" + str);
        }

        @Override // o0.m.b
        public void c() {
            e.F("onDisconnect(VirMd)");
            synchronized (e.this.f1960j) {
                e.this.S(0);
                e.this.f1959i = null;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class f extends IVmdriServerHandle.Stub {
        @Override // com.vivo.vmdri.IVmdriServerHandle
        public DeviceParcel getLocalDeviceInfo() {
            DeviceParcel deviceParcelB = e.this.f1965o.b();
            e.E("getLocalDeviceInfo, deviceParcel:" + deviceParcelB);
            return deviceParcelB;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public P2pInfoParcel getLocalP2pInfo() {
            P2pInfoParcel p2pInfoParcelN = e.this.f1965o.n();
            e.E("getLocalP2pInfo, p2pInfoParcel:" + p2pInfoParcelN);
            return p2pInfoParcelN;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public List getRemoteDeviceInfo() {
            ArrayList arrayList = new ArrayList(e.this.f1961k.size());
            Iterator it = e.this.f1961k.values().iterator();
            while (it.hasNext()) {
                arrayList.add(((w.d) it.next()).b());
            }
            return arrayList;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public P2pInfoParcel getRemoteP2pInfo(String str) {
            w.d dVar = (w.d) e.this.f1961k.get(str);
            P2pInfoParcel p2pInfoParcelN = dVar != null ? dVar.n() : new P2pInfoParcel();
            e.E("getRemoteP2pInfo remoteDevId" + str + ", remoteDevState:" + dVar + ", p2pInfoParcel:" + p2pInfoParcelN);
            return p2pInfoParcelN;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public boolean getRemoteScreenState(String str) {
            w.d dVar = (w.d) e.this.f1961k.get(str);
            boolean zD = dVar != null ? dVar.D() : false;
            e.E("getRemoteScreenState remoteDevId" + str + ", remoteDevState:" + dVar + ", screenState:" + zD);
            return zD;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public int getSwitchState(String str) {
            int iT;
            w.d dVar = (w.d) e.this.f1961k.get(str);
            if (dVar != null) {
                iT = e.this.f1965o.t() & dVar.t();
            } else {
                iT = 0;
            }
            e.E("get switch:" + w.p.f(iT));
            return iT;
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void sendIndRilMsg(String str, int i2, int i3, int i4, byte[] bArr) {
            if (VmdriLog.isFullDebugLevel()) {
                StringBuilder sb = new StringBuilder();
                sb.append("sendIndRilMsg, remoteDevId: ");
                sb.append(str);
                sb.append(", moduleId:");
                sb.append(i2);
                sb.append(", slotId:");
                sb.append(i3);
                sb.append(", indBuffLen:");
                sb.append(bArr != null ? Integer.valueOf(bArr.length) : null);
                e.E(sb.toString());
            }
            e.this.O(str, i2, i3, i4, bArr);
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void sendIndRilMsgToAll(int i2, int i3, int i4, byte[] bArr) {
            if (VmdriLog.isFullDebugLevel()) {
                StringBuilder sb = new StringBuilder();
                sb.append("sendIndRilMsgToAll moduleId: ");
                sb.append(i2);
                sb.append(", slotId:");
                sb.append(i3);
                sb.append(", messageId:");
                sb.append(i4);
                sb.append(", indBuff len:");
                sb.append(bArr != null ? Integer.valueOf(bArr.length) : null);
                e.E(sb.toString());
            }
            e.this.P(i2, i3, i4, bArr);
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void sendRespRilMsg(String str, int i2, int i3, int i4, byte[] bArr, int i5) {
            if (VmdriLog.isFullDebugLevel()) {
                StringBuilder sb = new StringBuilder();
                sb.append("sendRespRilMsg remoteDevId: ");
                sb.append(str);
                sb.append(" moduleId:");
                sb.append(i2);
                sb.append(", slotId:");
                sb.append(i3);
                sb.append(", serial:");
                sb.append(i4);
                sb.append(", respBuffLen:");
                sb.append(bArr != null ? Integer.valueOf(bArr.length) : null);
                sb.append(", errCode:");
                sb.append(i5);
                e.E(sb.toString());
            }
            e.this.R(str, i2, i3, i4, bArr, i5);
        }

        @Override // com.vivo.vmdri.IVmdriServerHandle
        public void serverRilReady() {
            e.this.S(1);
        }

        private f() {
        }
    }

    public e(Context context, Looper looper, s sVar) {
        super(looper);
        this.f1960j = new Object();
        this.f1961k = new ConcurrentHashMap();
        this.f1962l = new ConcurrentHashMap();
        this.f1963m = new ConcurrentHashMap();
        this.f1965o = new w.d(true);
        E("init");
        this.f1951a = context;
        this.f1952b = sVar;
        g0 cVar = new c(new Executor() { // from class: o0.c
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1948a.post(runnable);
            }
        });
        this.f1953c = cVar;
        b bVar = new b(new Executor() { // from class: o0.c
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1948a.post(runnable);
            }
        });
        this.f1954d = bVar;
        sVar.g(bVar);
        sVar.b(cVar);
        D();
        this.f1958h = new C0019e(new Executor() { // from class: o0.c
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1948a.post(runnable);
            }
        });
        m mVar = new m(context, looper, this.f1956f);
        this.f1957g = mVar;
        mVar.v(this.f1958h);
        DependentServiceController dependentServiceController = DependentServiceController.getInstance();
        this.f1955e = dependentServiceController;
        dependentServiceController.registerDependentServiceCallback(new a(new Executor() { // from class: o0.d
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1949a.postAtFrontOfQueue(runnable);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void B() {
        this.f1957g.q();
    }

    private int C(String str) {
        int iIntValue;
        synchronized (this.f1960j) {
            try {
                Integer num = (Integer) this.f1963m.get(str);
                iIntValue = num != null ? num.intValue() : 0;
            } catch (Throwable th) {
                throw th;
            }
        }
        return iIntValue;
    }

    private void D() {
        this.f1956f = new ComponentName("com.android.phone", "com.vivo.internal.telephony.VivoVirtualModemService");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void E(String str) {
        VmdriLog.d("RilServerManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void F(String str) {
        VmdriLog.e("RilServerManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G(w.d dVar) {
        E("notifyDeviceConnected, remoteDevice:" + dVar + ", localDevState:" + this.f1965o);
        if (this.f1959i == null) {
            F("notifyDeviceConnected RilServerHandle is null!");
            return;
        }
        try {
            this.f1959i.onRemoteDeviceConnected(dVar.b(), dVar.u().getVersionName());
            String strI = dVar.i();
            IRilServerHandle iRilServerHandle = this.f1959i;
            boolean z2 = true;
            if (C(strI) != 1) {
                z2 = false;
            }
            iRilServerHandle.onRemoteClientRilReady(strI, z2);
            this.f1959i.onRemoteScreenStateChanged(strI, dVar.D());
            this.f1959i.onRemoteP2pInfoChanged(strI, dVar.n());
            this.f1959i.onSwitchStateChanged(strI, dVar.t() & this.f1965o.t());
            this.f1959i.onLocalP2pInfoChanged(this.f1965o.n());
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H(w.d dVar) {
        E("notifyDeviceDisconnected:" + dVar);
        if (this.f1959i == null) {
            F("notifyDeviceDisconnected RilServerHandle is null");
            return;
        }
        try {
            this.f1959i.onRemoteDeviceDisconnected(dVar.b());
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I(String str, String str2) {
        E("notifyLocalP2pInfoChanged p2pIf:" + str + ", p2pIp:" + str2);
        if (this.f1959i == null) {
            F("notifyLocalP2pInfoChanged RilServerHandle is null!");
            return;
        }
        try {
            P2pInfoParcel p2pInfoParcel = new P2pInfoParcel();
            p2pInfoParcel.p2pIf = str;
            p2pInfoParcel.p2pIp = str2;
            this.f1959i.onLocalP2pInfoChanged(p2pInfoParcel);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    private void J(String str, boolean z2) {
        E("notifyRemoteClientRilReady, remoteDevId:" + str + ", ready:" + z2);
        IRilServerHandle iRilServerHandle = this.f1959i;
        if (iRilServerHandle == null) {
            F("notifyRemoteClientRilReady RilServerHandle is null!");
            return;
        }
        try {
            iRilServerHandle.onRemoteClientRilReady(str, z2);
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K(String str, String str2, String str3) {
        E("notifyRemoteP2pInfoChanged remoteDevId:" + str + ", p2pIf:" + str2 + ", p2pIp:" + str3);
        if (this.f1959i == null) {
            F("notifyRemoteP2pInfoChanged RilServerHandle is null!");
            return;
        }
        try {
            P2pInfoParcel p2pInfoParcel = new P2pInfoParcel();
            p2pInfoParcel.p2pIf = str2;
            p2pInfoParcel.p2pIp = str3;
            this.f1959i.onRemoteP2pInfoChanged(str, p2pInfoParcel);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L(String str, boolean z2) {
        E("notifyRemoteScreenStateChanged remoteDevId:" + str + ", screenOn:" + z2);
        IRilServerHandle iRilServerHandle = this.f1959i;
        if (iRilServerHandle == null) {
            F("notifyRemoteScreenStateChanged RilServerHandle is null!");
            return;
        }
        try {
            iRilServerHandle.onRemoteScreenStateChanged(str, z2);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M(String str, m0.a aVar) {
        if (VmdriLog.isFullDebugLevel()) {
            E("notifyRilRequest, deviceId:" + str + ", message:" + aVar);
        }
        IRilServerHandle iRilServerHandle = this.f1959i;
        if (iRilServerHandle == null) {
            F("notifyRilRequest RilServerHandle is null, drop data!");
            return;
        }
        try {
            iRilServerHandle.onRecvRilRequest(str, aVar.f1831a, aVar.f1832b, aVar.f1833c, aVar.f1834d, aVar.f1836f);
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void N(String str, int i2, int i3) {
        E("notifySwitchChanged remoteDevId:" + str + ", remoteSwitch:" + w.p.f(i2) + ", localSwitch:" + w.p.f(i3));
        IRilServerHandle iRilServerHandle = this.f1959i;
        if (iRilServerHandle == null) {
            F("notifySwitchChanged RilServerHandle is null!");
            return;
        }
        try {
            iRilServerHandle.onSwitchStateChanged(str, i2 & i3);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int O(String str, int i2, int i3, int i4, byte[] bArr) {
        m0.a aVar = new m0.a(i2, i3, i4, -1, 3, bArr);
        o0.b bVar = (o0.b) this.f1962l.get(str);
        if (bVar != null) {
            return bVar.g(aVar);
        }
        F("sendIndRilMsg error: can't find channel!");
        return 3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int P(int i2, int i3, int i4, byte[] bArr) {
        m0.a aVar = new m0.a(i2, i3, i4, -1, 3, bArr);
        Iterator it = this.f1962l.values().iterator();
        while (it.hasNext()) {
            ((o0.b) it.next()).g(aVar);
        }
        return 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Q(String str) {
        this.f1952b.X0(str, this.f1964n);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int R(String str, int i2, int i3, int i4, byte[] bArr, int i5) {
        m0.a aVar = new m0.a(i2, i3, -1, i4, 2, bArr);
        aVar.f1837g = i5;
        o0.b bVar = (o0.b) this.f1962l.get(str);
        if (bVar != null) {
            return bVar.h(aVar);
        }
        F("sendRespRilMsg error: can't find channel!");
        return 3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void S(int i2) {
        E("setLocalRilState, rilState:" + i2 + ", uid:" + Binder.getCallingUid() + ", pid:" + Binder.getCallingPid());
        synchronized (this.f1960j) {
            try {
                this.f1964n = i2;
                Iterator it = this.f1961k.values().iterator();
                while (it.hasNext()) {
                    Q(((w.d) it.next()).i());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean T(String str, int i2) {
        synchronized (this.f1960j) {
            try {
                if (((w.d) this.f1961k.get(str)) != null) {
                    U(str, i2);
                    boolean z2 = true;
                    if (i2 != 1) {
                        z2 = false;
                    }
                    J(str, z2);
                    return false;
                }
                F("setRemoteRilModuleState a does not exist device ID, remoteDevId:" + str + ", remoteRilState:" + i2);
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean U(String str, int i2) {
        boolean z2;
        synchronized (this.f1960j) {
            try {
                Integer num = (Integer) this.f1963m.get(str);
                z2 = false;
                if ((num != null ? num.intValue() : 0) != i2) {
                    this.f1963m.put(str, Integer.valueOf(i2));
                    z2 = true;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return z2;
    }
}
