package o0;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.ArraySet;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.IRilServerHandle;
import com.vivo.vmdri.ThreadManager;
import com.vivo.vmdri.VmdriLog;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f1977a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ComponentName f1979c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private c f1982f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private IRilServerHandle f1983g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private a f1984h;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f1986j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f1987k;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final Set f1981e = new ArraySet();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final Object f1985i = new Object();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final d f1978b = new d(this, ThreadManager.getsVmdriCommLooper());

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final DependentServiceController f1980d = DependentServiceController.getInstance();

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class a implements IBinder.DeathRecipient {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final ComponentName f1988a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private IBinder f1989b;

        a(ComponentName componentName) {
            this.f1988a = componentName;
        }

        public static /* synthetic */ void a(final b bVar) {
            bVar.getClass();
            bVar.invokeFromExecutor(new Runnable() { // from class: o0.l
                @Override // java.lang.Runnable
                public final void run() {
                    bVar.c();
                }
            });
        }

        public void b(IBinder iBinder) throws RemoteException {
            if (iBinder != null) {
                this.f1989b = iBinder;
                iBinder.linkToDeath(this, 0);
            }
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            m.t("VirMdService(" + this.f1988a + ") has died.");
            synchronized (m.this.f1985i) {
                m.this.f1986j = false;
                m.this.f1987k = false;
                m.this.f1980d.setRilBound(false);
                m.this.f1981e.forEach(new Consumer() { // from class: o0.k
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        m.a.a((m.b) obj);
                    }
                });
                m.this.w();
            }
        }

        public synchronized void c() {
            IBinder iBinder = this.f1989b;
            if (iBinder != null) {
                try {
                    iBinder.unlinkToDeath(this, 0);
                } catch (NoSuchElementException unused) {
                }
                this.f1989b = null;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class b extends w.a {
        public b(Executor executor) {
            super(executor);
        }

        public abstract void a(IRilServerHandle iRilServerHandle);

        public abstract void b(String str);

        public abstract void c();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class c implements ServiceConnection {
        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void c(b bVar) {
            bVar.a(m.this.f1983g);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void d(final b bVar) {
            bVar.invokeFromExecutor(new Runnable() { // from class: o0.o
                @Override // java.lang.Runnable
                public final void run() {
                    this.f1993a.c(bVar);
                }
            });
        }

        @Override // android.content.ServiceConnection
        public void onBindingDied(ComponentName componentName) {
            m.t("service " + componentName + " is now onBindingDied.");
            synchronized (m.this.f1985i) {
                m.this.f1986j = false;
                m.this.f1987k = false;
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            m.t("service " + componentName + " for vir md is connected.");
            synchronized (m.this.f1985i) {
                m.this.f1986j = true;
                m.this.f1987k = false;
                m.this.f1983g = IRilServerHandle.Stub.asInterface(iBinder);
                m mVar = m.this;
                mVar.f1984h = mVar.new a(componentName);
                try {
                    m.this.f1984h.b(iBinder);
                } catch (Exception e2) {
                    m.u("linkToDeath Exception:" + e2);
                }
                m.this.f1980d.setRilBound(true);
                m.this.f1981e.forEach(new Consumer() { // from class: o0.n
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        this.f1992a.d((m.b) obj);
                    }
                });
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            m.t("service " + componentName + " is now disconnected.");
            synchronized (m.this.f1985i) {
                m.this.f1986j = false;
                m.this.f1987k = false;
            }
        }

        private c() {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends Handler {
        public d(m mVar, Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            m.u("unsupported message:" + message.what);
        }
    }

    public m(Context context, Looper looper, ComponentName componentName) {
        this.f1977a = context;
        this.f1979c = componentName.clone();
    }

    private boolean p() {
        boolean zBindService;
        synchronized (this.f1985i) {
            if (!this.f1987k && !this.f1986j) {
                Intent intent = new Intent();
                intent.setComponent(this.f1979c);
                this.f1982f = new c();
                t("Try binding to " + this.f1979c);
                try {
                    Context context = this.f1977a;
                    final d dVar = this.f1978b;
                    dVar.getClass();
                    zBindService = context.bindService(intent, 1, new Executor() { // from class: o0.i
                        @Override // java.util.concurrent.Executor
                        public final void execute(Runnable runnable) {
                            dVar.post(runnable);
                        }
                    }, this.f1982f);
                } catch (Exception e2) {
                    u("Error binding to " + this.f1979c + ", e:" + e2);
                    zBindService = false;
                }
                if (zBindService) {
                    this.f1987k = true;
                } else {
                    u("Failed binding to " + this.f1979c);
                    this.f1982f = null;
                }
                return zBindService;
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void s(b bVar) {
        bVar.a(this.f1983g);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void t(String str) {
        VmdriLog.d("VirtualModemManger", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void u(String str) {
        VmdriLog.e("VirtualModemManger", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void w() {
        a aVar = this.f1984h;
        if (aVar != null) {
            aVar.c();
        }
        if (this.f1982f != null) {
            t("unbind service.");
            this.f1977a.unbindService(this.f1982f);
        }
        this.f1984h = null;
        this.f1983g = null;
        this.f1982f = null;
    }

    public void q() {
        synchronized (this.f1985i) {
            try {
                if (this.f1983g != null) {
                    return;
                }
                if (!this.f1987k && !this.f1986j) {
                    if (!p()) {
                        this.f1981e.forEach(new Consumer() { // from class: o0.h
                            @Override // java.util.function.Consumer
                            public final void accept(Object obj) {
                                m.b bVar = (m.b) obj;
                                bVar.invokeFromExecutor(new Runnable() { // from class: o0.j
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        bVar.b("conn vir md svc failed");
                                    }
                                });
                            }
                        });
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean r() {
        boolean z2;
        synchronized (this.f1985i) {
            z2 = this.f1986j;
        }
        return z2;
    }

    public void v(final b bVar) {
        synchronized (this.f1985i) {
            try {
                this.f1981e.add(bVar);
                if (this.f1983g != null) {
                    bVar.invokeFromExecutor(new Runnable() { // from class: o0.g
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f1972a.s(bVar);
                        }
                    });
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
