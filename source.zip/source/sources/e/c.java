package e;

import android.animation.ArgbEvaluator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import com.originui.core.utils.m;
import com.originui.widget.button.fab.VFabButton;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ValueAnimator f1589a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ValueAnimator f1590b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private float f1591c = 0.9f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f1592d = 0.9f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final Interpolator f1593e = new PathInterpolator(0.25f, 0.45f, 0.3f, 1.0f);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final Interpolator f1594f = new PathInterpolator(0.25f, 0.45f, 0.3f, 1.0f);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ArgbEvaluator f1595g = new ArgbEvaluator();

    public static /* synthetic */ void a(c cVar, VFabButton vFabButton, ValueAnimator valueAnimator) {
        cVar.getClass();
        vFabButton.setPivotX(vFabButton.getWidth() >> 1);
        vFabButton.setPivotY(vFabButton.getHeight() >> 1);
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue();
        float fFloatValue2 = ((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue();
        vFabButton.setScaleX(fFloatValue);
        vFabButton.setScaleY(fFloatValue2);
        cVar.f(vFabButton, valueAnimator, false);
        cVar.g(vFabButton, valueAnimator, fFloatValue);
        vFabButton.invalidate();
    }

    public static /* synthetic */ void b(c cVar, VFabButton vFabButton, ValueAnimator valueAnimator) {
        cVar.getClass();
        vFabButton.setPivotX(vFabButton.getWidth() >> 1);
        vFabButton.setPivotY(vFabButton.getHeight() >> 1);
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue("scaleX")).floatValue();
        float fFloatValue2 = ((Float) valueAnimator.getAnimatedValue("scaleY")).floatValue();
        vFabButton.setScaleX(fFloatValue);
        vFabButton.setScaleY(fFloatValue2);
        cVar.f(vFabButton, valueAnimator, true);
        cVar.g(vFabButton, valueAnimator, fFloatValue);
        vFabButton.invalidate();
    }

    private void f(VFabButton vFabButton, ValueAnimator valueAnimator, boolean z2) {
        if (vFabButton.getAbsFabButtonHelper() != null) {
            List list = f.a.a().f1612a;
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue("alphaAnimator")).floatValue();
            float fFloatValue2 = ((Float) valueAnimator.getAnimatedValue("blurAnimator")).floatValue();
            float fFloatValue3 = ((Float) valueAnimator.getAnimatedValue("mArgbEvaluatorOffset")).floatValue();
            int iIntValue = z2 ? ((Integer) this.f1595g.evaluate(fFloatValue3, -1, -16777216)).intValue() : ((Integer) this.f1595g.evaluate(fFloatValue3, -16777216, -1)).intValue();
            if (m.f583b) {
                m.b("VFabAnimUtils", "colorAnimator:" + Integer.toHexString(iIntValue));
                m.b("VFabAnimUtils", "int[]:" + Arrays.toString(e(iIntValue)) + "---blurAnimator" + fFloatValue2 + "----mArgbEvaluatorOffset" + fFloatValue3 + "----alphaAnimator" + fFloatValue);
            }
            ((f.b) list.get(4)).d(e(iIntValue));
            f.a.a().f1614c = fFloatValue2;
            vFabButton.p();
        }
    }

    private void g(VFabButton vFabButton, ValueAnimator valueAnimator, float f2) {
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue("mLimitX")).floatValue();
        float fFloatValue2 = ((Float) valueAnimator.getAnimatedValue("mLimitY")).floatValue();
        float fFloatValue3 = ((Float) valueAnimator.getAnimatedValue("mRadiusBlur")).floatValue();
        float fFloatValue4 = ((Float) valueAnimator.getAnimatedValue("mRadiusProportional")).floatValue();
        if (m.f583b) {
            m.b("VFabAnimUtils", "mLimitX:" + fFloatValue + "---mLimitY:" + fFloatValue2 + "---mRadiusBlur:" + fFloatValue3 + "---mRadiusProportional:" + fFloatValue4 + "-----scaleX:" + f2);
        }
        vFabButton.q(fFloatValue4, fFloatValue3, fFloatValue, fFloatValue2, f2);
    }

    public void c(final VFabButton vFabButton) {
        float fFloatValue;
        if (vFabButton == null) {
            return;
        }
        if (this.f1589a == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f1589a = valueAnimator;
            valueAnimator.setDuration(200L);
            this.f1589a.setInterpolator(this.f1593e);
            this.f1589a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: e.a
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    c.b(this.f1585a, vFabButton, valueAnimator2);
                }
            });
        }
        ValueAnimator valueAnimator2 = this.f1590b;
        float fFloatValue2 = 1.0f;
        if (valueAnimator2 == null || !valueAnimator2.isRunning()) {
            fFloatValue = 1.0f;
        } else {
            fFloatValue2 = ((Float) this.f1590b.getAnimatedValue("scaleX")).floatValue();
            fFloatValue = ((Float) this.f1590b.getAnimatedValue("scaleY")).floatValue();
            this.f1590b.cancel();
        }
        this.f1589a.setValues(PropertyValuesHolder.ofFloat("scaleX", fFloatValue2, this.f1591c), PropertyValuesHolder.ofFloat("scaleY", fFloatValue, this.f1592d), PropertyValuesHolder.ofFloat("alphaAnimator", 0.1f, 0.15f), PropertyValuesHolder.ofFloat("blurAnimator", 0.04f, 0.03f), PropertyValuesHolder.ofFloat("mLimitX", 1.0f, 1.0f), PropertyValuesHolder.ofFloat("mLimitY", 8.0f, 5.0f), PropertyValuesHolder.ofFloat("mRadiusBlur", 15.0f, 12.0f), PropertyValuesHolder.ofFloat("mRadiusProportional", 0.7f, 0.82f), PropertyValuesHolder.ofFloat("mArgbEvaluatorOffset", 0.0f, 1.0f));
        this.f1589a.start();
    }

    public void d(final VFabButton vFabButton) {
        if (this.f1590b == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f1590b = valueAnimator;
            valueAnimator.setDuration(250L);
            this.f1590b.setInterpolator(this.f1594f);
            this.f1590b.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: e.b
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    c.a(this.f1587a, vFabButton, valueAnimator2);
                }
            });
        }
        float fFloatValue = this.f1591c;
        float fFloatValue2 = this.f1592d;
        ValueAnimator valueAnimator2 = this.f1589a;
        if (valueAnimator2 != null && valueAnimator2.isRunning()) {
            fFloatValue = ((Float) this.f1589a.getAnimatedValue("scaleX")).floatValue();
            fFloatValue2 = ((Float) this.f1589a.getAnimatedValue("scaleY")).floatValue();
            this.f1589a.cancel();
        }
        this.f1590b.setValues(PropertyValuesHolder.ofFloat("scaleX", fFloatValue, 1.0f), PropertyValuesHolder.ofFloat("scaleY", fFloatValue2, 1.0f), PropertyValuesHolder.ofFloat("alphaAnimator", 0.15f, 0.1f), PropertyValuesHolder.ofFloat("blurAnimator", 0.03f, 0.04f), PropertyValuesHolder.ofFloat("mLimitX", 1.0f, 1.0f), PropertyValuesHolder.ofFloat("mLimitY", 5.0f, 8.0f), PropertyValuesHolder.ofFloat("mRadiusBlur", 12.0f, 15.0f), PropertyValuesHolder.ofFloat("mRadiusProportional", 0.82f, 0.7f), PropertyValuesHolder.ofFloat("mArgbEvaluatorOffset", 0.0f, 1.0f));
        this.f1590b.start();
    }

    public int[] e(int i2) {
        return new int[]{(i2 >> 16) & 255, (i2 >> 8) & 255, i2 & 255};
    }
}
