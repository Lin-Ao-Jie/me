package o;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.OverScroller;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Method f1921a;

    private static boolean a(Context context, NestedScrollView nestedScrollView, boolean z2) {
        Field declaredField;
        if (nestedScrollView == null) {
            return false;
        }
        boolean zD = d();
        try {
            try {
                declaredField = nestedScrollView.getClass().getDeclaredField("mScroller");
            } catch (NoSuchFieldException unused) {
                declaredField = nestedScrollView.getClass().getDeclaredField("mOverScroller");
            }
            declaredField.setAccessible(true);
            Object obj = declaredField.get(nestedScrollView);
            return obj instanceof OverScroller ? b(context, (OverScroller) obj, z2) : zD;
        } catch (Exception e2) {
            t.a.b("FlingEffectHelper", "nestedScrollView exception : " + e2.getMessage());
            return false;
        }
    }

    private static boolean b(Context context, OverScroller overScroller, boolean z2) {
        Method method;
        if (overScroller != null && (method = f1921a) != null) {
            try {
                method.invoke(overScroller, context, Boolean.valueOf(z2));
                return true;
            } catch (Exception e2) {
                Log.e("FlingEffectHelper", "setSpringEffect e: " + e2);
            }
        }
        return false;
    }

    private static boolean c(Context context, RecyclerView recyclerView, boolean z2) {
        Field declaredField;
        boolean zB = false;
        if (recyclerView == null) {
            return false;
        }
        boolean zD = d();
        Log.d("FlingEffectHelper", "initOverScrollerMethod: success=" + zD);
        try {
            Field declaredField2 = recyclerView.getClass().getDeclaredField("mViewFlinger");
            declaredField2.setAccessible(true);
            Object obj = declaredField2.get(recyclerView);
            Class<?> cls = obj.getClass();
            try {
                declaredField = cls.getDeclaredField("mScroller");
            } catch (NoSuchFieldException unused) {
                declaredField = cls.getDeclaredField("mOverScroller");
            }
            declaredField.setAccessible(true);
            Object obj2 = declaredField.get(obj);
            zB = obj2 instanceof OverScroller ? b(context, (OverScroller) obj2, z2) : zD;
        } catch (Exception e2) {
            Log.e("FlingEffectHelper", "flinger exception : " + e2);
        }
        Log.d("FlingEffectHelper", "hookOverScroller: success=" + zB);
        return zB;
    }

    private static boolean d() {
        try {
            f1921a = Class.forName("android.widget.OverScroller").getMethod("setFlingEffect", Context.class, Boolean.TYPE);
            return true;
        } catch (Exception e2) {
            Log.e("FlingEffectHelper", "initMethod fail e: " + e2.getMessage());
            return false;
        }
    }

    public static boolean e(Context context, View view, boolean z2) {
        return false;
    }
}
