package o;

import android.content.Context;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Object f1922a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Method f1923b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f1924c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Method f1925d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static Method f1926e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static Method f1927f;

    public static Object a(Context context) {
        t.a.a("IVivoScrollViewHelper", "initIVivoScrollView()");
        try {
            Class<?> cls = Class.forName("com.vivo.VivoSystemFrameworkFactory");
            Class[] clsArr = new Class[0];
            Method method = cls.getMethod("getSystemFrameworkFactoryImpl", null);
            method.setAccessible(true);
            Object objInvoke = method.invoke(null, null);
            if (objInvoke == null) {
                t.a.a("IVivoScrollViewHelper", "initIVivoScrollView(), Failed to get VivoSystemFrameworkFactory instance");
                return null;
            }
            Method method2 = cls.getMethod("createVivoScrollView", Context.class);
            method2.setAccessible(true);
            t.a.a("IVivoScrollViewHelper", "initIVivoScrollView(), success to get VivoSystemFrameworkFactory instance");
            Object objInvoke2 = method2.invoke(objInvoke, context);
            f1922a = objInvoke2;
            return objInvoke2;
        } catch (ClassNotFoundException unused) {
            t.a.b("IVivoScrollViewHelper", "IVivoScrollView not found!");
            return null;
        } catch (NoSuchMethodException unused2) {
            t.a.b("IVivoScrollViewHelper", "Method getSystemFrameworkFactoryImpl or createVivoScrollView not found");
            return null;
        } catch (Exception unused3) {
            t.a.b("IVivoScrollViewHelper", "IVivoScrollView invoke failed!");
            return null;
        }
    }

    public static void b(float f2, double d2, float f3) {
        Object obj = f1922a;
        if (obj == null) {
            t.a.a("IVivoScrollViewHelper", "onScrollFlingUpdate() failed: sIVivoScrollView is null");
            return;
        }
        try {
            if (f1926e != null) {
                t.a.a("IVivoScrollViewHelper", "onScrollFlingUpdate(), sIVivoScrollView == true");
                return;
            }
            Class<?> cls = obj.getClass();
            Class<?> cls2 = Float.TYPE;
            Method declaredMethod = cls.getDeclaredMethod("onScrollFlingUpdate", cls2, Double.TYPE, cls2);
            f1926e = declaredMethod;
            declaredMethod.setAccessible(true);
            f1926e.invoke(f1922a, Float.valueOf(f2), Double.valueOf(d2), Float.valueOf(f3));
            t.a.a("IVivoScrollViewHelper", "Invoke success, onScrollFlingUpdate()");
        } catch (Exception unused) {
            t.a.b("IVivoScrollViewHelper", "onScrollFlingUpdate(), invoke failed, no such method!");
        }
    }

    public static void c() {
        Object obj = f1922a;
        if (obj == null) {
            t.a.a("IVivoScrollViewHelper", "setFlingFlagEnd() failed: sIVivoScrollView is null");
            return;
        }
        try {
            if (f1924c != null) {
                t.a.a("IVivoScrollViewHelper", "setFlingFlagEnd(), sIVivoScrollView == true");
                return;
            }
            Class[] clsArr = new Class[0];
            Method declaredMethod = obj.getClass().getDeclaredMethod("setFlingFlagEnd", null);
            f1924c = declaredMethod;
            declaredMethod.setAccessible(true);
            f1924c.invoke(f1922a, null);
            t.a.a("IVivoScrollViewHelper", "Invoke success, setFlingFlagEnd()");
        } catch (Exception unused) {
            t.a.b("IVivoScrollViewHelper", "setFlingFlagEnd(), Invoke failed, no such method!");
        }
    }

    public static void d() {
        Object obj = f1922a;
        if (obj == null) {
            t.a.a("IVivoScrollViewHelper", "setFlingFlagStart() failed: sIVivoScrollView is null");
            return;
        }
        try {
            if (f1923b != null) {
                t.a.a("IVivoScrollViewHelper", "setFlingFlagStart(), sIVivoScrollView == true");
                return;
            }
            Class[] clsArr = new Class[0];
            Method declaredMethod = obj.getClass().getDeclaredMethod("setFlingFlagStart", null);
            f1923b = declaredMethod;
            declaredMethod.setAccessible(true);
            f1923b.invoke(f1922a, null);
            t.a.a("IVivoScrollViewHelper", "Invoke success, setFlingFlagStart()");
        } catch (Exception unused) {
            t.a.b("IVivoScrollViewHelper", "setFlingFlagStart() invoke failed, no such method!");
        }
    }

    public static void e(long j2) {
        Object obj = f1922a;
        if (obj == null) {
            t.a.a("IVivoScrollViewHelper", "setScrollerStartTime() failed: sIVivoScrollView is null");
            return;
        }
        try {
            if (f1927f != null) {
                t.a.a("IVivoScrollViewHelper", "setScrollerStartTime(), sIVivoScrollView == true");
                return;
            }
            Method declaredMethod = obj.getClass().getDeclaredMethod("setScrollerStartTime", Long.TYPE);
            f1927f = declaredMethod;
            declaredMethod.setAccessible(true);
            f1927f.invoke(f1922a, Long.valueOf(j2));
            t.a.a("IVivoScrollViewHelper", "Invoke success, setScrollerStartTime()");
        } catch (Exception unused) {
            t.a.b("IVivoScrollViewHelper", "setScrollerStartTime(), invoke failed, no such method!");
        }
    }

    public static long f(long j2, long j3) {
        Object obj = f1922a;
        if (obj == null) {
            t.a.a("IVivoScrollViewHelper", "update() failed: sIVivoScrollView is null");
            return -1L;
        }
        try {
            if (f1925d != null) {
                t.a.a("IVivoScrollViewHelper", "update(), sIVivoScrollView == true");
                return -1L;
            }
            Class<?> cls = obj.getClass();
            Class<?> cls2 = Long.TYPE;
            Method declaredMethod = cls.getDeclaredMethod("update", cls2, cls2);
            f1925d = declaredMethod;
            declaredMethod.setAccessible(true);
            t.a.a("IVivoScrollViewHelper", "Invoke success, update()");
            return ((Long) f1925d.invoke(f1922a, Long.valueOf(j2), Long.valueOf(j3))).longValue();
        } catch (Exception unused) {
            t.a.b("IVivoScrollViewHelper", "update(), invoke failed, no such method!");
        }
    }
}
