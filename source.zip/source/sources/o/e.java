package o;

import android.content.Context;
import android.view.View;
import android.widget.AbsListView;
import android.widget.HorizontalScrollView;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Method f1928a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Method f1929b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f1930c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static boolean f1931d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static double f1932e = 1.0d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static double f1933f = 2.2d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static double f1934g = 26.0d;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static double f1935h = 176.0d;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static double f1936i = 28.0d;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static double f1937j = 176.0d;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static final Object f1938k = new Object();

    private static boolean a(Context context, NestedScrollView nestedScrollView, boolean z2) {
        Field declaredField;
        if (nestedScrollView == null) {
            return false;
        }
        boolean zE = e();
        try {
            try {
                declaredField = nestedScrollView.getClass().getDeclaredField("mScroller");
            } catch (NoSuchFieldException unused) {
                declaredField = nestedScrollView.getClass().getDeclaredField("mOverScroller");
            }
            declaredField.setAccessible(true);
            Object obj = declaredField.get(nestedScrollView);
            return obj instanceof OverScroller ? b(context, (OverScroller) obj, z2) : zE;
        } catch (Exception e2) {
            t.a.b("SpringEffectHelper", "nestedScrollView exception : " + e2.getMessage());
            return false;
        }
    }

    public static boolean b(Context context, OverScroller overScroller, boolean z2) {
        boolean z3;
        if (overScroller == null) {
            return false;
        }
        Method method = f1928a;
        if (method != null) {
            try {
                method.invoke(overScroller, context, Boolean.valueOf(z2));
                z3 = true;
            } catch (Exception e2) {
                t.a.b("SpringEffectHelper", "setSpringEffect e: " + e2);
                z3 = false;
            }
        } else {
            z3 = false;
        }
        Method method2 = f1930c;
        if (method2 == null || !z2) {
            return z3;
        }
        try {
            method2.invoke(overScroller, context, Double.valueOf(f1933f), Double.valueOf(f1932e), Double.valueOf(f1934g), Double.valueOf(f1935h), Double.valueOf(f1936i), Double.valueOf(f1937j));
            return true;
        } catch (Exception e3) {
            t.a.b("SpringEffectHelper", "setSpringEffect e: " + e3.getMessage());
            return false;
        }
    }

    private static boolean c(Context context, RecyclerView recyclerView, boolean z2) {
        Field declaredField;
        if (recyclerView == null) {
            return false;
        }
        boolean zE = e();
        try {
            Field declaredField2 = recyclerView.getClass().getDeclaredField("mViewFlinger");
            declaredField2.setAccessible(true);
            Object obj = declaredField2.get(recyclerView);
            Class<?> cls = obj.getClass();
            try {
                declaredField = cls.getDeclaredField("mScroller");
            } catch (NoSuchFieldException unused) {
                declaredField = cls.getDeclaredField("mOverScroller");
            }
            declaredField.setAccessible(true);
            Object obj2 = declaredField.get(obj);
            return obj2 instanceof OverScroller ? b(context, (OverScroller) obj2, z2) : zE;
        } catch (Exception e2) {
            t.a.b("SpringEffectHelper", "flinger exception : " + e2.getMessage());
            return false;
        }
    }

    private static boolean d(View view) {
        try {
            if (view instanceof AbsListView) {
                f1928a = Class.forName("android.widget.AbsListView").getMethod("setSpringEffect", Boolean.TYPE);
                return true;
            }
            if (view instanceof ScrollView) {
                f1928a = Class.forName("android.widget.ScrollView").getMethod("setSpringEffect", Boolean.TYPE);
                return true;
            }
            if (view instanceof HorizontalScrollView) {
                f1928a = Class.forName("android.widget.HorizontalScrollView").getMethod("setSpringEffect", Boolean.TYPE);
            }
            return true;
        } catch (Exception e2) {
            t.a.b("SpringEffectHelper", "initMethod fail e: " + e2.getMessage());
            return false;
        }
    }

    private static boolean e() {
        try {
            Class<?> cls = Class.forName("android.widget.OverScroller");
            f1928a = cls.getMethod("setSpringEffect", Context.class, Boolean.TYPE);
            if (!f1931d) {
                return false;
            }
            Class<?> cls2 = Double.TYPE;
            f1930c = cls.getDeclaredMethod("setSpringEffectParam", Context.class, cls2, cls2, cls2, cls2, cls2, cls2);
            f1931d = false;
            return true;
        } catch (Exception e2) {
            t.a.b("SpringEffectHelper", "initMethod fail e: " + e2);
            return false;
        }
    }

    public static boolean f(Context context, View view, boolean z2) {
        if (!(view instanceof AbsListView) && !(view instanceof ScrollView) && !(view instanceof HorizontalScrollView)) {
            return true;
        }
        boolean zD = d(view);
        Method method = f1928a;
        if (method != null) {
            try {
                method.invoke(view, Boolean.valueOf(z2));
            } catch (Exception e2) {
                t.a.b("SpringEffectHelper", "setSpringEffect e: " + e2.getMessage());
                zD = false;
            }
        }
        Method method2 = f1929b;
        if (method2 != null) {
            try {
                method2.invoke(view, Boolean.valueOf(!z2));
            } catch (Exception e3) {
                t.a.b("SpringEffectHelper", "setSpringEffect e: " + e3.getMessage());
                return false;
            }
        }
        return zD;
    }
}
