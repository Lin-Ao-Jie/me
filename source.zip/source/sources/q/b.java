package q;

import android.content.Context;
import android.os.SystemClock;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f2044a = 1.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected float f2045b = Float.MIN_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected float f2046c = Float.MIN_VALUE;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected float f2047d = 0.0f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected float f2048e = 0.0f;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    protected long f2049f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected float f2050g = 0.0f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f2051h = 15.0f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public float f2052i = 800.0f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f2053j = 1.0f;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f2054k = 16.0f;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f2055l = 60;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private WeakReference f2056m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private d f2057n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private float f2058o;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class a extends d {

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        float f2059g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        float f2060h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        float f2061i;

        a(float f2, float f3, float f4) {
            super();
            t.a.a("SpringEstimateUtils", "Solution3 c1=" + f2 + " , c2=" + f3 + " , r=" + f4);
            this.f2059g = f2;
            this.f2060h = f3;
            this.f2061i = f4;
            g();
        }

        @Override // q.b.d
        public float b() {
            return this.f2075c;
        }

        @Override // q.b.d
        public float c(float f2) {
            float fPow = (float) Math.pow(2.718281828459045d, this.f2061i * f2);
            float f3 = this.f2061i;
            float f4 = this.f2059g;
            float f5 = this.f2060h;
            float f6 = (f3 * (f4 + (f2 * f5)) * fPow) + (f5 * fPow);
            this.f2074b = f6;
            return f6;
        }

        @Override // q.b.d
        public float f(float f2) {
            float fPow = (float) (((double) (this.f2059g + (this.f2060h * f2))) * Math.pow(2.718281828459045d, this.f2061i * f2));
            this.f2076d = fPow;
            return fPow;
        }

        public final void g() {
            float f2 = this.f2060h;
            float f3 = (-(((f2 * 2.0f) / this.f2061i) + this.f2059g)) / f2;
            int i2 = 0;
            if (f3 < 0.0f || Float.isInfinite(f3) || Float.isNaN(f3)) {
                f3 = 0.0f;
            } else {
                float f4 = f(f3);
                int i3 = 0;
                while (b.this.e(Math.abs(f4), b.this.f2045b, 0.0f)) {
                    i3++;
                    if (i3 > 999.0f) {
                        break;
                    }
                    f3 = (f3 + 0.0f) / 2.0f;
                    f4 = f(f3);
                }
                if (i3 > 999.0f) {
                    this.f2075c = f3;
                    return;
                }
            }
            float f5 = f(f3);
            float fC = c(f3);
            b.this.f2058o = fC;
            t.a.a("SpringEstimateUtils", "Solution1 curVelocity=" + b.this.f2058o);
            while (b.this.d(Math.abs(f5), b.this.f2045b, 0.0f)) {
                i2++;
                if (i2 > 999.0f) {
                    break;
                }
                f3 -= f5 / fC;
                if (f3 < 0.0f || Float.isNaN(f3) || Float.isInfinite(f3)) {
                    this.f2075c = 0.0f;
                    return;
                } else {
                    f5 = f(f3);
                    fC = c(f3);
                }
            }
            if (i2 > 999.0f) {
                this.f2075c = -1.0f;
            } else {
                this.f2075c = f3;
            }
        }
    }

    /* JADX INFO: renamed from: q.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class C0022b extends d {

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        float f2063g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        float f2064h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        float f2065i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        float f2066j;

        C0022b(float f2, float f3, float f4, float f5) {
            super();
            t.a.a("SpringEstimateUtils", "Solution2 c1=" + f2 + " , c2=" + f3 + " , r1=" + f4 + " , r2=" + f5);
            this.f2063g = f2;
            this.f2064h = f3;
            this.f2065i = f4;
            this.f2066j = f5;
            g();
        }

        @Override // q.b.d
        public float b() {
            return this.f2075c;
        }

        @Override // q.b.d
        public float c(float f2) {
            float f3 = this.f2063g;
            float f4 = this.f2065i;
            float fPow = f3 * f4 * ((float) Math.pow(2.718281828459045d, f4 * f2));
            float f5 = this.f2064h;
            float f6 = this.f2066j;
            float fPow2 = fPow + (f5 * f6 * ((float) Math.pow(2.718281828459045d, f6 * f2)));
            this.f2074b = fPow2;
            return fPow2;
        }

        @Override // q.b.d
        public float f(float f2) {
            float fPow = (this.f2063g * ((float) Math.pow(2.718281828459045d, this.f2065i * f2))) + (this.f2064h * ((float) Math.pow(2.718281828459045d, this.f2066j * f2)));
            this.f2076d = fPow;
            return fPow;
        }

        public final void g() {
            t.a.a("SpringEstimateUtils", "Solution2 doEstimateDuration");
            float f2 = this.f2063g;
            float f3 = this.f2065i;
            float fLog = (float) Math.log(Math.abs(f2 * f3 * f3));
            float f4 = -this.f2064h;
            float f5 = this.f2066j;
            float fLog2 = (fLog - ((float) Math.log(Math.abs((f4 * f5) * f5)))) / (this.f2066j - this.f2065i);
            int i2 = 0;
            if (fLog2 < 0.0f || Float.isInfinite(fLog2) || Float.isNaN(fLog2)) {
                fLog2 = 0.0f;
            } else {
                float f6 = f(fLog2);
                int i3 = 0;
                while (b.this.e(Math.abs(f6), b.this.f2045b, 0.0f)) {
                    i3++;
                    if (i3 > 999.0f) {
                        break;
                    }
                    fLog2 = (fLog2 + 0.0f) / 2.0f;
                    f6 = f(fLog2);
                }
                if (i3 > 999.0f) {
                    this.f2075c = fLog2;
                    return;
                }
            }
            float f7 = f(fLog2);
            float fC = c(fLog2);
            b.this.f2058o = fC;
            t.a.a("SpringEstimateUtils", "Solution2 curVelocity=" + b.this.f2058o);
            while (b.this.d(Math.abs(f7), b.this.f2045b, 0.0f)) {
                i2++;
                if (i2 > 999.0f) {
                    break;
                }
                fLog2 -= f7 / fC;
                if (fLog2 < 0.0f || Float.isNaN(fLog2) || Float.isInfinite(fLog2)) {
                    this.f2075c = 0.0f;
                    return;
                } else {
                    f7 = f(fLog2);
                    fC = c(fLog2);
                }
            }
            if (i2 > 999.0f) {
                this.f2075c = -1.0f;
            } else {
                this.f2075c = fLog2;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class c extends d {

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        float f2068g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        float f2069h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        float f2070i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        float f2071j;

        c(float f2, float f3, float f4, float f5) {
            super();
            this.f2068g = f2;
            this.f2069h = f3;
            this.f2071j = f4;
            this.f2070i = f5;
            g();
        }

        @Override // q.b.d
        public float b() {
            return this.f2075c;
        }

        @Override // q.b.d
        public float c(float f2) {
            float fPow = (float) Math.pow(2.718281828459045d, this.f2070i * f2);
            float fCos = (float) Math.cos(this.f2071j * f2);
            float fSin = (float) Math.sin(this.f2071j * f2);
            float f3 = this.f2069h;
            float f4 = this.f2071j;
            float f5 = this.f2068g;
            float f6 = ((((f3 * f4) * fCos) - ((f4 * f5) * fSin)) * fPow) + (this.f2070i * fPow * ((f3 * fSin) + (f5 * fCos)));
            this.f2074b = f6;
            return f6;
        }

        @Override // q.b.d
        public float f(float f2) {
            float fPow = ((float) Math.pow(2.718281828459045d, this.f2070i * f2)) * ((this.f2068g * ((float) Math.cos(this.f2071j * f2))) + (this.f2069h * ((float) Math.sin(this.f2071j * f2))));
            this.f2076d = fPow;
            return fPow;
        }

        public final void g() {
            t.a.a("SpringEstimateUtils", "Solution3 doEstimateDuration");
            b bVar = b.this;
            float f2 = bVar.f2051h;
            float fSqrt = (float) Math.sqrt((f2 * f2) / ((bVar.f2053j * 4.0f) * bVar.f2052i));
            b bVar2 = b.this;
            float fSqrt2 = (float) Math.sqrt(bVar2.f2052i / bVar2.f2053j);
            float fSqrt3 = ((float) Math.sqrt(1.0f - (fSqrt * fSqrt))) * fSqrt2;
            float f3 = 3.1415927f / fSqrt3;
            float fAtan = (float) Math.atan(this.f2069h / this.f2068g);
            if (Float.isNaN(fAtan)) {
                this.f2075c = 0.0f;
                return;
            }
            float fAcos = ((((float) Math.acos(0.0d)) + fAtan) % 3.1415927f) / this.f2071j;
            float fC = c(fAcos);
            b.this.f2058o = fC;
            t.a.a("SpringEstimateUtils", "Solution3 curVelocity=" + b.this.f2058o);
            float fAcos2 = (((((float) Math.acos(0.0d)) + ((float) Math.atan((double) (fSqrt3 / (fSqrt * fSqrt2))))) + fAtan) % 3.1415927f) / fSqrt3;
            int i2 = 0;
            float f4 = 0.0f;
            while (Math.abs(fC) > b.this.f2046c) {
                int i3 = i2 + 1;
                if (i2 >= 999.0f) {
                    i2 = i3;
                    break;
                }
                fAcos += f3;
                fC = c(fAcos);
                f4 += f3;
                fAcos2 += f3;
                i2 = i3;
            }
            float fA = -1.0f;
            if (i2 >= 999.0f) {
                this.f2075c = -1.0f;
                return;
            }
            if ((f4 <= fAcos2 && fAcos2 < fAcos) || f4 == fAcos) {
                fA = a(fAcos2, f3 + fAcos2);
                t.a.a("SpringEstimateUtils", "res=" + fA);
            } else if (f4 < fAcos && fAcos < fAcos2) {
                fA = a(Math.max(0.0f, fAcos2 - f3), fAcos2);
            }
            this.f2075c = fA;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private abstract class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        protected float f2073a = 0.0f;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        protected float f2074b = 0.0f;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        protected float f2075c = 0.0f;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        protected float f2076d = 0.0f;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private float[] f2077e = new float[17];

        protected d() {
        }

        private float d(float f2, float f3) {
            if (f2 <= 999.0f) {
                return f3;
            }
            return -1.0f;
        }

        /* JADX WARN: Code duplicated, block: B:15:0x004a  */
        private float e(float f2, float f3, float f4) {
            float f5;
            float f6 = (f4 - f3) / b.this.f2054k;
            t.a.a("SpringEstimateUtils", "delta=" + f6);
            boolean z2 = c((f4 + f3) / 2.0f) > 0.0f;
            for (int i2 = 1; i2 < 17; i2++) {
                float[] fArr = this.f2077e;
                float f7 = fArr[i2];
                int i3 = i2 - 1;
                float f8 = fArr[i3];
                float f9 = f7 - f8;
                if (!z2 || f7 < f2) {
                    if (!z2 && f7 <= f2) {
                        if (f9 == 0.0f) {
                            f5 = i3;
                        } else {
                            f5 = i2 - ((f7 - f2) / f9);
                        }
                    }
                } else if (f9 == 0.0f) {
                    f5 = i3;
                } else {
                    f5 = i3 + ((f2 - f8) / f9);
                }
                return f3 + (f5 * f6);
            }
            return f4;
        }

        public float a(float f2, float f3) {
            float f4;
            float f5 = (f3 - f2) / b.this.f2054k;
            float f6 = b.this.f2045b;
            for (int i2 = 0; i2 < 17; i2++) {
                this.f2077e[i2] = f((i2 * f5) + f2);
            }
            boolean z2 = true;
            int i3 = 1;
            while (true) {
                f4 = 0.0f;
                if (i3 >= 17) {
                    z2 = false;
                    break;
                }
                float[] fArr = this.f2077e;
                float f7 = fArr[i3 - 1];
                float f8 = b.this.f2045b;
                float f9 = fArr[i3];
                if ((f7 - f8) * (f9 - f8) < 0.0f) {
                    f6 = f8;
                    break;
                }
                if ((f7 + f8) * (f9 + f8) < 0.0f) {
                    f6 = -f8;
                    break;
                }
                i3++;
            }
            if (!z2) {
                return f2;
            }
            float fE = e(f6, f2, f3);
            while (true) {
                float f10 = fE;
                float f11 = f3;
                f3 = f10;
                float fAbs = Math.abs(f(f3));
                b bVar = b.this;
                if (fAbs >= bVar.f2045b || f11 - f3 < 0.0625f) {
                    break;
                }
                float f12 = (f3 - f2) / bVar.f2054k;
                for (int i4 = 0; i4 < 17; i4++) {
                    this.f2077e[i4] = f((i4 * f12) + f2);
                }
                fE = e(f6, f2, f3);
            }
            float f13 = f(f3);
            float fC = c(f3);
            while (Math.abs(f13) > b.this.f2045b) {
                float f14 = 1.0f + f4;
                if (f4 >= 999.0f) {
                    f4 = f14;
                    break;
                }
                f3 -= f13 / fC;
                f13 = f(f3);
                fC = c(f3);
                f4 = f14;
            }
            return d(f4, f3);
        }

        public abstract float b();

        public abstract float c(float f2);

        public abstract float f(float f2);
    }

    public b(Context context) {
        this.f2056m = null;
        this.f2056m = new WeakReference(context);
        k(g());
    }

    private void h(p.c cVar) {
        double dA;
        double dB;
        if (cVar.f2024e == 0) {
            dA = cVar.f2020a;
            dB = cVar.f2021b;
        } else {
            double d2 = cVar.f2023d;
            double d3 = cVar.f2022c;
            dA = u.a.a(d2, d3);
            dB = u.a.b(d3);
        }
        this.f2052i = Math.min(Math.max(1.0f, (float) dB), 999.0f);
        this.f2051h = Math.min(Math.max(1.0f, (float) dA), 99.0f);
    }

    private void i() {
        t.a.a("SpringEstimateUtils", "setMaxDeltaTimeSec");
        WeakReference weakReference = this.f2056m;
        if (weakReference == null) {
            t.a.a("SpringEstimateUtils", "null == mContextWeakReference");
            return;
        }
        Context context = (Context) weakReference.get();
        if (context == null) {
            t.a.a("SpringEstimateUtils", "null == context");
            return;
        }
        int iC = t.b.c(context);
        this.f2055l = iC;
        if (iC == 30) {
            this.f2054k = 33.0f;
        } else if (iC == 60) {
            this.f2054k = 16.0f;
        } else if (iC == 72) {
            this.f2054k = 14.0f;
        } else if (iC == 90) {
            this.f2054k = 11.0f;
        } else if (iC == 120) {
            this.f2054k = 8.0f;
        } else if (iC == 144) {
            this.f2054k = 7.0f;
        }
        t.a.a("SpringEstimateUtils", "DELTA_TIME_SEC=" + this.f2054k);
    }

    public boolean d(float f2, float f3, float f4) {
        return f2 > f3 - f4;
    }

    public boolean e(float f2, float f3, float f4) {
        return f2 < f3 - f4;
    }

    public float f() {
        float fB = this.f2057n.b();
        if (Float.compare(fB, -1.0f) == 0) {
            return 500.0f;
        }
        return fB * 1000.0f;
    }

    public float g() {
        return this.f2044a * 0.75f;
    }

    public void j(float f2, float f3, int i2, p.c cVar, float f4, float f5) {
        i();
        this.f2053j = 1.0f;
        h(cVar);
        this.f2057n = null;
        this.f2048e = f2;
        this.f2047d = f3;
        this.f2050g = i2;
        this.f2049f = 0L;
        l(f4, f5);
        this.f2057n = m(this.f2048e - this.f2047d, this.f2050g);
        this.f2049f = SystemClock.elapsedRealtime();
    }

    public b k(float f2) {
        float fAbs = Math.abs(f2);
        this.f2045b = fAbs;
        this.f2046c = (float) (((double) fAbs) * 62.5d);
        return this;
    }

    public b l(float f2, float f3) {
        this.f2045b = Math.abs(f2);
        this.f2046c = f3;
        return this;
    }

    public d m(float f2, float f3) {
        t.a.a("SpringEstimateUtils", "solve : s=" + f2 + " , velocity=" + f3);
        float f4 = this.f2051h;
        float f5 = this.f2053j;
        float f6 = f4 * f4;
        float f7 = 4.0f * f5 * this.f2052i;
        float f8 = f6 - f7;
        int iCompare = Float.compare(f6, f7);
        t.a.a("SpringEstimateUtils", "compare=" + iCompare);
        if (iCompare == 0) {
            float f9 = (-f4) / (f5 * 2.0f);
            return new a(f2, f3 - (f9 * f2), f9);
        }
        if (iCompare <= 0) {
            float f10 = f5 * 2.0f;
            float fSqrt = (float) (Math.sqrt(((double) f7) - ((double) f6)) / ((double) f10));
            float f11 = (-f4) / f10;
            return new c(f2, (f3 - (f11 * f2)) / fSqrt, fSqrt, f11);
        }
        double d2 = -f4;
        double d3 = f8;
        double d4 = f5 * 2.0f;
        float fSqrt2 = (float) ((d2 - Math.sqrt(d3)) / d4);
        float fSqrt3 = (float) ((d2 + Math.sqrt(d3)) / d4);
        float f12 = (f3 - (fSqrt2 * f2)) / (fSqrt3 - fSqrt2);
        return new C0022b(f2 - f12, f12, fSqrt2, fSqrt3);
    }
}
