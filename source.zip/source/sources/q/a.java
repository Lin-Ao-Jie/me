package q;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f2037a = Float.MIN_VALUE;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f2038b = Float.MIN_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private float f2039c = 0.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private float f2040d = 2.2f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private float f2041e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private float f2042f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float f2043g;

    private float c() {
        return 3.2f;
    }

    private float d() {
        return 1.157f;
    }

    private float e() {
        return Math.abs((float) (Math.log(((double) this.f2037a) / 2000.0d) / ((double) this.f2040d)));
    }

    public float a() {
        if (this.f2038b == 0.0f) {
            t.a.b("FlingEstimateUtils", "StartVelocity shouldn't be 0");
            return 0.0f;
        }
        if (this.f2040d == 0.0f) {
            t.a.b("FlingEstimateUtils", "Friction shouldn't be 0");
            return 0.0f;
        }
        float f2 = f(this.f2042f);
        this.f2043g = f2;
        return f2;
    }

    public float b() {
        if (this.f2038b == 0.0f) {
            t.a.b("FlingEstimateUtils", "StartVelocity shouldn't be 0");
            return 0.0f;
        }
        if (this.f2040d == 0.0f) {
            t.a.b("FlingEstimateUtils", "Friction shouldn't be 0");
            return 0.0f;
        }
        float fC = c();
        float f2 = this.f2038b;
        if (f2 >= 2000.0d || fC <= this.f2040d) {
            float fLog = (float) (Math.log(this.f2037a / f2) / ((double) this.f2040d));
            this.f2042f = fLog;
            float fAbs = Math.abs(fLog);
            this.f2042f = fAbs;
            this.f2042f = (fAbs - e()) + d();
        } else {
            float fLog2 = (float) (Math.log(this.f2037a / f2) / ((double) fC));
            this.f2042f = fLog2;
            this.f2042f = Math.abs(fLog2);
        }
        return this.f2042f * 1000.0f;
    }

    public float f(float f2) {
        float f3 = this.f2041e;
        float f4 = this.f2038b;
        float f5 = this.f2040d;
        return f3 * ((float) (((double) (f4 / (-f5))) * (Math.exp((-f5) * f2) - 1.0d)));
    }

    public void g(float f2, float f3, float f4, float f5) {
        this.f2037a = f4;
        this.f2038b = Math.abs(f3);
        this.f2040d = f5;
        this.f2041e = Math.signum(f3);
        this.f2039c = f2;
    }
}
