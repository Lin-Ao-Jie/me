package d;

import android.content.Context;
import com.originui.core.utils.j;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static float a(Context context, int i2) {
        float fB = b(i2);
        return context.getApplicationContext().getResources().getConfiguration().fontScale > fB ? fB : context.getApplicationContext().getResources().getConfiguration().fontScale;
    }

    public static float b(int i2) {
        float[] fArrC = c();
        if (fArrC.length == 0) {
            return 1.0f;
        }
        if (i2 <= 0) {
            return fArrC[0];
        }
        return fArrC.length >= i2 ? fArrC[i2 - 1] : fArrC[fArrC.length - 1];
    }

    public static float[] c() {
        return j.d();
    }
}
