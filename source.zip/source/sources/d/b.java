package d;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import com.originui.core.utils.p;
import com.originui.widget.button.R$anim;
import com.originui.widget.button.R$styleable;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {
    private static final int C = Color.parseColor("#B2B2B2");
    private int A;
    ViewGroup B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f1442a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private AnimatorSet f1443b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private AnimatorSet f1444c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1445d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1446e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private Interpolator f1447f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Interpolator f1448g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f1449h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float f1450i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1451j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f1452k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float f1453l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f1454m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f1455n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f1456o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f1457p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1458q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f1459r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private int f1460s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f1461t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private float f1462u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private int f1463v = 0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f1464w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private int f1465x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private Paint f1466y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private long f1467z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements ValueAnimator.AnimatorUpdateListener {
        a() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1456o = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            b bVar = b.this;
            bVar.q(bVar.f1456o);
        }
    }

    /* JADX INFO: renamed from: d.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class C0009b implements ValueAnimator.AnimatorUpdateListener {
        C0009b() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1462u = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            b.this.B.invalidate();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements ValueAnimator.AnimatorUpdateListener {
        c() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1449h = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements ValueAnimator.AnimatorUpdateListener {
        d() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1450i = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e implements ValueAnimator.AnimatorUpdateListener {
        e() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1453l = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f implements ValueAnimator.AnimatorUpdateListener {
        f() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1456o = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            b bVar = b.this;
            bVar.q(bVar.f1456o);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g implements ValueAnimator.AnimatorUpdateListener {
        g() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            b.this.f1462u = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            b.this.B.invalidate();
        }
    }

    public b(Context context, AttributeSet attributeSet, int i2, int i3, ViewGroup viewGroup) {
        this.f1451j = 0.95f;
        this.f1452k = 0.95f;
        this.f1454m = 0.3f;
        this.f1457p = false;
        this.f1458q = false;
        this.f1459r = -11035400;
        this.f1460s = p.a(3.0f);
        this.f1461t = p.a(2.0f);
        this.f1464w = false;
        this.f1465x = 0;
        this.A = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.AnimLayout, i2, i3);
        this.f1445d = typedArrayObtainStyledAttributes.getInteger(R$styleable.AnimLayout_durationDown, 200);
        this.f1446e = typedArrayObtainStyledAttributes.getInteger(R$styleable.AnimLayout_durationUp, 200);
        this.B = viewGroup;
        this.f1447f = (PathInterpolator) AnimationUtils.loadInterpolator(context, typedArrayObtainStyledAttributes.getResourceId(R$styleable.AnimLayout_interpolatorDown, R$anim.originui_anim_touch_down_interpolator_rom13_0));
        this.f1448g = (PathInterpolator) AnimationUtils.loadInterpolator(context, typedArrayObtainStyledAttributes.getResourceId(R$styleable.AnimLayout_interpolatorUp, R$anim.originui_anim_touch_up_interpolator_rom13_0));
        this.f1451j = typedArrayObtainStyledAttributes.getFloat(R$styleable.AnimLayout_scaleX, 0.95f);
        this.f1452k = typedArrayObtainStyledAttributes.getFloat(R$styleable.AnimLayout_scaleY, 0.95f);
        this.f1442a = typedArrayObtainStyledAttributes.getBoolean(R$styleable.AnimLayout_enableAnim, false);
        this.f1454m = typedArrayObtainStyledAttributes.getFloat(R$styleable.AnimLayout_alpahEnd, this.f1454m);
        this.f1455n = typedArrayObtainStyledAttributes.getColor(R$styleable.AnimLayout_shadowColorEnd, Color.parseColor("#b2b2b2"));
        this.A = typedArrayObtainStyledAttributes.getInt(R$styleable.AnimLayout_animType, this.A);
        this.f1460s = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.AnimLayout_strokeWidth, this.f1460s);
        this.f1461t = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.AnimLayout_strokeEndWidth, this.f1461t);
        this.f1457p = typedArrayObtainStyledAttributes.getBoolean(R$styleable.AnimLayout_strokeEnable, this.f1457p);
        this.f1458q = typedArrayObtainStyledAttributes.getBoolean(R$styleable.AnimLayout_strokeAnimEnable, this.f1458q);
        this.f1462u = this.f1460s;
        this.f1464w = typedArrayObtainStyledAttributes.getBoolean(R$styleable.AnimLayout_filletEnable, this.f1464w);
        this.f1465x = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.AnimLayout_cornerFillet, this.f1465x);
        this.f1459r = typedArrayObtainStyledAttributes.getColor(R$styleable.AnimLayout_strokeColor, this.f1459r);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void j() {
        n();
        AnimatorSet animatorSetG = g();
        this.f1443b = animatorSetG;
        if (animatorSetG != null) {
            animatorSetG.start();
        }
    }

    private void k() {
        AnimatorSet animatorSet = this.f1443b;
        if (animatorSet != null) {
            this.f1467z = animatorSet.getCurrentPlayTime();
        } else {
            this.f1467z = 0L;
        }
        n();
        AnimatorSet animatorSetH = h();
        this.f1444c = animatorSetH;
        if (animatorSetH != null) {
            animatorSetH.start();
        }
    }

    private int m(int i2, float f2) {
        return (16777215 & i2) | (((int) (Color.alpha(i2) * f2)) << 24);
    }

    private void n() {
        AnimatorSet animatorSet = this.f1443b;
        if (animatorSet != null && animatorSet.isRunning()) {
            this.f1443b.cancel();
        }
        AnimatorSet animatorSet2 = this.f1444c;
        if (animatorSet2 == null || !animatorSet2.isRunning()) {
            return;
        }
        this.f1444c.cancel();
    }

    protected AnimatorSet g() {
        AnimatorSet animatorSet = new AnimatorSet();
        ValueAnimator valueAnimatorOfArgb = ValueAnimator.ofArgb(C, this.f1455n);
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.f1460s, this.f1461t);
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this.B, "scaleX", 1.0f, this.f1451j);
        ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this.B, "scaleY", 1.0f, this.f1452k);
        ObjectAnimator objectAnimatorOfFloat3 = ObjectAnimator.ofFloat(this.B, "alpha", 1.0f, this.f1454m);
        if ((this.A & 1) != 0) {
            animatorSet.playTogether(objectAnimatorOfFloat);
            animatorSet.playTogether(objectAnimatorOfFloat2);
        }
        if ((this.A & 4) != 0) {
            animatorSet.playTogether(objectAnimatorOfFloat3);
        }
        if ((2 & this.A) != 0) {
            animatorSet.playTogether(valueAnimatorOfArgb);
        }
        if ((this.A & 8) != 0 && this.f1457p && this.f1458q) {
            animatorSet.playTogether(valueAnimatorOfFloat);
        }
        animatorSet.setDuration(this.f1445d);
        animatorSet.setInterpolator(this.f1447f);
        valueAnimatorOfArgb.addUpdateListener(new a());
        valueAnimatorOfFloat.addUpdateListener(new C0009b());
        objectAnimatorOfFloat.addUpdateListener(new c());
        objectAnimatorOfFloat2.addUpdateListener(new d());
        objectAnimatorOfFloat3.addUpdateListener(new e());
        return animatorSet;
    }

    protected AnimatorSet h() {
        AnimatorSet animatorSet = new AnimatorSet();
        ValueAnimator valueAnimatorOfArgb = ValueAnimator.ofArgb(this.f1456o, C);
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.f1462u, this.f1460s);
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this.B, "scaleX", this.f1449h, 1.0f);
        ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this.B, "scaleY", this.f1450i, 1.0f);
        ObjectAnimator objectAnimatorOfFloat3 = ObjectAnimator.ofFloat(this.B, "alpha", this.f1453l, 1.0f);
        if ((this.A & 1) != 0) {
            animatorSet.playTogether(objectAnimatorOfFloat);
            animatorSet.playTogether(objectAnimatorOfFloat2);
        }
        if ((this.A & 4) != 0) {
            animatorSet.playTogether(objectAnimatorOfFloat3);
        }
        if ((2 & this.A) != 0) {
            animatorSet.playTogether(valueAnimatorOfArgb);
        }
        if ((this.A & 8) != 0 && this.f1457p && this.f1458q) {
            animatorSet.playTogether(valueAnimatorOfFloat);
        }
        long j2 = this.f1467z;
        if (j2 > 0) {
            animatorSet.setDuration(j2);
        } else {
            animatorSet.setDuration(this.f1446e);
        }
        animatorSet.setInterpolator(this.f1448g);
        valueAnimatorOfArgb.addUpdateListener(new f());
        valueAnimatorOfFloat.addUpdateListener(new g());
        return animatorSet;
    }

    public void i(MotionEvent motionEvent) {
        if (this.B.isEnabled() && this.f1442a && (this.A & 15) != 0) {
            int action = motionEvent.getAction();
            if (action == 0) {
                j();
            } else if (action == 1 || action == 3 || action == 4) {
                k();
            }
        }
    }

    public void l(Canvas canvas) {
        if (this.f1457p) {
            if (this.f1466y == null) {
                this.f1466y = new Paint(3);
            }
            this.f1466y.setStyle(Paint.Style.STROKE);
            this.f1466y.setColor(this.B.isEnabled() ? this.f1459r : m(this.f1459r, 0.3f));
            this.f1466y.setStrokeWidth(this.f1462u);
            int i2 = this.f1460s;
            float f2 = i2 / 2;
            float f3 = i2 / 2;
            float width = this.B.getWidth() - (this.f1460s / 2);
            float height = this.B.getHeight() - (this.f1460s / 2);
            int i3 = this.f1463v;
            canvas.drawRoundRect(f2, f3, width, height, i3, i3, this.f1466y);
        }
    }

    public void o(boolean z2) {
        this.f1442a = z2;
    }

    public void p(int i2) {
        this.A = i2;
    }

    public void q(int i2) {
        this.B.setBackgroundTintList(ColorStateList.valueOf(i2));
        this.B.setBackgroundTintMode(PorterDuff.Mode.MULTIPLY);
    }
}
