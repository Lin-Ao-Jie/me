package d;

import com.originui.widget.button.R$color;
import com.originui.widget.button.R$dimen;
import com.originui.widget.button.R$integer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    public static int A() {
        return R$color.originui_button_state_fill_color_rom14_0;
    }

    public static int B() {
        return R$integer.originui_button_sub_text_font_rom13_0;
    }

    public static int C() {
        return R$color.originui_button_stroke_color_rom13_0;
    }

    public static int a() {
        return R$dimen.originui_button_m_l_xl_min_text_size_rom15_0;
    }

    public static int b() {
        return R$dimen.originui_button_m_l_xl_row_min_text_size_rom15_0;
    }

    public static int c() {
        return R$color.originui_button_fill_gray_text_color_rom13_0;
    }

    public static int d() {
        return R$dimen.originui_button_l_xl_down_padding_top_bottom;
    }

    public static int e() {
        return R$dimen.originui_button_fading_edge_length_rom15_0;
    }

    public static int f() {
        return R$dimen.originui_button_l_radius_rom15_0;
    }

    public static int g() {
        return R$dimen.originui_button_m_radius_rom15_0;
    }

    public static int h() {
        return R$dimen.originui_button_s_radius_rom15_0;
    }

    public static int i() {
        return R$color.originui_button_stroke_color_rom13_0;
    }

    public static int j() {
        return R$dimen.originui_button_s_min_text_size_rom15_0;
    }

    public static int k() {
        return R$dimen.originui_button_s_row_min_text_size_rom15_0;
    }

    public static int l() {
        return R$dimen.originui_button_state_fillet_rom15_0;
    }

    public static int m() {
        return R$dimen.originui_button_state_single_fillet_rom15_0;
    }

    public static int n() {
        return R$dimen.originui_button_min_sub_text_size_rom15_0;
    }

    public static int o() {
        return R$dimen.originui_button_sub_text_size_rom15_0;
    }

    public static int p() {
        return R$color.originui_button_fill_blue_color_rom13_0;
    }

    public static int q() {
        return R$color.originui_button_fill_blue_text_color_rom13_0;
    }

    public static int r() {
        return R$color.originui_button_fab_fill_main_color_rom16_0;
    }

    public static int s() {
        return R$color.originui_button_fill_alpha_blue_color_rom13_0;
    }

    public static int t() {
        return R$color.originui_button_fill_alpha_blue_text_color_rom13_0;
    }

    public static int u() {
        return R$integer.originui_button_text_font_rom13_0;
    }

    public static int v() {
        return R$color.originui_button_fill_gray_color_rom13_0;
    }

    public static int w() {
        return R$color.originui_button_fill_gray_color_4_pad;
    }

    public static int x(boolean z2, int i2) {
        if (z2) {
            return R$dimen.originui_button_xl_min_height_4_pad;
        }
        return i2 == 1 ? R$dimen.originui_button_xl_min_height_text_rom13_0 : R$dimen.originui_button_xl_min_height_rom13_0;
    }

    public static int y() {
        return R$color.originui_button_multiline_main_title_text_color_rom15_0;
    }

    public static int z() {
        return R$color.originui_button_multiline_sub_title_text_color_rom15_0;
    }
}
