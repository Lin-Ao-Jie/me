package f0;

import com.vivo.vmdri.VmdriLog;
import java.util.Base64;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1622a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public byte[] f1623b;

    private static void a(String str) {
        VmdriLog.e("CommMessage", str);
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a("Error parsing JSON CommMessage object" + e2.toString());
            return null;
        }
    }

    public static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1622a = jSONObject.optInt("bTp", 0);
            aVar.f1623b = !jSONObject.isNull("dt") ? Base64.getDecoder().decode(jSONObject.getString("dt")) : null;
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSON CommMessage object" + e2.toString());
            return null;
        }
    }

    public JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            int i2 = this.f1622a;
            if (i2 >= 0) {
                jSONObject.put("bTp", i2);
            }
            if (this.f1623b != null) {
                jSONObject.put("dt", Base64.getEncoder().encodeToString(this.f1623b));
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting CommMessage to JSONObject" + e2.toString());
        }
        return jSONObject;
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CommMessage{businessType=");
        sb.append(this.f1622a);
        sb.append(", dataLen=");
        byte[] bArr = this.f1623b;
        sb.append(bArr == null ? "null" : Integer.valueOf(bArr.length));
        sb.append('}');
        return sb.toString();
    }
}
