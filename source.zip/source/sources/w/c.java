package w;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public i f2195a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f2196b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f2197c;

    public c(i iVar, int i2) {
        this.f2195a = iVar;
        this.f2196b = i2;
    }

    public String a() {
        return this.f2197c;
    }

    public int b() {
        return this.f2196b;
    }

    public String c() {
        i iVar = this.f2195a;
        return iVar == null ? "" : iVar.d();
    }

    public void d(String str) {
        this.f2197c = str;
    }

    public String toString() {
        return "[remoteDevId:" + c() + " errorCode:" + e.a(this.f2196b) + " conflictAppName:" + this.f2197c + "]";
    }
}
