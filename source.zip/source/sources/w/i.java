package w;

import com.vivo.vmdri.VmdriLog;
import java.util.Objects;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final String f2223a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final int f2224b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final String f2225c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final String f2226d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f2227e;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f2229b;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f2232e;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private String f2228a = "";

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private String f2230c = "";

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private String f2231d = "";

        public i f() {
            return new i(this);
        }

        public a g(int i2) {
            this.f2232e = i2;
            return this;
        }

        public a h(String str) {
            this.f2230c = str;
            return this;
        }

        public a i(String str) {
            this.f2228a = str;
            return this;
        }

        public a j(int i2) {
            this.f2229b = i2;
            return this;
        }

        public a k(String str) {
            this.f2231d = str;
            return this;
        }
    }

    public i() {
        this.f2223a = "";
        this.f2224b = 0;
        this.f2225c = "";
        this.f2226d = "";
    }

    private static void l(String str) {
        VmdriLog.d("SdkDevInfo", str);
    }

    public static i m(i iVar) {
        return new a().i(iVar.f2223a).j(iVar.f2224b).h(iVar.f2225c).k(iVar.f2226d).g(iVar.f2227e).f();
    }

    public boolean a(int i2) {
        return b(p.g(i2));
    }

    public boolean b(int i2) {
        boolean z2;
        l("addConnTypeBitMask start " + this + ", add:" + p.e(i2));
        int i3 = this.f2227e;
        int i4 = i2 | i3;
        if (i4 != i3) {
            this.f2227e = i4;
            z2 = true;
        } else {
            z2 = false;
        }
        l("addConnectType end " + this.f2225c + ", now:" + p.e(this.f2227e) + ", changed:" + z2);
        return z2;
    }

    public int c() {
        return this.f2227e;
    }

    public String d() {
        return this.f2225c;
    }

    public String e() {
        return this.f2223a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            i iVar = (i) obj;
            if (this.f2224b == iVar.f2224b && this.f2227e == iVar.f2227e && Objects.equals(this.f2223a, iVar.f2223a) && Objects.equals(this.f2225c, iVar.f2225c) && Objects.equals(this.f2226d, iVar.f2226d)) {
                return true;
            }
        }
        return false;
    }

    public int f() {
        return this.f2224b;
    }

    public String g() {
        return this.f2226d;
    }

    public boolean h() {
        return (this.f2227e & 4) == 4;
    }

    public int hashCode() {
        return Objects.hash(this.f2223a, Integer.valueOf(this.f2224b), this.f2225c, this.f2226d, Integer.valueOf(this.f2227e));
    }

    public boolean i() {
        return (this.f2227e & 1) == 1;
    }

    public boolean j() {
        return (this.f2227e & 2) == 2;
    }

    public boolean k() {
        return this.f2227e != 0;
    }

    public boolean n(int i2) {
        return o(p.g(i2));
    }

    public boolean o(int i2) {
        boolean z2;
        l("removeConnTypeBitMask start " + this + ", remove:" + p.e(i2));
        int i3 = this.f2227e;
        int i4 = (~i2) & i3;
        if (i4 != i3) {
            this.f2227e = i4;
            z2 = true;
        } else {
            z2 = false;
        }
        l("removeConnTypeBitMask end " + this.f2225c + ", now:" + p.e(this.f2227e) + ", changed:" + z2);
        return z2;
    }

    public void p(int i2) {
        this.f2227e = i2;
    }

    public String toString() {
        return "SdkDevInfo{mDeviceName='" + this.f2223a + "', mDeviceType=" + p.k(this.f2224b) + ", mDeviceId='" + this.f2225c + "', mOpenId='" + this.f2226d + "', mConnTypeBitMask=(" + Integer.toBinaryString(this.f2227e) + ")" + p.e(this.f2227e) + '}';
    }

    public i(a aVar) {
        this.f2223a = aVar.f2228a;
        this.f2224b = aVar.f2229b;
        this.f2225c = aVar.f2230c;
        this.f2226d = aVar.f2231d;
        this.f2227e = aVar.f2232e;
    }
}
