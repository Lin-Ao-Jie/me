package w;

import java.util.Objects;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f2219a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f2220b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f2221c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f2222d;

    public h(int i2, int i3, int i4, int i5) {
        this.f2219a = i2;
        this.f2220b = i3;
        this.f2221c = i4;
        this.f2222d = i5;
    }

    public int a() {
        return this.f2222d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            h hVar = (h) obj;
            if (this.f2219a == hVar.f2219a && this.f2220b == hVar.f2220b && this.f2221c == hVar.f2221c) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return Objects.hash(Integer.valueOf(this.f2219a), Integer.valueOf(this.f2220b), Integer.valueOf(this.f2221c));
    }

    public String toString() {
        return "RilRequestKey{serial=" + this.f2219a + ", moduleId=" + this.f2220b + ", slotId=" + this.f2221c + ", messageId=" + this.f2222d + '}';
    }
}
