package w;

import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import com.vivo.vmdri.VmdriLog;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class j extends ContentObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Map f2233a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Context f2234b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Handler f2235c;

    public j(Context context, Handler handler) {
        super(null);
        this.f2233a = new HashMap();
        this.f2234b = context;
        this.f2235c = handler;
    }

    private static void a(String str) {
        VmdriLog.e("SettingsObserver", str);
    }

    public void b(Uri uri, int i2) {
        this.f2233a.put(uri, Integer.valueOf(i2));
        this.f2234b.getContentResolver().registerContentObserver(uri, false, this);
    }

    public void c() {
        this.f2234b.getContentResolver().unregisterContentObserver(this);
    }

    @Override // android.database.ContentObserver
    public void onChange(boolean z2) {
        a("Should never be reached.");
    }

    @Override // android.database.ContentObserver
    public void onChange(boolean z2, Uri uri) {
        Integer num = (Integer) this.f2233a.get(uri);
        if (num != null) {
            this.f2235c.obtainMessage(num.intValue()).sendToTarget();
            return;
        }
        a("No matching event to send for URI=" + uri);
    }
}
