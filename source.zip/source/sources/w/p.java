package w;

import android.text.TextUtils;
import java.util.function.IntFunction;
import java.util.function.IntPredicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class p {
    public static /* synthetic */ boolean c(long j2, int i2) {
        return (j2 & ((long) h(i2))) == ((long) h(i2));
    }

    public static /* synthetic */ boolean d(long j2, int i2) {
        return (j2 & ((long) g(i2))) == ((long) g(i2));
    }

    public static String e(final long j2) {
        String str = (String) IntStream.rangeClosed(1, 3).filter(new IntPredicate() { // from class: w.l
            @Override // java.util.function.IntPredicate
            public final boolean test(int i2) {
                return p.d(j2, i2);
            }
        }).mapToObj(new IntFunction() { // from class: w.m
            @Override // java.util.function.IntFunction
            public final Object apply(int i2) {
                return p.j(i2);
            }
        }).collect(Collectors.joining("|"));
        return TextUtils.isEmpty(str) ? "UNKNOWN" : str;
    }

    public static String f(final long j2) {
        String str = (String) IntStream.rangeClosed(1, 4).filter(new IntPredicate() { // from class: w.n
            @Override // java.util.function.IntPredicate
            public final boolean test(int i2) {
                return p.c(j2, i2);
            }
        }).mapToObj(new IntFunction() { // from class: w.o
            @Override // java.util.function.IntFunction
            public final Object apply(int i2) {
                return p.m(i2);
            }
        }).collect(Collectors.joining("|"));
        return TextUtils.isEmpty(str) ? "UNKNOWN" : str;
    }

    public static int g(int i2) {
        int i3 = 1;
        if (i2 != 1) {
            i3 = 2;
            if (i2 != 2) {
                return i2 != 3 ? 0 : 4;
            }
        }
        return i3;
    }

    public static int h(int i2) {
        int i3 = 1;
        if (i2 != 1) {
            i3 = 2;
            if (i2 != 2) {
                if (i2 != 3) {
                    return i2 != 4 ? 0 : 8;
                }
                return 4;
            }
        }
        return i3;
    }

    public static String i(int i2) {
        if (i2 == 0) {
            return "UNKNOWN";
        }
        if (i2 == 1) {
            return "CONNECTED";
        }
        if (i2 == 2) {
            return "DISCONNECTED";
        }
        return "UNKNOWN(" + i2 + ")";
    }

    public static String j(int i2) {
        if (i2 == 0) {
            return "UNKNOWN";
        }
        if (i2 == 1) {
            return "BR";
        }
        if (i2 == 2) {
            return "P2P";
        }
        if (i2 == 3) {
            return "BASE_TUNNEL";
        }
        return "UNKNOWN(" + i2 + ")";
    }

    public static String k(int i2) {
        if (i2 == 1) {
            return "PHONE";
        }
        if (i2 == 2) {
            return "PAD";
        }
        return "UNSUPPORTED DEVICE(" + i2 + ")";
    }

    public static String l(int i2) {
        if (i2 == 0) {
            return "UNKNOWN";
        }
        if (i2 == 1) {
            return "ALIVE";
        }
        if (i2 == 2) {
            return "DIED";
        }
        return "UNKNOWN(" + i2 + ")";
    }

    public static String m(int i2) {
        if (i2 == 0) {
            return "UNKNOWN";
        }
        if (i2 == 1) {
            return "CALL";
        }
        if (i2 == 2) {
            return "SMS";
        }
        if (i2 == 3) {
            return "DATA";
        }
        if (i2 == 4) {
            return "AUTO_CONN";
        }
        return "UNKNOWN(" + i2 + ")";
    }
}
