package w;

import android.text.TextUtils;
import com.vivo.commshare.CommDevInfo;
import com.vivo.vmdri.DeviceParcel;
import com.vivo.vmdri.P2pInfoParcel;
import com.vivo.vmdri.VmdriConfig;
import com.vivo.vmdri.VmdriVersion;
import d0.y;
import java.util.Objects;
import vendor.vivo.hardware.radio.vmdri.HwDeviceParcel;
import vendor.vivo.hardware.radio.vmdri.HwP2pInfoParcel;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f2198a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private VmdriVersion f2199b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private VmdriVersion f2200c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f2201d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private String f2202e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private long f2203f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private String f2204g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f2205h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private String f2206i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private String f2207j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private String f2208k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f2209l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f2210m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f2211n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private boolean f2212o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f2213p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f2214q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f2215r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    i f2216s;

    public d(d dVar) {
        this.f2204g = "";
        this.f2206i = "";
        this.f2207j = "";
        this.f2208k = "Disabled";
        this.f2216s = new i();
        e(dVar);
    }

    public boolean A() {
        return this.f2209l;
    }

    public boolean B() {
        return j() == 2;
    }

    public boolean C() {
        return j() == 1;
    }

    public boolean D() {
        return this.f2210m;
    }

    public boolean E() {
        return this.f2213p;
    }

    public boolean F() {
        return this.f2212o;
    }

    public void G(boolean z2) {
        this.f2211n = z2;
    }

    public void H(boolean z2) {
        this.f2214q = z2;
    }

    public void I(int i2) {
        this.f2216s.p(i2);
    }

    public void J(boolean z2) {
        this.f2209l = z2;
    }

    public void K(String str) {
        this.f2204g = str;
    }

    public void L(String str) {
        this.f2206i = str;
    }

    public void M(String str) {
        this.f2207j = str;
    }

    public void N(String str) {
        this.f2208k = str;
    }

    public void O(boolean z2) {
        this.f2210m = z2;
    }

    public void P(i iVar) {
        this.f2216s = iVar;
    }

    public void Q(int i2) {
        this.f2215r = i2;
    }

    public void R(int i2) {
        this.f2205h = i2;
    }

    public void S(boolean z2) {
        this.f2213p = z2;
    }

    public void T(boolean z2) {
        this.f2212o = z2;
    }

    public CommDevInfo a() {
        CommDevInfo commDevInfo = new CommDevInfo();
        commDevInfo.version = q().getVersionName();
        commDevInfo.deviceId = i();
        commDevInfo.deviceType = j();
        commDevInfo.deviceName = h();
        commDevInfo.openId = l();
        commDevInfo.connTypeBitmask = f();
        commDevInfo.p2pIfName = m();
        commDevInfo.p2pIp = o();
        return commDevInfo;
    }

    public DeviceParcel b() {
        DeviceParcel deviceParcel = new DeviceParcel();
        deviceParcel.deviceId = i();
        deviceParcel.deviceType = j();
        return deviceParcel;
    }

    public HwDeviceParcel c() {
        HwDeviceParcel hwDeviceParcel = new HwDeviceParcel();
        hwDeviceParcel.deviceId = i();
        hwDeviceParcel.deviceType = j();
        return hwDeviceParcel;
    }

    public k0.a d() {
        k0.a aVar = new k0.a();
        aVar.f1791a = i();
        aVar.f1792b = g();
        aVar.f1794d = t();
        aVar.f1795e = m();
        aVar.f1796f = o();
        aVar.f1797g = p();
        aVar.f1798h = s();
        aVar.f1799i = A();
        aVar.f1800j = D();
        aVar.f1801k = x();
        aVar.f1802l = F();
        aVar.f1803m = E();
        aVar.f1804n = z();
        return aVar;
    }

    protected void e(d dVar) {
        this.f2198a = dVar.f2198a;
        this.f2199b = dVar.f2199b;
        this.f2200c = dVar.f2200c;
        this.f2201d = dVar.f2201d;
        this.f2202e = dVar.f2202e;
        this.f2203f = dVar.f2203f;
        this.f2216s = i.m(dVar.f2216s);
        this.f2204g = dVar.g();
        this.f2205h = dVar.f2205h;
        this.f2206i = dVar.f2206i;
        this.f2207j = dVar.f2207j;
        this.f2208k = dVar.f2208k;
        this.f2215r = dVar.f2215r;
        this.f2209l = dVar.f2209l;
        this.f2210m = dVar.f2210m;
        this.f2211n = dVar.f2211n;
        this.f2212o = dVar.f2212o;
        this.f2213p = dVar.f2213p;
        this.f2214q = dVar.f2214q;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            d dVar = (d) obj;
            if (this.f2198a == dVar.f2198a && this.f2203f == dVar.f2203f && this.f2205h == dVar.f2205h && this.f2209l == dVar.f2209l && this.f2210m == dVar.f2210m && this.f2211n == dVar.f2211n && this.f2212o == dVar.f2212o && this.f2213p == dVar.f2213p && this.f2214q == dVar.f2214q && this.f2215r == dVar.f2215r && Objects.equals(this.f2199b, dVar.f2199b) && Objects.equals(this.f2200c, dVar.f2200c) && Objects.equals(this.f2201d, dVar.f2201d) && Objects.equals(this.f2202e, dVar.f2202e) && Objects.equals(this.f2204g, dVar.f2204g) && Objects.equals(this.f2206i, dVar.f2206i) && Objects.equals(this.f2207j, dVar.f2207j) && Objects.equals(this.f2216s, dVar.f2216s) && Objects.equals(this.f2208k, dVar.f2208k)) {
                return true;
            }
        }
        return false;
    }

    public int f() {
        return this.f2216s.c();
    }

    public String g() {
        return this.f2204g;
    }

    public String h() {
        return !TextUtils.isEmpty(this.f2204g) ? this.f2204g : this.f2216s.e();
    }

    public int hashCode() {
        return Objects.hash(Boolean.valueOf(this.f2198a), this.f2199b, this.f2200c, this.f2201d, this.f2202e, Long.valueOf(this.f2203f), this.f2204g, Integer.valueOf(this.f2205h), this.f2206i, this.f2207j, this.f2208k, Boolean.valueOf(this.f2209l), Boolean.valueOf(this.f2210m), Boolean.valueOf(this.f2211n), Boolean.valueOf(this.f2212o), Boolean.valueOf(this.f2213p), Boolean.valueOf(this.f2214q), Integer.valueOf(this.f2215r), this.f2216s);
    }

    public String i() {
        return this.f2216s.d();
    }

    public int j() {
        return this.f2216s.f();
    }

    public HwP2pInfoParcel k() {
        HwP2pInfoParcel hwP2pInfoParcel = new HwP2pInfoParcel();
        hwP2pInfoParcel.p2pIf = m();
        hwP2pInfoParcel.p2pIp = o();
        return hwP2pInfoParcel;
    }

    public String l() {
        return this.f2216s.g();
    }

    public String m() {
        return this.f2206i;
    }

    public P2pInfoParcel n() {
        P2pInfoParcel p2pInfoParcel = new P2pInfoParcel();
        p2pInfoParcel.p2pIf = m();
        p2pInfoParcel.p2pIp = o();
        return p2pInfoParcel;
    }

    public String o() {
        return this.f2207j;
    }

    public String p() {
        return this.f2208k;
    }

    public VmdriVersion q() {
        return this.f2199b;
    }

    public i r() {
        return this.f2216s;
    }

    public int s() {
        return this.f2215r;
    }

    public int t() {
        return this.f2205h;
    }

    public String toString() {
        return "DeviceState{mIsLocal=" + this.f2198a + ", mDeviceInfo=" + this.f2216s + ", mDevName=" + this.f2204g + ", mRealVersion='" + this.f2199b + "', mUseVersion='" + this.f2200c + "', mSysBuildVersion='" + this.f2201d + "', mVmdriBuildVersionName='" + this.f2202e + "', mVmdriBuildVersionCode=" + this.f2203f + ", mP2pIf='" + this.f2206i + "', mP2pIp='" + this.f2207j + "', mP2pState='" + this.f2208k + "', mScreenOn=" + this.f2210m + ", mVmdriSwitchBitmask=(" + this.f2205h + ")" + p.f(this.f2205h) + ", hasSim=" + this.f2215r + ", dataEnable=" + this.f2209l + ", airplane=" + this.f2211n + ", bluetooth=" + this.f2214q + ", mWifiApOn=" + this.f2213p + ", wifiOn=" + this.f2212o + '}';
    }

    public VmdriVersion u() {
        return this.f2200c;
    }

    public boolean v() {
        return (f() & 1) == 1;
    }

    public boolean w() {
        return (f() & 2) == 2;
    }

    public boolean x() {
        return this.f2211n;
    }

    public boolean y() {
        return (t() & 8) == 8;
    }

    public boolean z() {
        return this.f2214q;
    }

    public d(i iVar, VmdriVersion vmdriVersion, String str, String str2, long j2) {
        this(false);
        this.f2216s = iVar;
        this.f2199b = vmdriVersion;
        this.f2200c = y.b(vmdriVersion, VmdriConfig.sLocalVersion);
        this.f2201d = str;
        this.f2202e = str2;
        this.f2203f = j2;
    }

    public d(VmdriVersion vmdriVersion, String str, String str2, long j2) {
        this(true);
        this.f2199b = vmdriVersion;
        this.f2201d = str;
        this.f2202e = str2;
        this.f2203f = j2;
    }

    public d(boolean z2) {
        this.f2204g = "";
        this.f2206i = "";
        this.f2207j = "";
        this.f2208k = "Disabled";
        this.f2216s = new i();
        this.f2198a = z2;
        if (z2) {
            this.f2199b = VmdriConfig.sLocalVersion;
        }
    }
}
