package w;

import android.os.Message;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f2236a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f2237b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f2238c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f2239d;

    public k(Object obj, Object obj2, int i2, String str) {
        this.f2236a = obj;
        this.f2237b = obj2;
        this.f2238c = i2;
        this.f2239d = str;
    }

    public static k a(Message message, Object obj, int i2, String str) {
        k kVar = new k(message.obj, obj, i2, str);
        message.obj = kVar;
        return kVar;
    }

    public String toString() {
        return "VmdriAsyncResult{userObj=" + this.f2236a + ", result=" + this.f2237b + ", errCode=" + this.f2238c + ", errStr='" + this.f2239d + "'}";
    }
}
