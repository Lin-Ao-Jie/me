package w;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {
    public static String a(int i2) {
        if (i2 == 0) {
            return "NONE";
        }
        if (i2 >= 5000) {
            return "RIL_INTERNAL_ERROR_START";
        }
        if (i2 == 1) {
            return "GENERIC_FAILURE";
        }
        if (i2 == 2) {
            return "NOT_SUPPORTED";
        }
        if (i2 == 3) {
            return "DEVICE_NOT_CONN";
        }
        if (i2 == 4) {
            return "LOCAL_NOT_READY";
        }
        if (i2 == 6) {
            return "RESP_TIME_OUT";
        }
        if (i2 == 7) {
            return "SDK_ERROR";
        }
        if (i2 == 8) {
            return "TYPE_ERROR";
        }
        if (i2 == 9) {
            return "CHANNEL_NOT_CONN";
        }
        if (i2 == 10) {
            return "RESP_NOT_REQUEST_CACHE";
        }
        if (i2 == 11) {
            return "TOO_LARGE_PACKET";
        }
        if (i2 == 13) {
            return "LOCAL_MAX_PREFER_DEV_REACHED";
        }
        if (i2 == 14) {
            return "REMOTE_MAX_PREFER_DEV_REACHED";
        }
        if (i2 == 15) {
            return "BOTH_MAX_PREFER_DEV_REACHED";
        }
        if (i2 == 16) {
            return "LOCAL_ON_AIRPLANE_MODE";
        }
        if (i2 == 17) {
            return "REMOTE_ON_AIRPLANE_MODE";
        }
        if (i2 == 18) {
            return "BOTH_ON_AIRPLANE_MODE";
        }
        if (i2 == 19) {
            return "LOCAL_NOT_SIM";
        }
        if (i2 == 20) {
            return "REMOTE_NOT_SIM";
        }
        if (i2 == 21) {
            return "ALREADY_COMM_SHARING";
        }
        if (i2 == 239) {
            return "STATUS_LOCAL_P2P_AP_BUSY";
        }
        if (i2 == 244) {
            return "STATUS_LOCAL_P2P_CONNECTING_CONFLICT";
        }
        if (i2 == 245) {
            return "STATUS_REMOTE_P2P_CONNECTING_CONFLICT";
        }
        if (i2 == 246) {
            return "STATUS_LOCAL_P2P_CONNECTED_CONFLICT";
        }
        if (i2 == 247) {
            return "STATUS_REMOTE_P2P_CONNECTED_CONFLICT";
        }
        if (i2 == 249) {
            return "STATUS_P2P_PCCONFLICT_ERROR";
        }
        if (i2 == 270) {
            return "NEWSTATUS_LOCAL_P2P_AP_BUSY";
        }
        if (i2 == 276) {
            return "STATUS_AUTO_CONNECT_REMOTE_P2P_CONNECTED_CONFLICT";
        }
        if (i2 == -408) {
            return "CODE_OTHER_P2P_CONNECTED";
        }
        if (i2 == 23) {
            return "CURRENT_IN_TARGETING";
        }
        if (i2 == 24) {
            return "ALL_PHYSICAL_DISCONNECTED";
        }
        if (i2 == 25) {
            return "DEV_STATE_SYN_TIMEOUT";
        }
        if (i2 == 26) {
            return "SETUP_BR_CONN_TIME_OUT";
        }
        if (i2 == 27) {
            return "VMDRI_NOT_READY";
        }
        if (i2 == 28) {
            return "DEV_NOT_CONNECT";
        }
        if (i2 == 29) {
            return "UNEXPECTED_PREEMPTION";
        }
        if (i2 == 30) {
            return "UNEXPECTED_DUPLICATE_TARGET";
        }
        if (i2 == 31) {
            return "DEV_STOP_TIMEOUT";
        }
        if (i2 == 32) {
            return "START_REQUEST_HAS_PROCESSED";
        }
        if (i2 == 33) {
            return "LOCAL_RIL_SERVICE_NOT_BOUND";
        }
        if (i2 == 34) {
            return "LOCAL_CAPABILITY_SERVICE_NOT_BOUND";
        }
        if (i2 == 35) {
            return "REMOTE_DEV_NOT_CONN";
        }
        if (i2 == 36) {
            return "CTRL_INVALID_RESPONSE";
        }
        if (i2 == 37) {
            return "CTRL_GENERIC_FAILURE";
        }
        if (i2 == 38) {
            return "CTRL_NOT_SUPPORTED";
        }
        if (i2 == 39) {
            return "REMOTE_DEV_NOT_FOUND";
        }
        if (i2 == 40) {
            return "REMOTE_NOT_REEVALUATE_ME";
        }
        if (i2 == 41) {
            return "REMOTE_RIL_SERVICE_NOT_BOUND";
        }
        if (i2 == 42) {
            return "REMOTE_CAPABILITY_SERVICE_NOT_BOUND";
        }
        return "UNKNOWN(" + Integer.toString(i2) + ")";
    }

    public static boolean b(int i2) {
        return i2 == 239 || i2 == 244 || i2 == 245 || i2 == 246 || i2 == 247 || i2 == 249 || i2 == 270 || i2 == 276 || i2 == -408;
    }
}
