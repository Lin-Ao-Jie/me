package w;

import android.annotation.NonNull;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    @NonNull
    private final Executor mExecutor;

    public a(Executor executor) {
        this.mExecutor = executor;
    }

    @NonNull
    public Executor getExecutor() {
        return this.mExecutor;
    }

    public void invokeFromExecutor(@NonNull Runnable runnable) {
        this.mExecutor.execute(runnable);
    }
}
