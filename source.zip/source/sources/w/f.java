package w;

import com.android.internal.util.Preconditions;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private List f2217a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f2218b;

    public f(int i2) {
        Preconditions.checkArgument(i2 > 0, "maxSize (%s) must > 0", new Object[]{Integer.valueOf(i2)});
        this.f2217a = new ArrayList(i2);
        this.f2218b = i2;
    }

    public boolean a(Object obj) {
        obj.getClass();
        int size = this.f2217a.size();
        int i2 = this.f2218b;
        if (size == i2) {
            this.f2217a.remove(i2 - 1);
        }
        this.f2217a.add(0, obj);
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("size:");
        sb.append(this.f2217a.size());
        sb.append(", maxSize:");
        sb.append(this.f2218b);
        sb.append("[");
        for (int i2 = 0; i2 < this.f2217a.size(); i2++) {
            sb.append(this.f2217a.get(i2).toString());
            if (i2 != this.f2217a.size() - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
