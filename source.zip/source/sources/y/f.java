package y;

import a0.g0;
import a0.w;
import android.content.Context;
import android.os.AsyncResult;
import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemProperties;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.client.ril.RilRespException;
import java.util.Objects;
import java.util.concurrent.Executor;
import vendor.vivo.hardware.radio.vmdri.HwDeviceParcel;
import vendor.vivo.hardware.radio.vmdri.HwP2pInfoParcel;
import vendor.vivo.hardware.radio.vmdri.IRilClientHandle;
import vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle;
import w.p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class f extends Handler {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final boolean f2284p = SystemProperties.getBoolean("persist.vmdri.debug", false);

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final byte[] f2285q = new byte[0];

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f2286a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private b f2287b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final com.vivo.vmdri.ctrl.h f2288c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final g0 f2289d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final c f2290e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final DependentServiceController f2291f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final o f2292g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private g f2293h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private IRilClientHandle f2294i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f2296k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private w.d f2297l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private final y.b f2298m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f2299n;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final Object f2295j = new Object();

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private w.d f2300o = new w.d(true);

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends DependentServiceController.DependentServiceCallback {
        a(Executor executor) {
            super(executor);
        }

        @Override // com.vivo.vmdri.DependentServiceController.DependentServiceCallback
        public void tryStartBindDependentService() {
            if (f.this.f2294i == null) {
                f.y("tryStartBindDependentService connectRildService");
                f.this.f2292g.o();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class b extends Handler {
        public b(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                f.z("unsupported message type:" + message.what);
                return;
            }
            Object obj = message.obj;
            if (obj == null) {
                f.z("EVENT_ASYNC_REQUEST_DONE msg.obj is null!");
                return;
            }
            AsyncResult asyncResult = (AsyncResult) obj;
            C0028f c0028f = (C0028f) asyncResult.userObj;
            Object obj2 = asyncResult.result;
            m0.a aVar = obj2 == null ? null : (m0.a) obj2;
            Throwable th = asyncResult.exception;
            f.this.x(c0028f, aVar, th != null ? (RilRespException) th : null);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class c extends w {
        public c(Executor executor) {
            super(executor);
        }

        @Override // a0.w
        public void c(w.d dVar) {
            super.c(dVar);
            w.d dVar2 = f.this.f2300o;
            f.this.f2300o = dVar;
            f.y("onLocalDeviceStateChanged, oldLocalDevState:" + dVar2 + ", newLocalDevState:" + dVar);
            if (f.this.f2297l == null) {
                return;
            }
            String strM = dVar.m();
            String strO = dVar.o();
            String strM2 = dVar2.m();
            String strO2 = dVar2.o();
            if (!Objects.equals(strM, strM2) || !Objects.equals(strO, strO2)) {
                f fVar = f.this;
                fVar.C(fVar.f2300o.m(), f.this.f2300o.o());
            }
            int iT = dVar.t();
            if (iT != dVar2.t()) {
                f fVar2 = f.this;
                fVar2.I(fVar2.f2297l.i(), f.this.f2297l.t(), iT);
            }
        }

        @Override // a0.w
        public void d(w.d dVar, boolean z2) {
            super.d(dVar, z2);
            f.y("onRemoteDeviceConnected: " + dVar + ", isUserTarget:" + z2);
            synchronized (f.this.f2295j) {
                try {
                    if (f.this.f2297l == null) {
                        f.this.f2297l = dVar;
                        f.this.f2298m.b(dVar);
                        f.this.K(dVar.i());
                        f.this.A(dVar);
                        return;
                    }
                    f.z("serious error! client can only connect to one device, old:" + f.this.f2297l + ", new:" + dVar);
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // a0.w
        public void e(w.d dVar, boolean z2) {
            super.e(dVar, z2);
            f.y("onRemoteDeviceDisconnected, oldRemoteDevState:" + f.this.f2297l + ", newRemoteDevState:" + dVar + ", isUserTarget:" + z2);
            synchronized (f.this.f2295j) {
                try {
                    if (f.this.f2297l != null && Objects.equals(f.this.f2297l.i(), dVar.i())) {
                        f.this.B(dVar);
                        f.this.f2298m.c();
                        f.this.N(0);
                        f.this.f2297l = null;
                        return;
                    }
                    f.z("serious error! disconnect the device repeatedly, or disconnect a device that has not been connected before!, old:" + f.this.f2297l + ", new:" + dVar);
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // a0.w
        public void f(w.d dVar) {
            super.f(dVar);
            String strI = dVar.i();
            synchronized (f.this.f2295j) {
                try {
                    f.y("onRemoteDeviceStateChanged, newRemoteDevState:" + dVar + ", oldServerDevice:" + f.this.f2297l);
                    if (f.this.f2297l != null && Objects.equals(f.this.f2297l.i(), strI)) {
                        w.d dVar2 = f.this.f2297l;
                        f.this.f2297l = dVar;
                        String strM = dVar.m();
                        String strO = dVar.o();
                        String strM2 = dVar2.m();
                        String strO2 = dVar2.o();
                        if (!Objects.equals(strM, strM2) || !Objects.equals(strO, strO2)) {
                            f.this.D(strI, strM, strO);
                        }
                        int iT = dVar.t();
                        if (iT != dVar2.t()) {
                            f.this.I(strI, iT, f.this.f2300o.t());
                        }
                        if (dVar.D() != dVar2.D()) {
                            f.this.E(strI, dVar.D());
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class d extends g0 {
        public d(Executor executor) {
            super(executor);
        }

        @Override // a0.g0
        public void c(String str, int i2) {
            super.c(str, i2);
            f.y("onRilStateIndication, remoteDevId:" + str + ", rilState:" + i2);
            f.this.M(str, i2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class e extends y.b.C0027b {
        @Override // y.b.C0027b
        public void a(String str, m0.a aVar) {
            f.this.G(str, aVar);
        }

        private e() {
        }
    }

    /* JADX INFO: renamed from: y.f$f, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private static final class C0028f {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f2306a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f2307b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f2308c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f2309d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public byte[] f2310e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public byte[] f2311f;

        public C0028f(int i2, int i3, int i4, int i5, byte[] bArr) {
            this.f2306a = i2;
            this.f2307b = i3;
            this.f2309d = i5;
            this.f2308c = i4;
            this.f2310e = bArr;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("RilRequestRecord{moduleId=");
            sb.append(this.f2306a);
            sb.append(", slotId=");
            sb.append(this.f2307b);
            sb.append(", serial=");
            sb.append(this.f2309d);
            sb.append(", messageId=");
            sb.append(this.f2308c);
            sb.append(", reqDataLen=");
            byte[] bArr = this.f2310e;
            sb.append(bArr == null ? "null" : Integer.valueOf(bArr.length));
            sb.append(", respData=");
            byte[] bArr2 = this.f2311f;
            sb.append(bArr2 != null ? Integer.valueOf(bArr2.length) : "null");
            sb.append('}');
            return sb.toString();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private final class g extends o.b {
        public g(Executor executor) {
            super(executor);
        }

        @Override // y.o.b
        public void a(IRilClientHandle iRilClientHandle) {
            f.y("onConnected(rild):" + iRilClientHandle);
            f.this.f2294i = iRilClientHandle;
            try {
                f.this.f2294i.registerVmdriClientHandle(new h());
            } catch (RemoteException | RuntimeException e2) {
                f.z("onConnected ex:" + e2);
            }
            synchronized (f.this.f2295j) {
                try {
                    if (f.this.f2297l != null) {
                        f fVar = f.this;
                        fVar.A(fVar.f2297l);
                        f fVar2 = f.this;
                        fVar2.K(fVar2.f2297l.i());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // y.o.b
        public void b(String str) {
            f.y("onConnectedFailed(rild) reason:" + str);
        }

        @Override // y.o.b
        public void c() {
            f.y("onDisconnect(rild)");
            synchronized (f.this.f2295j) {
                f.this.L(0);
                f.this.f2294i = null;
            }
            f.this.f2292g.o();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class h extends IVmdriClientHandle.Stub {
        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public void clientRilReady() {
            f.this.L(1);
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public String getInterfaceHash() {
            return "f6cd1a2562f9e3a2e5c511f6d8d97b8272cc87d9";
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public int getInterfaceVersion() {
            return 1;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public HwDeviceParcel getLocalDeviceInfo() {
            HwDeviceParcel hwDeviceParcelC = f.this.f2300o.c();
            f.y("getLocalDeviceInfo, hwDeviceParcel:" + hwDeviceParcelC);
            return hwDeviceParcelC;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public HwP2pInfoParcel getLocalP2pInfo() {
            HwP2pInfoParcel hwP2pInfoParcelK = f.this.f2300o.k();
            f.y("getLocalP2pInfo, hwP2pInfoParcel:" + hwP2pInfoParcelK);
            return hwP2pInfoParcelK;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public HwDeviceParcel getRemoteDeviceInfo() {
            HwDeviceParcel hwDeviceParcelC = f.this.f2297l.c();
            f.y("getRemoteDeviceInfo, hwDeviceParcel:" + hwDeviceParcelC);
            return hwDeviceParcelC;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public HwP2pInfoParcel getRemoteP2pInfo() {
            HwP2pInfoParcel hwP2pInfoParcelK;
            synchronized (f.this.f2295j) {
                try {
                    hwP2pInfoParcelK = f.this.f2297l != null ? f.this.f2297l.k() : new HwP2pInfoParcel();
                } catch (Throwable th) {
                    throw th;
                }
            }
            f.y("getRemoteP2pInfo, mServerDevice: " + f.this.f2297l + ", hwP2pInfoParcel:" + hwP2pInfoParcelK);
            return hwP2pInfoParcelK;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public boolean getRemoteScreenState() {
            boolean zD;
            synchronized (f.this.f2295j) {
                try {
                    zD = f.this.f2297l != null ? f.this.f2297l.D() : false;
                } catch (Throwable th) {
                    throw th;
                }
            }
            f.y("getRemoteScreenState, " + zD + ", mServerDevice:" + f.this.f2297l);
            return zD;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public int getSwitchState() {
            int iT;
            synchronized (f.this.f2295j) {
                try {
                    if (f.this.f2297l != null) {
                        iT = f.this.f2300o.t() & f.this.f2297l.t();
                    } else {
                        iT = 0;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            f.y("get switch:" + p.f(iT));
            return iT;
        }

        @Override // vendor.vivo.hardware.radio.vmdri.IVmdriClientHandle
        public void sendASyncReqRilMsg(int i2, int i3, int i4, int i5, byte[] bArr, long j2) {
            if (VmdriLog.isFullDebugLevel()) {
                StringBuilder sb = new StringBuilder();
                sb.append("sendASyncReqRilMsg moduleId:");
                sb.append(i2);
                sb.append(", slotId:");
                sb.append(i3);
                sb.append(", messageId:");
                sb.append(i4);
                sb.append(", serial:");
                sb.append(i5);
                sb.append(", reqBuffLen:");
                sb.append(bArr != null ? Integer.valueOf(bArr.length) : null);
                sb.append(", timeoutInMs:");
                sb.append(j2);
                f.y(sb.toString());
            }
            f.this.J(i2, i3, i4, i5, bArr, j2);
        }

        private h() {
        }
    }

    public f(Context context, Looper looper, com.vivo.vmdri.ctrl.h hVar) {
        y("init");
        this.f2286a = context;
        this.f2288c = hVar;
        this.f2287b = new b(looper);
        this.f2298m = new y.b(context, looper, new e());
        final b bVar = this.f2287b;
        bVar.getClass();
        g0 dVar = new d(new Executor() { // from class: y.c
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                bVar.post(runnable);
            }
        });
        this.f2289d = dVar;
        final b bVar2 = this.f2287b;
        bVar2.getClass();
        c cVar = new c(new Executor() { // from class: y.c
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                bVar2.post(runnable);
            }
        });
        this.f2290e = cVar;
        hVar.g(cVar);
        hVar.b(dVar);
        this.f2293h = new g(new Executor() { // from class: y.d
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f2282a.post(runnable);
            }
        });
        o oVar = new o(context);
        this.f2292g = oVar;
        oVar.v(this.f2293h);
        DependentServiceController dependentServiceController = DependentServiceController.getInstance();
        this.f2291f = dependentServiceController;
        dependentServiceController.registerDependentServiceCallback(new a(new Executor() { // from class: y.e
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f2283a.postAtFrontOfQueue(runnable);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A(w.d dVar) {
        y("notifyDeviceConnected, remoteDevice:" + dVar + ", localDevState:" + this.f2300o + ", remoteRilState:" + this.f2296k);
        if (this.f2294i == null) {
            z("notifyDeviceConnected RilClientHandle is null!");
            return;
        }
        try {
            this.f2294i.onRemoteDeviceConnected(dVar.c(), dVar.u().getVersionName());
            IRilClientHandle iRilClientHandle = this.f2294i;
            boolean z2 = true;
            if (this.f2296k != 1) {
                z2 = false;
            }
            iRilClientHandle.onRemoteServerRilReady(z2);
            this.f2294i.onRemoteScreenStateChanged(dVar.D());
            this.f2294i.onRemoteP2pInfoChanged(dVar.k());
            this.f2294i.onSwitchStateChanged(dVar.t() & this.f2300o.t());
            this.f2294i.onLocalP2pInfoChanged(this.f2300o.k());
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void B(w.d dVar) {
        y("notifyDeviceDisconnected:" + dVar);
        if (this.f2294i == null) {
            z("notifyDeviceDisconnected RilClientHandle is null!");
            return;
        }
        try {
            this.f2294i.onRemoteDeviceDisconnected(dVar.c());
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void C(String str, String str2) {
        y("notifyLocalP2pInfoChanged p2pIf:" + str + ", p2pIp:" + str2);
        if (this.f2294i == null) {
            z("notifyLocalP2pInfoChanged RilClientHandle is null!");
            return;
        }
        try {
            HwP2pInfoParcel hwP2pInfoParcel = new HwP2pInfoParcel();
            hwP2pInfoParcel.p2pIf = str;
            hwP2pInfoParcel.p2pIp = str2;
            this.f2294i.onLocalP2pInfoChanged(hwP2pInfoParcel);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void D(String str, String str2, String str3) {
        y("notifyRemoteP2pInfoChanged remoteDevId:" + str + ", p2pIf:" + str2 + ", p2pIp:" + str3);
        if (this.f2294i == null) {
            z("notifyRemoteP2pInfoChanged RilClientHandle is null!");
            return;
        }
        try {
            HwP2pInfoParcel hwP2pInfoParcel = new HwP2pInfoParcel();
            hwP2pInfoParcel.p2pIf = str2;
            hwP2pInfoParcel.p2pIp = str3;
            this.f2294i.onRemoteP2pInfoChanged(hwP2pInfoParcel);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void E(String str, boolean z2) {
        y("notifyRemoteScreenStateChanged remoteDevId:" + str + ", screenOn:" + z2);
        IRilClientHandle iRilClientHandle = this.f2294i;
        if (iRilClientHandle == null) {
            z("notifyRemoteScreenStateChanged RilClientHandle is null!");
            return;
        }
        try {
            iRilClientHandle.onRemoteScreenStateChanged(z2);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    private void F(String str, boolean z2) {
        y("notifyRemoteServerRilReady, remoteDevId:" + str + ", ready:" + z2);
        IRilClientHandle iRilClientHandle = this.f2294i;
        if (iRilClientHandle == null) {
            z("notifyRemoteServerRilReady RilClientHandle is null!");
            return;
        }
        try {
            iRilClientHandle.onRemoteServerRilReady(z2);
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void G(String str, m0.a aVar) {
        if (VmdriLog.isFullDebugLevel()) {
            y("notifyRilIndication remoteDevId:" + str + ", msg:" + aVar);
        }
        IRilClientHandle iRilClientHandle = this.f2294i;
        if (iRilClientHandle == null) {
            z("notifyRilIndication RilClientHandle is null, drop data!");
            return;
        }
        try {
            iRilClientHandle.onRecvRilIndication(aVar.f1831a, aVar.f1832b, aVar.f1833c, aVar.f1836f);
        } catch (RemoteException | RuntimeException e2) {
            z("indicationData error: " + e2);
        }
    }

    private void H(int i2, int i3, int i4, int i5, int i6, byte[] bArr) {
        if (VmdriLog.isFullDebugLevel()) {
            StringBuilder sb = new StringBuilder();
            sb.append("notifyRilResponse, errCode:");
            sb.append(i2);
            sb.append(", moduleId:");
            sb.append(i3);
            sb.append(", slotId:");
            sb.append(i4);
            sb.append(", messageId:");
            sb.append(i5);
            sb.append(", serial:");
            sb.append(i6);
            sb.append(", respDataLen=");
            sb.append(bArr == null ? "null" : Integer.valueOf(bArr.length));
            y(sb.toString());
        }
        IRilClientHandle iRilClientHandle = this.f2294i;
        if (iRilClientHandle == null) {
            z("notifyRilResponse RilClientHandle is null, drop data!");
            return;
        }
        try {
            iRilClientHandle.onRecvRilResponse(i2, i3, i4, i5, i6, bArr);
        } catch (RemoteException | RuntimeException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I(String str, int i2, int i3) {
        y("notifySwitchChanged remoteDevId:" + str + ", remoteSwitch:" + p.f(i2) + ", localSwitch:" + p.f(i3));
        IRilClientHandle iRilClientHandle = this.f2294i;
        if (iRilClientHandle == null) {
            z("notifySwitchChanged RilClientHandle is null!");
            return;
        }
        try {
            iRilClientHandle.onSwitchStateChanged(i2 & i3);
        } catch (RemoteException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K(String str) {
        this.f2288c.c1(str, this.f2299n);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L(int i2) {
        y("setLocalRilState, rilState:" + i2 + ", uid:" + Binder.getCallingUid() + ", pid:" + Binder.getCallingPid());
        synchronized (this.f2295j) {
            try {
                this.f2299n = i2;
                w.d dVar = this.f2297l;
                if (dVar != null) {
                    K(dVar.i());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean M(String str, int i2) {
        synchronized (this.f2295j) {
            try {
                w.d dVar = this.f2297l;
                if (dVar != null && dVar.i().equals(str)) {
                    N(i2);
                    boolean z2 = true;
                    if (i2 != 1) {
                        z2 = false;
                    }
                    F(str, z2);
                    return false;
                }
                z("setRemoteRilModuleState a wrong device ID remoteDevId:" + str + ", remoteRilState:" + i2 + ", mServerDevice:" + this.f2297l);
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean N(int i2) {
        boolean z2;
        synchronized (this.f2295j) {
            try {
                if (this.f2296k != i2) {
                    this.f2296k = i2;
                    z2 = true;
                } else {
                    z2 = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return z2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void x(C0028f c0028f, m0.a aVar, RilRespException rilRespException) {
        byte[] bArr;
        if (VmdriLog.isFullDebugLevel()) {
            y("handleAsyncRilResponse, rilReqRecord" + c0028f + ", rilRespMsg:" + aVar + ", exception:" + rilRespException);
        }
        int errCode = rilRespException != null ? rilRespException.getErrCode() : 0;
        byte[] bArr2 = f2285q;
        if (aVar != null && (bArr = aVar.f1836f) != null) {
            bArr2 = bArr;
        }
        H(errCode, c0028f.f2306a, c0028f.f2307b, c0028f.f2308c, c0028f.f2309d, bArr2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void y(String str) {
        VmdriLog.d("RilClientManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void z(String str) {
        VmdriLog.e("RilClientManager", str);
    }

    public int J(int i2, int i3, int i4, int i5, byte[] bArr, long j2) {
        C0028f c0028f = new C0028f(i2, i3, i4, i5, bArr);
        return this.f2298m.h(new m0.a(c0028f.f2306a, c0028f.f2307b, c0028f.f2308c, c0028f.f2309d, 1, c0028f.f2310e), this.f2287b.obtainMessage(1, c0028f), j2);
    }
}
