package y;

import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.ArraySet;
import com.vivo.vmdri.DependentServiceController;
import com.vivo.vmdri.ThreadManager;
import com.vivo.vmdri.VmdriLog;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import vendor.vivo.hardware.radio.vmdri.IRilClientHandle;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f2321a;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private IRilClientHandle f2325e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private a f2326f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f2328h;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Set f2323c = new ArraySet();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final Object f2327g = new Object();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Handler f2322b = new c(ThreadManager.getsVmdriCommLooper());

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final DependentServiceController f2324d = DependentServiceController.getInstance();

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    final class a implements IBinder.DeathRecipient {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private IBinder f2329a;

        a() {
        }

        public static /* synthetic */ void a(final b bVar) {
            bVar.getClass();
            bVar.invokeFromExecutor(new Runnable() { // from class: y.n
                @Override // java.lang.Runnable
                public final void run() {
                    bVar.c();
                }
            });
        }

        public void b(IBinder iBinder) throws RemoteException {
            if (iBinder != null) {
                this.f2329a = iBinder;
                iBinder.linkToDeath(this, 0);
            }
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            o.s("RildService has died.");
            synchronized (o.this.f2327g) {
                o.this.f2324d.setRilBound(false);
                o.this.f2328h = false;
                o.this.f2323c.forEach(new Consumer() { // from class: y.m
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        o.a.a((o.b) obj);
                    }
                });
                o.this.w();
            }
        }

        public synchronized void c() {
            IBinder iBinder = this.f2329a;
            if (iBinder != null) {
                try {
                    iBinder.unlinkToDeath(this, 0);
                } catch (NoSuchElementException unused) {
                }
                this.f2329a = null;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class b extends w.a {
        public b(Executor executor) {
            super(executor);
        }

        public abstract void a(IRilClientHandle iRilClientHandle);

        public abstract void b(String str);

        public abstract void c();
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class c extends Handler {
        public c(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what == 1) {
                o.this.n();
                return;
            }
            o.t("unsupported message:" + message.what);
        }
    }

    public o(Context context) {
        this.f2321a = context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean n() {
        synchronized (this.f2327g) {
            try {
                if (this.f2325e != null) {
                    u("already bind rild now!");
                    return true;
                }
                s("try to get vivo rild IRilClientHandle");
                IBinder iBinderWaitForDeclaredService = ServiceManager.waitForDeclaredService(IRilClientHandle.DESCRIPTOR + "/default");
                IRilClientHandle iRilClientHandleAsInterface = IRilClientHandle.Stub.asInterface(iBinderWaitForDeclaredService);
                this.f2325e = iRilClientHandleAsInterface;
                if (iRilClientHandleAsInterface == null) {
                    this.f2323c.forEach(new Consumer() { // from class: y.i
                        @Override // java.util.function.Consumer
                        public final void accept(Object obj) {
                            o.b bVar = (o.b) obj;
                            bVar.invokeFromExecutor(new Runnable() { // from class: y.k
                                @Override // java.lang.Runnable
                                public final void run() {
                                    bVar.b("conn vivo rild svc failed");
                                }
                            });
                        }
                    });
                    return false;
                }
                this.f2324d.setRilBound(true);
                a aVar = new a();
                this.f2326f = aVar;
                try {
                    aVar.b(iBinderWaitForDeclaredService);
                } catch (Exception e2) {
                    t("linkToDeath Exception:" + e2);
                }
                this.f2323c.forEach(new Consumer() { // from class: y.j
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        this.f2316a.q((o.b) obj);
                    }
                });
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void p(b bVar) {
        bVar.a(this.f2325e);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void q(final b bVar) {
        bVar.invokeFromExecutor(new Runnable() { // from class: y.l
            @Override // java.lang.Runnable
            public final void run() {
                this.f2318a.p(bVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void r(b bVar) {
        bVar.a(this.f2325e);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void s(String str) {
        VmdriLog.d("RildManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void t(String str) {
        VmdriLog.e("RildManager", str);
    }

    private static void u(String str) {
        VmdriLog.w("RildManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void w() {
        a aVar = this.f2326f;
        if (aVar != null) {
            aVar.c();
        }
        this.f2326f = null;
        this.f2325e = null;
    }

    public void o() {
        synchronized (this.f2327g) {
            try {
                if (this.f2325e != null) {
                    return;
                }
                if (this.f2328h) {
                    return;
                }
                this.f2322b.sendEmptyMessage(1);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void v(final b bVar) {
        synchronized (this.f2327g) {
            try {
                this.f2323c.add(bVar);
                if (this.f2325e != null) {
                    bVar.invokeFromExecutor(new Runnable() { // from class: y.h
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f2314a.r(bVar);
                        }
                    });
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
