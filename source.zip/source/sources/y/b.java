package y;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import c0.r;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import com.vivo.vmdri.client.ril.RilRespException;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f2274a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private c0.l f2275b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private C0027b f2276c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f2277d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final ConcurrentHashMap f2278e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private c0.l.b f2279f;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends c0.l.b {
        a(Executor executor) {
            super(executor);
        }

        @Override // c0.l.b
        public void a(String str, String str2) {
            super.a(str, str2);
            b.this.d(str, m0.a.f(str2));
        }
    }

    /* JADX INFO: renamed from: y.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class C0027b {
        public abstract void a(String str, m0.a aVar);
    }

    public b(Context context, Looper looper, C0027b c0027b) {
        super(looper);
        this.f2277d = false;
        this.f2278e = new ConcurrentHashMap();
        this.f2279f = new a(new Executor() { // from class: y.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f2273a.post(runnable);
            }
        });
        e("RilChannel init");
        this.f2274a = context;
        this.f2276c = c0027b;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d(String str, m0.a aVar) {
        String strConvertCommShareDataCallList;
        if (VmdriLog.isFullDebugLevel()) {
            e("handleRilMessage rilMsg:" + aVar + ", from:" + str);
        }
        int i2 = aVar.f1835e;
        if (i2 == 1) {
            f("handleRilMessage, client can't handle RIL request, drop! " + aVar);
            return;
        }
        if (i2 != 2) {
            if (i2 != 3) {
                f("handleRilMessage recv a not support ril msg:" + aVar);
                return;
            }
            this.f2276c.a(str, aVar);
            if (aVar.f1831a == 2 && aVar.f1833c == 500 && (strConvertCommShareDataCallList = VmdriUtils.convertCommShareDataCallList(str, aVar.a())) != null) {
                VmdriLog.localLog(VmdriLog.REASON_DUMP_DATA_CALL_LIST, strConvertCommShareDataCallList);
                return;
            }
            return;
        }
        w.h hVar = new w.h(aVar.f1834d, aVar.f1831a, aVar.f1832b, aVar.f1833c);
        if (hasEqualMessages(1, hVar)) {
            removeEqualMessages(1, hVar);
        }
        Message message = (Message) this.f2278e.remove(hVar);
        if (message == null) {
            g("handleRilMessage, rilMessage not request cache, drop!" + aVar);
            return;
        }
        if (aVar.f1837g == 0) {
            AsyncResult.forMessage(message, aVar, (Throwable) null);
        } else {
            String str2 = "remote error:" + aVar.f1837g + ", for response ril msg:" + aVar;
            g("handleRilMessage:" + str2);
            AsyncResult.forMessage(message, aVar, new RilRespException(aVar.f1837g, str2, true));
        }
        message.sendToTarget();
    }

    private static void e(String str) {
        VmdriLog.d("RilClientChannel", str);
    }

    private static void f(String str) {
        VmdriLog.e("RilClientChannel", str);
    }

    private static void g(String str) {
        VmdriLog.w("RilClientChannel", str);
    }

    public void b(w.d dVar) {
        e("connect, remoteDevState:" + dVar);
        this.f2275b = r.u().p(dVar.i(), 4, this.f2279f);
        this.f2277d = true;
    }

    public void c() {
        e("disconnect, DataChannel:" + this.f2275b);
        this.f2277d = false;
        r.u().r(this.f2275b, true);
        removeMessages(1);
        Iterator it = this.f2278e.keySet().iterator();
        while (it.hasNext()) {
            Message message = (Message) this.f2278e.get((w.h) it.next());
            AsyncResult.forMessage(message, (Object) null, new RilRespException(9, "ril channel close!"));
            message.sendToTarget();
        }
        this.f2278e.clear();
        this.f2275b = null;
    }

    public int h(m0.a aVar, Message message, long j2) {
        if (this.f2275b == null) {
            f("sendRilMessage channel not connect error!");
            AsyncResult.forMessage(message, (Object) null, new RilRespException(3, "device is not conn!"));
            message.sendToTarget();
            return 3;
        }
        if (aVar.f1835e != 1) {
            String str = "client can only send ril request! type:" + aVar.f1835e;
            f("sendRilMessage, " + str);
            AsyncResult.forMessage(message, (Object) null, new RilRespException(8, str));
            message.sendToTarget();
            return 8;
        }
        w.h hVar = new w.h(aVar.f1834d, aVar.f1831a, aVar.f1832b, aVar.f1833c);
        this.f2278e.put(hVar, message);
        int iZ = this.f2275b.Z(aVar.e());
        if (iZ != 0) {
            this.f2278e.remove(hVar);
            AsyncResult.forMessage(message, (Object) null, new RilRespException(iZ, "data channel error:" + w.e.a(iZ)));
            message.sendToTarget();
        } else if (iZ == 0 && j2 >= 0) {
            sendMessageDelayed(obtainMessage(1, hVar), j2);
        }
        if (VmdriLog.isNormalDebugLevel()) {
            e("sendRilData to " + this.f2275b + ", ril msg:" + aVar + ", errCode:" + iZ + ", timeoutInMs:" + j2);
        }
        return iZ;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        if (message.what != 1) {
            f("unsupported message type:" + message.what);
            return;
        }
        w.h hVar = (w.h) message.obj;
        Message message2 = (Message) this.f2278e.remove(hVar);
        if (message2 != null) {
            String str = "asynchronous request time out! for request:" + hVar;
            f(str);
            AsyncResult.forMessage(message2, (Object) null, new RilRespException(6, str));
            message2.sendToTarget();
        }
    }
}
