package e0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import org.json.JSONObject;
import w.p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final Object f1596m = new Object();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static a f1597n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static int f1598o;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f1599a = "";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f1600b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1601c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f1602d = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1603e = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1604f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1605g = -1;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1606h = -1;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f1607i = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f1608j = "";

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f1609k = 0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    a f1610l;

    public static String a(int i2) {
        if (i2 == 1) {
            return "HS";
        }
        if (i2 == 2) {
            return "CTRL";
        }
        if (i2 == 3) {
            return "DEV_STATE";
        }
        if (i2 == 4) {
            return "RIL";
        }
        if (i2 == 5) {
            return "COMM_DATA";
        }
        return "UNKNOWN(" + i2 + ")";
    }

    private static void e(String str) {
        VmdriLog.e("DataPacket", str);
    }

    public static a f() {
        synchronized (f1596m) {
            try {
                a aVar = f1597n;
                if (aVar == null) {
                    return new a();
                }
                f1597n = aVar.f1610l;
                aVar.f1610l = null;
                f1598o--;
                return aVar;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static a l(JSONObject jSONObject) {
        try {
            a aVarF = f();
            aVarF.f1599a = jSONObject.optString("src", "");
            aVarF.f1600b = jSONObject.optString("dst", "");
            aVarF.f1601c = jSONObject.optInt("cid", -1);
            aVarF.f1604f = jSONObject.optInt("flg", 0);
            aVarF.f1605g = jSONObject.optInt("seq", -1);
            aVarF.f1606h = jSONObject.optInt("ack", -1);
            aVarF.f1602d = jSONObject.optString("seId", "");
            aVarF.f1603e = jSONObject.optInt("unid", -1);
            aVarF.f1607i = jSONObject.optInt("isCmp", 0) == 1;
            aVarF.f1608j = jSONObject.optString("dt", "");
            return aVarF;
        } catch (Exception e2) {
            e("Error parsing JSONObject to DataPacket object" + e2.toString());
            return null;
        }
    }

    public static a m(byte[] bArr) {
        if (bArr == null) {
            return f();
        }
        try {
            return l(new JSONObject(new String(bArr, StandardCharsets.UTF_8)));
        } catch (JSONException e2) {
            a aVarF = f();
            e("Error parsing byte[] to DataPacket object:" + e2.toString());
            return aVarF;
        }
    }

    public boolean b() {
        return (this.f1604f & 2) == 2;
    }

    public boolean c() {
        return (this.f1604f & 4) == 4;
    }

    public boolean d() {
        return (this.f1604f & 1) == 1;
    }

    public void g() {
        h();
    }

    void h() {
        this.f1599a = "";
        this.f1600b = "";
        this.f1601c = -1;
        this.f1602d = "";
        this.f1603e = -1;
        this.f1604f = 0;
        this.f1605g = -1;
        this.f1606h = -1;
        this.f1607i = false;
        this.f1608j = "";
        this.f1609k = 0;
        synchronized (f1596m) {
            try {
                int i2 = f1598o;
                if (i2 < 25) {
                    this.f1610l = f1597n;
                    f1597n = this;
                    f1598o = i2 + 1;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public byte[] i() {
        return j().toString().getBytes(StandardCharsets.UTF_8);
    }

    public JSONObject j() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("src", this.f1599a);
            jSONObject.put("dst", this.f1600b);
            jSONObject.put("cid", this.f1601c);
            jSONObject.put("seId", this.f1602d);
            int i2 = this.f1603e;
            if (i2 >= 0) {
                jSONObject.put("unid", i2);
            }
            int i3 = this.f1604f;
            if (i3 >= 0) {
                jSONObject.put("flg", i3);
            }
            int i4 = this.f1605g;
            if (i4 >= 0) {
                jSONObject.put("seq", i4);
            }
            int i5 = this.f1606h;
            if (i5 >= 0) {
                jSONObject.put("ack", i5);
            }
            jSONObject.put("isCmp", this.f1607i ? 1 : 0);
            if (!TextUtils.isEmpty(this.f1608j)) {
                jSONObject.put("dt", this.f1608j);
                return jSONObject;
            }
        } catch (JSONException e2) {
            e("Error converting msg to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public void k(int i2) {
        this.f1609k = i2;
    }

    public String toString() {
        String strSubstring;
        StringBuilder sb = new StringBuilder();
        sb.append("DataPacket{srcDeviceId:'");
        sb.append(this.f1599a);
        sb.append('\'');
        sb.append(", dstDeviceId:'");
        sb.append(this.f1600b);
        sb.append('\'');
        sb.append(", channel:");
        sb.append(a(this.f1601c));
        sb.append(", connType:");
        sb.append(p.j(this.f1609k));
        sb.append(", sessionId:");
        sb.append(this.f1602d);
        sb.append(", uniqueId:");
        sb.append(this.f1603e);
        sb.append(", flag:");
        sb.append(this.f1604f);
        sb.append(", seq:");
        sb.append(this.f1605g);
        sb.append(", ack:");
        sb.append(this.f1606h);
        sb.append(", isCompression:");
        sb.append(this.f1607i);
        sb.append(", dataLen:");
        String str = this.f1608j;
        sb.append(str == null ? "null" : Integer.valueOf(str.length()));
        sb.append(", data:");
        if (TextUtils.isEmpty(this.f1608j)) {
            strSubstring = "";
        } else {
            String str2 = this.f1608j;
            strSubstring = str2.substring(0, Math.min(str2.length(), 200));
        }
        sb.append(strSubstring);
        sb.append('}');
        return sb.toString();
    }
}
