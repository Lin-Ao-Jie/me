package i0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1737a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f1738b = "";

    private static void a(String str) {
        VmdriLog.e("StopCommShareResponseMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("err", this.f1737a);
            if (!TextUtils.isEmpty(this.f1738b)) {
                jSONObject.put("desc", this.f1738b);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting StopCommShareResponseMsg to JSONObject" + e2.toString());
        }
        return jSONObject;
    }

    public static b d(String str) {
        if (str == null) {
            return new b();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            b bVar = new b();
            a("Error parsing jsonStr to StopCommShareResponseMsg object:" + e2.toString());
            return bVar;
        }
    }

    private static b e(JSONObject jSONObject) {
        try {
            b bVar = new b();
            bVar.f1737a = jSONObject.optInt("err", 0);
            bVar.f1738b = jSONObject.optString("desc", "");
            return bVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to StopCommShareResponseMsg object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "StopCommShareResponseMsg{errorCode=" + this.f1737a + ", explainInfo='" + this.f1738b + "'}";
    }
}
