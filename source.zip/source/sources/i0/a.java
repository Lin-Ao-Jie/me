package i0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1734a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f1735b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public HashMap f1736c = new HashMap();

    private static void a(String str) {
        VmdriLog.e("StartCommShareResponseMsg", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("err", this.f1734a);
            if (!TextUtils.isEmpty(this.f1735b)) {
                jSONObject.put("desc", this.f1735b);
            }
            if (this.f1736c.size() > 0) {
                JSONArray jSONArray = new JSONArray();
                for (String str : this.f1736c.keySet()) {
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject2.put("id", str);
                    jSONObject2.put("name", this.f1736c.get(str));
                    jSONArray.put(jSONObject2);
                }
                jSONObject.put("pDevs", jSONArray);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting StartCommShareResponseMsg to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            a("Error parsing jsonStr to StartCommShareResponseMsg object:" + e2.toString());
            return aVar;
        }
    }

    private static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1734a = jSONObject.optInt("err", 0);
            aVar.f1735b = jSONObject.optString("desc", "");
            if (!jSONObject.isNull("pDevs")) {
                JSONArray jSONArray = jSONObject.getJSONArray("pDevs");
                int length = jSONArray.length();
                for (int i2 = 0; i2 < length; i2++) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                    aVar.f1736c.put(jSONObject2.optString("id", ""), jSONObject2.optString("name", ""));
                }
            }
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to StartCommShareResponseMsg object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "StartCommShareResponseMsg{errorCode=" + this.f1734a + ", explainInfo='" + this.f1735b + "', preferredDevs=" + this.f1736c + '}';
    }
}
