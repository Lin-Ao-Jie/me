package d0;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.ArraySet;
import android.util.IndentingPrintWriter;
import android.view.Display;
import c0.e0;
import c0.z0;
import com.vivo.vmdri.VmdriConfig;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriVersion;
import com.vivo.vmdri.ctrl.RemoteDevConnEvaluation;
import java.io.FileDescriptor;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class l extends Handler {
    private static l B;
    private static final Object C = new Object();
    private final DisplayManager.DisplayListener A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f1497a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private TelephonyManager f1498b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private PowerManager f1499c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private DisplayManager f1500d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private WifiManager f1501e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private WifiP2pManager f1502f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private BluetoothManager f1503g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private BluetoothAdapter f1504h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private p f1505i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private z0 f1506j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private i f1507k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final Set f1508l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1509m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int[] f1510n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private w.d f1511o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private final ConcurrentHashMap f1512p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private final ConcurrentHashMap f1513q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private final ConcurrentHashMap f1514r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private final ConcurrentHashMap f1515s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private final ConcurrentHashMap f1516t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private z.c f1517u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private c0.l.b f1518v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private e0.b f1519w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private p.d f1520x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private z0.b f1521y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private BroadcastReceiver f1522z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends z.c {
        a() {
        }

        @Override // d0.z.c
        public void a(String str, String str2) {
            l.this.U0(str2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends c0.l.b {
        b(Executor executor) {
            super(executor);
        }

        @Override // c0.l.b
        public void a(String str, String str2) {
            super.a(str, str2);
            k0.a aVarD = k0.a.d(str2);
            if (TextUtils.isEmpty(aVarD.f1791a)) {
                l.n0("onDataRecv dev is empty, remoteDevId" + str + ", msg:" + aVarD);
                aVarD.f1791a = str;
            }
            if (!TextUtils.isEmpty(aVarD.f1793c)) {
                l.this.a0(aVarD);
            }
            l.this.b0(aVarD);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends e0.b {
        c(Executor executor) {
            super(executor);
        }

        @Override // c0.e0.b
        public void a(String str, String str2) {
            l.this.O0(str, str2);
        }

        @Override // c0.e0.b
        public void b(w.i iVar) {
            l.l0("onLocalDeviceInfoChanged, get local SdkDevInfo:" + iVar);
            l.this.f1511o.P(iVar);
            l lVar = l.this;
            lVar.s0(lVar.f1511o);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends p.d {
        d() {
        }

        @Override // d0.p.d
        public void a(w.c cVar) {
            l.this.q0(cVar);
        }

        @Override // d0.p.d
        public void b(w.i iVar, VmdriVersion vmdriVersion, String str, String str2, long j2) {
            super.b(iVar, vmdriVersion, str, str2, j2);
            l.l0("onRemoteDevConnected, devInfo:" + iVar + ", version:" + vmdriVersion + ", pdVersion:" + str + ", vmdriBuildVersionName:" + str2 + ", vmdriBuildVersionCode:" + j2);
            w.d dVar = new w.d(iVar, vmdriVersion, str, str2, j2);
            l.this.f1512p.put(dVar.i(), dVar);
            c0.l lVarP = c0.r.u().p(iVar.d(), 3, l.this.f1518v);
            l.this.f1513q.put(lVarP.w(), lVarP);
            l.this.t0(dVar);
            l.this.F0(lVarP.w(), false);
        }

        @Override // d0.p.d
        public void c(w.i iVar) {
            super.c(iVar);
            l.l0("onRemoteDevDisConnected, devInfo:" + iVar);
            String strD = iVar.d();
            l.this.f1513q.remove(strD);
            w.d dVar = (w.d) l.this.f1512p.remove(strD);
            l.this.f1514r.remove(strD);
            l.this.f1515s.remove(strD);
            l.this.f1516t.remove(strD);
            l.this.u0(dVar);
        }

        @Override // d0.p.d
        public void d(w.i iVar) {
            super.d(iVar);
            l.l0("onRemoteDevInfoChanged, devInfo:" + iVar);
            w.d dVar = (w.d) l.this.f1512p.get(iVar.d());
            if (dVar != null) {
                dVar.I(iVar.c());
                l.this.v0(dVar, false, true);
            } else {
                l.m0("onRemoteDevInfoChanged, not find remote DeviceState, for :" + iVar);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e extends z0.b {
        e(Executor executor) {
            super(executor);
        }

        @Override // c0.z0.b
        public void a(int i2) {
            super.a(i2);
            l.this.R0(i2);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class f extends BroadcastReceiver {
        f() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            action.hashCode();
            switch (action) {
                case "android.net.wifi.WIFI_STATE_CHANGED":
                    l.l0("WifiManager.WIFI_STATE_CHANGED_ACTION, newWifiState:" + intent.getIntExtra("wifi_state", 4) + ", prevWifiState:" + intent.getIntExtra("previous_wifi_state", 4));
                    l lVar = l.this;
                    lVar.S0(lVar.j0());
                    break;
                case "android.bluetooth.adapter.action.STATE_CHANGED":
                    l.l0("BluetoothAdapter.ACTION_STATE_CHANGED, newBtState:" + intent.getIntExtra("android.bluetooth.adapter.extra.STATE", Integer.MIN_VALUE) + ", prevBtState:" + intent.getIntExtra("android.bluetooth.adapter.extra.PREVIOUS_STATE", Integer.MIN_VALUE));
                    l lVar2 = l.this;
                    lVar2.L0(lVar2.e0());
                    break;
                case "android.telephony.action.SIM_APPLICATION_STATE_CHANGED":
                case "android.telephony.action.SIM_CARD_STATE_CHANGED":
                    l.this.Q0(intent.getIntExtra("android.telephony.extra.SLOT_INDEX", -1), intent.getIntExtra("android.telephony.extra.SIM_STATE", 0));
                    break;
                case "android.net.wifi.WIFI_AP_STATE_CHANGED":
                    l.l0("WifiManager.WIFI_AP_STATE_CHANGED_ACTION, newWifiApState:" + intent.getIntExtra("wifi_state", 11) + ", prevWifiApState:" + intent.getIntExtra("previous_wifi_state", 11));
                    l lVar3 = l.this;
                    lVar3.T0(lVar3.k0());
                    break;
                default:
                    l.n0("receive a not support broadcast:" + intent);
                    break;
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    private class i extends ContentObserver {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Context f1531a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Uri f1532b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final Uri f1533c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final Uri f1534d;

        public i(Handler handler, Context context) {
            super(handler);
            this.f1531a = context;
            Uri uriFor = Settings.Global.getUriFor("airplane_mode_on");
            this.f1532b = uriFor;
            Uri uriFor2 = Settings.Global.getUriFor("mobile_data");
            this.f1533c = uriFor2;
            Uri uriFor3 = Settings.Global.getUriFor("vivo_user_define_device_name");
            this.f1534d = uriFor3;
            context.getContentResolver().registerContentObserver(uriFor, false, this);
            context.getContentResolver().registerContentObserver(uriFor2, false, this);
            context.getContentResolver().registerContentObserver(uriFor3, false, this);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2, Uri uri) {
            if (uri.equals(this.f1532b)) {
                l lVar = l.this;
                lVar.K0(lVar.d0());
            } else if (uri.equals(this.f1533c)) {
                l lVar2 = l.this;
                lVar2.M0(lVar2.i0());
            } else if (uri.equals(this.f1534d)) {
                l lVar3 = l.this;
                lVar3.N0(lVar3.Z());
            }
        }
    }

    private l(Context context, p pVar) {
        super(pVar.getLooper());
        this.f1508l = new ArraySet();
        this.f1511o = new w.d(true);
        this.f1512p = new ConcurrentHashMap();
        this.f1513q = new ConcurrentHashMap();
        this.f1514r = new ConcurrentHashMap();
        this.f1515s = new ConcurrentHashMap();
        this.f1516t = new ConcurrentHashMap();
        this.f1517u = new a();
        this.f1518v = new b(new Executor() { // from class: d0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1477a.post(runnable);
            }
        });
        this.f1519w = new c(new Executor() { // from class: d0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1477a.post(runnable);
            }
        });
        this.f1520x = new d();
        this.f1521y = new e(new Executor() { // from class: d0.a
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1477a.post(runnable);
            }
        });
        this.f1522z = new f();
        this.A = new g();
        this.f1497a = context;
        this.f1506j = z0.f();
        this.f1507k = new i(this, context);
        this.f1505i = pVar;
        this.f1499c = (PowerManager) this.f1497a.getSystemService("power");
        this.f1500d = (DisplayManager) this.f1497a.getSystemService("display");
        this.f1498b = (TelephonyManager) this.f1497a.getSystemService("phone");
        this.f1501e = (WifiManager) this.f1497a.getSystemService("wifi");
        this.f1502f = (WifiP2pManager) this.f1497a.getSystemService("wifip2p");
        BluetoothManager bluetoothManager = (BluetoothManager) this.f1497a.getSystemService("bluetooth");
        this.f1503g = bluetoothManager;
        BluetoothAdapter adapter = bluetoothManager.getAdapter();
        this.f1504h = adapter;
        if (adapter == null) {
            n0("Local device doesn't support Bluetooth!");
        }
        z.o().v(this.f1517u);
        c0();
        z0();
    }

    private void D0(String str) {
        if (((Boolean) this.f1515s.getOrDefault(str, Boolean.FALSE)).booleanValue()) {
            return;
        }
        l0("handleRemoteDeviceStateMsg, This device status validity period:5000ms");
        removeMessages(1);
        sendMessageDelayed(obtainMessage(1, str), 5000L);
    }

    private void E0(String str, String str2) {
        c0.l lVar = (c0.l) this.f1513q.get(str);
        if (lVar == null) {
            m0("sendDevStateCmd, dataChannel is null remoteDevId:" + str);
            return;
        }
        k0.a aVarD = this.f1511o.d();
        aVarD.f1793c = str2;
        l0("sendDevStateCmd, remoteDevId:" + str + ", message:" + aVarD);
        lVar.Z(aVarD.c());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void F0(String str, boolean z2) {
        c0.l lVar = (c0.l) this.f1513q.get(str);
        if (lVar == null) {
            m0("sendLocalDevStateToRemote, dataChannel is null, remoteDevId:" + str + ", force:" + z2);
            return;
        }
        if (!f0(str) && !z2) {
            l0("sendDeviceStateToRemote, skip:" + str);
            return;
        }
        k0.a aVarD = this.f1511o.d();
        l0("sendLocalDevStateToRemote, remoteDevId:" + str + ", force:" + z2 + ", message:" + aVarD);
        lVar.Z(aVarD.c());
    }

    private void G0(boolean z2) {
        k0.a aVarD = this.f1511o.d();
        StringBuilder sb = new StringBuilder("sendLocalDevStateToAllRemote");
        sb.append(", force:");
        sb.append(z2);
        sb.append(", msg:");
        sb.append(aVarD);
        sb.append(", to:");
        int i2 = 0;
        for (c0.l lVar : this.f1513q.values()) {
            String strW = lVar.w();
            i2++;
            if (f0(strW) || z2) {
                sb.append("(notify:");
                sb.append(strW);
                sb.append(")");
                lVar.Z(aVarD.c());
            } else {
                sb.append("(skip:");
                sb.append(strW);
                sb.append(")");
            }
        }
        if (i2 > 0) {
            l0(sb.toString());
        }
    }

    public static String H0(int i2) {
        switch (i2) {
            case 0:
                return "UNKNOWN";
            case 1:
                return "ABSENT";
            case 2:
                return "PIN_REQUIRED";
            case 3:
                return "PUK_REQUIRED";
            case 4:
                return "NETWORK_LOCKED";
            case 5:
                return "READY";
            case 6:
                return "NOT_READY";
            case 7:
                return "PERM_DISABLED";
            case 8:
                return "CARD_IO_ERROR";
            case 9:
                return "CARD_RESTRICTED";
            case 10:
                return "LOADED";
            case 11:
                return "PRESENT";
            default:
                return "UNKNOWN(" + i2 + ")";
        }
    }

    private void J0(RemoteDevConnEvaluation remoteDevConnEvaluation) {
        boolean z2;
        boolean zD0;
        boolean zJ0;
        boolean zE0;
        StringBuilder sb = new StringBuilder();
        boolean z3 = true;
        if (!remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.LOCAL_BLUETOOTH_DISABLE) || this.f1511o.z() == (zE0 = e0())) {
            z2 = false;
        } else {
            l0("tryUpdateLocalDevState: update Bluetooth state " + this.f1511o.z() + " -> " + zE0);
            sb.append("|br|");
            this.f1511o.H(zE0);
            z2 = true;
        }
        if (remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.LOCAL_WIFI_DISABLE) && this.f1511o.F() != (zJ0 = j0())) {
            l0("tryUpdateLocalDevState: update wifi state " + this.f1511o.F() + " -> " + zJ0);
            sb.append("|wifi|");
            this.f1511o.T(zJ0);
            z2 = true;
        }
        if (!remoteDevConnEvaluation.c(RemoteDevConnEvaluation.DisallowedReason.LOCAL_ON_AIRPLANE_MODE) || this.f1511o.x() == (zD0 = d0())) {
            z3 = z2;
        } else {
            l0("tryUpdateLocalDevState: update airplane state " + this.f1511o.x() + " -> " + zD0);
            sb.append("|airplane|");
            this.f1511o.T(zD0);
        }
        if (z3) {
            r0(this.f1511o, sb.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void K0(boolean z2) {
        if (z2 != this.f1511o.x()) {
            l0("updateAndNotifyLocalDevAirplaneChanged: curAirplaneMode:" + z2);
            this.f1511o.G(z2);
            r0(this.f1511o, "airplane");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L0(boolean z2) {
        if (z2 != this.f1511o.z()) {
            l0("updateAndNotifyLocalDevBluetoothEnabledChanged:curBluetoothOn:" + z2);
            this.f1511o.H(z2);
            r0(this.f1511o, "bt");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M0(boolean z2) {
        if (z2 != this.f1511o.A()) {
            l0("updateAndNotifyLocalDevMobileDataChanged: curMobileDataEnable:" + z2);
            this.f1511o.J(z2);
            r0(this.f1511o, "mobileData");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void N0(String str) {
        if (Objects.equals(str, this.f1511o.g())) {
            return;
        }
        l0("updateAndNotifyLocalDevNameChanged: curLocalDevName:" + str);
        this.f1511o.K(str);
        r0(this.f1511o, "devName");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void O0(String str, String str2) {
        String strO = this.f1511o.o();
        String strM = this.f1511o.m();
        l0("updateAndNotifyLocalDevP2pInfoChanged, old:" + strM + "(" + strO + "), cur:" + str2 + "(" + str + ")");
        if (Objects.equals(str, strO) && Objects.equals(str2, strM)) {
            return;
        }
        this.f1511o.M(str);
        this.f1511o.L(str2);
        r0(this.f1511o, "p2p");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void P0(boolean z2) {
        if (z2 != this.f1511o.D()) {
            l0("updateAndNotifyLocalDevScreenChanged: curScreenOn:" + z2);
            this.f1511o.O(z2);
            r0(this.f1511o, "screen");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Q0(int i2, int i3) {
        l0("updateAndNotifyLocalDevSimState slot:" + i2 + ", simState:(" + i3 + ")" + H0(i3));
        if (i3 == 1 || i3 == 11) {
            this.f1510n[i2] = i3;
            int i4 = 0;
            for (int i5 = 0; i5 < this.f1509m; i5++) {
                if (this.f1510n[i5] == 11) {
                    i4++;
                }
            }
            if (this.f1511o.s() != i4) {
                this.f1511o.Q(i4);
                l0("updateAndNotifyLocalDevSimState, mLocalDevState:" + this.f1511o);
                r0(this.f1511o, "simState");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void R0(int i2) {
        if (i2 != this.f1511o.t()) {
            l0("updateAndNotifyLocalDevVmdriSwitchChanged: curSwitchStatus:" + w.p.f(i2));
            this.f1511o.R(i2);
            r0(this.f1511o, "vmdriSwitch");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void S0(boolean z2) {
        if (z2 != this.f1511o.F()) {
            l0("updateAndNotifyLocalDevWiFiEnabledChanged:curWifiOn:" + z2);
            this.f1511o.T(z2);
            r0(this.f1511o, "wifi");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void T0(boolean z2) {
        if (z2 != this.f1511o.E()) {
            l0("updateAndNotifyLocalDevWiFiApChanged: curWifiApEnable:" + z2);
            this.f1511o.S(z2);
            r0(this.f1511o, "wifiAp");
        }
    }

    public static l U(Context context, p pVar) {
        l lVar;
        synchronized (C) {
            try {
                if (B != null) {
                    throw new RuntimeException("DeviceStateTracker already created!");
                }
                lVar = new l(context, pVar);
                B = lVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return lVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void U0(String str) {
        l0("updateAndNotifyLocalP2pState: state change:" + this.f1511o.p() + " -> " + str);
        this.f1511o.N(str);
        if (this.f1511o.C()) {
            G0(false);
        }
    }

    private String W() {
        try {
            BluetoothAdapter bluetoothAdapter = this.f1504h;
            return bluetoothAdapter != null ? bluetoothAdapter.getName() : "";
        } catch (Exception e2) {
            m0("getBluetoothName error:" + e2);
            return "";
        }
    }

    public static l Y() {
        l lVar = B;
        if (lVar != null) {
            return lVar;
        }
        throw new RuntimeException("DeviceStateTracker.getInstance can't be called before create()");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String Z() {
        String string = Settings.Global.getString(this.f1497a.getContentResolver(), "vivo_user_define_device_name");
        if (!TextUtils.isEmpty(string)) {
            return string;
        }
        String string2 = Settings.Global.getString(this.f1497a.getContentResolver(), "bluetooth_recover_name");
        if (!TextUtils.isEmpty(string2)) {
            return string2;
        }
        String strW = W();
        if (!TextUtils.isEmpty(strW)) {
            return strW;
        }
        String str = SystemProperties.get("ro.vivo.market.name", "");
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        String str2 = Build.MODEL;
        return !TextUtils.isEmpty(str2) ? str2 : "";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a0(k0.a aVar) {
        if (TextUtils.isEmpty(aVar.f1793c)) {
            return;
        }
        String str = aVar.f1791a;
        String str2 = aVar.f1793c;
        l0("handleRemoteDeviceStateCmd, remoteDevId:" + str + ", cmd:" + aVar.f1793c);
        if ("sts".equals(str2)) {
            o0(str, false);
            return;
        }
        if ("stfcomm".equals(str2)) {
            o0(str, true);
            return;
        }
        if ("sps".equals(str2)) {
            p0(str, false);
            return;
        }
        if ("spfcomm".equals(str2)) {
            p0(str, true);
            return;
        }
        if ("notiSt".equals(str2)) {
            this.f1515s.put(str, Boolean.TRUE);
        } else if ("notiSp".equals(str2)) {
            this.f1515s.put(str, Boolean.FALSE);
            D0(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b0(k0.a aVar) {
        boolean z2;
        l0("handleRemoteDeviceStateMsg:" + aVar);
        w.d dVar = (w.d) this.f1512p.get(aVar.f1791a);
        if (dVar == null) {
            m0("handleRemoteDeviceStateMsg remote dev is null!");
            return;
        }
        String strI = dVar.i();
        l0("handleRemoteDeviceStateMsg, oldDev:" + dVar);
        if (Objects.equals(dVar.g(), aVar.f1792b)) {
            z2 = false;
        } else {
            dVar.K(aVar.f1792b);
            z2 = true;
        }
        if (!Integer.valueOf(dVar.t()).equals(Integer.valueOf(aVar.f1794d))) {
            dVar.R(aVar.f1794d);
            z2 = true;
        }
        String strO = dVar.o();
        String strM = dVar.m();
        String strP = dVar.p();
        String str = aVar.f1796f;
        String str2 = aVar.f1795e;
        String str3 = aVar.f1797g;
        if (!Objects.equals(str, strO) || !Objects.equals(str2, strM) || !Objects.equals(str3, strP)) {
            dVar.M(str);
            dVar.L(str2);
            dVar.N(str3);
            z2 = true;
        }
        if (!Boolean.valueOf(dVar.D()).equals(Boolean.valueOf(aVar.f1800j))) {
            dVar.O(aVar.f1800j);
            z2 = true;
        }
        if (!Boolean.valueOf(dVar.x()).equals(Boolean.valueOf(aVar.f1801k))) {
            dVar.G(aVar.f1801k);
            z2 = true;
        }
        if (!Integer.valueOf(dVar.s()).equals(Integer.valueOf(aVar.f1798h))) {
            dVar.Q(aVar.f1798h);
            z2 = true;
        }
        if (!Boolean.valueOf(dVar.A()).equals(Boolean.valueOf(aVar.f1799i))) {
            dVar.J(aVar.f1799i);
            z2 = true;
        }
        if (!Boolean.valueOf(dVar.F()).equals(Boolean.valueOf(aVar.f1802l))) {
            dVar.T(aVar.f1802l);
            z2 = true;
        }
        if (!Boolean.valueOf(dVar.z()).equals(Boolean.valueOf(aVar.f1804n))) {
            dVar.H(aVar.f1804n);
            z2 = true;
        }
        if (!Boolean.valueOf(dVar.E()).equals(Boolean.valueOf(aVar.f1803m))) {
            dVar.S(aVar.f1803m);
            z2 = true;
        }
        this.f1516t.put(strI, Boolean.TRUE);
        D0(strI);
        if (z2) {
            l0("handleRemoteDeviceStateMsg dev state changed, new:" + dVar);
        }
        v0(dVar, true, z2);
    }

    private void c0() {
        this.f1511o = new w.d(VmdriConfig.sLocalVersion, VmdriContext.getInstance().getSystemBuildVersion(), VmdriContext.getInstance().getVmdriBuildVersionName(), VmdriContext.getInstance().getVmdriBuildLongVersionCode());
        int activeModemCount = this.f1498b.getActiveModemCount();
        this.f1509m = activeModemCount;
        this.f1510n = new int[activeModemCount];
        for (int i2 = 0; i2 < this.f1509m; i2++) {
            this.f1510n[i2] = 0;
        }
        this.f1511o.K(Z());
        this.f1511o.O(g0());
        this.f1511o.G(d0());
        this.f1511o.T(j0());
        this.f1511o.S(k0());
        this.f1511o.H(e0());
        this.f1511o.J(i0());
        l0("initLocalDevState:" + this.f1511o);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean d0() {
        return Settings.Global.getInt(this.f1497a.getContentResolver(), "airplane_mode_on", 0) != 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean e0() {
        try {
            BluetoothAdapter bluetoothAdapter = this.f1504h;
            if (bluetoothAdapter != null) {
                return bluetoothAdapter.isEnabled();
            }
            return false;
        } catch (Exception e2) {
            m0("isBlueToothEnabled error:" + e2);
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean g0() {
        Display[] displays = this.f1500d.getDisplays();
        if (displays == null) {
            n0("No displays found");
            return false;
        }
        for (Display display : displays) {
            if (display.getState() == 2) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean i0() {
        return Settings.Global.getInt(this.f1497a.getContentResolver(), "mobile_data", 0) != 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean j0() {
        return this.f1501e.isWifiEnabled();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean k0() {
        return this.f1501e.isWifiApEnabled();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void l0(String str) {
        VmdriLog.d("DeviceStateTracker", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void m0(String str) {
        VmdriLog.e("DeviceStateTracker", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void n0(String str) {
        VmdriLog.w("DeviceStateTracker", str);
    }

    private void o0(String str, boolean z2) {
        int i2 = z2 ? 2 : 1;
        int iIntValue = ((Integer) this.f1514r.getOrDefault(str, 0)).intValue();
        int i3 = iIntValue | i2;
        l0("markStartToNotifyToRemoteIfNeed, remoteDevId:" + str + ", oldSynDevStateFlag:" + iIntValue + ", appendFlag:" + i2 + ", newSynDevStateFlag:" + i3);
        this.f1514r.put(str, Integer.valueOf(i3));
        if (f0(str)) {
            w0(str);
        } else {
            F0(str, true);
        }
    }

    private void p0(String str, boolean z2) {
        int i2 = z2 ? 2 : 1;
        int iIntValue = ((Integer) this.f1514r.getOrDefault(str, 0)).intValue();
        int i3 = (~i2) & iIntValue;
        l0("markStopToNotifyToRemoteIfNeed, remoteDevId:" + str + ", oldSynDevStateFlag:" + iIntValue + ", removeFlag:" + i2 + ", newSynDevStateFlag:" + i3);
        this.f1514r.put(str, Integer.valueOf(i3));
        if (f0(str)) {
            F0(str, true);
        } else {
            x0(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void q0(final w.c cVar) {
        synchronized (this.f1508l) {
            this.f1508l.forEach(new Consumer() { // from class: d0.j
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    l.h hVar = (l.h) obj;
                    hVar.a(new Runnable() { // from class: d0.b
                        @Override // java.lang.Runnable
                        public final void run() {
                            hVar.b(cVar);
                        }
                    });
                }
            });
        }
    }

    private void r0(w.d dVar, String str) {
        l0("notifyLocalDeviceStateChanged, reason:" + str + ", localDev:" + dVar);
        s0(dVar);
        G0(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void s0(final w.d dVar) {
        synchronized (this.f1508l) {
            this.f1508l.forEach(new Consumer() { // from class: d0.c
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    l.h hVar = (l.h) obj;
                    hVar.a(new Runnable() { // from class: d0.d
                        @Override // java.lang.Runnable
                        public final void run() {
                            hVar.c(new w.d(dVar));
                        }
                    });
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void t0(final w.d dVar) {
        synchronized (this.f1508l) {
            this.f1508l.forEach(new Consumer() { // from class: d0.k
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    l.h hVar = (l.h) obj;
                    hVar.a(new Runnable() { // from class: d0.e
                        @Override // java.lang.Runnable
                        public final void run() {
                            hVar.d(dVar);
                        }
                    });
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void u0(final w.d dVar) {
        synchronized (this.f1508l) {
            this.f1508l.forEach(new Consumer() { // from class: d0.g
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    l.h hVar = (l.h) obj;
                    hVar.a(new Runnable() { // from class: d0.h
                        @Override // java.lang.Runnable
                        public final void run() {
                            hVar.e(dVar);
                        }
                    });
                }
            });
        }
        z.o().k();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void v0(final w.d dVar, final boolean z2, final boolean z3) {
        synchronized (this.f1508l) {
            this.f1508l.forEach(new Consumer() { // from class: d0.f
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    l.h hVar = (l.h) obj;
                    hVar.a(new Runnable() { // from class: d0.i
                        @Override // java.lang.Runnable
                        public final void run() {
                            hVar.f(new w.d(dVar), z, z);
                        }
                    });
                }
            });
        }
    }

    private void w0(String str) {
        l0("notifyStartReportStateToRemote, remoteDevId:" + str);
        E0(str, "notiSt");
    }

    private void x0(String str) {
        l0("notifyStopReportStateToRemote, remoteDevId:" + str);
        E0(str, "notiSp");
    }

    private void z0() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.telephony.action.SIM_CARD_STATE_CHANGED");
        intentFilter.addAction("android.telephony.action.SIM_APPLICATION_STATE_CHANGED");
        intentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        intentFilter.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        intentFilter.addAction("android.bluetooth.adapter.action.STATE_CHANGED");
        this.f1497a.registerReceiver(this.f1522z, intentFilter, null, this, 2);
        this.f1500d.registerDisplayListener(this.A, this);
        e0.A().K(this.f1519w);
        this.f1505i.y(this.f1520x);
        this.f1506j.l(this.f1521y);
    }

    public void A0(String str) {
        l0("requestStartReportState, remoteDevId:" + str);
        E0(str, "sts");
    }

    public void B0(String str) {
        l0("requestStartReportStateForCommShare, remoteDevId:" + str);
        E0(str, "stfcomm");
    }

    public void C0(String str) {
        l0("requestStopReportStateForCommShare, remoteDevId:" + str);
        E0(str, "spfcomm");
    }

    public void I0(RemoteDevConnEvaluation remoteDevConnEvaluation) {
        sendMessage(obtainMessage(2, remoteDevConnEvaluation));
    }

    public void V(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("DeviceStateTracker:");
        indentingPrintWriter.increaseIndent();
        for (int i2 = 0; i2 < this.f1509m; i2++) {
            indentingPrintWriter.println("sim(" + i2 + ")state:(" + this.f1510n[i2] + ")" + H0(this.f1510n[i2]));
        }
        indentingPrintWriter.println("mLocalDevState=" + this.f1511o);
        indentingPrintWriter.println("mRemoteDeviceStates=" + this.f1512p);
        indentingPrintWriter.println("mNeedNotifyDevStateToRemote=" + this.f1514r);
        indentingPrintWriter.println("mRemoteWillNotifyDevStateToMe=" + this.f1515s);
        indentingPrintWriter.println("mDataChannels=" + this.f1513q);
        indentingPrintWriter.println("mHasSynFromRemoteDevs=" + this.f1516t);
        indentingPrintWriter.decreaseIndent();
    }

    public String X(String str) {
        return z.o().n(str);
    }

    public boolean f0(String str) {
        int iIntValue = ((Integer) this.f1514r.getOrDefault(str, 0)).intValue();
        l0("isNeedNotifyDevStateToRemote, remoteDevId:" + str + ", curSynDevStateFlag:" + iIntValue);
        if ((iIntValue & 2) == 2) {
            return true;
        }
        return (iIntValue & 1) == 1 && !VmdriConfig.isSynDevStateOnlyCommShare();
    }

    public boolean h0(String str) {
        return ((Boolean) this.f1516t.getOrDefault(str, Boolean.FALSE)).booleanValue();
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        super.handleMessage(message);
        int i2 = message.what;
        if (i2 != 1) {
            if (i2 == 2) {
                J0((RemoteDevConnEvaluation) message.obj);
                return;
            }
            m0(" Unknown msg.what: " + message.what);
            return;
        }
        String str = (String) message.obj;
        if (((Boolean) this.f1515s.getOrDefault(str, Boolean.FALSE)).booleanValue() || !this.f1516t.containsKey(str)) {
            return;
        }
        l0("Device status validity period timed out, remoteDevId:" + str);
        this.f1516t.remove(str);
    }

    public void y0(h hVar) {
        if (hVar == null) {
            return;
        }
        synchronized (this.f1508l) {
            this.f1508l.add(hVar);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class g implements DisplayManager.DisplayListener {
        g() {
        }

        @Override // android.hardware.display.DisplayManager.DisplayListener
        public void onDisplayChanged(int i2) {
            l.this.P0(l.this.g0());
        }

        @Override // android.hardware.display.DisplayManager.DisplayListener
        public void onDisplayAdded(int i2) {
        }

        @Override // android.hardware.display.DisplayManager.DisplayListener
        public void onDisplayRemoved(int i2) {
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class h {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Executor f1530a;

        public h(Executor executor) {
            this.f1530a = executor;
        }

        public void a(Runnable runnable) {
            this.f1530a.execute(runnable);
        }

        public void b(w.c cVar) {
        }

        public void c(w.d dVar) {
        }

        public void d(w.d dVar) {
        }

        public void e(w.d dVar) {
        }

        public void f(w.d dVar, boolean z2, boolean z3) {
        }
    }
}
