package d0;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.util.IndentingPrintWriter;
import c0.c1;
import c0.e0;
import com.vivo.vmdri.VmdriConfig;
import com.vivo.vmdri.VmdriContext;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriVersion;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class p extends Handler {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static p f1543i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static final Object f1544j = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f1545a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private x f1546b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private c0.r f1547c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private List f1548d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final HashMap f1549e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final HashMap f1550f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final HashMap f1551g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private c0.l.b f1552h;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends c0.l.b {
        a(Executor executor) {
            super(executor);
        }

        @Override // c0.l.b
        public void a(String str, String str2) {
            super.a(str, str2);
            l0.a aVarD = l0.a.d(str2);
            if (TextUtils.isEmpty(aVarD.f1807a)) {
                p.w("onDataRecv dev is empty, remoteDevId" + str + ", msg:" + aVarD);
                aVarD.f1807a = str;
            }
            p.this.t(aVarD);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends x.b {
        b() {
        }

        @Override // d0.x.b
        public void a(w.c cVar) {
            p.this.x(cVar);
        }

        @Override // d0.x.b
        public void b(w.i iVar) {
            p.u("onRemoteDevConnected: remoteDevInfo:" + iVar);
            p.this.f1549e.put(iVar.d(), iVar);
            c0.l lVarP = p.this.f1547c.p(iVar.d(), 1, p.this.f1552h);
            p.this.z(lVarP);
            p.this.f1551g.put(lVarP.w(), lVarP);
            p.this.A(iVar.d());
        }

        @Override // d0.x.b
        public void c(final w.i iVar) {
            p.u("onRemoteDevDisConnected: remoteDevInfo:" + iVar);
            p.this.f1549e.remove(iVar.d());
            c0.l lVar = (c0.l) p.this.f1551g.remove(iVar.d());
            if (lVar != null) {
                p.this.f1547c.r(lVar, true);
            }
            if (((w.i) p.this.f1550f.remove(iVar.d())) != null) {
                p.this.f1548d.forEach(new Consumer() { // from class: d0.r
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((p.d) obj).c(iVar);
                    }
                });
            }
        }

        @Override // d0.x.b
        public void d(final w.i iVar) {
            p.u("onRemoteDevInfoChanged: remoteDevInfo:" + iVar);
            if (p.this.f1549e.containsKey(iVar.d())) {
                p.this.f1549e.put(iVar.d(), iVar);
            }
            if (p.this.f1550f.containsKey(iVar.d())) {
                p.this.f1548d.forEach(new Consumer() { // from class: d0.q
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((p.d) obj).d(iVar);
                    }
                });
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c extends c0.l.d {
        c(Executor executor) {
            super(executor);
        }

        @Override // c0.l.d
        public void a(c0.l lVar, e0.a aVar) {
            p.v("onRecvUniqueIdGreaterThanWon, hsDataChannel:" + lVar + ", dataPacket:" + aVar);
            if (p.this.f1550f.containsKey(lVar.w())) {
                p.w("onRecvUniqueIdGreaterThanWon, on recv hsMessage!");
            } else {
                p.this.s(lVar, aVar);
            }
        }
    }

    private p(Context context, x xVar) {
        super(xVar.getLooper());
        this.f1548d = new ArrayList();
        this.f1549e = new HashMap();
        this.f1550f = new HashMap();
        this.f1551g = new HashMap();
        this.f1552h = new a(new m(this));
        this.f1546b = xVar;
        this.f1545a = context;
        this.f1547c = c0.r.u();
        this.f1546b.r(new b());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A(String str) {
        c0.l lVar = (c0.l) this.f1551g.get(str);
        if (lVar == null) {
            v("sendHsMessage error, not hsChannel for remoteDevId:" + str);
            return;
        }
        l0.a aVar = new l0.a();
        aVar.f1808b = VmdriConfig.sLocalVersion.getVersionName();
        aVar.f1807a = e0.A().B();
        aVar.f1811e = VmdriContext.getInstance().getSystemBuildVersion();
        aVar.f1809c = VmdriContext.getInstance().getVmdriBuildVersionName();
        aVar.f1810d = VmdriContext.getInstance().getVmdriBuildLongVersionCode();
        lVar.Z(aVar.c());
    }

    public static p q(Context context, x xVar) {
        p pVar;
        synchronized (f1544j) {
            try {
                if (f1543i != null) {
                    throw new RuntimeException("HsManager already created!");
                }
                pVar = new p(context, xVar);
                f1543i = pVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return pVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void s(c0.l lVar, e0.a aVar) {
        String strW = lVar.w();
        c0.l lVar2 = (c0.l) this.f1551g.remove(strW);
        if (lVar2 != null) {
            this.f1547c.r(lVar2, true);
        }
        c0.l lVarP = this.f1547c.p(strW, 1, this.f1552h);
        z(lVarP);
        this.f1551g.put(strW, lVarP);
        A(strW);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void t(l0.a aVar) {
        u("handleRemoteHs, hsMsg:" + aVar);
        String str = aVar.f1807a;
        final w.i iVar = (w.i) this.f1549e.get(str);
        if (iVar == null) {
            w("handleRemoteHs, devInfo is not in AllRemoteDevInfo");
            return;
        }
        if (this.f1550f.containsKey(str)) {
            w("handleRemoteHs, already in the HsRemoteDevInfo");
            return;
        }
        this.f1550f.put(str, iVar);
        c1.c().e(str, 1);
        final VmdriVersion vmdriVersionFromString = VmdriVersion.fromString(aVar.f1808b);
        final String str2 = aVar.f1811e;
        final String str3 = aVar.f1809c;
        final long j2 = aVar.f1810d;
        this.f1548d.forEach(new Consumer() { // from class: d0.o
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((p.d) obj).b(iVar, vmdriVersionFromString, str2, str3, j2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void u(String str) {
        VmdriLog.d("HsManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void v(String str) {
        VmdriLog.e("HsManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void w(String str) {
        VmdriLog.w("HsManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void x(final w.c cVar) {
        this.f1548d.forEach(new Consumer() { // from class: d0.n
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((p.d) obj).a(cVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void z(c0.l lVar) {
        lVar.V(new c(new m(this)));
    }

    public void r(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("HsManager:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mAllRemoteDevInfo=" + this.f1549e);
        indentingPrintWriter.println("mHsRemoteDevInfo=" + this.f1550f);
        indentingPrintWriter.println("mHsDataChannels=" + this.f1551g);
        indentingPrintWriter.decreaseIndent();
    }

    public void y(d dVar) {
        this.f1548d.add(dVar);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class d {
        d() {
        }

        public abstract void a(w.c cVar);

        public void c(w.i iVar) {
        }

        public void d(w.i iVar) {
        }

        public void b(w.i iVar, VmdriVersion vmdriVersion, String str, String str2, long j2) {
        }
    }
}
