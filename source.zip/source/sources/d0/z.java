package d0;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class z extends Handler {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static String f1570i = "wifi_p2p_usage_state";

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static volatile z f1571j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f1572a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ConnectivityManager f1573b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private WifiP2pManager f1574c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private WifiP2pManager.Channel f1575d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private d f1576e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private ConcurrentHashMap f1577f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ArrayList f1578g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private String f1579h;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements WifiP2pManager.ChannelListener {
        a(z zVar) {
        }

        @Override // android.net.wifi.p2p.WifiP2pManager.ChannelListener
        public void onChannelDisconnected() {
            z.r("onChannelDisconnected");
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b extends ContentObserver {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ ContentResolver f1580a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        b(Handler handler, ContentResolver contentResolver) {
            super(handler);
            this.f1580a = contentResolver;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z2, Uri uri) {
            String strP = z.this.p(this.f1580a);
            if (z.this.f1579h.equals(strP)) {
                return;
            }
            z.q("wifi p2p state changed oldState " + z.this.f1579h + " -> newState:" + strP);
            z zVar = z.this;
            zVar.s(zVar.f1579h, strP);
            z.this.f1579h = strP;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static abstract class c {
        public abstract void a(String str, String str2);
    }

    private z(Context context, Looper looper) {
        super(looper);
        this.f1577f = new ConcurrentHashMap();
        this.f1578g = new ArrayList();
        this.f1579h = "Disabled";
        this.f1572a = context;
        this.f1573b = (ConnectivityManager) context.getSystemService("connectivity");
        WifiP2pManager wifiP2pManager = (WifiP2pManager) this.f1572a.getSystemService("wifip2p");
        this.f1574c = wifiP2pManager;
        this.f1575d = wifiP2pManager.initialize(this.f1572a, looper, new a(this));
        u();
        ContentResolver contentResolver = this.f1572a.getContentResolver();
        contentResolver.registerContentObserver(Settings.Global.getUriFor(f1570i), false, new b(this, contentResolver));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void j(String str, String str2) {
        q("addIpIfName:" + VmdriUtils.convertIpAddress(str) + " - " + str2);
        this.f1577f.put(str, str2);
    }

    public static z l(Context context, Looper looper) {
        if (f1571j == null) {
            synchronized (z.class) {
                try {
                    if (f1571j == null) {
                        f1571j = new z(context, looper);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return f1571j;
    }

    public static z o() {
        return f1571j;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String p(ContentResolver contentResolver) {
        String string = Settings.Global.getString(contentResolver, f1570i);
        return TextUtils.isEmpty(string) ? "Disabled" : string;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void q(String str) {
        VmdriLog.d("WifiP2pStateTracker", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void r(String str) {
        VmdriLog.e("WifiP2pStateTracker", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void s(String str, String str2) {
        ArrayList arrayList = this.f1578g;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            ((c) obj).a(str, str2);
        }
    }

    private void u() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.wifi.p2p.CONNECTION_STATE_CHANGE");
        d dVar = new d(this.f1574c, this.f1575d);
        this.f1576e = dVar;
        this.f1572a.registerReceiver(dVar, intentFilter, null, this, 2);
    }

    public void k() {
        q("clearIfNameIpCache");
        this.f1577f.clear();
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00e4 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:47:0x00e6 A[Catch: IOException -> 0x00e2, TRY_LEAVE, TryCatch #5 {IOException -> 0x00e2, blocks: (B:43:0x00de, B:47:0x00e6), top: B:70:0x00de }] */
    /* JADX WARN: Code duplicated, block: B:59:0x0111 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:60:0x0113 A[Catch: IOException -> 0x010f, TRY_LEAVE, TryCatch #6 {IOException -> 0x010f, blocks: (B:56:0x010b, B:60:0x0113), top: B:72:0x010b }] */
    /* JADX WARN: Code duplicated, block: B:64:0x012f  */
    /* JADX WARN: Code duplicated, block: B:70:0x00de A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:72:0x010b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:84:? A[SYNTHETIC] */
    public String m() throws Throwable {
        Process processExec;
        BufferedReader bufferedReader;
        Exception exc;
        StringBuilder sb = new StringBuilder();
        BufferedReader bufferedReader2 = null;
        try {
            processExec = Runtime.getRuntime().exec("ifconfig");
            try {
                BufferedReader bufferedReader3 = new BufferedReader(new InputStreamReader(processExec.getInputStream()));
                try {
                    while (true) {
                        try {
                            try {
                                try {
                                    String line = bufferedReader3.readLine();
                                    if (line == null) {
                                        break;
                                    }
                                    sb.append(line);
                                    sb.append("\n");
                                } catch (IOException | InterruptedException e2) {
                                    bufferedReader = null;
                                    bufferedReader2 = bufferedReader3;
                                    exc = e2;
                                }
                                if (processExec != null) {
                                    processExec.destroy();
                                }
                                return sb.toString();
                            } catch (Throwable th) {
                                th = th;
                                bufferedReader = null;
                            }
                            r("executeIfconfig error:" + exc.getMessage());
                            if (bufferedReader2 != null) {
                                try {
                                    bufferedReader2.close();
                                    if (bufferedReader != null) {
                                        bufferedReader.close();
                                    }
                                } catch (IOException e3) {
                                    r("executeIfconfig close error:" + e3.getMessage());
                                }
                            } else if (bufferedReader != null) {
                                bufferedReader.close();
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            if (bufferedReader2 != null) {
                                try {
                                    bufferedReader2.close();
                                    if (bufferedReader != null) {
                                        bufferedReader.close();
                                    }
                                } catch (IOException e4) {
                                    r("executeIfconfig close error:" + e4.getMessage());
                                    if (processExec == null) {
                                        throw th;
                                    }
                                    processExec.destroy();
                                    throw th;
                                }
                            } else if (bufferedReader != null) {
                                bufferedReader.close();
                            }
                            if (processExec == null) {
                                throw th;
                            }
                            processExec.destroy();
                            throw th;
                        }
                    }
                    bufferedReader3.close();
                    bufferedReader.close();
                } catch (IOException e5) {
                    r("executeIfconfig close error:" + e5.getMessage());
                }
                bufferedReader = new BufferedReader(new InputStreamReader(processExec.getErrorStream()));
                while (true) {
                    try {
                        String line2 = bufferedReader.readLine();
                        if (line2 == null) {
                            break;
                        }
                        sb.append("[ERROR] ");
                        sb.append(line2);
                        sb.append("\n");
                    } catch (IOException | InterruptedException e6) {
                        exc = e6;
                        bufferedReader2 = bufferedReader3;
                        r("executeIfconfig error:" + exc.getMessage());
                        if (bufferedReader2 != null) {
                            bufferedReader2.close();
                            if (bufferedReader != null) {
                                bufferedReader.close();
                            }
                        } else if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                        if (processExec != null) {
                        }
                        return sb.toString();
                    } catch (Throwable th3) {
                        th = th3;
                        bufferedReader2 = bufferedReader3;
                        if (bufferedReader2 != null) {
                            bufferedReader2.close();
                            if (bufferedReader != null) {
                                bufferedReader.close();
                            }
                        } else if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                        if (processExec == null) {
                            throw th;
                        }
                        processExec.destroy();
                        throw th;
                    }
                }
                if (!processExec.waitFor(1L, TimeUnit.SECONDS)) {
                    processExec.destroy();
                    r("Process timed out and was terminated");
                }
                if (processExec.exitValue() != 0) {
                    r("Process exited with status: " + processExec.exitValue());
                }
            } catch (IOException | InterruptedException e7) {
                exc = e7;
                bufferedReader = null;
            } catch (Throwable th4) {
                th = th4;
                bufferedReader = null;
            }
        } catch (IOException | InterruptedException e8) {
            processExec = null;
            exc = e8;
            bufferedReader = null;
        } catch (Throwable th5) {
            th = th5;
            processExec = null;
            bufferedReader = null;
        }
        processExec.destroy();
        return sb.toString();
    }

    public String n(String str) {
        return (String) this.f1577f.getOrDefault(str, "");
    }

    public void t(String str) {
        for (String str2 : str.split("\n\n")) {
            Matcher matcher = Pattern.compile("\\bp2p[a-z0-9-]*\\b").matcher(str2);
            if (matcher.find()) {
                String strGroup = matcher.group(0);
                Matcher matcher2 = Pattern.compile("inet (addr:)?(\\d+\\.\\d+\\.\\d+\\.\\d+)").matcher(str2);
                if (matcher2.find()) {
                    String strGroup2 = matcher2.group(2);
                    q("ifName:" + strGroup + " addr: " + VmdriUtils.convertIpAddress(strGroup2));
                    j(strGroup2, strGroup);
                }
            }
        }
    }

    public void v(c cVar) {
        this.f1578g.add(cVar);
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d extends BroadcastReceiver {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private WifiP2pManager f1582a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private WifiP2pManager.Channel f1583b;

        public d(WifiP2pManager wifiP2pManager, WifiP2pManager.Channel channel) {
            this.f1582a = wifiP2pManager;
            this.f1583b = channel;
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) throws Throwable {
            String action = intent.getAction();
            if ("android.net.wifi.p2p.STATE_CHANGED".equals(action)) {
                intent.getIntExtra("wifi_p2p_state", -1);
                return;
            }
            if ("android.net.wifi.p2p.PEERS_CHANGED".equals(action)) {
                return;
            }
            if (!"android.net.wifi.p2p.CONNECTION_STATE_CHANGE".equals(action)) {
                "android.net.wifi.p2p.THIS_DEVICE_CHANGED".equals(action);
                return;
            }
            NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
            WifiP2pGroup wifiP2pGroup = (WifiP2pGroup) intent.getParcelableExtra("p2pGroupInfo");
            WifiP2pInfo wifiP2pInfo = (WifiP2pInfo) intent.getParcelableExtra("wifiP2pInfo");
            if (networkInfo != null && networkInfo.isConnected()) {
                z.this.f1574c.requestConnectionInfo(z.this.f1575d, new a(this));
            }
            if (wifiP2pInfo != null) {
                boolean z2 = wifiP2pInfo.groupFormed;
                if (wifiP2pGroup == null || !z2) {
                    if (z2) {
                        return;
                    }
                    z.this.k();
                    return;
                }
                String str = wifiP2pGroup.getInterface();
                boolean zIsGroupOwner = wifiP2pGroup.isGroupOwner();
                z.q(action + ", ifName:" + str + ", isGroupOwner:" + zIsGroupOwner);
                if (zIsGroupOwner) {
                    z.this.j(wifiP2pInfo.groupOwnerAddress.getHostAddress(), str);
                } else {
                    z.this.t(z.this.m());
                }
            }
        }

        /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
        class a implements WifiP2pManager.ConnectionInfoListener {
            a(d dVar) {
            }

            @Override // android.net.wifi.p2p.WifiP2pManager.ConnectionInfoListener
            public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {
            }
        }
    }
}
