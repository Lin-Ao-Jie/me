package d0;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.IndentingPrintWriter;
import c0.e0;
import com.vivo.vmdri.VmdriLog;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class x extends Handler {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static x f1563e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static final Object f1564f = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f1565a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private HashMap f1566b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private List f1567c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private e0.c f1568d;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a extends e0.c {
        a(Executor executor) {
            super(executor);
        }

        @Override // c0.e0.c
        public void a(w.c cVar) {
            x.this.n(cVar);
        }

        @Override // c0.e0.c
        public void b(w.i iVar) {
            String strD = iVar.d();
            w.i iVar2 = (w.i) x.this.f1566b.get(strD);
            x.m("onRemoteDeviceConnStatusChanged, oldRemoteDevInfo:" + iVar2 + ", newRemoteDevInfo:" + iVar);
            if (iVar2 == null && iVar.k()) {
                x.this.f1566b.put(strD, iVar);
                x.this.o(iVar);
            } else if (iVar2 != null && iVar.k()) {
                x.this.f1566b.put(strD, iVar);
                x.this.q(iVar);
            } else {
                if (iVar2 == null || iVar.k()) {
                    return;
                }
                x.this.f1566b.remove(strD);
                x.this.p(iVar);
            }
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    static class b {
        b() {
        }

        public abstract void a(w.c cVar);

        public abstract void b(w.i iVar);

        public abstract void c(w.i iVar);

        public abstract void d(w.i iVar);
    }

    private x(Context context, Looper looper) {
        super(looper);
        this.f1566b = new HashMap();
        this.f1567c = new ArrayList();
        this.f1568d = new a(new Executor() { // from class: d0.s
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f1558a.post(runnable);
            }
        });
        this.f1565a = context;
        e0.A().L(this.f1568d);
    }

    public static x k(Context context, Looper looper) {
        x xVar;
        synchronized (f1564f) {
            try {
                if (f1563e != null) {
                    throw new RuntimeException("LinkManager already created!");
                }
                xVar = new x(context, looper);
                f1563e = xVar;
            } catch (Throwable th) {
                throw th;
            }
        }
        return xVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void m(String str) {
        VmdriLog.d("LinkManager", str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void n(final w.c cVar) {
        this.f1567c.forEach(new Consumer() { // from class: d0.w
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((x.b) obj).a(cVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void o(final w.i iVar) {
        this.f1567c.forEach(new Consumer() { // from class: d0.u
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((x.b) obj).b(iVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void p(final w.i iVar) {
        this.f1567c.forEach(new Consumer() { // from class: d0.v
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((x.b) obj).c(iVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void q(final w.i iVar) {
        this.f1567c.forEach(new Consumer() { // from class: d0.t
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((x.b) obj).d(iVar);
            }
        });
    }

    public void l(FileDescriptor fileDescriptor, IndentingPrintWriter indentingPrintWriter, String[] strArr) {
        indentingPrintWriter.println("LinkManager:");
        indentingPrintWriter.increaseIndent();
        indentingPrintWriter.println("mRemoteDevInfos=" + this.f1566b);
        indentingPrintWriter.println("mLinkManagerCallbackList=" + this.f1567c);
        indentingPrintWriter.decreaseIndent();
    }

    public void r(b bVar) {
        this.f1567c.add(bVar);
    }
}
