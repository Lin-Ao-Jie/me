package d0;

import java.util.concurrent.Executor;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class m implements Executor {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ p f1536a;

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f1536a.post(runnable);
    }
}
