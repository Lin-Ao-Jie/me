package d0;

import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriVersion;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class y {
    private static void a(String str) {
        VmdriLog.d("VersionStrategy", str);
    }

    public static VmdriVersion b(VmdriVersion vmdriVersion, VmdriVersion vmdriVersion2) {
        VmdriVersion vmdriVersion3 = vmdriVersion.compareTo(vmdriVersion2) < 0 ? vmdriVersion : vmdriVersion2;
        a("selectVersion, ver1:" + vmdriVersion + ", ver2:" + vmdriVersion2 + ", useVersion:" + vmdriVersion3);
        return vmdriVersion3;
    }
}
