package l0;

import android.text.TextUtils;
import com.vivo.vmdri.VmdriLog;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f1807a = "";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f1808b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f1809c = "";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f1810d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f1811e = "";

    private static void a(String str) {
        VmdriLog.e("HsMessage", str);
    }

    private JSONObject b() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(this.f1807a)) {
                jSONObject.put("id", this.f1807a);
            }
            if (!TextUtils.isEmpty(this.f1808b)) {
                jSONObject.put("ver", this.f1808b);
            }
            if (!TextUtils.isEmpty(this.f1811e)) {
                jSONObject.put("sysVer", this.f1811e);
            }
            if (!TextUtils.isEmpty(this.f1809c)) {
                jSONObject.put("vVerN", this.f1809c);
            }
            long j2 = this.f1810d;
            if (j2 > 0) {
                jSONObject.put("vVerC", j2);
                return jSONObject;
            }
        } catch (JSONException e2) {
            a("Error converting HsMessage to JSONObject" + e2.toString());
        }
        return jSONObject;
    }

    public static a d(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return e(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            a("Error parsing jsonStr to HsMessage object:" + e2.toString());
            return aVar;
        }
    }

    private static a e(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1807a = jSONObject.optString("id", "");
            aVar.f1808b = jSONObject.optString("ver", "");
            aVar.f1811e = jSONObject.optString("sysVer", "");
            aVar.f1809c = jSONObject.optString("vVerN", "14");
            aVar.f1810d = jSONObject.optLong("vVerC", 34L);
            return aVar;
        } catch (Exception e2) {
            a("Error parsing JSONObject to HsMessage object:" + e2.toString());
            return null;
        }
    }

    public String c() {
        return b().toString();
    }

    public String toString() {
        return "HsMessage{devId='" + this.f1807a + "', version='" + this.f1808b + "', vmdriBuildVersionName='" + this.f1809c + "', vmdriBuildVersionCode=" + this.f1810d + ", sysBuildVersion='" + this.f1811e + "'}";
    }
}
