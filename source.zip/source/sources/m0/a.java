package m0;

import com.vivo.vmdri.VmdriLog;
import com.vivo.vmdri.VmdriUtils;
import java.util.Base64;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1831a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1832b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1833c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1834d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1835e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte[] f1836f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1837g;

    public a(int i2, int i3, int i4, int i5, int i6, byte[] bArr) {
        this.f1831a = i2;
        this.f1832b = i3;
        this.f1833c = i4;
        this.f1834d = i5;
        this.f1835e = i6;
        this.f1836f = bArr;
    }

    private static void c(String str) {
        VmdriLog.e("RilMessage", str);
    }

    private JSONObject d() {
        JSONObject jSONObject = new JSONObject();
        try {
            int i2 = this.f1831a;
            if (i2 >= 0) {
                jSONObject.put("mdlId", i2);
            }
            int i3 = this.f1832b;
            if (i3 >= 0) {
                jSONObject.put("slot", i3);
            }
            int i4 = this.f1833c;
            if (i4 >= 0) {
                jSONObject.put("mId", i4);
            }
            int i5 = this.f1834d;
            if (i5 >= 0) {
                jSONObject.put("sn", i5);
            }
            int i6 = this.f1835e;
            if (i6 >= 0) {
                jSONObject.put("tp", i6);
            }
            if (this.f1836f != null) {
                jSONObject.put("dt", Base64.getEncoder().encodeToString(this.f1836f));
            }
            int i7 = this.f1837g;
            if (i7 != 0) {
                jSONObject.put("err", i7);
                return jSONObject;
            }
        } catch (JSONException e2) {
            c("Error converting RilMessage to JSONObject:" + e2.toString());
        }
        return jSONObject;
    }

    public static a f(String str) {
        if (str == null) {
            return new a();
        }
        try {
            return g(new JSONObject(str));
        } catch (JSONException e2) {
            a aVar = new a();
            c("Error parsing jsonStr to RilMessage object" + e2.toString());
            return aVar;
        }
    }

    private static a g(JSONObject jSONObject) {
        try {
            a aVar = new a();
            aVar.f1831a = jSONObject.optInt("mdlId", -1);
            aVar.f1832b = jSONObject.optInt("slot", -1);
            aVar.f1833c = jSONObject.optInt("mId", -1);
            aVar.f1834d = jSONObject.optInt("sn", -1);
            aVar.f1835e = jSONObject.optInt("tp", -1);
            aVar.f1836f = !jSONObject.isNull("dt") ? Base64.getDecoder().decode(jSONObject.getString("dt")) : null;
            aVar.f1837g = jSONObject.optInt("err", 0);
            return aVar;
        } catch (Exception e2) {
            c("Error parsing JSONObject to RilMessage object:" + e2.toString());
            return null;
        }
    }

    public String a() {
        byte[] bArr = this.f1836f;
        if (bArr == null || bArr.length <= 0) {
            return "null";
        }
        return "[" + this.f1832b + "]" + VmdriUtils.convertByteToHexString(this.f1836f);
    }

    public String b() {
        int i2 = this.f1835e;
        if (i2 == 1) {
            return "REQ";
        }
        if (i2 == 2) {
            return "RESP";
        }
        if (i2 == 3) {
            return "UNSOL";
        }
        return "UNKNOWN(" + this.f1835e + ")";
    }

    public String e() {
        return d().toString();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("RilMessage{messageId=");
        sb.append(this.f1833c);
        sb.append(", serial=");
        sb.append(this.f1834d);
        sb.append(", moduleId=");
        sb.append(this.f1831a);
        sb.append(", slotId=");
        sb.append(this.f1832b);
        sb.append(", type=");
        sb.append(b());
        sb.append(", dataLen=");
        byte[] bArr = this.f1836f;
        sb.append(bArr == null ? "null" : Integer.valueOf(bArr.length));
        sb.append(", errCode=");
        sb.append(this.f1837g);
        sb.append('}');
        return sb.toString();
    }

    private a() {
    }
}
