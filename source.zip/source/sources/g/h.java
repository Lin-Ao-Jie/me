package g;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Point;
import android.graphics.Rect;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static String f1648a = "phone";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static boolean f1649b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Field f1650c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Method f1651d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static Method f1652e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static Method f1653f;

    /* JADX WARN: Code duplicated, block: B:17:0x0056  */
    /* JADX WARN: Code duplicated, block: B:18:0x0059 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:19:0x005b  */
    /* JADX WARN: Code duplicated, block: B:21:0x0060  */
    /* JADX WARN: Code duplicated, block: B:24:0x006f  */
    /* JADX WARN: Code duplicated, block: B:25:0x0072  */
    public static i a(Activity activity) {
        int iHeight;
        int iWidth;
        int i2;
        int i3;
        Rect rectN;
        Display displayG = g(activity);
        Point point = new Point();
        displayG.getSize(point);
        Point point2 = new Point();
        displayG.getRealSize(point2);
        int i4 = 0;
        if (activity.getApplicationContext().getApplicationInfo().targetSdkVersion >= 35 || (rectN = n(activity.getResources().getConfiguration())) == null) {
            iHeight = 0;
            iWidth = 0;
        } else {
            iWidth = rectN.width();
            iHeight = rectN.height();
        }
        int rotation = displayG.getRotation();
        int rotation2 = displayG.getRotation();
        if (rotation2 == 0) {
            if (iHeight == 0) {
                i2 = point.y;
            } else {
                i2 = iHeight;
            }
            i4 = (int) ((((((double) i2) * 1.0d) * 100.0d) / (((double) point2.y) * 1.0d)) + 0.5d);
        } else if (rotation2 == 1) {
            if (iWidth == 0) {
                i3 = point.x;
            } else {
                i3 = iWidth;
            }
            i4 = (int) ((((((double) i3) * 1.0d) * 100.0d) / (((double) point2.x) * 1.0d)) + 0.5d);
        } else if (rotation2 == 2) {
            if (iHeight == 0) {
                i2 = point.y;
            } else {
                i2 = iHeight;
            }
            i4 = (int) ((((((double) i2) * 1.0d) * 100.0d) / (((double) point2.y) * 1.0d)) + 0.5d);
        } else if (rotation2 == 3) {
            if (iWidth == 0) {
                i3 = point.x;
            } else {
                i3 = iWidth;
            }
            i4 = (int) ((((((double) i3) * 1.0d) * 100.0d) / (((double) point2.x) * 1.0d)) + 0.5d);
        }
        int iC = c(displayG, activity);
        int iJ = j(iC);
        i iVar = new i();
        i iVarJ = iVar.i(displayG).k(i4).l(rotation).j(iJ);
        if (iHeight == 0) {
            iHeight = point.y;
        }
        i iVarO = iVarJ.n(iHeight).o(iC);
        if (iWidth == 0) {
            iWidth = point.x;
        }
        iVarO.p(activity, iWidth).h(e(activity, t(iC)));
        return iVar;
    }

    /* JADX WARN: Code duplicated, block: B:21:0x005e  */
    public static i b(Context context) {
        Display defaultDisplay;
        double d2;
        int i2;
        int i3;
        try {
            defaultDisplay = context.getDisplay();
        } catch (Exception e2) {
            l.c("ResponsiveCalculate", "getDisplay error:", e2);
            defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        }
        if (defaultDisplay == null) {
            l.a("ResponsiveCalculate", "calculateDeviceByContextWindow display is null");
            return null;
        }
        Point point = new Point();
        defaultDisplay.getSize(point);
        Point point2 = new Point();
        defaultDisplay.getRealSize(point2);
        int iO = o(context.getResources().getConfiguration());
        if (iO == 0) {
            d2 = ((double) point.y) * 1.0d * 100.0d;
            i2 = point2.y;
            i3 = (int) ((d2 / (((double) i2) * 1.0d)) + 0.5d);
        } else {
            if (iO != 1) {
                if (iO == 2) {
                    d2 = ((double) point.y) * 1.0d * 100.0d;
                    i2 = point2.y;
                    i3 = (int) ((d2 / (((double) i2) * 1.0d)) + 0.5d);
                } else if (iO != 3) {
                    i3 = 0;
                }
            }
            d2 = ((double) point.x) * 1.0d * 100.0d;
            i2 = point2.x;
            i3 = (int) ((d2 / (((double) i2) * 1.0d)) + 0.5d);
        }
        int iK = k(iO);
        int iD = d(defaultDisplay, context, iK);
        i iVar = new i();
        iVar.i(defaultDisplay).k(i3).l(iO).j(iK).n(point.y).o(iD).h(f(context)).p(context, point.x);
        return iVar;
    }

    public static int c(Display display, Activity activity) {
        double d2;
        if (activity != null && display != null) {
            if (s(activity.getResources().getConfiguration(), activity)) {
                return 256;
            }
            if (!activity.isInMultiWindowMode()) {
                return activity.getResources().getConfiguration().orientation == 1 ? 1 : 16;
            }
            if (u(activity)) {
                return 256;
            }
            Rect rect = new Rect();
            Point point = new Point();
            display.getRealSize(point);
            rect.set(0, 0, point.x, point.y);
            Point point2 = new Point();
            display.getSize(point2);
            Rect rect2 = new Rect();
            rect2.set(0, 0, point2.x, point2.y);
            int iHeight = rect.height();
            int iWidth = rect.width();
            int i2 = activity.getResources().getDisplayMetrics().heightPixels;
            int i3 = activity.getResources().getDisplayMetrics().widthPixels;
            l.d("ResponsiveCalculate", "calculateResponsiveState mAbsHeight:" + iHeight + " ,mAbsWidth:" + iWidth + " ,windowHeight: " + i2 + " ,windowWidth: " + i3 + " ,displayHeight: " + rect2.height() + " ,displayWidth: " + rect2.width() + " , responsive_6.0.1.11");
            if (i3 < iWidth && i2 < iHeight && r(activity)) {
                return 256;
            }
            if (i3 != iWidth) {
                d2 = 80.0d;
                if (i3 < ((double) iWidth) * 0.95d) {
                    double d3 = (i3 / iWidth) * 100.0f;
                    if (d3 > 20.0d && d3 <= 40.0d) {
                        return 128;
                    }
                    if (d3 > 40.0d && d3 <= 55.0d) {
                        return 64;
                    }
                    if (d3 > 55.0d && d3 < 80.0d) {
                        return 32;
                    }
                    if (activity.isInMultiWindowMode()) {
                        return 64;
                    }
                }
            } else {
                d2 = 80.0d;
            }
            double d4 = (i2 / iHeight) * 100.0f;
            if (d4 > 20.0d && d4 <= 40.0d) {
                return 8;
            }
            if (d4 > 40.0d && d4 <= 55.0d) {
                return 4;
            }
            if (d4 > 55.0d && d4 < d2) {
                return 2;
            }
            if (activity.isInMultiWindowMode()) {
                return 4;
            }
        }
        return 1;
    }

    public static int d(Display display, Context context, int i2) {
        if (context == null || display == null) {
            return 1;
        }
        Rect rect = new Rect();
        Point point = new Point();
        display.getRealSize(point);
        rect.set(0, 0, point.x, point.y);
        Point point2 = new Point();
        display.getSize(point2);
        Rect rect2 = new Rect();
        rect2.set(0, 0, point2.x, point2.y);
        int iHeight = rect.height();
        int iWidth = rect.width();
        int i3 = context.getResources().getDisplayMetrics().heightPixels;
        int i4 = context.getResources().getDisplayMetrics().widthPixels;
        l.d("ResponsiveCalculate", "calculateResponsiveState mAbsHeight:" + iHeight + " ,mAbsWidth:" + iWidth + " ,windowHeight: " + i3 + " ,windowWidth: " + i4 + " ,displayHeight: " + rect2.height() + " ,displayWidth: " + rect2.width() + " , orien=" + i2);
        if (i4 < iWidth && i3 < iHeight && r(context)) {
            return 256;
        }
        if (i2 == 1) {
            float f2 = (i3 / iHeight) * 100.0f;
            l.a("ResponsiveCalculate", "PORTRAIT heightPercentage =" + f2);
            double d2 = (double) f2;
            if (d2 > 20.0d && d2 <= 40.0d) {
                return 8;
            }
            if (d2 <= 40.0d || d2 > 55.0d) {
                return (d2 <= 55.0d || d2 >= 80.0d) ? 1 : 2;
            }
            return 4;
        }
        float f3 = (i4 / iWidth) * 100.0f;
        l.a("ResponsiveCalculate", "LANDSCAPE widthPercentage =" + f3);
        double d3 = (double) f3;
        if (d3 > 20.0d && d3 <= 40.0d) {
            return 128;
        }
        if (d3 <= 40.0d || d3 > 55.0d) {
            return (d3 <= 55.0d || d3 >= 80.0d) ? 16 : 32;
        }
        return 64;
    }

    public static int e(Activity activity, boolean z2) {
        Configuration configuration;
        String strH = h();
        strH.getClass();
        switch (strH) {
            case "tablet":
                return 2;
            case "flip":
                return 16;
            case "foldable":
                if (activity != null && (configuration = activity.getResources().getConfiguration()) != null) {
                    int i2 = configuration.screenLayout & 48;
                    if (z2) {
                        return q(activity) ? 4 : 8;
                    }
                    if (i2 == 32) {
                        return 4;
                    }
                    if (i2 == 16) {
                        return 8;
                    }
                }
                return 1;
            default:
                return 1;
        }
    }

    public static int f(Context context) {
        String strH = h();
        strH.getClass();
        switch (strH) {
            case "tablet":
                return 2;
            case "flip":
                return 16;
            case "foldable":
                if (context != null) {
                    return q(context) ? 4 : 8;
                }
                return 1;
            default:
                return 1;
        }
    }

    public static Display g(Context context) {
        return ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
    }

    public static String h() {
        if (!f1649b) {
            p();
        }
        return f1648a;
    }

    public static String i() {
        try {
            Class<?> cls = Class.forName("android.util.FtDeviceInfo");
            Class[] clsArr = new Class[0];
            return (String) cls.getDeclaredMethod("getDeviceType", null).invoke(cls.newInstance(), null);
        } catch (Throwable unused) {
            return "";
        }
    }

    public static int j(int i2) {
        return (i2 == 1 || i2 == 2 || i2 == 4 || i2 == 8 || i2 == 15) ? 1 : 2;
    }

    public static int k(int i2) {
        return (i2 == 0 || i2 == 2) ? 1 : 2;
    }

    public static i l(Activity activity) {
        if (activity != null) {
            return a(activity);
        }
        return null;
    }

    public static String m() {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            return (String) cls.getDeclaredMethod("get", String.class).invoke(cls, "ro.vivo.device.type");
        } catch (Throwable unused) {
            return "";
        }
    }

    private static Rect n(Configuration configuration) {
        Rect rect = null;
        try {
            if (f1650c == null) {
                f1650c = Configuration.class.getField("windowConfiguration");
            }
            f1650c.setAccessible(true);
            Object obj = f1650c.get(configuration);
            if (f1652e == null) {
                Class[] clsArr = new Class[0];
                f1652e = obj.getClass().getMethod("getBounds", null);
            }
            Rect rect2 = (Rect) f1652e.invoke(obj, null);
            try {
                l.a("ResponsiveCalculate", "getWindowBounds success");
                return rect2;
            } catch (Exception unused) {
                rect = rect2;
                l.a("ResponsiveCalculate", "getWindowBounds error");
                return rect;
            }
        } catch (Exception unused2) {
        }
    }

    private static int o(Configuration configuration) {
        int iIntValue = 0;
        try {
            if (f1650c == null) {
                f1650c = Configuration.class.getField("windowConfiguration");
            }
            f1650c.setAccessible(true);
            Object obj = f1650c.get(configuration);
            if (f1653f == null) {
                Class[] clsArr = new Class[0];
                f1653f = obj.getClass().getMethod("getRotation", null);
            }
            iIntValue = ((Integer) f1653f.invoke(obj, null)).intValue();
            l.a("ResponsiveCalculate", "getRotation success");
            return iIntValue;
        } catch (Exception unused) {
            l.a("ResponsiveCalculate", "getRotation error");
            return iIntValue;
        }
    }

    public static void p() {
        String strM = m();
        f1648a = strM;
        if (TextUtils.isEmpty(strM)) {
            f1648a = i();
        }
        if (TextUtils.isEmpty(f1648a)) {
            f1648a = "phone";
        }
        f1649b = true;
    }

    public static boolean q(Context context) {
        try {
            Rect bounds = ((WindowManager) context.getSystemService("window")).getMaximumWindowMetrics().getBounds();
            float fHeight = bounds.height();
            float fWidth = bounds.width();
            if (k.d(context)) {
                fWidth = bounds.right;
            }
            float f2 = fHeight > fWidth ? fHeight / fWidth : fWidth / fHeight;
            l.b("ResponsiveCalculate", "screenHeight: " + fHeight + "screenWidth：" + fWidth);
            return f2 > 1.67f;
        } catch (Throwable th) {
            l.b("ResponsiveCalculate", "isFolderByDisplay error : " + th.getMessage());
            return false;
        }
    }

    public static boolean r(Context context) {
        try {
            return Settings.System.getInt(context.getContentResolver(), "smartmultiwindow_freeform", 0) == 1;
        } catch (Exception unused) {
        }
    }

    private static boolean s(Configuration configuration, Activity activity) {
        try {
            if (f1650c == null) {
                f1650c = Configuration.class.getField("windowConfiguration");
            }
            f1650c.setAccessible(true);
            Object obj = f1650c.get(configuration);
            if (f1651d == null) {
                Class[] clsArr = new Class[0];
                f1651d = obj.getClass().getMethod("getWindowingMode", null);
            }
            int iIntValue = ((Integer) f1651d.invoke(obj, null)).intValue();
            l.a("ResponsiveCalculate", "isWindowInFreeFormByTaskInfo, windowingMode: " + iIntValue);
            return iIntValue == 106;
        } catch (Exception e2) {
            l.a("ResponsiveCalculate", "isWindowInFreeFormByTaskInfo error" + e2);
            try {
                l.a("ResponsiveCalculate", "setInVivoFreeform == " + v(activity));
                return v(activity);
            } catch (Exception e3) {
                l.a("ResponsiveCalculate", "setInVivoFreeform error" + e3);
                return false;
            }
        }
    }

    public static boolean t(int i2) {
        return i2 == 2 || i2 == 4 || i2 == 8 || i2 == 32 || i2 == 64 || i2 == 128 || i2 == 256;
    }

    public static boolean u(Activity activity) {
        Method method;
        if (activity != null) {
            Window window = activity.getWindow();
            try {
                Class<?> cls = window.getClass();
                if (cls.getSuperclass() != null) {
                    method = null;
                    for (Method method2 : cls.getSuperclass().getDeclaredMethods()) {
                        if (method2 != null && "getWindowControllerCallback".equals(method2.getName())) {
                            method = method2;
                        }
                    }
                } else {
                    method = null;
                }
                if (method == null) {
                    l.b("ResponsiveCalculate", "<isWindowModeFreeForm> registerActivityObserver not implement in IActivityManager");
                    return false;
                }
                Object objInvoke = method.invoke(window, null);
                if (objInvoke != null) {
                    for (Method method3 : objInvoke.getClass().getDeclaredMethods()) {
                        if (method3 != null && "isInVivoFreeformMode".equals(method3.getName())) {
                            method = method3;
                        }
                    }
                    return ((Boolean) method.invoke(objInvoke, null)).booleanValue();
                }
            } catch (Exception e2) {
                l.c("ResponsiveCalculate", "<isWindowModeFreeForm> registerActivityObserver-e = ", e2);
            }
        }
        return false;
    }

    private static boolean v(Activity activity) {
        return activity.getResources().getConfiguration().toString().contains("mWindowingMode=vivofreeform");
    }
}
