package g;

import android.content.Context;
import android.view.Display;
import com.originui.core.utils.s;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1654a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1655b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1656c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1657d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1658e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Display f1659f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1660g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1661h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f1662i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f1663j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f1664k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public b f1665l;

    public int a() {
        return this.f1657d;
    }

    public int b() {
        return this.f1658e;
    }

    public int c() {
        return this.f1655b;
    }

    public b d() {
        return this.f1665l;
    }

    public int e() {
        return this.f1656c;
    }

    public int f() {
        return this.f1654a;
    }

    public int g() {
        return this.f1663j;
    }

    public i h(int i2) {
        this.f1655b = i2;
        return this;
    }

    public i i(Display display) {
        this.f1659f = display;
        return this;
    }

    public i j(int i2) {
        this.f1662i = i2;
        return this;
    }

    public i k(int i2) {
        this.f1660g = i2;
        return this;
    }

    public i l(int i2) {
        this.f1661h = i2;
        return this;
    }

    public void m(i iVar) {
        if (iVar != null) {
            this.f1654a = iVar.f();
            this.f1655b = iVar.c();
            this.f1656c = iVar.e();
            this.f1657d = iVar.a();
            this.f1658e = iVar.b();
        }
    }

    public i n(int i2) {
        this.f1664k = i2;
        return this;
    }

    public i o(int i2) {
        this.f1654a = i2;
        return this;
    }

    public i p(Context context, int i2) {
        this.f1663j = i2;
        c cVarC = c.c();
        boolean z2 = false;
        if (!s.f(context) && this.f1654a == 256) {
            z2 = true;
        }
        this.f1665l = cVarC.a(i2, z2);
        return this;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("{");
        if (this.f1654a > 0) {
            stringBuffer.append(" window = ");
            stringBuffer.append(this.f1654a);
        }
        if (this.f1655b > 0) {
            stringBuffer.append(", device = ");
            stringBuffer.append(this.f1655b);
        }
        if (this.f1656c > 0) {
            stringBuffer.append(", rom = ");
            stringBuffer.append(this.f1656c);
        }
        if (this.f1657d > 0) {
            stringBuffer.append(", category = ");
            stringBuffer.append(this.f1657d);
        }
        if (this.f1658e > 0) {
            stringBuffer.append(", model = ");
            stringBuffer.append(this.f1658e);
        }
        if (this.f1663j > 0) {
            stringBuffer.append(", windowWidth = ");
            stringBuffer.append(this.f1663j);
        }
        if (this.f1665l != null) {
            stringBuffer.append(", gridSystem = ");
            stringBuffer.append(this.f1665l.toString());
        }
        stringBuffer.append('}');
        String string = stringBuffer.toString();
        stringBuffer.setLength(0);
        return string;
    }
}
