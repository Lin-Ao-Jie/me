package g;

import vivo.util.VLog;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f1709a = true;

    public static void a(String str, String str2) {
        if (f1709a) {
            VLog.d("ResponsiveDebug/" + str, str2);
        }
    }

    public static void b(String str, String str2) {
        if (f1709a) {
            VLog.e("ResponsiveDebug/" + str, str2);
        }
    }

    public static void c(String str, String str2, Exception exc) {
        if (f1709a) {
            VLog.e("ResponsiveDebug/" + str, str2, exc);
        }
    }

    public static void d(String str, String str2) {
        if (f1709a) {
            VLog.i("ResponsiveDebug/" + str, str2);
        }
    }
}
