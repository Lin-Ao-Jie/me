package g;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface f extends e {
    @Override // g.e
    default a getBaseStateManager() {
        return getGridContainer().getBaseStateManager();
    }

    @Override // g.e
    default int getCalculateBarHeight() {
        return getGridContainer().getCalculateBarHeight();
    }

    @Override // g.e
    default int getCustomDefaultIndent() {
        return getGridContainer().getCustomDefaultIndent();
    }

    @Override // g.e
    default int getFoldPageMargin() {
        return getGridContainer().getFoldPageMargin();
    }

    e getGridContainer();

    @Override // g.e
    default int getGridIndent() {
        return getGridContainer().getGridIndent();
    }

    @Override // j.c
    default j.a getGridRule() {
        return getGridContainer().getGridRule();
    }

    @Override // g.e
    default int getIndentType() {
        return getGridContainer().getIndentType();
    }

    @Override // g.e
    default boolean getIsDisplayCutout() {
        return getGridContainer().getIsDisplayCutout();
    }

    @Override // g.e
    default int getOffset() {
        return getGridContainer().getOffset();
    }

    @Override // g.e
    default i getResponsiveState() {
        return getGridContainer().getResponsiveState();
    }

    @Override // g.e
    default void setCardStyle(boolean z2) {
        getGridContainer().setCardStyle(z2);
    }

    @Override // g.e
    default void setCustomDefaultIndent(int i2) {
        getGridContainer().setCustomDefaultIndent(i2);
    }

    @Override // g.e
    default void setCustomResponsiveState(i iVar) {
        getGridContainer().setCustomResponsiveState(iVar);
    }

    @Override // g.e
    default void setFoldPageMargin(int i2) {
        getGridContainer().setFoldPageMargin(i2);
    }

    @Override // g.e
    default void setFullColumn(boolean z2) {
        getGridContainer().setFullColumn(z2);
    }

    @Override // g.e
    default void setGridIndent(boolean z2) {
        getGridContainer().setGridIndent(z2);
    }

    @Override // g.e
    default void setGridIndentListener(d dVar) {
        getGridContainer().setGridIndentListener(dVar);
    }

    @Override // g.e
    default void setIndentStyle(int i2) {
        getGridContainer().setIndentStyle(i2);
    }

    @Override // g.e
    default void setIndentType(int i2) {
        getGridContainer().setIndentType(i2);
    }

    @Override // g.e
    default void setLeftSplitScreen(boolean z2) {
        getGridContainer().setLeftSplitScreen(z2);
    }

    @Override // g.e
    default void setOffset(int i2) {
        getGridContainer().setOffset(i2);
    }

    @Override // g.e
    default void setSplitScreen(boolean z2) {
        getGridContainer().setSplitScreen(z2);
    }

    @Override // g.e
    default void setUseDisplayCutout(boolean z2) {
        getGridContainer().setUseDisplayCutout(z2);
    }
}
