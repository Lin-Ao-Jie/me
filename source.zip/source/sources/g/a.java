package g;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected final i f1624a = new i();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected i f1625b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private g f1626c;

    public void a(Configuration configuration) {
        this.f1624a.m(this.f1625b);
        if (c() != null) {
            this.f1625b = h.l(c());
        } else {
            Context contextD = d();
            if (contextD != null) {
                this.f1625b = h.b(contextD);
            }
        }
        f(configuration, this.f1625b);
    }

    public void b(g gVar) {
        this.f1626c = gVar;
        Activity activityC = c();
        if (activityC != null) {
            this.f1625b = h.l(activityC);
        } else {
            Context contextD = d();
            if (contextD != null) {
                this.f1625b = h.b(contextD);
            }
        }
        this.f1624a.m(this.f1625b);
        g gVar2 = this.f1626c;
        if (gVar2 != null) {
            gVar2.b(this.f1625b);
        }
    }

    public Activity c() {
        g gVar = this.f1626c;
        if (gVar != null) {
            return gVar.getResponsiveSubject();
        }
        return null;
    }

    public Context d() {
        g gVar = this.f1626c;
        if (gVar != null) {
            return gVar.getResponsiveContext();
        }
        return null;
    }

    protected boolean e(i iVar, i iVar2) {
        return iVar != null && iVar2 != null && iVar.f() == iVar2.f() && iVar.c() == iVar2.c() && iVar.e() == iVar2.e() && iVar.a() == iVar2.a() && iVar.b() == iVar2.b();
    }

    public void f(Configuration configuration, i iVar) {
        if (this.f1626c != null) {
            this.f1626c.a(configuration, iVar, e(this.f1625b, this.f1624a));
        }
    }
}
