package g;

import android.app.Activity;
import android.content.Context;
import com.originui.core.utils.m;
import com.originui.core.utils.s;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public abstract class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static boolean f1700a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Field f1701b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f1702c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static Method f1703d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static Method f1704e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static Method f1705f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static Class f1706g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static Method f1707h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static Object f1708i;

    static {
        try {
            Class<?> cls = Class.forName("androidx.window.extensions.embedding.SplitController");
            f1706g = cls;
            Class[] clsArr = new Class[0];
            Method declaredMethod = cls.getDeclaredMethod("getInstance", null);
            f1707h = declaredMethod;
            Object objInvoke = declaredMethod.invoke(null, null);
            f1708i = objInvoke;
            if (objInvoke != null) {
                Method declaredMethod2 = objInvoke.getClass().getDeclaredMethod("isActivityEmbedded", Activity.class);
                f1703d = declaredMethod2;
                declaredMethod2.setAccessible(true);
            }
        } catch (Throwable th) {
            m.c("VGridDelegateUtils", "get mActivityEmbedding error", th);
        }
    }

    private static boolean a(Context context) {
        boolean zBooleanValue = false;
        try {
            Object obj = f1708i;
            if (obj != null) {
                zBooleanValue = ((Boolean) f1703d.invoke(obj, context)).booleanValue();
            }
        } catch (Exception e2) {
            m.b("VGridDelegateUtils", "activityEmbeddingControllerError: " + e2);
        }
        m.b("VGridDelegateUtils", "activityEmbeddingController isSplit=" + zBooleanValue);
        return zBooleanValue;
    }

    public static boolean b() {
        return f1700a;
    }

    public static boolean c(Context context) {
        if (!s.f(context)) {
            return false;
        }
        int iA = com.originui.core.utils.j.a(context);
        double dE = c.e();
        BigDecimal bigDecimalValueOf = BigDecimal.valueOf(context.getResources().getDisplayMetrics().density);
        BigDecimal bigDecimalValueOf2 = BigDecimal.valueOf(dE);
        BigDecimal bigDecimalValueOf3 = BigDecimal.valueOf(160L);
        RoundingMode roundingMode = RoundingMode.HALF_UP;
        BigDecimal bigDecimalDivide = bigDecimalValueOf.divide(bigDecimalValueOf2.divide(bigDecimalValueOf3, 2, roundingMode), 2, roundingMode);
        if ((!com.originui.core.utils.h.g() || bigDecimalDivide.compareTo(new BigDecimal("1.2")) < 0 || iA < 4) && iA < 5) {
            return com.originui.core.utils.h.i() && bigDecimalDivide.compareTo(new BigDecimal("1.1")) >= 0 && iA >= 4;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:51:0x0101  */
    public static boolean d(Context context) {
        boolean z2;
        boolean z3;
        if (!b()) {
            m.b("VGridDelegateUtils", "getLayoutGridDelegate is false");
            return false;
        }
        if (com.originui.core.utils.h.k() && com.originui.core.utils.h.g()) {
            m.b("VGridDelegateUtils", "currentDeviceType is phone");
            return false;
        }
        try {
            Class<?> cls = Class.forName("android.content.res.Configuration");
            if (f1701b == null) {
                f1701b = cls.getField("windowConfiguration");
            }
            Object obj = f1701b.get(context.getResources().getConfiguration());
            Class<?> cls2 = obj.getClass();
            if (f1702c == null) {
                Class[] clsArr = new Class[0];
                Method declaredMethod = cls2.getDeclaredMethod("isEmbedding", null);
                f1702c = declaredMethod;
                declaredMethod.setAccessible(true);
            }
            if (f1704e == null) {
                Class[] clsArr2 = new Class[0];
                Method declaredMethod2 = cls2.getDeclaredMethod("getWindowingMode", null);
                f1704e = declaredMethod2;
                declaredMethod2.setAccessible(true);
            }
            try {
                try {
                    if (f1705f == null) {
                        Class[] clsArr3 = new Class[0];
                        Method declaredMethod3 = cls2.getDeclaredMethod("inSplitScreenMode", null);
                        f1705f = declaredMethod3;
                        declaredMethod3.setAccessible(true);
                    }
                } catch (Exception e2) {
                    m.b("VGridDelegateUtils", "inSplitScreenMode error: " + e2);
                    if (((Boolean) f1702c.invoke(obj, null)).booleanValue() && ((Integer) f1704e.invoke(obj, null)).intValue() != 1 && ((Integer) f1704e.invoke(obj, null)).intValue() != 6) {
                        z2 = true;
                    }
                    if (((Boolean) f1702c.invoke(obj, null)).booleanValue()) {
                        z3 = false;
                    } else {
                        z3 = false;
                    }
                    if (z3) {
                    }
                }
                if (((Boolean) f1702c.invoke(obj, null)).booleanValue() || ((Integer) f1704e.invoke(obj, null)).intValue() == 1 || (((Boolean) f1705f.invoke(obj, null)).booleanValue() && ((Integer) f1704e.invoke(obj, null)).intValue() == 6)) {
                    z3 = false;
                } else {
                    z3 = true;
                }
            } catch (Exception e3) {
                e = e3;
                m.b("VGridDelegateUtils", "isSplitLayout error: " + e);
                z3 = z2;
            }
            z2 = false;
        } catch (Exception e4) {
            e = e4;
            z2 = false;
        }
        return !z3 || a(context);
    }
}
