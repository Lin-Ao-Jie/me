package g;

import android.content.res.Resources;
import android.text.TextUtils;
import com.originui.core.utils.q;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Method f1637a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static Class f1638b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Method f1639c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static int f1640d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static volatile c f1641e;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final int f1642a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final int f1643b;

        static {
            f1642a = q.p() ? 32 : 30;
            f1643b = q.p() ? 26 : 24;
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final int f1644a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final int f1645b;

        static {
            int i2;
            int i3;
            if (c.f()) {
                i2 = C0010c.f1646a;
            } else {
                i2 = q.p() ? 32 : 30;
            }
            f1644a = i2;
            if (c.f()) {
                i3 = C0010c.f1647b;
            } else {
                i3 = q.p() ? 26 : 24;
            }
            f1645b = i3;
        }
    }

    /* JADX INFO: renamed from: g.c$c, reason: collision with other inner class name */
    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    public static class C0010c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final int f1646a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final int f1647b;

        static {
            f1646a = q.p() ? 26 : 24;
            f1647b = q.p() ? 22 : 20;
        }
    }

    public static int b(float f2) {
        float f3 = Resources.getSystem().getDisplayMetrics().density;
        if (f1640d == -1) {
            g();
        }
        int i2 = f1640d;
        if (i2 != -1 && i2 >= 160.0f) {
            f3 = i2 / 160.0f;
        }
        return Math.round(f3 * f2);
    }

    public static c c() {
        if (f1641e == null) {
            synchronized (c.class) {
                try {
                    if (f1641e == null) {
                        f1641e = new c();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return f1641e;
    }

    public static int d() {
        int iIntValue = -1;
        try {
            if (f1638b == null) {
                f1638b = Class.forName("android.view.WindowManagerGlobal");
            }
            if (f1637a == null) {
                Class[] clsArr = new Class[0];
                f1637a = f1638b.getMethod("getWindowManagerService", null);
            }
            f1637a.setAccessible(true);
            Object objInvoke = f1637a.invoke(f1638b, null);
            if (f1639c == null) {
                f1639c = objInvoke.getClass().getMethod("getInitialDisplayDensity", Integer.TYPE);
            }
            f1639c.setAccessible(true);
            iIntValue = ((Integer) f1639c.invoke(objInvoke, 0)).intValue();
            l.a("GridSystemFactory", "getDefaultDisplayDensity sucess , value : " + iIntValue + ", density : " + Resources.getSystem().getDisplayMetrics().density);
            return iIntValue;
        } catch (Throwable th) {
            l.a("GridSystemFactory", "getDefaultDisplayDensity error , " + th.getMessage());
            return iIntValue;
        }
    }

    public static int e() {
        if (f1640d == -1) {
            g();
        }
        return f1640d;
    }

    public static boolean f() {
        return TextUtils.equals("foldable", h.h());
    }

    public static void g() {
        f1640d = d();
    }

    public g.b a(int i2, boolean z2) {
        if (z2) {
            return new g.b(i2, 2, 480, 4, 8, C0010c.f1646a, C0010c.f1647b);
        }
        if (i2 <= b(200.0f)) {
            return new g.b(i2, 1, 200, 2, 8, 8, 8);
        }
        if (i2 <= b(480.0f)) {
            return new g.b(i2, 2, 480, 4, 8, C0010c.f1646a, C0010c.f1647b);
        }
        return i2 <= b(920.0f) ? new g.b(i2, 4, 920, 8, 8, b.f1644a, b.f1645b) : new g.b(i2, 8, 2000, 12, 8, a.f1642a, a.f1643b);
    }
}
