package g;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface e extends j.c {
    a getBaseStateManager();

    int getCalculateBarHeight();

    int getCustomDefaultIndent();

    int getFoldPageMargin();

    int getGridIndent();

    int getIndentType();

    boolean getIsDisplayCutout();

    int getOffset();

    i getResponsiveState();

    void setCardStyle(boolean z2);

    void setCustomDefaultIndent(int i2);

    void setCustomResponsiveState(i iVar);

    void setFoldPageMargin(int i2);

    void setFullColumn(boolean z2);

    void setGridIndent(boolean z2);

    void setGridIndentListener(d dVar);

    void setIndentStyle(int i2);

    void setIndentType(int i2);

    void setLeftSplitScreen(boolean z2);

    void setOffset(int i2);

    void setSplitScreen(boolean z2);

    void setUseDisplayCutout(boolean z2);
}
