package g;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Insets;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import com.originui.core.utils.a0;
import com.originui.core.utils.m;
import com.originui.core.utils.p;
import com.originui.core.utils.q;
import com.originui.core.utils.r;
import com.originui.core.utils.s;
import com.originui.core.utils.u;
import com.originui.core.utils.v;
import com.originui.widget.responsive.R$styleable;
import java.lang.reflect.Method;
import java.util.ArrayList;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class j implements g, g.e {
    private static Class G = null;
    private static Method H = null;
    private static String I = null;
    protected static boolean J = false;
    protected static int K = -1;
    private boolean A;
    private boolean B;
    private boolean C;
    private int D;
    private j.a E;
    private g F;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private g.a f1666a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f1667b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Context f1668c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f1669d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f1670e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private long f1671f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1672g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1673h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1674i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1675j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1676k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1677l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1678m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private i f1679n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private i f1680o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f1681p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1682q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f1683r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private j.b f1684s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f1685t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f1686u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f1687v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f1688w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f1689x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private int f1690y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private View.OnAttachStateChangeListener f1691z;

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class a implements View.OnAttachStateChangeListener {
        a() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            j.this.H();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            j.this.f1667b.removeOnAttachStateChangeListener(j.this.f1691z);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            j.this.f1667b.requestApplyInsets();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            j.this.f1667b.requestApplyInsets();
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class d implements View.OnApplyWindowInsetsListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private Rect f1695a = new Rect();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private Rect f1696b = new Rect();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private Rect f1697c = new Rect();

        d() {
        }

        @Override // android.view.View.OnApplyWindowInsetsListener
        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("view = " + v.d(view) + "-" + r.g(view) + "@" + view.hashCode() + ";");
            DisplayCutout displayCutout = windowInsets.getDisplayCutout();
            if (displayCutout == null) {
                this.f1695a.setEmpty();
            } else {
                this.f1695a.set(displayCutout.getSafeInsetLeft(), displayCutout.getSafeInsetTop(), displayCutout.getSafeInsetRight(), displayCutout.getSafeInsetBottom());
            }
            stringBuffer.append("cutoutInsetRect  = " + this.f1695a + ";");
            Insets insets = windowInsets.getInsets(WindowInsets.Type.statusBars());
            this.f1696b.set(insets.left, insets.top, insets.right, insets.bottom);
            stringBuffer.append("statusBarInsetRect  = " + this.f1696b + ";");
            Insets insets2 = windowInsets.getInsets(WindowInsets.Type.navigationBars());
            this.f1697c.set(insets2.left, insets2.top, insets2.right, insets2.bottom);
            stringBuffer.append("navigationBarInsetRect  = " + this.f1697c + ";");
            Rect rect = this.f1695a;
            if (rect.left == 0 && rect.right == 0) {
                j.this.f1687v = false;
            } else {
                j.this.f1687v = true;
                j.this.f1683r = this.f1697c.right;
            }
            Rect rect2 = this.f1695a;
            if (rect2.left != 0 || rect2.right != 0 || j.this.f1685t != this.f1695a.left || j.this.f1686u != this.f1695a.right) {
                j.this.P();
                if (j.this.E != null) {
                    j jVar = j.this;
                    jVar.t(jVar.E);
                    j jVar2 = j.this;
                    jVar2.A(-2, jVar2.f1668c.getResources().getConfiguration(), j.this.f1679n, null, true);
                }
            }
            j.this.f1685t = this.f1695a.left;
            j.this.f1686u = this.f1695a.right;
            m.b("responsive_6.0.1.11_VGridDelegate", " onApplyWindowInsets: sb = " + ((Object) stringBuffer));
            return view.onApplyWindowInsets(windowInsets);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
    class e implements Runnable {
        e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            j.this.f1666a.b(j.this.F);
        }
    }

    public j(View view) {
        this.f1666a = new g.a();
        com.originui.core.utils.h.j();
        this.f1671f = -1L;
        this.f1673h = 0;
        this.f1674i = 0;
        this.f1688w = true;
        this.f1669d = false;
        F(view, view.getContext(), null, 0, 0);
    }

    private int B() {
        int customDefaultIndent = getCustomDefaultIndent();
        return customDefaultIndent >= getOffset() ? customDefaultIndent - getOffset() : customDefaultIndent;
    }

    private boolean C(Context context) {
        Object obj;
        if (K != -1) {
            return J;
        }
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null && (obj = bundle.get("originui.gridIndent.useGridIndentDefault")) != null) {
                String string = obj.toString();
                if (!TextUtils.isEmpty(string)) {
                    J = Boolean.parseBoolean(string);
                    m.h("getIsManifestUseIndentDefault : " + J);
                    return J;
                }
            }
            K = 1;
        } catch (Exception e2) {
            if (m.f583b) {
                m.f("responsive_6.0.1.11_VGridDelegate", "getIsManifestUseIndentDefault error = ", e2);
            }
        }
        return J;
    }

    private int D() {
        if (q.p()) {
            return p.b(this.f1668c, I() ? 22.0f : 26.0f);
        }
        return p.b(this.f1668c, I() ? 20.0f : 24.0f);
    }

    private int E(String str) {
        str.getClass();
        return !str.equals("component") ? -1 : -2;
    }

    private void F(View view, Context context, AttributeSet attributeSet, int i2, int i3) {
        this.F = this;
        this.f1684s = new j.b(view, context, attributeSet, i2, i3);
        this.f1667b = view;
        this.f1668c = context;
        if (k.b()) {
            this.A = N();
            this.D = p.b(this.f1667b.getContext(), 8.0f);
            this.B = J();
            G(context, attributeSet, i2, i3);
            a aVar = new a();
            this.f1691z = aVar;
            this.f1667b.addOnAttachStateChangeListener(aVar);
            i iVarL = h.l(a0.b(this.f1667b.getContext()));
            if (com.originui.core.utils.h.g() || (iVarL != null && iVarL.f1655b == 4)) {
                S(this.f1667b);
            }
        }
        com.originui.core.utils.d.j(this.f1667b, true, "GridView");
    }

    private void G(Context context, AttributeSet attributeSet, int i2, int i3) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.GridLayout, i2, i3);
        this.f1669d = typedArrayObtainStyledAttributes.getBoolean(R$styleable.GridLayout_vIsGridIndent, K());
        this.f1682q = typedArrayObtainStyledAttributes.getBoolean(R$styleable.GridLayout_vIsCardStyle, false);
        if (C(this.f1668c) && s.c(context) >= 15.0f && !N()) {
            this.f1672g = p.b(context, this.f1682q ? 20.0f : 24.0f);
        }
        this.f1672g = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.GridLayout_vCustomDefaultIndent, this.f1672g);
        this.f1673h = typedArrayObtainStyledAttributes.getInt(R$styleable.GridLayout_vIndentType, 0);
        this.f1674i = typedArrayObtainStyledAttributes.getInt(R$styleable.GridLayout_vIntentStyle, 0);
        this.f1670e = typedArrayObtainStyledAttributes.getBoolean(R$styleable.GridLayout_vIsSplitScreen, k.d(context));
        this.f1681p = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.GridLayout_vGridIndentOffset, 0);
        this.f1689x = typedArrayObtainStyledAttributes.getBoolean(R$styleable.GridLayout_vIsLeftSplitScreen, false);
        this.f1690y = typedArrayObtainStyledAttributes.getInt(R$styleable.GridLayout_vFoldPageMargin, 0);
        this.C = typedArrayObtainStyledAttributes.getBoolean(R$styleable.GridLayout_vUseFullColumn, false);
        this.f1688w = typedArrayObtainStyledAttributes.getBoolean(R$styleable.GridLayout_vUseDisplayCutout, true);
        if (!this.f1670e) {
            this.f1670e = this.f1689x;
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void H() {
        this.f1675j = this.f1667b.getPaddingLeft();
        this.f1676k = this.f1667b.getPaddingRight();
        if (this.f1667b.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1667b.getLayoutParams();
            this.f1677l = marginLayoutParams.leftMargin;
            this.f1678m = marginLayoutParams.rightMargin;
        }
        if (m.f583b) {
            m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " mDefaultLeftPadding=" + this.f1675j + ",mDefaultLeftMargin=" + this.f1677l);
        }
        this.f1666a.b(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void P() {
        if (!k.b()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "getLayoutGridDelegate is false");
                return;
            }
            return;
        }
        if (!s.e(this.f1667b.getContext())) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " is not Over OS5.0, don't response refresh");
                return;
            }
            return;
        }
        if (C(this.f1668c) && K() && !N()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " isGridIndent: " + K() + ",isSystemIndentSupport:" + N() + " don't respone refresh");
            }
            Q(this.f1667b);
            return;
        }
        if (!(K() && N()) && this.A == N()) {
            return;
        }
        this.A = N();
        if (com.originui.core.utils.h.k() && !K()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " close gridIndent, isSupport=" + N());
            }
            R();
            return;
        }
        if (N()) {
            Q(this.f1667b);
            return;
        }
        if (m.f583b) {
            m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " isSystemIndentSupport change reset");
        }
        R();
    }

    private void S(View view) {
        view.setOnApplyWindowInsetsListener(new d());
    }

    private boolean T() {
        int i2 = this.f1679n.f1654a;
        return ((i2 & 240) == 0 || i2 == 16) ? false : true;
    }

    private boolean U() {
        return this.B && this.C;
    }

    private int s(int i2) {
        if (i2 < getOffset()) {
            return 0;
        }
        m.b("responsive_6.0.1.11_VGridDelegate", "gridIndent=" + i2 + ",set customOffset=" + getOffset());
        return i2 - getOffset();
    }

    private int u(g.b bVar) {
        if (this.f1679n.f1654a != 16 && bVar.i() != 4) {
            return U() ? this.D : D();
        }
        if (this.f1674i == 1) {
            return (this.f1687v && this.f1688w) ? getCalculateBarHeight() : D();
        }
        bVar.m(p.c(D()));
        return D() + bVar.c(bVar.j()) + p.b(this.f1668c, bVar.h());
    }

    private int v(g.b bVar) {
        if (this.f1687v && this.f1688w) {
            int calculateBarHeight = getCalculateBarHeight();
            if (!s.f(this.f1668c)) {
                return calculateBarHeight;
            }
        } else if (!s.f(this.f1668c)) {
            return D();
        }
        return u(bVar);
    }

    private int w(g.b bVar) {
        if (M() || L() || this.f1679n.f1654a == 256 || (bVar.i() != 4 && T())) {
            return U() ? this.D : D();
        }
        bVar.p(4);
        bVar.n(8);
        bVar.o(8);
        bVar.q(920);
        int iY = y();
        bVar.m(iY);
        if (this.f1674i != 0) {
            return p.b(this.f1668c, iY);
        }
        int iB = p.b(this.f1668c, iY);
        int iC = bVar.c(bVar.j());
        return s.f(this.f1667b.getContext()) ? iB + iC + p.b(this.f1668c, bVar.h()) : iB + iC;
    }

    private int x(g.b bVar) {
        int i2;
        if (bVar.i() == 2 || L()) {
            if (U()) {
                return this.D;
            }
            if (L()) {
                return p.b(this.f1668c, this.f1682q ? 20.0f : 24.0f);
            }
            return p.b(this.f1668c, bVar.g());
        }
        if (M() && !s.f(this.f1668c)) {
            return p.b(this.f1668c, this.f1682q ? 20.0f : 30.0f);
        }
        int i3 = 30;
        if (s.f(this.f1667b.getContext()) && this.f1682q) {
            i3 = 24;
        }
        bVar.m(i3);
        if (this.f1674i == 0) {
            int iB = p.b(this.f1668c, i3);
            int iC = bVar.c(bVar.j());
            int iB2 = p.b(this.f1668c, bVar.h());
            if (bVar.i() == 4) {
                i2 = iB + iC;
            } else if (bVar.i() == 8) {
                i2 = iB + (iC * 2);
                iB2 *= 2;
            }
            return i2 + iB2;
        }
        return U() ? this.D : p.b(this.f1668c, i3);
    }

    private int y() {
        if (q.p()) {
            if (s.f(this.f1667b.getContext())) {
                return this.f1682q ? 22 : 26;
            }
            return this.f1690y == 0 ? 22 : 26;
        }
        if (s.f(this.f1667b.getContext())) {
            return this.f1682q ? 20 : 24;
        }
        return this.f1690y == 0 ? 20 : 24;
    }

    public boolean A(int i2, Configuration configuration, i iVar, Object obj, boolean z2) {
        return this.f1684s.c(i2, configuration, iVar, obj, z2);
    }

    public boolean I() {
        return this.f1682q;
    }

    public boolean J() {
        return k.c(this.f1668c);
    }

    public boolean K() {
        return this.f1669d;
    }

    public boolean L() {
        return this.f1689x;
    }

    public boolean M() {
        return this.f1670e;
    }

    public boolean N() {
        if (q.p()) {
            return s.c(this.f1668c) > 6.0f;
        }
        if (s.b() > 15.1d || com.originui.core.utils.h.j() || com.originui.core.utils.h.g()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "isSystemIndentSupport is over os6.0=true");
            }
            return true;
        }
        i iVar = this.f1679n;
        if (iVar != null && iVar.f1655b != 8) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "isSystemIndentSupport is not FOLDABLE_UNFOLD=true");
            }
            return true;
        }
        Float fValueOf = Float.valueOf(1.0f);
        if (I == null) {
            I = "unknown";
            try {
                if (H == null) {
                    Class<?> cls = Class.forName("android.os.SystemProperties");
                    G = cls;
                    H = cls.getDeclaredMethod("get", String.class, String.class);
                }
                I = (String) H.invoke(G, "ro.vivo.os.indent_version", "unknown");
                if (m.f583b) {
                    m.b("responsive_6.0.1.11_VGridDelegate", "sIsSupportIndent init=" + I);
                }
            } catch (Exception e2) {
                m.b("responsive_6.0.1.11_VGridDelegate", "get(<String>), e = " + e2);
                return true;
            }
        }
        if (m.f583b) {
            m.b("responsive_6.0.1.11_VGridDelegate", "isSystemIndentSupport sIsSupportIndent=" + I);
        }
        if (!TextUtils.equals(I, "unknown")) {
            try {
                fValueOf = Float.valueOf(I);
            } catch (NumberFormatException unused) {
            }
        }
        return s.b() >= 15.0f && fValueOf.floatValue() >= 5.1f;
    }

    public j.a O() {
        if (!this.f1687v || !this.f1688w) {
            j.a aVar = this.E;
            if (aVar != null) {
                return aVar;
            }
            return null;
        }
        j.a gridRule = getGridRule();
        j.a aVar2 = new j.a();
        if (gridRule != null) {
            ArrayList arrayListG = gridRule.g();
            int size = arrayListG.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayListG.get(i2);
                i2++;
                k.e eVar = (k.e) obj;
                if (eVar != null) {
                    k.e eVar2 = new k.e(eVar.a().clone(), eVar.c(), eVar.d(), eVar.b());
                    k.a aVarA = eVar2.a();
                    aVarA.l(p.c(getCalculateBarHeight()));
                    aVarA.i(p.c(getCalculateBarHeight()));
                    eVar2.f(aVarA);
                    aVar2.g().add(eVar2);
                }
            }
        }
        aVar2.b(gridRule.f());
        aVar2.k(gridRule.e());
        aVar2.l(gridRule.h());
        aVar2.m(gridRule.i());
        return aVar2;
    }

    public void Q(View view) {
        i iVar;
        if (!k.b()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "getLayoutGridDelegate is false");
                return;
            }
            return;
        }
        int gridIndent = getGridIndent();
        if (m.f583b && (iVar = this.f1679n) != null && iVar.d() != null) {
            m.b("responsive_6.0.1.11_VGridDelegate", view + " refreshIndent gridLayout=" + this.f1679n.d() + ",windowWidth=" + this.f1679n.d().j() + ",isDisplayCutout=" + this.f1687v + ",isSplitScreen=" + M() + ",isLeftSplitScreen=" + L() + ",density=" + Resources.getSystem().getDisplayMetrics().density + ",mIsCardStyle=" + this.f1682q + ",getIndentType=" + getIndentType() + ",mFoldPageMargin=" + this.f1690y + ",mUseFullColumn=" + this.C + "," + this.B);
        }
        if (getIndentType() == 0) {
            view.setPadding(gridIndent, view.getPaddingTop(), gridIndent, view.getPaddingBottom());
            return;
        }
        if (getIndentType() == 1) {
            try {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
                marginLayoutParams.rightMargin = gridIndent;
                marginLayoutParams.leftMargin = gridIndent;
                view.setLayoutParams(marginLayoutParams);
            } catch (Exception e2) {
                m.f("responsive_6.0.1.11_VGridDelegate", "refreshViewIndent error: ", e2);
            }
        }
    }

    public void R() {
        if (getIndentType() == 0) {
            View view = this.f1667b;
            view.setPadding(this.f1675j, view.getPaddingTop(), this.f1676k, this.f1667b.getPaddingBottom());
        } else if (getIndentType() == 1) {
            try {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1667b.getLayoutParams();
                marginLayoutParams.leftMargin = this.f1677l;
                marginLayoutParams.rightMargin = this.f1678m;
                this.f1667b.setLayoutParams(marginLayoutParams);
            } catch (Exception e2) {
                m.f("responsive_6.0.1.11_VGridDelegate", "resetIndent margin error:", e2);
            }
        }
    }

    @Override // g.g
    public void a(Configuration configuration, i iVar, boolean z2) {
        View view;
        i iVar2 = this.f1680o;
        if (iVar2 != null) {
            this.f1679n = iVar2;
        } else {
            this.f1679n = iVar;
        }
        if (this.f1671f == -1) {
            this.f1670e = k.d(this.f1667b.getContext());
        }
        if (m.f583b) {
            m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " onResponsiveLayout " + this.f1679n + ",mCusResponsiveState=" + this.f1680o);
        }
        this.B = J();
        P();
        j.a aVar = this.E;
        z(aVar == null ? -1 : E(aVar.h()), configuration, this.f1679n, null);
        if (getGridRule() == null || (view = this.f1667b) == null) {
            return;
        }
        view.post(new b());
    }

    @Override // g.g
    public void b(i iVar) {
        View view;
        i iVar2 = this.f1680o;
        if (iVar2 != null) {
            this.f1679n = iVar2;
        } else {
            this.f1679n = iVar;
        }
        if (m.f583b) {
            m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " onBindResponsive " + this.f1679n + ",mCusResponsiveState=" + this.f1680o + ",mDefaultGridRule=" + this.E);
        }
        P();
        j.a aVar = this.E;
        z(aVar == null ? -1 : E(aVar.h()), this.f1668c.getResources().getConfiguration(), this.f1679n, null);
        if (getGridRule() == null || (view = this.f1667b) == null) {
            return;
        }
        view.post(new c());
    }

    @Override // g.e
    public g.a getBaseStateManager() {
        return this.f1666a;
    }

    @Override // g.e
    public int getCalculateBarHeight() {
        int iB = p.b(this.f1668c, 11.0f);
        int iB2 = p.b(this.f1668c, 10.0f);
        int i2 = this.f1683r;
        if (!q.p()) {
            iB = iB2;
        }
        return Math.max(i2, iB + u.a(this.f1667b.getContext()));
    }

    @Override // g.e
    public int getCustomDefaultIndent() {
        return this.f1672g;
    }

    @Override // g.e
    public int getFoldPageMargin() {
        return this.f1690y;
    }

    @Override // g.e
    public int getGridIndent() {
        int iB;
        if (!N()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "return default indent ,system don't support indent");
            }
            return B();
        }
        i iVar = this.f1679n;
        if (iVar == null || iVar.d() == null) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "return default indent ,responsiveState error");
            }
            return B();
        }
        g.b bVarD = this.f1679n.d();
        bVarD.k(this.f1682q);
        i iVar2 = this.f1679n;
        int i2 = iVar2.f1655b;
        if (i2 == 8) {
            iB = w(bVarD);
        } else if (i2 != 1 && i2 != 4) {
            iB = x(bVarD);
        } else if ((iVar2.f1654a & 240) != 0) {
            iB = v(bVarD);
        } else {
            iB = U() ? this.D : p.b(this.f1668c, bVarD.g());
        }
        return s(iB);
    }

    @Override // j.c
    public j.a getGridRule() {
        return this.f1684s.getGridRule();
    }

    @Override // g.e
    public int getIndentType() {
        return this.f1673h;
    }

    @Override // g.e
    public boolean getIsDisplayCutout() {
        return this.f1687v;
    }

    @Override // g.e
    public int getOffset() {
        return this.f1681p;
    }

    @Override // g.g
    public Context getResponsiveContext() {
        return this.f1667b.getContext();
    }

    @Override // g.e
    public i getResponsiveState() {
        return this.f1679n;
    }

    @Override // g.g
    public Activity getResponsiveSubject() {
        return a0.b(this.f1667b.getContext());
    }

    public void r(Configuration configuration) {
        if (!k.b()) {
            if (m.f583b) {
                m.b("responsive_6.0.1.11_VGridDelegate", "getLayoutGridDelegate is false");
                return;
            }
            return;
        }
        this.f1666a.a(configuration);
        i iVarL = h.l(a0.b(this.f1667b.getContext()));
        if (iVarL != null) {
            int i2 = iVarL.f1655b;
            if (i2 == 4) {
                S(this.f1667b);
            } else if (i2 == 8) {
                this.f1667b.setOnApplyWindowInsetsListener(null);
            }
        }
    }

    @Override // g.e
    public void setCardStyle(boolean z2) {
        if (this.f1682q != z2) {
            this.f1682q = z2;
            P();
        }
    }

    @Override // g.e
    public void setCustomDefaultIndent(int i2) {
        if (this.f1672g != i2) {
            this.f1672g = i2;
            P();
        }
    }

    @Override // g.e
    public void setCustomResponsiveState(i iVar) {
        this.f1680o = iVar;
        if (m.f583b) {
            m.b("responsive_6.0.1.11_VGridDelegate", this.f1667b + " setCustomResponsiveState " + this.f1680o);
        }
    }

    @Override // g.e
    public void setFoldPageMargin(int i2) {
        this.f1690y = i2;
    }

    @Override // g.e
    public void setFullColumn(boolean z2) {
        if (s.f(this.f1667b.getContext())) {
            this.C = z2;
            P();
        }
    }

    @Override // g.e
    public void setGridIndent(boolean z2) {
        if (this.f1669d != z2) {
            this.f1669d = z2;
            P();
        }
    }

    @Override // g.e
    public void setGridIndentListener(g.d dVar) {
        P();
    }

    @Override // g.e
    public void setIndentStyle(int i2) {
        if (this.f1674i != i2) {
            R();
            this.f1674i = i2;
            P();
        }
    }

    @Override // g.e
    public void setIndentType(int i2) {
        if (this.f1673h != i2) {
            R();
            this.f1673h = i2;
            P();
        }
    }

    @Override // g.e
    public void setLeftSplitScreen(boolean z2) {
        if (this.f1689x != z2) {
            this.f1689x = z2;
            this.f1670e = z2;
            P();
        }
    }

    @Override // g.e
    public void setOffset(int i2) {
        if (this.f1681p != i2) {
            this.f1681p = i2;
            P();
        }
    }

    @Override // g.e
    public void setSplitScreen(boolean z2) {
        if (this.f1670e != z2) {
            this.f1670e = z2;
            this.f1671f = this.f1667b.getId() + 2;
            P();
        }
        if (z2) {
            return;
        }
        this.f1689x = z2;
    }

    @Override // g.e
    public void setUseDisplayCutout(boolean z2) {
        this.f1688w = z2;
        P();
    }

    public void t(j.a aVar) {
        this.E = aVar;
        this.f1684s.a(O());
        this.f1667b.post(new e());
    }

    public boolean z(int i2, Configuration configuration, i iVar, Object obj) {
        return this.f1684s.b(i2, configuration, iVar, obj);
    }

    public j(View view, Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f1666a = new g.a();
        this.f1669d = !com.originui.core.utils.h.j();
        this.f1671f = -1L;
        this.f1673h = 0;
        this.f1674i = 0;
        this.f1688w = true;
        F(view, context, attributeSet, i2, i3);
    }
}
