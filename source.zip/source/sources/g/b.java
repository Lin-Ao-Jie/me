package g;

import com.originui.core.utils.p;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1627a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1628b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1629c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1630d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1631e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f1632f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1633g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1634h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1635i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f1636j;

    public b(int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        this.f1627a = i2;
        this.f1628b = i3;
        this.f1629c = i4;
        this.f1630d = i5;
        this.f1631e = i6;
        this.f1632f = i7;
        this.f1635i = i8;
        b(i2);
        a(this.f1627a);
    }

    public int a(int i2) {
        this.f1627a = i2;
        int iA = i2 - (p.a(this.f1635i) * 2);
        int iA2 = p.a(this.f1631e);
        int i3 = this.f1630d;
        this.f1634h = (iA - (iA2 * (i3 - 1))) / i3;
        l.d("GridLayout", "calculateGridCardItemWidth " + toString());
        return this.f1634h;
    }

    public int b(int i2) {
        this.f1627a = i2;
        int iA = i2 - (p.a(this.f1632f) * 2);
        int iA2 = p.a(this.f1631e);
        int i3 = this.f1630d;
        this.f1633g = (iA - (iA2 * (i3 - 1))) / i3;
        l.d("GridLayout", "windowWidth=" + this.f1627a + ",calculateGridItemWidth " + toString());
        return this.f1633g;
    }

    public int c(int i2) {
        this.f1627a = i2;
        int iA = p.a(this.f1632f);
        if (this.f1636j) {
            iA = p.a(this.f1635i);
        }
        int i3 = this.f1627a - (iA * 2);
        int iA2 = p.a(this.f1631e);
        int i4 = this.f1630d;
        this.f1633g = (i3 - (iA2 * (i4 - 1))) / i4;
        l.d("GridLayout", "windowWidth=" + this.f1627a + ",calculateResponsiveGridWidth " + toString());
        return this.f1633g;
    }

    public int d() {
        return this.f1635i;
    }

    public int e() {
        return this.f1634h;
    }

    public int f() {
        return this.f1636j ? e() : this.f1633g;
    }

    public int g() {
        return this.f1636j ? d() : this.f1632f;
    }

    public int h() {
        return this.f1631e;
    }

    public int i() {
        return this.f1628b;
    }

    public int j() {
        return this.f1627a;
    }

    public b k(boolean z2) {
        this.f1636j = z2;
        return this;
    }

    public b l(int i2) {
        this.f1635i = i2;
        return this;
    }

    public b m(int i2) {
        if (this.f1636j) {
            return l(i2);
        }
        this.f1632f = i2;
        return this;
    }

    public b n(int i2) {
        this.f1631e = i2;
        return this;
    }

    public b o(int i2) {
        this.f1630d = i2;
        return this;
    }

    public b p(int i2) {
        this.f1628b = i2;
        return this;
    }

    public b q(int i2) {
        this.f1629c = i2;
        return this;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("GridLayout{");
        stringBuffer.append("layout=");
        stringBuffer.append(this.f1628b);
        stringBuffer.append(", width=");
        stringBuffer.append(this.f1629c);
        stringBuffer.append(", sum=");
        stringBuffer.append(this.f1630d);
        stringBuffer.append(", space=");
        stringBuffer.append(this.f1631e);
        stringBuffer.append(", margins=");
        stringBuffer.append(this.f1632f);
        stringBuffer.append(", cardMargins=");
        stringBuffer.append(this.f1635i);
        stringBuffer.append(", itemWidth=");
        stringBuffer.append(this.f1633g);
        stringBuffer.append(", cardItemWidth=");
        stringBuffer.append(this.f1634h);
        stringBuffer.append(", card=");
        stringBuffer.append(this.f1636j);
        stringBuffer.append('}');
        return stringBuffer.toString();
    }
}
