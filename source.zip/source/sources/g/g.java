package g;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;

/* JADX INFO: compiled from: go/retraceme 8dbf1ac7b411f4236c2f8433132a2fd972376a4af057a018039416efa59c2d31 */
/* JADX INFO: loaded from: classes.dex */
public interface g {
    void a(Configuration configuration, i iVar, boolean z2);

    void b(i iVar);

    default Context getResponsiveContext() {
        return null;
    }

    Activity getResponsiveSubject();

    default void setActivity(Activity activity) {
    }
}
